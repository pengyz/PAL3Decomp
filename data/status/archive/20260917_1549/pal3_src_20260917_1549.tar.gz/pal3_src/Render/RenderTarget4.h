#pragma once
// Auto-generated: RenderTarget4
#include "pal3/ida_types.h"

class RenderTarget4 {
public:
    _BYTE _tail_000[4]; // +0x0
    // total size: 0x4 (4)

    // Scalar-wrapper: ctors for IDA (Cls)int casts (no init code)
    RenderTarget4() {}
    RenderTarget4(int v) { *(int*)this = v; }

};
