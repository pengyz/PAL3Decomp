#include "pal3/ida_defs.h"
#include "globals.h"
#include "pal3/pal3_constants.h"
#include "Script/PalScriptMgr.h"
#include "Role/Actor.h"
#include "Misc/Array.h"
#include "Misc/CCBEditor.h"
#include "Combat/CCBStage.h"
#include "Combat/CCBStageScene.h"
#include "Misc/CG_Entry.h"
#include "Misc/CG_Scene.h"
#include "Render/CScreenMode.h"
#include "Scene/CameraCtrl.h"
#include "GameBase/GRPinput.h"
#include "Misc/GeomNode.h"
#include "GameBase/InputSystem.h"
#include "Role/Object3D.h"
#include "Misc/OpenBaseFile.h"
#include "Misc/OpenNULLFile.h"
#include "Misc/OpenSceneFile.h"
#include "GameBase/PAL3.h"
#include "Data/PAL_GDB.h"
#include "Script/PalScript.h"
#include "Misc/PathObj.h"
#include "Misc/PtrArray.h"
#include "Role/Role.h"
#include "Misc/RoleCameraCtrl.h"
#include "Role/RoleSystem.h"
#include "Scene/Scene.h"
#include "Scene/SceneMgr.h"
#include "Misc/ScriptSystemData.h"
#include "Misc/ScriptVM.h"
#include "Misc/String.h"
#include "UI/UIListBox.h"
#include "UI/UIScene.h"
#include "Misc/_Console.h"
#include "Misc/scAsmDecoder.h"
#include "Misc/scSCEFile.h"
#include "free_functions.h"

// Forward declarations for unnamed functions

// 0x004100A0
int PalScriptMgr::RunScript(int nVal, int nVal2, int nVal3)
{
  int result; // eax
  unsigned int *v4; // edx
  scAsmDecoder *v5; // edi
  int v6; // ebx
  scAsmDecoder *v7; // esi
  unsigned int v8; // ecx
  int v9; // eax
  GRPinput *v10; // eax
  GRPinput *v11; // esi
  CScreenMode *Instance; // eax
  const void *v13; // [esp-0x8] [ebp-0x13C]
  void *pData[6]; // [esp+0x10] [ebp-0x124]
  char Buffer[256]; // [esp+0x28] [ebp-0x10C] BYREF
  int v16; // [esp+0x130] [ebp-0x4]

  v4 = (unsigned int *)&g_RoleSlotBuf.m_partyActor.m_dwMatMsg[2];
  v5 = g_SceneMgr.m_nCurrentRoleSlot;
  v6 = 0;
  v7 = 0;
  do
  {
    LOBYTE(result) = *((_BYTE *)&((RoleSystem *)&stru_C059A0)->m_nRetryCount + (_DWORD)v7);
    if ( (_BYTE)result )
    {
      LOBYTE(result) = nVal3;
      if ( !(_BYTE)nVal3 || v7 == v5 )
      {
        v8 = (unsigned long)*v4;
        v9 = (unsigned long)(*v4 - nVal);
        if ( v9 < 1 )
          v9 = 1;
        *v4 = v9;
        result = v9 - v8;
        if ( v7 == v5 )
          v6 = result;
      }
    }
    v4 += 352;
    v7 = (scAsmDecoder *)((char *)v7 + 1);
  }
  while ( (int)v4 < (int)&((RoleSystem *)&stru_C059A0)->m_teamSlotOverlay.m_teamSlots[174] );
  if ( v6 < 0 )
  {
    sprintf(Buffer, &dir[20], v6);
    v10 = (GRPinput *)operator new(0x24u);
    pData[5] = v10;
    v16 = 0;
    if ( v10 )
      v11 = (((GRPinput *)v10))->GRPinput::SetMousePos();
    else
      v11 = 0;
    v16 = -1;
    (((GRPinput *)v11))->GRPinput::SetJoystickPos(Buffer, 0);
    (((PtrArray *)&g_pScriptObjArray))->PtrArray::SetAt((int)g_pScriptEventObj, (int)v11);
    LOBYTE(result) = nVal2;
    if ( (_BYTE)nVal2 )
    {
      pData[0] = "we015";
      pData[1] = "we016";
      pData[2] = "we017";
      pData[3] = "we018";
      pData[4] = "we019";
      v13 = pData[(_DWORD)g_SceneMgr.m_nCurrentRoleSlot];
      Instance = (CScreenMode *)CScreenMode::GetInstance();
      (((CScreenMode *)Instance))->CScreenMode::AudioSetPosition(v13, 1);
    }
  }
  return result;
}

// 0x00410920
int * PalScriptMgr::LoadYlfScript()
{
  const char *v1; // eax

  int *result; // eax
  char Buffer[128]; // [esp+0x0] [ebp-0x80] BYREF

  v1 = (const char *)UISceneUpdate();
  sprintf(Buffer, "_ylf_%s_%s", v1, v1 + 32);
  PtrArray::IsArrayReady();
  this->PalScriptMgr::Destroy();
  return result;
}

// 0x0041BDE0
int * PalScriptMgr::Get_result()
{
  int *result; // eax

  result = (int *)this;
  *(_DWORD *)&this->m_bGetSceneScript = 0;
  this->m_script.m_pData = 0;
  this->m_script.capacity = 0;
  this->m_script.m_nSize = 0;
  return result;
}

// 0x00420B40
void PalScriptMgr::CheckTileScript(RoleSystem *pRole, float fVal, char bExecute)
{
  int m_nState; // esi
  __int64 v6; // rax
  unsigned __int8 Tile; // bl
  char *v8; // eax
  char *v9; // eax
  char v10; // al
  int nX; // [esp+0xC] [ebp-0x8]

  if ( pRole )
  {
    m_nState = pRole->m_partyActor.m_nState;
    nX = (__int64)((*(float *)(&pRole[1].m_teamSlotsB.combat.m_bCommandEdited + 146)
                  - *((float *)&this[51].m_nField_1D94 + 41 * m_nState + 55))
                 / g_fTileScale);
    v6 = (__int64)((*(float *)(&pRole[1].m_teamSlotsB.combat.m_bCommandEdited + 154)
                  - *((float *)&this[51].m_nField_1D94 + 41 * m_nState + 57))
                 / g_fTileScale);
    if ( nX < 0
      || nX >= *(&this[51].m_nField_1D94 + 41 * m_nState + 61)
      || (int)v6 < 0
      || (int)v6 >= *(&this[51].m_nField_1D94 + 41 * m_nState + 62) )
    {
      Tile = -1;
    }
    else
    {
      Tile = (((RoleSystem *)(&this->m_RoleAnimData + 5 * m_nState + 1)))->RoleSystem::GetTile(nX, v6);
    }
    if ( bExecute )
    {
      if ( Tile != 0xFF )
      {
        v8 = (char *)(&this->m_bGetSceneScript + 896 * Tile);
        if ( v8[397] )
        {
          if ( v8[468] == 38 )
            (((ScriptVM *)(v8 + 224)))->ScriptVM::ExecuteBlock();
        }
      }
    }
    else
    {
      if ( Tile != 0xFF )
      {
        v9 = (char *)(&this->m_bGetSceneScript + 896 * Tile);
        if ( v9[397] )
        {
          (((ScriptVM *)(v9 + 224)))->ScriptVM::ExecuteBlock();
          (((RoleSystem *)pRole))->RoleSystem::GetActiveRole();
        }
      }
      v10 = *((_BYTE *)&this[51].m_nField_1D94 + 464);
      if ( v10 != Tile && v10 != -1 )
        (((PalScriptMgr *)(&this->m_fAngle
                                                    + 224 * *((unsigned __int8 *)&this[51].m_nField_1D94 + 464))))->PalScriptMgr::GetScriptState();
      *((_BYTE *)&this[51].m_nField_1D94 + 464) = Tile;
    }
  }
}

// 0x00429D80
int PalScriptMgr::InitControlBlock()
{
  // [AUTO-COMMENTED] (gbMatrix4 *)&this->m_script.capacity->gbMatrix4();
  memset(this, 0, 0x54u);
  return (int)this;
}

// 0x00429DB0
void PalScriptMgr::BuildCmdTransform(gbMatrix4 *pMatrix)
{
  char m_nCmdType; // al
  int m_nTodo_058; // eax
  int *p_m_nTodo_060; // esi
  double v5; // st6
  float v6; // [esp+0x4] [ebp-0x18]
  float v7; // [esp+0x8] [ebp-0x14]
  float v8; // [esp+0x8] [ebp-0x14]
  float v9; // [esp+0xC] [ebp-0x10]
  float v10; // [esp+0xC] [ebp-0x10]
  struct gbVec3D v11; // [esp+0x10] [ebp-0xC] BYREF

  m_nCmdType = this->m_nCmdType;
  if ( m_nCmdType == 20 || m_nCmdType == 27 )
  {
    v6 = this->m_fPosBX - this->m_fPosAX;
    v7 = this->m_fPosBY - this->m_fPosAY;
    v5 = this->m_fPosBZ - this->m_fPosAZ;
    v11.x = v6;
    v11.y = v7;
    v9 = v5;
    *(float *)&pMatrix[1] = v6;
    v11.z = v9;
    pMatrix[1].xy = v7;
    pMatrix[1].xz = v9;
    v8 = this->m_fPosBY + this->m_fPosAY;
    v10 = this->m_fPosBZ + this->m_fPosAZ;
    v11.x = (this->m_fPosAX + this->m_fPosBX) * 0.5;
    v11.y = v8 * 0.5;
    v11.z = v10 * 0.5;
    (((gbMatrix4 *)pMatrix))->gbMatrix4::LoadIdentity();
    (((gbMatrix4 *)pMatrix))->gbMatrix4::RightTranslate(*v11);
  }
  else
  {
    m_nTodo_058 = this->m_nTodo_058;
    if ( m_nTodo_058 )
    {
      if ( m_nTodo_058 == 2 || m_nTodo_058 == 3 )
      {
        p_m_nTodo_060 = (int *)&this->m_nTodo_060;
        (((gbMatrix4 *)pMatrix))->gbMatrix4::operator=(&this->m_nTodo_060);
        *(_DWORD *)&pMatrix[1] = (unsigned long)p_m_nTodo_060[16];
        LODWORD(pMatrix[1].xy) = (unsigned long)p_m_nTodo_060[17];
        LODWORD(pMatrix[1].xz) = (unsigned long)p_m_nTodo_060[18];
      }
      else
      {
        (*(void ( **)(char *, gbMatrix4 *))(*(_DWORD *)this->m_pExecSystem + 56))(
          this->m_pExecSystem,
          pMatrix);
      }
    }
  }
}

// 0x00429F90
void PalScriptMgr::BuildFullTransform(gbMatrix4 *pMatrix, gbVec3D *pPos)
{
  gbMatrix4 v4; // [esp+0x14] [ebp-0x40] BYREF

  this->PalScriptMgr::BuildCmdTransform(pMatrix);
  (((gbMatrix4 *)&v4))->gbMatrix4::LoadIdentity();
  gbMatrix4::SetAxisAngle(v4,  0,  this->m_nMatrixData);
  (((gbMatrix4 *)pMatrix))->gbMatrix4::RightMultiply(v4);
  gbMatrix4::SetAxisAngle(v4,  1,  LODWORD(this->m_fAngle));
  (((gbMatrix4 *)pMatrix))->gbMatrix4::RightMultiply(v4);
  (((gbMatrix4 *)pMatrix))->gbMatrix4::RightTranslate(*pPos);
}

// 0x0042AAE0
BOOL PalScriptMgr::CheckTileCollision(int *pnVal, int nVal, gbVec3D *p)
{
  GRPinput *RolePtr; // eax
  BOOL result; // eax
  int v7; // edx
  LONG left; // ecx
  Object3D *v9; // ebx
  int v10; // edi
  LONG v11; // eax
  int i; // ebx
  unsigned __int8 Tile; // [esp+0x10] [ebp-0x9C]
  struct gbOBBox v14; // [esp+0x14] [ebp-0x98] BYREF
  gbOBBox pMatrix; // [esp+0x60] [ebp-0x4C] BYREF

  RolePtr = (GRPinput *)(((RoleSystem *)this->m_pSceneMgr->m_rect.left))->RoleSystem::GetRolePtr((unsigned __int8)this->m_bExecuteOpcode);
  result = (((GRPinput *)RolePtr))->GRPinput::GetJoystickFreePos((int)pnVal, nVal);
  if ( result )
  {
    Tile = (((RoleSystem *)this->m_pSceneMgr))->RoleSystem::GetTile((int)pnVal, nVal);
    if ( Tile != 0xFF )
    {
      v7 = 896 * Tile;
      left = this->m_pSceneMgr->m_rect.left;
      v9 = (Object3D *)(v7 + left + 224);
      if ( !*(_BYTE *)(v7 + left + 433) && (*(_BYTE *)(v7 + left + 432) & 2) != 0 )
      {
        // [AUTO-COMMENTED] (gbMatrix4 *)&pMatrix->gbMatrix4();
        // [AUTO-COMMENTED] (gbMatrix4 *)&v14->gbMatrix4();
        this->PalScriptMgr::BuildFullTransform((gbMatrix4 *)&pMatrix, p);
        (((Object3D *)v9))->Object3D::SetTransform((gbMatrix4 *)&v14);
        if ( gbOBBox::IsColOBB(*pMatrix,   &v14) )
          return 0;
      }
    }
    if ( this->m_nCmdType == 11 )
    {
      // [AUTO-COMMENTED] (gbMatrix4 *)&v14->gbMatrix4();
      // [AUTO-COMMENTED] (gbMatrix4 *)&pMatrix->gbMatrix4();
      this->PalScriptMgr::BuildFullTransform((gbMatrix4 *)&v14, p);
      v10 = 0;
      v11 = this->m_pSceneMgr->m_rect.left;
      if ( *(int *)(v11 + 220) > 0 )
      {
        for ( i = 0; ; i += 896 )
        {
          if ( v10 != (unsigned __int8)this->m_bRoleCmd && *(_BYTE *)(i + v11 + 468) == 11 )
          {
            (((Object3D *)(i + v11 + 224)))->Object3D::SetTransform((gbMatrix4 *)&pMatrix);
            if ( gbOBBox::IsColOBB(*v14,   &pMatrix) )
              break;
          }
          ++v10;
          v11 = this->m_pSceneMgr->m_rect.left;
          if ( v10 >= *(_DWORD *)(v11 + 220) )
            return 1;
        }
        return 0;
      }
    }
    return 1;
  }
  return result;
}

// 0x0042AC80
int PalScriptMgr::CmdUpdateRolePath(float *pfVal, float *pfVal2)
{
  int result; // eax
  int RolePtr; // esi

  result = (int)this->m_pSceneMgr;
  if ( result )
  {
    RolePtr = (*(RoleSystem **)(result + 16))->RoleSystem::GetRolePtr((unsigned __int8)this->m_bExecuteOpcode);
    return (((RoleSystem *)this->m_pSceneMgr->m_rect.left))->RoleSystem::UpdatePathProgress(this->m_bRoleCmd, (unsigned __int8)this->m_bExecuteOpcode, (char *)(__int64)((*pfVal - *(float *)(RolePtr + 128)) / g_ScriptSystemData.m_g_fTimeDelta), (__int64)((pfVal[2] - *(float *)(RolePtr + 136)) / g_ScriptSystemData.m_g_fTimeDelta), (char *)(__int64)((*pfVal2 - *(float *)(RolePtr + 128)) / g_ScriptSystemData.m_g_fTimeDelta), (__int64)((pfVal2[2] - *(float *)(RolePtr + 136)) / g_ScriptSystemData.m_g_fTimeDelta));
  }
  return result;
}

// 0x0042AF80
char PalScriptMgr::GetScriptState()
{
  char result; // al

  result = this->m_nCmdType;
  if ( result == 9 )
  {
    this->m_bBigMapState = 0;
  }
  else if ( result == 38 )
  {
    this->m_nTodo_054 = 0;
  }
  return result;
}

// 0x0042AFA0
int PalScriptMgr::SaveExecutionState()
{
  int v1; // edi
  int RolePtr; // ebp
  __int64 v4; // rax
  int v5; // ecx
  char *v6; // eax
  double v7; // st7
  int v8; // edx
  float v9; // ecx
  float v10; // edx
  int v11; // ecx
  int v12; // eax
  char *v13; // edx
  int m_nCmdParam0; // ecx
  RoleSystem *m_pSceneMgr; // edx
  int v16; // eax
  PalScriptMgr *v17; // edi
  PalScriptMgr *v18; // eax
  PalScriptMgr *v19; // ebx
  int result; // eax
  int v21; // [esp-0x4] [ebp-0x28]
  int v22; // [esp+0x0] [ebp-0x24]
  float v23; // [esp+0x10] [ebp-0x14] BYREF
  char v24; // [esp+0x14] [ebp-0x10]
  char v25; // [esp+0x15] [ebp-0xF]
  float v26; // [esp+0x18] [ebp-0xC]
  int pPoint; // [esp+0x1C] [ebp-0x8] BYREF
  int v28; // [esp+0x20] [ebp-0x4]

  v1 = ((RoleSystem *)&stru_C10DF0)->m_teamSlotOverlay.m_teamSlots[154];
  (((RoleSystem *)this))->RoleSystem::ProcessAction() /* [ROWTABLE] */;
  RolePtr = (((RoleSystem *)this->m_pSceneMgr->m_rect.left))->RoleSystem::GetRolePtr(*(_DWORD *)(v1 + 628));
  v4 = (__int64)((*(float *)(v1 + 12) - *(float *)(RolePtr + 136)) / g_ScriptSystemData.m_g_fTimeDelta);
  pPoint = (__int64)((*(float *)(v1 + 4) - *(float *)(RolePtr + 128)) / g_ScriptSystemData.m_g_fTimeDelta);
  v28 = v4;
  if ( PointInRect((int *)&this->m_pCmdBuffer, &pPoint) )
  {
    switch ( this->m_nExecState )
    {
      case 0:
        v5 = v28;
        v6 = this->m_pCmdBuffer - 1;
        pPoint = (int)v6;
        goto LABEL_9;
      case 1:
        v5 = v28;
        v6 = (char *)(this->m_nLoopCountB + 1);
        pPoint = (int)v6;
        goto LABEL_9;
      case 2:
        v5 = this->m_nLoopCountA - 1;
        v28 = v5;
        goto LABEL_8;
      case 3:
        v5 = this->m_nLoopCountC + 1;
        v28 = v5;
        goto LABEL_8;
      default:
        v5 = v28;
LABEL_8:
        v6 = (char *)pPoint;
LABEL_9:
        v7 = 0.0;
        v23 = ((double)pPoint + 0.5) * g_ScriptSystemData.m_g_fTimeDelta + *(float *)(RolePtr + 128);
        v26 = ((double)v28 + 0.5) * g_ScriptSystemData.m_g_fTimeDelta + *(float *)(RolePtr + 136);
        if ( (int)v6 >= 0 )
        {
          v8 = *(_DWORD *)(RolePtr + 152);
          if ( (int)v6 < v8 && v5 >= 0 && v5 < *(_DWORD *)(RolePtr + 156) )
            v7 = *(float *)(*(_DWORD *)(RolePtr + 160) + 8 * (_DWORD)&v6[v5 * v8]);
        }
        v9 = v23;
        v10 = v26;
        *(float *)(v1 + 8) = v7;
        *(float *)(v1 + 4) = v9;
        *(float *)(v1 + 12) = v10;
        *(_DWORD *)(v1 + 8) = 0;
        (((RoleSystem *)v1))->RoleSystem::SetMoveSpeed(0.0, 0, v22);
        break;
    }
  }
  this->m_bBigMapState = 0;
  (((RoleSystem *)v1))->RoleSystem::Notify();
  if ( this->m_nCmdValue == 2 && this->PalScriptMgr::IsScriptReady() )
  {
    v11 = *(&this->m_bBigMapState + 1);
    v24 = -1;
    v12 = this->m_nExecState - 2;
    v13 = (char *)&v23 + v11;
    m_nCmdParam0 = (unsigned __int16)this->m_nCmdParam0;
    v23 = 9.3672217e-38;
    v25 = 0;
    LOBYTE(v12) = (unsigned long)v13[3 * v12];
    m_pSceneMgr = (RoleSystem *)this->m_pSceneMgr;
    *(&this->m_bBigMapState + 1) = v12;
    (((PalScript *)m_pSceneMgr->m_rect.left))->PalScript::SetAction(m_nCmdParam0);
    v17 = (PalScriptMgr *)v16;
    LOWORD(v16) = this->m_nCmdParam1;
    (((PalScript *)this->m_pSceneMgr->m_rect.left))->PalScript::SetAction(v16);
    v19 = (PalScriptMgr *)v18;
    switch ( *(&this->m_bBigMapState + 1) )
    {
      case 0:
        (((PalScriptMgr *)v17))->PalScriptMgr::SetPauseState(0);
        v21 = 0;
        goto LABEL_23;
      case 1:
        (((PalScriptMgr *)v17))->PalScriptMgr::SetPauseState(1);
        break;
      case 2:
        v21 = 1;
LABEL_23:
        (((PalScriptMgr *)v19))->PalScriptMgr::SetPauseState(v21);
        break;
    }
  }
  this->m_nExecuteBlock = LODWORD(this->m_fCamX);
  result = LODWORD(this->m_fCamY);
  this->m_nSavedDataA = result;
  this->m_nSavedDataB = LODWORD(this->m_fCamZ);
  return result;
}

// 0x0042B350
void PalScriptMgr::ProcessRoleLoading()
{
  Actor *SaveDataManager; // eax
  int v3; // eax
  double m_nCmdValue; // st7
  int v5; // eax
  int v6; // eax
  int v7; // edi
  char v8; // cl
  RoleSystem *v9; // eax
  const char *v10; // [esp-0xC] [ebp-0x14]
  int m_bScriptByte; // [esp-0x4] [ebp-0xC]
  int m_bExecuteOpcode; // [esp-0x4] [ebp-0xC]

  if ( this->m_nCmdType == 22 )
  {
    if ( *((_BYTE *)&this->m_nScriptID + 2) )
    {
      if ( this->m_bScriptByte != 0xFF )
      {
        m_bScriptByte = (unsigned __int8)this->m_bScriptByte;
        v10 = (const char *)UISceneUpdate();
        SaveDataManager = (Actor *)GetSaveDataManager();
        v3 = (((Actor *)SaveDataManager))->Actor::AddActionByName(v10, (const char *)&this->m_nScriptID + 2, m_bScriptByte);
        if ( v3 )
        {
          if ( *(_BYTE *)(v3 + 3) )
          {
            m_nCmdValue = (double)this->m_nCmdValue;
            v5 = *(_DWORD *)&this->m_nCmdParam0;
            this->m_bOpcodeFlag = 1;
            this->m_fCamY = m_nCmdValue;
            this->m_bBigMapState = 2;
            if ( v5 )
              (((RoleSystem *)this))->RoleSystem::UpdateStateMode() /* [ROWTABLE] */;
          }
        }
      }
    }
    (((PalScript *)this->m_pSceneMgr->m_rect.left))->PalScript::SetAction(this->m_nCmdParam1);
    v7 = v6;
    if ( v6 )
    {
      v8 = *(_BYTE *)(v6 + 246);
      *(float *)(v6 + 44) = this->m_fCamY;
      if ( this->m_bExecuteOpcode != v8 )
      {
        (((RoleSystem *)v6))->RoleSystem::ProcessAction();
        m_bExecuteOpcode = (unsigned __int8)this->m_bExecuteOpcode;
        v9 = (RoleSystem *)UISceneUpdate();
        *(_DWORD *)(v7 + 796) = (unsigned long)(((RoleSystem *)v9))->RoleSystem::NotifyPathEnd(m_bExecuteOpcode);
        (((RoleSystem *)v7))->RoleSystem::ProcessAction();
        *(_BYTE *)(v7 + 246) = this->m_bExecuteOpcode;
      }
      if ( this->m_nSavedPosX )
        *(float *)(((RoleSystem *)&stru_C10DF0)->m_teamSlotOverlay.m_teamSlots[154] + 164) = this->m_fCamY;
    }
  }
}

// 0x0042B450
BOOL PalScriptMgr::IsPosInBounds(float *pfPos)
{
  int RolePtr; // esi
  int v5; // ebx
  double v6; // st7
  __int64 v7; // rax

  if ( !pfPos )
    return 0;
  if ( (unsigned __int8)this->m_bExecuteOpcode != *((_DWORD *)pfPos + 157) )
    return 0;
  RolePtr = (((RoleSystem *)this->m_pSceneMgr->m_rect.left))->RoleSystem::GetRolePtr((unsigned __int8)this->m_bExecuteOpcode);
  v5 = (__int64)((pfPos[1] - *(float *)(RolePtr + 128)) / g_ScriptSystemData.m_g_fTimeDelta);
  v6 = (pfPos[3] - *(float *)(RolePtr + 136)) / g_ScriptSystemData.m_g_fTimeDelta;
  v7 = (__int64)v6;
  return v5 >= 0
      && v5 < *(_DWORD *)(RolePtr + 152)
      && (int)v7 >= 0
      && (int)v7 < *(_DWORD *)(RolePtr + 156)
      && (((RoleSystem *)this->m_pSceneMgr))->RoleSystem::GetTile(v5, (__int64)v6) == this->m_bRoleCmd;
}

// 0x0042B5B0
double PalScriptMgr::UpdateScriptRoles(double thisa, int nVal, int nVal2)
{
  char m_nCmdType; // al
  const char *v6; // eax
  char v7; // al
  char *v8; // eax
  int v9; // eax
  int m_nCmdValue; // ecx
  int m_nCmdParam2; // edx
  double result; // st7
  float v13; // eax
  char *v14; // edi
  int v15; // ebx
  int *p_m_RoleAnimData; // eax
  int *p_m_nCmdValue; // eax
  int v18; // ecx
  _BYTE *v19; // eax
  float *v20; // ecx
  float *p_m_fPrevPosY; // eax
  float v22; // edx
  signed __int16 *v23; // eax
  _BYTE *p_m_bRunCommand; // eax
  int *v25; // eax
  int v26; // ecx
  int m_Sub_0034; // eax
  int m_nScriptDepth; // eax
  float v29; // ecx
  int *v30; // eax
  float v31; // eax
  int v32; // eax
  int v33; // edx
  int v34; // edi
  LONG left; // ebx
  PalScriptMgr *v36; // ebp
  RoleSystem *m_pSceneMgr; // ecx
  int v38; // [esp+0x8] [ebp-0x1BC]
  OpenBaseFile v39; // [esp+0xC] [ebp-0x1B8] BYREF
  int nY; // [esp+0x10] [ebp-0x1B4]
  int p_DWORD; // [esp+0x14] [ebp-0x1B0] BYREF
  float m_fCamY; // [esp+0x18] [ebp-0x1AC]
  float m_fCamZ; // [esp+0x1C] [ebp-0x1A8]
  gbMatrix4 v44; // [esp+0x20] [ebp-0x1A4] BYREF
  float v45; // [esp+0x64] [ebp-0x160]
  gbMatrix4 pMatrix; // [esp+0x6C] [ebp-0x158] BYREF
  float v47; // [esp+B0h] [ebp-0x114]
  char Buffer[256]; // [esp+B8h] [ebp-0x10C] BYREF
  int v49; // [esp+0x1C0] [ebp-0x4]

  m_nCmdType = this->m_nCmdType;
  if ( m_nCmdType != 23 || *(_DWORD *)&this->m_nCmdParam1 != 2 )
  {
    if ( m_nCmdType != 11 || !this->m_pScriptObj && (v6 = (const char *)UISceneUpdate(), _strcmpi(v6, "m02")) )
    {
      v7 = this->m_nCmdType;
      if ( v7 != 11 || this->m_nCmdValue > 0 )
      {
        if ( v7 == 40 && *(_BYTE *)(LODWORD(thisa) + 74) != this->m_bExecuteOpcode )
        {
          (((RoleSystem *)this))->RoleSystem::ProcessAction() /* [ROWTABLE] */;
          v8 = (((RoleSystem *)this->m_pSceneMgr->m_rect.left))->RoleSystem::NotifyPathEnd(*(unsigned __int8 *)(LODWORD(thisa) + 74));
          this->m_pSceneMgr = (RoleSystem *)v8;
          (*((RoleSystem **)v8 + 4))->RoleSystem::GetRolePtr(*(unsigned __int8 *)(LODWORD(thisa) + 74));
          v9 = *(unsigned __int8 *)(LODWORD(thisa) + 74);
          if ( *(_BYTE *)(LODWORD(thisa) + 74) )
          {
            m_nCmdValue = *(_DWORD *)&this->m_nCmdParam1;
            m_nCmdParam2 = this->m_nCmdParam2;
          }
          else
          {
            m_nCmdValue = this->m_nCmdValue;
            m_nCmdParam2 = *(_DWORD *)&this->m_nCmdParam0;
          }
          nY = m_nCmdParam2;
          p_DWORD = LODWORD(this->m_fCamX);
          m_fCamY = this->m_fCamY;
          m_fCamZ = this->m_fCamZ;
          m_fCamY = (((Scene *)this->m_pSceneMgr->m_rect.left))->Scene::GetTileHeight(v9, m_nCmdValue, m_nCmdParam2, 0);
          this->PalScriptMgr::BuildCmdTransform(&pMatrix);
          result = v47 + m_fCamY;
          v13 = m_fCamZ;
          LODWORD(this->m_fCamX) = p_DWORD;
          this->m_fCamZ = v13;
          this->m_fCamY = result;
          this->m_bExecuteOpcode = *(_BYTE *)(LODWORD(thisa) + 74);
          (((RoleSystem *)this))->RoleSystem::ProcessAction() /* [ROWTABLE] */;
        }
        v14 = (char *)&this->m_szScriptFile[4];
        v15 = LODWORD(thisa) - (_DWORD)&this->m_szScriptFile[4];
        *(_DWORD *)&this->m_szScriptFile[4] = *(_DWORD *)LODWORD(thisa);
        p_m_RoleAnimData = (int *)&this->m_RoleAnimData;
        do
        {
          *(_BYTE *)p_m_RoleAnimData = *((_BYTE *)p_m_RoleAnimData + v15);
          p_m_RoleAnimData = (int *)((char *)p_m_RoleAnimData + 1);
        }
        while ( (unsigned int)p_m_RoleAnimData - 4 - (unsigned int)&this->m_szScriptFile[4] < 0x20 );
        this->m_pSavedIndex = *(_BYTE *)(LODWORD(thisa) + 36);
        this->m_bOpcodeFlag = *(_BYTE *)(LODWORD(thisa) + 37);
        this->m_nExecuteBlock = *(_DWORD *)(LODWORD(thisa) + 40);
        this->m_nSavedDataA = *(_DWORD *)(LODWORD(thisa) + 44);
        this->m_nSavedDataB = *(_DWORD *)(LODWORD(thisa) + 48);
        this->m_fAngle = *(float *)(LODWORD(thisa) + 52);
        this->m_nExecRangeA = *(_DWORD *)(LODWORD(thisa) + 56);
        this->m_nExecRangeB = *(_DWORD *)(LODWORD(thisa) + 60);
        this->m_nExecRangeC = *(_DWORD *)(LODWORD(thisa) + 64);
        this->m_nExecRangeD = *(_DWORD *)(LODWORD(thisa) + 68);
        this->m_nCmdType = *(_BYTE *)(LODWORD(thisa) + 72);
        this->m_nTodo_0F5 = *(_BYTE *)(LODWORD(thisa) + 73);
        this->m_bExecuteOpcode = *(_BYTE *)(LODWORD(thisa) + 74);
        this->m_nTodo_0F7 = *(_BYTE *)(LODWORD(thisa) + 75);
        p_m_nCmdValue = (int *)&this->m_nCmdValue;
        v18 = 6;
        do
        {
          *p_m_nCmdValue = *(int *)((char *)p_m_nCmdValue + v15);
          ++p_m_nCmdValue;
          --v18;
        }
        while ( v18 );
        this->m_nTodo_110 = *(_BYTE *)(LODWORD(thisa) + 100);
        this->m_nTodo_112 = *(_WORD *)(LODWORD(thisa) + 102);
        this->m_Actor = *(_WORD *)(LODWORD(thisa) + 104);
        this->m_nTodo_116 = *(_WORD *)(LODWORD(thisa) + 106);
        this->m_nField_0118 = *(_WORD *)(LODWORD(thisa) + 108);
        this->m_nTodo_11A = *(_BYTE *)(LODWORD(thisa) + 110);
        v19 = (_BYTE *)(&this->m_nTodo_11A + 1);
        do
        {
          *v19 = v19[v15];
          ++v19;
        }
        while ( (unsigned int)&v19[-111 - (_DWORD)v14] < 0x10 );
        this->m_pScriptObj = *(PalScriptMgr **)(LODWORD(thisa) + 128);
        this->m_nScriptDepth = *(_DWORD *)(LODWORD(thisa) + 132);
        v20 = (float *)(LODWORD(thisa) + 136);
        p_m_fPrevPosY = (float *)&this->m_fPrevPosY;
        v38 = 16;
        v39.m_plastsys = (gbVFileSystem *)(LODWORD(thisa) + 132 - (_DWORD)&this->m_nScriptDepth);
        do
        {
          v22 = *v20;
          v20 += 3;
          *(p_m_fPrevPosY - 1) = v22;
          *p_m_fPrevPosY = *(float *)((char *)&v39.m_plastsys->IsInit + (unsigned int)p_m_fPrevPosY);
          p_m_fPrevPosY[1] = *(v20 - 1);
          p_m_fPrevPosY += 3;
          --v38;
        }
        while ( v38 );
        this->m_nScriptID = *(_WORD *)(LODWORD(thisa) + 328);
        v23 = (signed __int16 *)(&this->m_nScriptID + 1);
        do
        {
          *(_BYTE *)v23 = *((_BYTE *)v23 + v15);
          v23 = (signed __int16 *)((char *)v23 + 1);
        }
        while ( (unsigned int)v23 - 330 - (unsigned int)v14 < 0x20 );
        this->m_bScriptByte = *(_BYTE *)(LODWORD(thisa) + 362);
        gbVec3D::operator=(&this->m_fPosAX, LODWORD(thisa) + 364);
        gbVec3D::operator=(&this->m_fPosBX, LODWORD(thisa) + 376);
        this->m_nMatrixData = *(_DWORD *)(LODWORD(thisa) + 388);
        p_m_bRunCommand = (_BYTE *)&this->m_bRunCommand;
        do
        {
          *p_m_bRunCommand = p_m_bRunCommand[v15];
          ++p_m_bRunCommand;
        }
        while ( (unsigned int)&p_m_bRunCommand[-392 - (_DWORD)v14] < 8 );
        this->m_nTodo_23C = *(_DWORD *)(LODWORD(thisa) + 400);
        this->m_bInputBlock = *(_DWORD *)(LODWORD(thisa) + 404);
        this->m_bRoleLock = *(_DWORD *)(LODWORD(thisa) + 408);
        v25 = (int *)(&this->m_bRoleLock + 1);
        v26 = 52;
        do
        {
          *v25 = *(int *)((char *)v25 + v15);
          ++v25;
          --v26;
        }
        while ( v26 );
        m_Sub_0034 = this->m_Sub_0034;
        *(_QWORD *)&this->m_Sub_0034 = *(_QWORD *)HIDWORD(thisa);
        *(_QWORD *)&this->m_fField3C = *(_QWORD *)(HIDWORD(thisa) + 8);
        *(_QWORD *)&this->m_fField44 = *(_QWORD *)(HIDWORD(thisa) + 16);
        this->m_scepath = *(scSCEFile **)(HIDWORD(thisa) + 24);
        *(_WORD *)&this->m_bBigMapState = *(_WORD *)(HIDWORD(thisa) + 28);
        this->m_nTodo_054 = *(_DWORD *)(HIDWORD(thisa) + 32);
        this->m_Sub_0034 = m_Sub_0034;
        switch ( this->m_nCmdType )
        {
          case 5:
            if ( this->m_nCmdValue == 1 || *(_BYTE *)(HIDWORD(thisa) + 28) != 3 )
              goto LABEL_31;
            (((RoleSystem *)this))->RoleSystem::ProcessAction() /* [ROWTABLE] */;
            m_nScriptDepth = this->m_nScriptDepth;
            v29 = *((float *)&this->m_nScriptCount + 3 * m_nScriptDepth);
            v30 = (int *)(&this->m_nScriptCount + 3 * m_nScriptDepth);
            this->m_fCamX = v29;
            LODWORD(this->m_fCamY) = (unsigned long)v30[1];
            LODWORD(this->m_fCamZ) = (unsigned long)v30[2];
            (((RoleSystem *)this))->RoleSystem::ProcessAction() /* [ROWTABLE] */;
            this->m_bBigMapState = *(_BYTE *)(HIDWORD(thisa) + 28);
            goto LABEL_78;
          case 7:
            v31 = *(float *)&this->m_nExecHandle;
            v39.m_plastsys = (gbVFileSystem *)LODWORD(this->m_fAngle);
            this->m_fAngle = v31;
            (((RoleSystem *)this))->RoleSystem::ProcessAction() /* [ROWTABLE] */;
            LODWORD(this->m_fAngle) = (OpenBaseFile)v39.m_plastsys;
            break;
          case 0xB:
          case 0x22:
LABEL_31:
            (((RoleSystem *)this))->RoleSystem::ProcessAction() /* [ROWTABLE] */;
            LODWORD(this->m_fCamX) = this->m_nExecuteBlock;
            LODWORD(this->m_fCamY) = this->m_nSavedDataA;
            LODWORD(this->m_fCamZ) = this->m_nSavedDataB;
            break;
          case 0xC:
            if ( !this->m_szScriptFile[5] )
              break;
            goto LABEL_78;
          case 0x11:
            if ( *(_DWORD *)&this->m_nCmdParam0 && this->m_bBigMapState == 1 && this->m_nTodo_058 == 3 )
              goto LABEL_39;
            goto LABEL_78;
          case 0x13:
            if ( this->m_bBigMapState == 1 )
            {
LABEL_39:
              (*(void ( **)(char *, int))(*(_DWORD *)this->m_pExecSystem + 24))(
                this->m_pExecSystem,
                -1082130432);
              (((gbVisNode *)this->m_pExecSystem))->gbVisNode::SetTimeScale(0.0);
            }
            goto LABEL_78;
          case 0x16:
            if ( *(_BYTE *)(HIDWORD(thisa) + 28) == 2 )
            {
              result = (double)this->m_nCmdValue;
              v32 = *(_DWORD *)&this->m_nCmdParam0;
              this->m_bOpcodeFlag = 1;
              this->m_fCamY = result;
              if ( v32 )
                (((RoleSystem *)this))->RoleSystem::UpdateStateMode() /* [ROWTABLE] */;
              this->m_bBigMapState = *(_BYTE *)(HIDWORD(thisa) + 28);
              this->PalScriptMgr::ProcessRoleLoading();
            }
            goto LABEL_78;
          case 0x17:
            if ( !this->m_bExecuteBlock )
            {
              (((gbVisNode *)this->m_pExecSystem))->gbVisNode::SetTimeScale(0.0);
              (*(void ( **)(char *, int))(*(_DWORD *)this->m_pExecSystem + 24))(
                this->m_pExecSystem,
                -1082130432);
              (((PalScript *)&this->m_nTodo_058))->PalScript::GetCount(0);
            }
            if ( this->m_nCmdValue && this->m_bScriptPause )
            {
              (((gbVisNode *)this->m_pExecSystem))->gbVisNode::SetTimeScale(0.0);
              (*(void ( **)(char *, int))(*(_DWORD *)this->m_pExecSystem + 24))(
                this->m_pExecSystem,
                -1082130432);
              (((PalScript *)&this->m_nTodo_058))->PalScript::GetCount(0);
            }
            if ( *(_DWORD *)&this->m_nCmdParam1 == 1 )
            {
              LOBYTE(g_ScriptSystemData.m_nScriptFlag) = this->m_bScriptPause == 0;
              /* [MISATTRIBUTED] ScriptVM on PalScriptMgr::this -> fix IDB name of callee */ ScriptVM::OpenSceneScript((ScriptVM *)this);
              v34 = 0;
              left = this->m_pSceneMgr->m_rect.left;
              if ( *(int *)(left + 220) > 0 )
              {
                v36 = (PalScriptMgr *)(left + 224);
                do
                {
                  if ( v36->m_nCmdType == 37 )
                    (((PalScriptMgr *)v36))->PalScriptMgr::LoadSceneGeometry(g_ScriptSystemData.m_nScriptFlag);
                  ++v34;
                  v36 = (PalScriptMgr *)((char *)v36 + 896);
                }
                while ( v34 < *(_DWORD *)(left + 220) );
              }
            }
            goto LABEL_78;
          case 0x18:
            if ( *(_DWORD *)&this->m_nCmdParam0 == 1 )
            {
              v33 = this->m_nCmdValue;
              m_fCamY = 0.0;
              m_fCamZ = 0.0;
              p_DWORD = v33;
              if ( (((CCBStage *)&((RoleSystem *)&stru_C059A0)->m_fAnimSpeed))->CCBStage::GetByIndex(&p_DWORD) )
                this->m_szScriptFile[5] = 0;
            }
            goto LABEL_78;
          case 0x1A:
            if ( *(_BYTE *)(HIDWORD(thisa) + 28) != 1 )
              goto LABEL_78;
            if ( *(&this->m_bBigMapState + 1) >= 3u )
            {
              sprintf(
                Buffer,
                "object\\wz20_%d.cvd",
                this->m_szScriptFile[strlen((const char *)&this->m_RoleAnimData) + 3] - 48);
              v49 = 0;
              (((GeomNode *)&this->m_nTodo_058))->GeomNode::InitFromFile((const gbGeomNode *)Buffer, 0);
              v49 = -1;
              // [AUTO-COMMENTED] (OpenNULLFile *)&v39->OpenNULLFile();
            }
            (((gbVisNode *)this->m_pExecSystem))->gbVisNode::SetTimeScale(0.0);
            (*(void ( **)(char *, int))(*(_DWORD *)this->m_pExecSystem + 24))(
              this->m_pExecSystem,
              -1082130432);
            (((PalScript *)&this->m_nTodo_058))->PalScript::GetCount(0);
            break;
          case 0x1E:
            if ( this->m_bBigMapState == 3 )
            {
              this->PalScriptMgr::BuildCmdTransform(&v44);
              result = this->m_fCamY - v45;
              this->m_fCamY = result;
            }
            this->m_bOpcodeFlag = this->m_bScriptPause;
            goto LABEL_78;
          case 0x1F:
            if ( (!this->m_szScriptFile[5] || this->m_bBigMapState == 2)
              && !_strcmpi((const char *)this->m_pSceneMgr->m_rect.left, "m09") )
            {
              (((RoleSystem *)this))->RoleSystem::SetTileTypeVisible(2, 1) /* [ROWTABLE] */;
            }
            goto LABEL_78;
          case 0x21:
            LODWORD(this->m_fCamX) = this->m_nExecuteBlock;
            LODWORD(this->m_fCamY) = this->m_nSavedDataA;
            LODWORD(this->m_fCamZ) = this->m_nSavedDataB;
            goto LABEL_78;
          case 0x24:
            if ( this->m_bBigMapState != 2 )
              goto LABEL_78;
            LODWORD(this->m_fCamX) = this->m_nExecuteBlock;
            LODWORD(this->m_fCamY) = this->m_nSavedDataA;
            LODWORD(this->m_fCamZ) = this->m_nSavedDataB;
            m_pSceneMgr = (RoleSystem *)this->m_pSceneMgr;
            this->m_bOpcodeFlag = 0;
            (((RoleSystem *)m_pSceneMgr))->RoleSystem::GetCurrentID(&this->m_nExecRangeA, 255);
            break;
          case 0x29:
            if ( *(_BYTE *)(HIDWORD(thisa) + 28) != 2 )
              goto LABEL_78;
            (((gbVisNode *)this->m_pExecSystem))->gbVisNode::SetTimeScale(0.0);
            (*(void ( **)(char *, int))(*(_DWORD *)this->m_pExecSystem + 24))(
              this->m_pExecSystem,
              -1082130432);
            (((PalScript *)&this->m_nTodo_058))->PalScript::GetCount(0);
            break;
          default:
            goto LABEL_78;
        }
        (((RoleSystem *)this))->RoleSystem::ProcessAction() /* [ROWTABLE] */;
LABEL_78:
        if ( this->m_bRoleLock )
        {
          LODWORD(this->m_fCamX) = this->m_nExecuteBlock;
          LODWORD(this->m_fCamY) = this->m_nSavedDataA;
          LODWORD(this->m_fCamZ) = this->m_nSavedDataB;
        }
      }
    }
  }
  return result;
}

// 0x0042BEA0
void PalScriptMgr::OnAnimFinish()
{
  if ( this->m_nTodo_058 == 3 )
  {
    (((gbVisNode *)this->m_pExecSystem))->gbVisNode::SetTimeScale(2.0);
    (*(void ( **)(char *, _DWORD))(*(_DWORD *)this->m_pExecSystem + 24))(this->m_pExecSystem, 0);
    this->m_bBigMapState = 2;
    this->PalScriptMgr::RunCommand(0);
  }
}

// 0x0042BEF0
void PalScriptMgr::HandleGetItem(int nSkillGDBID)
{
  char *v1; // eax
  CScreenMode *Instance; // eax
  int v3; // [esp-0x4] [ebp-0x110]
  int pConfig; // [esp+0x0] [ebp-0x10C] BYREF
  int v5; // [esp+0x4] [ebp-0x108]
  int SkillNum; // [esp+0x8] [ebp-0x104]
  char Buffer[256]; // [esp+0xC] [ebp-0x100] BYREF

  pConfig = nSkillGDBID;
  v5 = 1;
  SkillNum = (((PAL_GDB *)&g_pGDB))->PAL_GDB::GDB_GetSkillNum(nSkillGDBID);
  if ( SkillNum )
  {
    (((CCBStage *)&((RoleSystem *)&stru_C059A0)->m_fAnimSpeed))->CCBStage::GetAlive(&pConfig);
    v3 = SkillNum + 4;
    v1 = (((PalScript *)g_PAL3_Instance.m_nTodo_140))->PalScript::SetAppName("getitem");
    _snprintf(Buffer, 0xFFu, v1, v3, pConfig, v5);
    (((InputSystem *)Buffer))->InputSystem::ProcessFrame();
    Instance = (CScreenMode *)CScreenMode::GetInstance();
    (((CScreenMode *)Instance))->CScreenMode::AudioSetPosition("wa006", 1);
  }
}

// 0x0042BF90
PalScriptMgr * PalScriptMgr::ExecuteScriptByID()
{
  signed __int16 m_nScriptID; // ax
  ScriptVM *v2; // eax
  PalScriptMgr *v3; // esi

  m_nScriptID = this->m_nScriptID;
  if ( m_nScriptID == -1 )
    return 0;
  (((PalScript *)this->m_pSceneMgr->m_rect.left))->PalScript::SetAction(m_nScriptID);
  v3 = (PalScriptMgr *)v2;
  if ( !v2 )
    return 0;
  (((ScriptVM *)v2))->ScriptVM::ExecuteBlock();
  return v3;
}

// 0x0042BFE0
bool PalScriptMgr::IsScriptReady()
{
  int m_nExecState; // ecx

  if ( *(&this->m_bBigMapState + 1) )
  {
    if ( *(&this->m_bBigMapState + 1) == 1 )
      return this->m_nExecState == 2;
    else
      return *(&this->m_bBigMapState + 1) != 2 || this->m_nExecState == 3;
  }
  else
  {
    m_nExecState = this->m_nExecState;
    return m_nExecState == 2 || m_nExecState == 3;
  }
}

// 0x0042C030
void PalScriptMgr::SetPauseState(int bPause)
{
  double v3; // st7
  gbMatrix4 pMatrix; // [esp+0x4] [ebp-0x4C] BYREF
  float v5; // [esp+0x48] [ebp-0x8]

  if ( bPause != (unsigned __int8)this->m_bScriptPause )
  {
    this->m_bScriptPause = bPause;
    if ( (_BYTE)bPause )
      this->m_bBigMapState = 1;
    else
      this->m_bBigMapState = 2;
    this->m_nTodo_054 = 0;
    this->m_nFrameCounter = LODWORD(this->m_fCamX);
    this->m_fField3C = this->m_fCamY;
    this->m_pBigMapSce = (scSCEFile *)LODWORD(this->m_fCamZ);
    this->PalScriptMgr::BuildCmdTransform(&pMatrix);
    v3 = v5 - 2.0;
    this->m_bOpcodeFlag = this->m_bScriptPause;
    this->m_fField44 = v3;
    this->PalScriptMgr::RunCommand(0);
  }
}

// 0x0042C280
gbVFileSystem * PalScriptMgr::LoadSceneGeometry(char bNoPol)
{
  LONG left; // ecx
  gbVFileSystem *result; // eax
  char v5; // [esp+0x7] [ebp-0x115] BYREF
  OpenSceneFile v6; // [esp+0x8] [ebp-0x114] BYREF
  char Buffer[260]; // [esp+0xC] [ebp-0x110] BYREF
  int v8; // [esp+0x118] [ebp-0x4]

  if ( this->m_nTodo_058 )
    (((RoleSystem *)this))->RoleSystem::ProcessAction() /* [ROWTABLE] */;
  sprintf(Buffer, "%s%s", "scene\\", (const char *)this->m_pSceneMgr->m_rect.left);
  left = this->m_pSceneMgr->m_rect.left;
  v8 = 0;
  sprintf(Buffer, "%s\\%s", (const char *)(left + 64), (const char *)&this->m_RoleAnimData);
  if ( !bNoPol )
    strcpy(&v5 + strlen(Buffer), a2Pol);
  (((GeomNode *)&this->m_nTodo_058))->GeomNode::InitFromFile((const gbGeomNode *)Buffer, 0);
  (((RoleSystem *)this))->RoleSystem::ProcessAction() /* [ROWTABLE] */;
  this->m_bOpcodeFlag = bNoPol;
  v8 = -1;
  (((OpenSceneFile *)&v6))->OpenSceneFile::~OpenSceneFile();
  return result;
}

// 0x0042C3A0
bool PalScriptMgr::IsInputBlocked()
{
  bool result; // al

  if ( this->m_bInputBlock || this->m_bRoleLock )
    return 1;
  switch ( this->m_nCmdType )
  {
    case 0:
      result = (((UIScene *)"m22"))->UIScene::ProcessInput(pszName2);
      break;
    case 1:
    case 2:
    case 3:
    case 0xD:
    case 0xE:
    case 0xF:
    case 0x12:
    case 0x15:
    case 0x19:
    case 0x1B:
    case 0x2A:
    case 0x2B:
      result = 0;
      break;
    case 0x11:
      result = *(_DWORD *)&this->m_nCmdParam0 == 1;
      break;
    default:
      return 1;
  }
  return result;
}

// 0x0042C440
void PalScriptMgr::RunCommand(int a1)
{
  const char *p_m_bRunCommand; // edi
  int m_nTodo_058; // ecx
  CScreenMode *Instance; // eax
  _DWORD pData[4]; // [esp+0x8] [ebp-0x10] BYREF

  memset(pData, 0, sizeof(pData));
  p_m_bRunCommand = (char *)&this->m_bRunCommand;
  if ( !this->m_bRunCommand )
  {
    switch ( this->m_nCmdType )
    {
      case 3:
        goto LABEL_4;
      case 4:
        m_nTodo_058 = this->m_nTodo_058;
        if ( m_nTodo_058 != 3 )
          goto LABEL_20;
LABEL_4:
        p_m_bRunCommand = (const char *)"wg006";
        break;
      case 6:
        p_m_bRunCommand = (const char *)"wg007";
        break;
      case 7:
        p_m_bRunCommand = (const char *)"wg004";
        break;
      case 0xB:
        p_m_bRunCommand = (const char *)"We025";
        break;
      case 0xC:
        switch ( this->m_nCmdValue )
        {
          case 0:
            p_m_bRunCommand = (const char *)"We026";
            goto LABEL_30;
          case 1:
            p_m_bRunCommand = (const char *)"We027";
            goto LABEL_30;
          case 2:
            p_m_bRunCommand = (const char *)"We028";
            goto LABEL_30;
          case 3:
            p_m_bRunCommand = (const char *)"We029";
            goto LABEL_30;
          case 4:
            p_m_bRunCommand = (const char *)"We030";
            goto LABEL_30;
          default:
            goto LABEL_31;
        }
        goto LABEL_31;
      case 0xD:
        p_m_bRunCommand = (const char *)"Wb002";
        break;
      case 0x13:
        p_m_bRunCommand = (const char *)"Wg001";
        break;
      case 0x16:
      case 0x1E:
        goto LABEL_24;
      case 0x1A:
        if ( a1 )
          goto LABEL_29;
        p_m_bRunCommand = (const char *)"wa004";
        break;
      case 0x1C:
        m_nTodo_058 = this->m_nTodo_058;
        if ( m_nTodo_058 == 3 )
        {
          p_m_bRunCommand = (const char *)"wg010";
          break;
        }
LABEL_20:
        if ( m_nTodo_058 != 2 )
          goto LABEL_31;
LABEL_21:
        p_m_bRunCommand = (const char *)"wg009";
        break;
      case 0x1D:
        if ( a1 )
          p_m_bRunCommand = (const char *)"We026";
        else
LABEL_24:
          p_m_bRunCommand = (const char *)"Wg005";
        break;
      case 0x1F:
        p_m_bRunCommand = (const char *)"Wc007";
        break;
      case 0x20:
        p_m_bRunCommand = (const char *)"WG008";
        break;
      case 0x22:
        p_m_bRunCommand = (const char *)"wg005";
        break;
      case 0x24:
        goto LABEL_21;
      case 0x27:
        p_m_bRunCommand = (const char *)"wc014";
        break;
      case 0x29:
LABEL_29:
        p_m_bRunCommand = (const char *)"wg011";
        break;
      default:
        goto LABEL_31;
    }
  }
LABEL_30:
  strcpy((char *)pData, p_m_bRunCommand);
LABEL_31:
  if ( LOBYTE(pData[0]) )
  {
    Instance = (CScreenMode *)CScreenMode::GetInstance();
    (((CScreenMode *)Instance))->CScreenMode::AudioSetPosition(pData, 1);
  }
}

// 0x0042CF60
int PalScriptMgr::CmdPushCmd04(int nVal, unsigned __int8 pData)
{
  PalScriptMgr **p_m_pSubScriptB; // ebx
  int m_nWaitCount; // eax
  float m_fExecPosZ; // edi
  float m_fExecPosY; // ecx
  int result; // eax
  PalScriptMgr *v9; // esi
  PalScriptMgr *v10; // eax
  float v11; // ecx
  float v12; // edx
  float x; // eax
  PalScriptMgr *v14; // esi
  unsigned int v15; // eax
  PalScriptMgr *v16; // eax
  float v17; // edx
  float v18; // ecx
  PalScriptMgr *v19; // edx
  int v20; // edi
  gbVec3D *RoleName; // eax
  PalScriptMgr *v22; // edi
  float y; // ecx
  float z; // eax
  PalScriptMgr *v25; // ecx
  int v26; // ecx
  gbVec3D v27; // [esp+0xC] [ebp-0x5C] BYREF
  PalScriptMgr *v28; // [esp+0x18] [ebp-0x50]
  _DWORD v29[19]; // [esp+0x1C] [ebp-0x4C] BYREF

  (((CG_Entry *)v29))->CG_Entry::GetCGEntry();
  p_m_pSubScriptB = (PalScriptMgr **)&this->m_pSubScriptB;
  v29[15] = pData;
  LOBYTE(v29[0]) = 4;
  m_nWaitCount = this->m_nWaitCount;
  v29[16] = nVal;
  if ( !m_nWaitCount
    || (m_fExecPosZ = this->m_fExecPosZ, m_fExecPosY = this->m_fExecPosY, LODWORD(m_fExecPosZ) == LODWORD(m_fExecPosY)) )
  {
    v9 = (PalScriptMgr *)operator new(0xFBCu);
    if ( p_m_pSubScriptB[11] )
    {
      v15 = (unsigned int)p_m_pSubScriptB[8];
      if ( v15 >= (unsigned int)p_m_pSubScriptB[9] + 4 * (_DWORD)p_m_pSubScriptB[10] - 4 )
      {
        v20 = ((int)(v15 - (_DWORD)p_m_pSubScriptB[4]) >> 2) + 1;
        RoleName = (gbVec3D *)(((RoleSystem *)p_m_pSubScriptB))->RoleSystem::GetRoleName(2 * v20);
        v22 = (PalScriptMgr *)(&RoleName->x + v20);
        *(_DWORD *)&v22->m_bGetSceneScript = (_DWORD)v9;
        (((gbVec3D *)&v27))->gbVec3D::Copy((int)p_m_pSubScriptB[3], RoleName);
        y = v27.y;
        p_m_pSubScriptB[1] = (PalScriptMgr *)LODWORD(v27.x);
        z = v27.z;
        *((float *)p_m_pSubScriptB + 2) = y;
        v25 = (PalScriptMgr *)v28;
        *((float *)p_m_pSubScriptB + 3) = z;
        p_m_pSubScriptB[4] = v25;
        v26 = *(_DWORD *)&v22->m_bGetSceneScript + 4028;
        p_m_pSubScriptB[5] = *(PalScriptMgr **)&v22->m_bGetSceneScript;
        p_m_pSubScriptB[6] = (PalScriptMgr *)v26;
        p_m_pSubScriptB[7] = v9;
        p_m_pSubScriptB[8] = v22;
      }
      else
      {
        v16 = (PalScriptMgr *)(v15 + 4);
        p_m_pSubScriptB[8] = v16;
        *(_DWORD *)&v16->m_bGetSceneScript = (_DWORD)v9;
        (((gbVec3D *)&v27))->gbVec3D::Copy((int)v9, (gbVec3D *)p_m_pSubScriptB[8]);
        v17 = v27.y;
        p_m_pSubScriptB[5] = (PalScriptMgr *)LODWORD(v27.x);
        v18 = v27.z;
        *((float *)p_m_pSubScriptB + 6) = v17;
        v19 = (PalScriptMgr *)v28;
        *((float *)p_m_pSubScriptB + 7) = v18;
        p_m_pSubScriptB[8] = v19;
      }
    }
    else
    {
      p_m_pSubScriptB[10] = (PalScriptMgr *)2;
      v10 = (PalScriptMgr *)operator new(8u);
      p_m_pSubScriptB[9] = v10;
      v10->m_script.m_pData = (char *)&v9->m_bGetSceneScript;
      (((gbVec3D *)&v27))->gbVec3D::Copy((int)(&v9->m_ctrlParabola + 15), (gbVec3D *)&p_m_pSubScriptB[9]->m_script);
      v11 = v27.y;
      v12 = v27.z;
      x = v27.x;
      v14 = (PalScriptMgr *)v28;
      p_m_pSubScriptB[1] = (PalScriptMgr *)LODWORD(v27.x);
      *((float *)p_m_pSubScriptB + 2) = v11;
      *((float *)p_m_pSubScriptB + 3) = v12;
      p_m_pSubScriptB[4] = v14;
      *((float *)p_m_pSubScriptB + 5) = x;
      *((float *)p_m_pSubScriptB + 6) = v11;
      *((float *)p_m_pSubScriptB + 7) = v12;
      p_m_pSubScriptB[8] = v14;
    }
    m_fExecPosZ = *((float *)p_m_pSubScriptB + 7);
    p_m_pSubScriptB[7] = (PalScriptMgr *)(LODWORD(m_fExecPosZ) + 76);
    if ( m_fExecPosZ == 0.0 )
      goto LABEL_16;
    goto LABEL_15;
  }
  LODWORD(this->m_fExecPosZ) = LODWORD(m_fExecPosZ) + 76;
  if ( LODWORD(m_fExecPosZ) + 76 != LODWORD(m_fExecPosY) )
  {
    if ( m_fExecPosZ == 0.0 )
    {
LABEL_16:
      result = (int)(&p_m_pSubScriptB[11]->m_bGetSceneScript + 1);
      p_m_pSubScriptB[11] = (PalScriptMgr *)result;
      return result;
    }
LABEL_15:
    qmemcpy((void *)LODWORD(m_fExecPosZ), v29, 0x4Cu);
    goto LABEL_16;
  }
  if ( m_fExecPosZ != 0.0 )
    qmemcpy((void *)LODWORD(m_fExecPosZ), v29, 0x4Cu);
  (((ScriptVM *)p_m_pSubScriptB))->ScriptVM::GetString();
  result = this->m_nWaitCount + 1;
  this->m_nWaitCount = result;
  return result;
}

// 0x0042D130
int PalScriptMgr::CmdPushCmd05(unsigned __int8 pData)
{
  PalScriptMgr **p_m_pSubScriptB; // ebx
  float m_fExecPosZ; // edi
  float m_fExecPosY; // ecx
  int result; // eax
  PalScriptMgr *v7; // esi
  PalScriptMgr *v8; // eax
  float x; // eax
  float v10; // ecx
  PalScriptMgr *v11; // esi
  float v12; // edx
  unsigned int v13; // eax
  PalScriptMgr *v14; // eax
  float v15; // edx
  float v16; // ecx
  PalScriptMgr *v17; // edx
  int v18; // edi
  gbVec3D *RoleName; // eax
  PalScriptMgr *v20; // edi
  float y; // ecx
  float z; // eax
  PalScriptMgr *v23; // ecx
  int v24; // ecx
  gbVec3D v25; // [esp+0xC] [ebp-0x5C] BYREF
  PalScriptMgr *v26; // [esp+0x18] [ebp-0x50]
  _DWORD v27[19]; // [esp+0x1C] [ebp-0x4C] BYREF

  (((CG_Entry *)v27))->CG_Entry::GetCGEntry();
  p_m_pSubScriptB = (PalScriptMgr **)&this->m_pSubScriptB;
  LOBYTE(v27[0]) = 5;
  v27[15] = pData;
  if ( !this->m_nWaitCount
    || (m_fExecPosZ = this->m_fExecPosZ, m_fExecPosY = this->m_fExecPosY, LODWORD(m_fExecPosZ) == LODWORD(m_fExecPosY)) )
  {
    v7 = (PalScriptMgr *)operator new(0xFBCu);
    if ( p_m_pSubScriptB[11] )
    {
      v13 = (unsigned int)p_m_pSubScriptB[8];
      if ( v13 >= (unsigned int)p_m_pSubScriptB[9] + 4 * (_DWORD)p_m_pSubScriptB[10] - 4 )
      {
        v18 = ((int)(v13 - (_DWORD)p_m_pSubScriptB[4]) >> 2) + 1;
        RoleName = (gbVec3D *)(((RoleSystem *)p_m_pSubScriptB))->RoleSystem::GetRoleName(2 * v18);
        v20 = (PalScriptMgr *)(&RoleName->x + v18);
        *(_DWORD *)&v20->m_bGetSceneScript = (_DWORD)v7;
        (((gbVec3D *)&v25))->gbVec3D::Copy((int)p_m_pSubScriptB[3], RoleName);
        y = v25.y;
        p_m_pSubScriptB[1] = (PalScriptMgr *)LODWORD(v25.x);
        z = v25.z;
        *((float *)p_m_pSubScriptB + 2) = y;
        v23 = (PalScriptMgr *)v26;
        *((float *)p_m_pSubScriptB + 3) = z;
        p_m_pSubScriptB[4] = v23;
        v24 = *(_DWORD *)&v20->m_bGetSceneScript + 4028;
        p_m_pSubScriptB[5] = *(PalScriptMgr **)&v20->m_bGetSceneScript;
        p_m_pSubScriptB[6] = (PalScriptMgr *)v24;
        p_m_pSubScriptB[7] = v7;
        p_m_pSubScriptB[8] = v20;
      }
      else
      {
        v14 = (PalScriptMgr *)(v13 + 4);
        p_m_pSubScriptB[8] = v14;
        *(_DWORD *)&v14->m_bGetSceneScript = (_DWORD)v7;
        (((gbVec3D *)&v25))->gbVec3D::Copy((int)v7, (gbVec3D *)p_m_pSubScriptB[8]);
        v15 = v25.y;
        p_m_pSubScriptB[5] = (PalScriptMgr *)LODWORD(v25.x);
        v16 = v25.z;
        *((float *)p_m_pSubScriptB + 6) = v15;
        v17 = (PalScriptMgr *)v26;
        *((float *)p_m_pSubScriptB + 7) = v16;
        p_m_pSubScriptB[8] = v17;
      }
    }
    else
    {
      p_m_pSubScriptB[10] = (PalScriptMgr *)2;
      v8 = (PalScriptMgr *)operator new(8u);
      p_m_pSubScriptB[9] = v8;
      v8->m_script.m_pData = (char *)&v7->m_bGetSceneScript;
      (((gbVec3D *)&v25))->gbVec3D::Copy((int)(&v7->m_ctrlParabola + 15), (gbVec3D *)&p_m_pSubScriptB[9]->m_script);
      x = v25.x;
      v10 = v25.y;
      v11 = (PalScriptMgr *)v26;
      v12 = v25.z;
      p_m_pSubScriptB[1] = (PalScriptMgr *)LODWORD(v25.x);
      *((float *)p_m_pSubScriptB + 2) = v10;
      *((float *)p_m_pSubScriptB + 3) = v12;
      p_m_pSubScriptB[4] = v11;
      *((float *)p_m_pSubScriptB + 5) = x;
      *((float *)p_m_pSubScriptB + 6) = v10;
      *((float *)p_m_pSubScriptB + 7) = v12;
      p_m_pSubScriptB[8] = v11;
    }
    m_fExecPosZ = *((float *)p_m_pSubScriptB + 7);
    p_m_pSubScriptB[7] = (PalScriptMgr *)(LODWORD(m_fExecPosZ) + 76);
    if ( m_fExecPosZ == 0.0 )
      goto LABEL_16;
    goto LABEL_15;
  }
  LODWORD(this->m_fExecPosZ) = LODWORD(m_fExecPosZ) + 76;
  if ( LODWORD(m_fExecPosZ) + 76 != LODWORD(m_fExecPosY) )
  {
    if ( m_fExecPosZ == 0.0 )
    {
LABEL_16:
      result = (int)(&p_m_pSubScriptB[11]->m_bGetSceneScript + 1);
      p_m_pSubScriptB[11] = (PalScriptMgr *)result;
      return result;
    }
LABEL_15:
    qmemcpy((void *)LODWORD(m_fExecPosZ), v27, 0x4Cu);
    goto LABEL_16;
  }
  if ( m_fExecPosZ != 0.0 )
    qmemcpy((void *)LODWORD(m_fExecPosZ), v27, 0x4Cu);
  (((ScriptVM *)p_m_pSubScriptB))->ScriptVM::GetString();
  result = this->m_nWaitCount + 1;
  this->m_nWaitCount = result;
  return result;
}

// 0x0042D2F0
int PalScriptMgr::CmdPushCmd07(unsigned __int8 pData)
{
  PalScriptMgr **p_m_pSubScriptB; // ebx
  float m_fExecPosZ; // edi
  float m_fExecPosY; // ecx
  int result; // eax
  PalScriptMgr *v7; // esi
  PalScriptMgr *v8; // eax
  float x; // eax
  float v10; // ecx
  PalScriptMgr *v11; // esi
  float v12; // edx
  unsigned int v13; // eax
  PalScriptMgr *v14; // eax
  float v15; // edx
  float v16; // ecx
  PalScriptMgr *v17; // edx
  int v18; // edi
  gbVec3D *RoleName; // eax
  PalScriptMgr *v20; // edi
  float y; // ecx
  float z; // eax
  PalScriptMgr *v23; // ecx
  int v24; // ecx
  gbVec3D v25; // [esp+0xC] [ebp-0x5C] BYREF
  PalScriptMgr *v26; // [esp+0x18] [ebp-0x50]
  _DWORD v27[19]; // [esp+0x1C] [ebp-0x4C] BYREF

  (((CG_Entry *)v27))->CG_Entry::GetCGEntry();
  p_m_pSubScriptB = (PalScriptMgr **)&this->m_pSubScriptB;
  LOBYTE(v27[0]) = 7;
  v27[15] = pData;
  if ( !this->m_nWaitCount
    || (m_fExecPosZ = this->m_fExecPosZ, m_fExecPosY = this->m_fExecPosY, LODWORD(m_fExecPosZ) == LODWORD(m_fExecPosY)) )
  {
    v7 = (PalScriptMgr *)operator new(0xFBCu);
    if ( p_m_pSubScriptB[11] )
    {
      v13 = (unsigned int)p_m_pSubScriptB[8];
      if ( v13 >= (unsigned int)p_m_pSubScriptB[9] + 4 * (_DWORD)p_m_pSubScriptB[10] - 4 )
      {
        v18 = ((int)(v13 - (_DWORD)p_m_pSubScriptB[4]) >> 2) + 1;
        RoleName = (gbVec3D *)(((RoleSystem *)p_m_pSubScriptB))->RoleSystem::GetRoleName(2 * v18);
        v20 = (PalScriptMgr *)(&RoleName->x + v18);
        *(_DWORD *)&v20->m_bGetSceneScript = (_DWORD)v7;
        (((gbVec3D *)&v25))->gbVec3D::Copy((int)p_m_pSubScriptB[3], RoleName);
        y = v25.y;
        p_m_pSubScriptB[1] = (PalScriptMgr *)LODWORD(v25.x);
        z = v25.z;
        *((float *)p_m_pSubScriptB + 2) = y;
        v23 = (PalScriptMgr *)v26;
        *((float *)p_m_pSubScriptB + 3) = z;
        p_m_pSubScriptB[4] = v23;
        v24 = *(_DWORD *)&v20->m_bGetSceneScript + 4028;
        p_m_pSubScriptB[5] = *(PalScriptMgr **)&v20->m_bGetSceneScript;
        p_m_pSubScriptB[6] = (PalScriptMgr *)v24;
        p_m_pSubScriptB[7] = v7;
        p_m_pSubScriptB[8] = v20;
      }
      else
      {
        v14 = (PalScriptMgr *)(v13 + 4);
        p_m_pSubScriptB[8] = v14;
        *(_DWORD *)&v14->m_bGetSceneScript = (_DWORD)v7;
        (((gbVec3D *)&v25))->gbVec3D::Copy((int)v7, (gbVec3D *)p_m_pSubScriptB[8]);
        v15 = v25.y;
        p_m_pSubScriptB[5] = (PalScriptMgr *)LODWORD(v25.x);
        v16 = v25.z;
        *((float *)p_m_pSubScriptB + 6) = v15;
        v17 = (PalScriptMgr *)v26;
        *((float *)p_m_pSubScriptB + 7) = v16;
        p_m_pSubScriptB[8] = v17;
      }
    }
    else
    {
      p_m_pSubScriptB[10] = (PalScriptMgr *)2;
      v8 = (PalScriptMgr *)operator new(8u);
      p_m_pSubScriptB[9] = v8;
      v8->m_script.m_pData = (char *)&v7->m_bGetSceneScript;
      (((gbVec3D *)&v25))->gbVec3D::Copy((int)(&v7->m_ctrlParabola + 15), (gbVec3D *)&p_m_pSubScriptB[9]->m_script);
      x = v25.x;
      v10 = v25.y;
      v11 = (PalScriptMgr *)v26;
      v12 = v25.z;
      p_m_pSubScriptB[1] = (PalScriptMgr *)LODWORD(v25.x);
      *((float *)p_m_pSubScriptB + 2) = v10;
      *((float *)p_m_pSubScriptB + 3) = v12;
      p_m_pSubScriptB[4] = v11;
      *((float *)p_m_pSubScriptB + 5) = x;
      *((float *)p_m_pSubScriptB + 6) = v10;
      *((float *)p_m_pSubScriptB + 7) = v12;
      p_m_pSubScriptB[8] = v11;
    }
    m_fExecPosZ = *((float *)p_m_pSubScriptB + 7);
    p_m_pSubScriptB[7] = (PalScriptMgr *)(LODWORD(m_fExecPosZ) + 76);
    if ( m_fExecPosZ == 0.0 )
      goto LABEL_16;
    goto LABEL_15;
  }
  LODWORD(this->m_fExecPosZ) = LODWORD(m_fExecPosZ) + 76;
  if ( LODWORD(m_fExecPosZ) + 76 != LODWORD(m_fExecPosY) )
  {
    if ( m_fExecPosZ == 0.0 )
    {
LABEL_16:
      result = (int)(&p_m_pSubScriptB[11]->m_bGetSceneScript + 1);
      p_m_pSubScriptB[11] = (PalScriptMgr *)result;
      return result;
    }
LABEL_15:
    qmemcpy((void *)LODWORD(m_fExecPosZ), v27, 0x4Cu);
    goto LABEL_16;
  }
  if ( m_fExecPosZ != 0.0 )
    qmemcpy((void *)LODWORD(m_fExecPosZ), v27, 0x4Cu);
  (((ScriptVM *)p_m_pSubScriptB))->ScriptVM::GetString();
  result = this->m_nWaitCount + 1;
  this->m_nWaitCount = result;
  return result;
}

// 0x0042D830
int PalScriptMgr::CmdPushCmd10(unsigned __int8 pData)
{
  PalScriptMgr **p_m_pSubScriptB; // ebx
  float m_fExecPosZ; // edi
  float m_fExecPosY; // ecx
  int result; // eax
  PalScriptMgr *v7; // esi
  PalScriptMgr *v8; // eax
  float x; // eax
  float v10; // ecx
  PalScriptMgr *v11; // esi
  float v12; // edx
  unsigned int v13; // eax
  PalScriptMgr *v14; // eax
  float v15; // edx
  float v16; // ecx
  PalScriptMgr *v17; // edx
  int v18; // edi
  gbVec3D *RoleName; // eax
  PalScriptMgr *v20; // edi
  float y; // ecx
  float z; // eax
  PalScriptMgr *v23; // ecx
  int v24; // ecx
  gbVec3D v25; // [esp+0xC] [ebp-0x5C] BYREF
  PalScriptMgr *v26; // [esp+0x18] [ebp-0x50]
  _DWORD v27[19]; // [esp+0x1C] [ebp-0x4C] BYREF

  (((CG_Entry *)v27))->CG_Entry::GetCGEntry();
  p_m_pSubScriptB = (PalScriptMgr **)&this->m_pSubScriptB;
  LOBYTE(v27[0]) = 10;
  v27[15] = pData;
  if ( !this->m_nWaitCount
    || (m_fExecPosZ = this->m_fExecPosZ, m_fExecPosY = this->m_fExecPosY, LODWORD(m_fExecPosZ) == LODWORD(m_fExecPosY)) )
  {
    v7 = (PalScriptMgr *)operator new(0xFBCu);
    if ( p_m_pSubScriptB[11] )
    {
      v13 = (unsigned int)p_m_pSubScriptB[8];
      if ( v13 >= (unsigned int)p_m_pSubScriptB[9] + 4 * (_DWORD)p_m_pSubScriptB[10] - 4 )
      {
        v18 = ((int)(v13 - (_DWORD)p_m_pSubScriptB[4]) >> 2) + 1;
        RoleName = (gbVec3D *)(((RoleSystem *)p_m_pSubScriptB))->RoleSystem::GetRoleName(2 * v18);
        v20 = (PalScriptMgr *)(&RoleName->x + v18);
        *(_DWORD *)&v20->m_bGetSceneScript = (_DWORD)v7;
        (((gbVec3D *)&v25))->gbVec3D::Copy((int)p_m_pSubScriptB[3], RoleName);
        y = v25.y;
        p_m_pSubScriptB[1] = (PalScriptMgr *)LODWORD(v25.x);
        z = v25.z;
        *((float *)p_m_pSubScriptB + 2) = y;
        v23 = (PalScriptMgr *)v26;
        *((float *)p_m_pSubScriptB + 3) = z;
        p_m_pSubScriptB[4] = v23;
        v24 = *(_DWORD *)&v20->m_bGetSceneScript + 4028;
        p_m_pSubScriptB[5] = *(PalScriptMgr **)&v20->m_bGetSceneScript;
        p_m_pSubScriptB[6] = (PalScriptMgr *)v24;
        p_m_pSubScriptB[7] = v7;
        p_m_pSubScriptB[8] = v20;
      }
      else
      {
        v14 = (PalScriptMgr *)(v13 + 4);
        p_m_pSubScriptB[8] = v14;
        *(_DWORD *)&v14->m_bGetSceneScript = (_DWORD)v7;
        (((gbVec3D *)&v25))->gbVec3D::Copy((int)v7, (gbVec3D *)p_m_pSubScriptB[8]);
        v15 = v25.y;
        p_m_pSubScriptB[5] = (PalScriptMgr *)LODWORD(v25.x);
        v16 = v25.z;
        *((float *)p_m_pSubScriptB + 6) = v15;
        v17 = (PalScriptMgr *)v26;
        *((float *)p_m_pSubScriptB + 7) = v16;
        p_m_pSubScriptB[8] = v17;
      }
    }
    else
    {
      p_m_pSubScriptB[10] = (PalScriptMgr *)2;
      v8 = (PalScriptMgr *)operator new(8u);
      p_m_pSubScriptB[9] = v8;
      v8->m_script.m_pData = (char *)&v7->m_bGetSceneScript;
      (((gbVec3D *)&v25))->gbVec3D::Copy((int)(&v7->m_ctrlParabola + 15), (gbVec3D *)&p_m_pSubScriptB[9]->m_script);
      x = v25.x;
      v10 = v25.y;
      v11 = (PalScriptMgr *)v26;
      v12 = v25.z;
      p_m_pSubScriptB[1] = (PalScriptMgr *)LODWORD(v25.x);
      *((float *)p_m_pSubScriptB + 2) = v10;
      *((float *)p_m_pSubScriptB + 3) = v12;
      p_m_pSubScriptB[4] = v11;
      *((float *)p_m_pSubScriptB + 5) = x;
      *((float *)p_m_pSubScriptB + 6) = v10;
      *((float *)p_m_pSubScriptB + 7) = v12;
      p_m_pSubScriptB[8] = v11;
    }
    m_fExecPosZ = *((float *)p_m_pSubScriptB + 7);
    p_m_pSubScriptB[7] = (PalScriptMgr *)(LODWORD(m_fExecPosZ) + 76);
    if ( m_fExecPosZ == 0.0 )
      goto LABEL_16;
    goto LABEL_15;
  }
  LODWORD(this->m_fExecPosZ) = LODWORD(m_fExecPosZ) + 76;
  if ( LODWORD(m_fExecPosZ) + 76 != LODWORD(m_fExecPosY) )
  {
    if ( m_fExecPosZ == 0.0 )
    {
LABEL_16:
      result = (int)(&p_m_pSubScriptB[11]->m_bGetSceneScript + 1);
      p_m_pSubScriptB[11] = (PalScriptMgr *)result;
      return result;
    }
LABEL_15:
    qmemcpy((void *)LODWORD(m_fExecPosZ), v27, 0x4Cu);
    goto LABEL_16;
  }
  if ( m_fExecPosZ != 0.0 )
    qmemcpy((void *)LODWORD(m_fExecPosZ), v27, 0x4Cu);
  (((ScriptVM *)p_m_pSubScriptB))->ScriptVM::GetString();
  result = this->m_nWaitCount + 1;
  this->m_nWaitCount = result;
  return result;
}

// 0x0042DF30
int PalScriptMgr::CmdPushCmd14(int nVal, unsigned __int8 pData)
{
  PalScriptMgr **p_m_pSubScriptB; // ebx
  int m_nWaitCount; // eax
  float m_fExecPosZ; // edi
  float m_fExecPosY; // ecx
  int result; // eax
  PalScriptMgr *v9; // esi
  PalScriptMgr *v10; // eax
  float v11; // ecx
  float v12; // edx
  float x; // eax
  PalScriptMgr *v14; // esi
  unsigned int v15; // eax
  PalScriptMgr *v16; // eax
  float v17; // edx
  float v18; // ecx
  PalScriptMgr *v19; // edx
  int v20; // edi
  gbVec3D *RoleName; // eax
  PalScriptMgr *v22; // edi
  float y; // ecx
  float z; // eax
  PalScriptMgr *v25; // ecx
  int v26; // ecx
  gbVec3D v27; // [esp+0xC] [ebp-0x5C] BYREF
  PalScriptMgr *v28; // [esp+0x18] [ebp-0x50]
  _DWORD v29[19]; // [esp+0x1C] [ebp-0x4C] BYREF

  (((CG_Entry *)v29))->CG_Entry::GetCGEntry();
  p_m_pSubScriptB = (PalScriptMgr **)&this->m_pSubScriptB;
  v29[15] = nVal;
  LOBYTE(v29[0]) = 14;
  m_nWaitCount = this->m_nWaitCount;
  v29[16] = pData;
  if ( !m_nWaitCount
    || (m_fExecPosZ = this->m_fExecPosZ, m_fExecPosY = this->m_fExecPosY, LODWORD(m_fExecPosZ) == LODWORD(m_fExecPosY)) )
  {
    v9 = (PalScriptMgr *)operator new(0xFBCu);
    if ( p_m_pSubScriptB[11] )
    {
      v15 = (unsigned int)p_m_pSubScriptB[8];
      if ( v15 >= (unsigned int)p_m_pSubScriptB[9] + 4 * (_DWORD)p_m_pSubScriptB[10] - 4 )
      {
        v20 = ((int)(v15 - (_DWORD)p_m_pSubScriptB[4]) >> 2) + 1;
        RoleName = (gbVec3D *)(((RoleSystem *)p_m_pSubScriptB))->RoleSystem::GetRoleName(2 * v20);
        v22 = (PalScriptMgr *)(&RoleName->x + v20);
        *(_DWORD *)&v22->m_bGetSceneScript = (_DWORD)v9;
        (((gbVec3D *)&v27))->gbVec3D::Copy((int)p_m_pSubScriptB[3], RoleName);
        y = v27.y;
        p_m_pSubScriptB[1] = (PalScriptMgr *)LODWORD(v27.x);
        z = v27.z;
        *((float *)p_m_pSubScriptB + 2) = y;
        v25 = (PalScriptMgr *)v28;
        *((float *)p_m_pSubScriptB + 3) = z;
        p_m_pSubScriptB[4] = v25;
        v26 = *(_DWORD *)&v22->m_bGetSceneScript + 4028;
        p_m_pSubScriptB[5] = *(PalScriptMgr **)&v22->m_bGetSceneScript;
        p_m_pSubScriptB[6] = (PalScriptMgr *)v26;
        p_m_pSubScriptB[7] = v9;
        p_m_pSubScriptB[8] = v22;
      }
      else
      {
        v16 = (PalScriptMgr *)(v15 + 4);
        p_m_pSubScriptB[8] = v16;
        *(_DWORD *)&v16->m_bGetSceneScript = (_DWORD)v9;
        (((gbVec3D *)&v27))->gbVec3D::Copy((int)v9, (gbVec3D *)p_m_pSubScriptB[8]);
        v17 = v27.y;
        p_m_pSubScriptB[5] = (PalScriptMgr *)LODWORD(v27.x);
        v18 = v27.z;
        *((float *)p_m_pSubScriptB + 6) = v17;
        v19 = (PalScriptMgr *)v28;
        *((float *)p_m_pSubScriptB + 7) = v18;
        p_m_pSubScriptB[8] = v19;
      }
    }
    else
    {
      p_m_pSubScriptB[10] = (PalScriptMgr *)2;
      v10 = (PalScriptMgr *)operator new(8u);
      p_m_pSubScriptB[9] = v10;
      v10->m_script.m_pData = (char *)&v9->m_bGetSceneScript;
      (((gbVec3D *)&v27))->gbVec3D::Copy((int)(&v9->m_ctrlParabola + 15), (gbVec3D *)&p_m_pSubScriptB[9]->m_script);
      v11 = v27.y;
      v12 = v27.z;
      x = v27.x;
      v14 = (PalScriptMgr *)v28;
      p_m_pSubScriptB[1] = (PalScriptMgr *)LODWORD(v27.x);
      *((float *)p_m_pSubScriptB + 2) = v11;
      *((float *)p_m_pSubScriptB + 3) = v12;
      p_m_pSubScriptB[4] = v14;
      *((float *)p_m_pSubScriptB + 5) = x;
      *((float *)p_m_pSubScriptB + 6) = v11;
      *((float *)p_m_pSubScriptB + 7) = v12;
      p_m_pSubScriptB[8] = v14;
    }
    m_fExecPosZ = *((float *)p_m_pSubScriptB + 7);
    p_m_pSubScriptB[7] = (PalScriptMgr *)(LODWORD(m_fExecPosZ) + 76);
    if ( m_fExecPosZ == 0.0 )
      goto LABEL_16;
    goto LABEL_15;
  }
  LODWORD(this->m_fExecPosZ) = LODWORD(m_fExecPosZ) + 76;
  if ( LODWORD(m_fExecPosZ) + 76 != LODWORD(m_fExecPosY) )
  {
    if ( m_fExecPosZ == 0.0 )
    {
LABEL_16:
      result = (int)(&p_m_pSubScriptB[11]->m_bGetSceneScript + 1);
      p_m_pSubScriptB[11] = (PalScriptMgr *)result;
      return result;
    }
LABEL_15:
    qmemcpy((void *)LODWORD(m_fExecPosZ), v29, 0x4Cu);
    goto LABEL_16;
  }
  if ( m_fExecPosZ != 0.0 )
    qmemcpy((void *)LODWORD(m_fExecPosZ), v29, 0x4Cu);
  (((ScriptVM *)p_m_pSubScriptB))->ScriptVM::GetString();
  result = this->m_nWaitCount + 1;
  this->m_nWaitCount = result;
  return result;
}

// 0x0042E100
int PalScriptMgr::CmdPushCmd15(unsigned __int8 pData)
{
  PalScriptMgr **p_m_pSubScriptB; // ebx
  float m_fExecPosZ; // edi
  float m_fExecPosY; // ecx
  int result; // eax
  PalScriptMgr *v7; // esi
  PalScriptMgr *v8; // eax
  float x; // eax
  float v10; // ecx
  PalScriptMgr *v11; // esi
  float v12; // edx
  unsigned int v13; // eax
  PalScriptMgr *v14; // eax
  float v15; // edx
  float v16; // ecx
  PalScriptMgr *v17; // edx
  int v18; // edi
  gbVec3D *RoleName; // eax
  PalScriptMgr *v20; // edi
  float y; // ecx
  float z; // eax
  PalScriptMgr *v23; // ecx
  int v24; // ecx
  gbVec3D v25; // [esp+0xC] [ebp-0x5C] BYREF
  PalScriptMgr *v26; // [esp+0x18] [ebp-0x50]
  _DWORD v27[19]; // [esp+0x1C] [ebp-0x4C] BYREF

  (((CG_Entry *)v27))->CG_Entry::GetCGEntry();
  p_m_pSubScriptB = (PalScriptMgr **)&this->m_pSubScriptB;
  LOBYTE(v27[0]) = 15;
  v27[15] = pData;
  if ( !this->m_nWaitCount
    || (m_fExecPosZ = this->m_fExecPosZ, m_fExecPosY = this->m_fExecPosY, LODWORD(m_fExecPosZ) == LODWORD(m_fExecPosY)) )
  {
    v7 = (PalScriptMgr *)operator new(0xFBCu);
    if ( p_m_pSubScriptB[11] )
    {
      v13 = (unsigned int)p_m_pSubScriptB[8];
      if ( v13 >= (unsigned int)p_m_pSubScriptB[9] + 4 * (_DWORD)p_m_pSubScriptB[10] - 4 )
      {
        v18 = ((int)(v13 - (_DWORD)p_m_pSubScriptB[4]) >> 2) + 1;
        RoleName = (gbVec3D *)(((RoleSystem *)p_m_pSubScriptB))->RoleSystem::GetRoleName(2 * v18);
        v20 = (PalScriptMgr *)(&RoleName->x + v18);
        *(_DWORD *)&v20->m_bGetSceneScript = (_DWORD)v7;
        (((gbVec3D *)&v25))->gbVec3D::Copy((int)p_m_pSubScriptB[3], RoleName);
        y = v25.y;
        p_m_pSubScriptB[1] = (PalScriptMgr *)LODWORD(v25.x);
        z = v25.z;
        *((float *)p_m_pSubScriptB + 2) = y;
        v23 = (PalScriptMgr *)v26;
        *((float *)p_m_pSubScriptB + 3) = z;
        p_m_pSubScriptB[4] = v23;
        v24 = *(_DWORD *)&v20->m_bGetSceneScript + 4028;
        p_m_pSubScriptB[5] = *(PalScriptMgr **)&v20->m_bGetSceneScript;
        p_m_pSubScriptB[6] = (PalScriptMgr *)v24;
        p_m_pSubScriptB[7] = v7;
        p_m_pSubScriptB[8] = v20;
      }
      else
      {
        v14 = (PalScriptMgr *)(v13 + 4);
        p_m_pSubScriptB[8] = v14;
        *(_DWORD *)&v14->m_bGetSceneScript = (_DWORD)v7;
        (((gbVec3D *)&v25))->gbVec3D::Copy((int)v7, (gbVec3D *)p_m_pSubScriptB[8]);
        v15 = v25.y;
        p_m_pSubScriptB[5] = (PalScriptMgr *)LODWORD(v25.x);
        v16 = v25.z;
        *((float *)p_m_pSubScriptB + 6) = v15;
        v17 = (PalScriptMgr *)v26;
        *((float *)p_m_pSubScriptB + 7) = v16;
        p_m_pSubScriptB[8] = v17;
      }
    }
    else
    {
      p_m_pSubScriptB[10] = (PalScriptMgr *)2;
      v8 = (PalScriptMgr *)operator new(8u);
      p_m_pSubScriptB[9] = v8;
      v8->m_script.m_pData = (char *)&v7->m_bGetSceneScript;
      (((gbVec3D *)&v25))->gbVec3D::Copy((int)(&v7->m_ctrlParabola + 15), (gbVec3D *)&p_m_pSubScriptB[9]->m_script);
      x = v25.x;
      v10 = v25.y;
      v11 = (PalScriptMgr *)v26;
      v12 = v25.z;
      p_m_pSubScriptB[1] = (PalScriptMgr *)LODWORD(v25.x);
      *((float *)p_m_pSubScriptB + 2) = v10;
      *((float *)p_m_pSubScriptB + 3) = v12;
      p_m_pSubScriptB[4] = v11;
      *((float *)p_m_pSubScriptB + 5) = x;
      *((float *)p_m_pSubScriptB + 6) = v10;
      *((float *)p_m_pSubScriptB + 7) = v12;
      p_m_pSubScriptB[8] = v11;
    }
    m_fExecPosZ = *((float *)p_m_pSubScriptB + 7);
    p_m_pSubScriptB[7] = (PalScriptMgr *)(LODWORD(m_fExecPosZ) + 76);
    if ( m_fExecPosZ == 0.0 )
      goto LABEL_16;
    goto LABEL_15;
  }
  LODWORD(this->m_fExecPosZ) = LODWORD(m_fExecPosZ) + 76;
  if ( LODWORD(m_fExecPosZ) + 76 != LODWORD(m_fExecPosY) )
  {
    if ( m_fExecPosZ == 0.0 )
    {
LABEL_16:
      result = (int)(&p_m_pSubScriptB[11]->m_bGetSceneScript + 1);
      p_m_pSubScriptB[11] = (PalScriptMgr *)result;
      return result;
    }
LABEL_15:
    qmemcpy((void *)LODWORD(m_fExecPosZ), v27, 0x4Cu);
    goto LABEL_16;
  }
  if ( m_fExecPosZ != 0.0 )
    qmemcpy((void *)LODWORD(m_fExecPosZ), v27, 0x4Cu);
  (((ScriptVM *)p_m_pSubScriptB))->ScriptVM::GetString();
  result = this->m_nWaitCount + 1;
  this->m_nWaitCount = result;
  return result;
}

// 0x0042E2C0
char * PalScriptMgr::CmdCameraOrbitPos(
        
        int nVal,
        float fVal,
        float fVal2,
        unsigned __int8 pData)
{
  float *v6; // eax
  PalScriptMgr **p_m_pSubScriptB; // ebx
  int m_nWaitCount; // eax
  float m_fExecPosZ; // edi
  float m_fExecPosY; // ecx
  char *result; // eax
  char *v12; // esi
  PalScriptMgr *v13; // eax
  float v14; // ecx
  float v15; // edx
  float x; // eax
  PalScriptMgr *v17; // esi
  unsigned int v18; // eax
  PalScriptMgr *v19; // eax
  float v20; // edx
  float v21; // ecx
  PalScriptMgr *v22; // edx
  int v23; // edi
  gbVec3D *RoleName; // eax
  gbVec3D *v25; // edi
  float y; // ecx
  float z; // eax
  PalScriptMgr *v28; // ecx
  float v29; // ecx
  float v30; // eax
  PalScriptMgr *v31; // ecx
  gbVec3D v32; // [esp+0xC] [ebp-0x5C] BYREF
  PalScriptMgr *v33; // [esp+0x18] [ebp-0x50]
  _DWORD v34[19]; // [esp+0x1C] [ebp-0x4C] BYREF

  (((CG_Entry *)v34))->CG_Entry::GetCGEntry();
  LOBYTE(v34[0]) = 16;
  v6 = (((CameraCtrl *)&g_pCameraCtrl))->CameraCtrl::CalcOrbitalPos((float *)&nVal, *(float *)&nVal, fVal, fVal2);
  p_m_pSubScriptB = (PalScriptMgr **)&this->m_pSubScriptB;
  *(float *)&v34[3] = (unsigned long)*v6;
  *(float *)&v34[4] = (unsigned long)v6[1];
  *(float *)&v34[5] = (unsigned long)v6[2];
  m_nWaitCount = this->m_nWaitCount;
  v34[15] = pData;
  if ( !m_nWaitCount
    || (m_fExecPosZ = this->m_fExecPosZ, m_fExecPosY = this->m_fExecPosY, LODWORD(m_fExecPosZ) == LODWORD(m_fExecPosY)) )
  {
    v12 = (char *)operator new(0xFBCu);
    if ( p_m_pSubScriptB[11] )
    {
      v18 = (unsigned int)p_m_pSubScriptB[8];
      if ( v18 >= (unsigned int)p_m_pSubScriptB[9] + 4 * (_DWORD)p_m_pSubScriptB[10] - 4 )
      {
        v23 = ((int)(v18 - (_DWORD)p_m_pSubScriptB[4]) >> 2) + 1;
        RoleName = (gbVec3D *)(((RoleSystem *)p_m_pSubScriptB))->RoleSystem::GetRoleName(2 * v23);
        v25 = (gbVec3D *)((char *)RoleName + 4 * v23);
        LODWORD(v25->x) = (unsigned long)v12;
        (((gbVec3D *)&v32))->gbVec3D::Copy((int)p_m_pSubScriptB[3], RoleName);
        y = v32.y;
        p_m_pSubScriptB[1] = (PalScriptMgr *)LODWORD(v32.x);
        z = v32.z;
        *((float *)p_m_pSubScriptB + 2) = y;
        v28 = (PalScriptMgr *)v33;
        *((float *)p_m_pSubScriptB + 3) = z;
        p_m_pSubScriptB[4] = v28;
        (((gbVec3D *)&v32))->gbVec3D::Copy((int)v12, v25);
        v29 = v32.y;
        p_m_pSubScriptB[5] = (PalScriptMgr *)LODWORD(v32.x);
        v30 = v32.z;
        *((float *)p_m_pSubScriptB + 6) = v29;
        v31 = (PalScriptMgr *)v33;
        *((float *)p_m_pSubScriptB + 7) = v30;
        p_m_pSubScriptB[8] = v31;
      }
      else
      {
        v19 = (PalScriptMgr *)(v18 + 4);
        p_m_pSubScriptB[8] = v19;
        *(_DWORD *)&v19->m_bGetSceneScript = (_DWORD)v12;
        (((gbVec3D *)&v32))->gbVec3D::Copy((int)v12, (gbVec3D *)p_m_pSubScriptB[8]);
        v20 = v32.y;
        p_m_pSubScriptB[5] = (PalScriptMgr *)LODWORD(v32.x);
        v21 = v32.z;
        *((float *)p_m_pSubScriptB + 6) = v20;
        v22 = (PalScriptMgr *)v33;
        *((float *)p_m_pSubScriptB + 7) = v21;
        p_m_pSubScriptB[8] = v22;
      }
    }
    else
    {
      p_m_pSubScriptB[10] = (PalScriptMgr *)2;
      v13 = (PalScriptMgr *)operator new(8u);
      p_m_pSubScriptB[9] = v13;
      v13->m_script.m_pData = v12;
      (((gbVec3D *)&v32))->gbVec3D::Copy((int)(v12 + 1976), (gbVec3D *)&p_m_pSubScriptB[9]->m_script);
      v14 = v32.y;
      v15 = v32.z;
      x = v32.x;
      v17 = (PalScriptMgr *)v33;
      p_m_pSubScriptB[1] = (PalScriptMgr *)LODWORD(v32.x);
      *((float *)p_m_pSubScriptB + 2) = v14;
      *((float *)p_m_pSubScriptB + 3) = v15;
      p_m_pSubScriptB[4] = v17;
      *((float *)p_m_pSubScriptB + 5) = x;
      *((float *)p_m_pSubScriptB + 6) = v14;
      *((float *)p_m_pSubScriptB + 7) = v15;
      p_m_pSubScriptB[8] = v17;
    }
    m_fExecPosZ = *((float *)p_m_pSubScriptB + 7);
    p_m_pSubScriptB[7] = (PalScriptMgr *)(LODWORD(m_fExecPosZ) + 76);
    if ( m_fExecPosZ == 0.0 )
      goto LABEL_16;
    goto LABEL_15;
  }
  LODWORD(this->m_fExecPosZ) = LODWORD(m_fExecPosZ) + 76;
  if ( LODWORD(m_fExecPosZ) + 76 != LODWORD(m_fExecPosY) )
  {
    if ( m_fExecPosZ == 0.0 )
    {
LABEL_16:
      result = (char *)(&p_m_pSubScriptB[11]->m_bGetSceneScript + 1);
      p_m_pSubScriptB[11] = (PalScriptMgr *)result;
      return result;
    }
LABEL_15:
    qmemcpy((void *)LODWORD(m_fExecPosZ), v34, 0x4Cu);
    goto LABEL_16;
  }
  if ( m_fExecPosZ != 0.0 )
    qmemcpy((void *)LODWORD(m_fExecPosZ), v34, 0x4Cu);
  result = (((ScriptVM *)p_m_pSubScriptB))->ScriptVM::GetString();
  ++this->m_nWaitCount;
  return result;
}

// 0x0042E4D0
int PalScriptMgr::CmdRoleMoveSmooth(int nVal, unsigned __int8 pData)
{
  PalScriptMgr **p_m_pSubScriptB; // ebx
  float m_fExecPosZ; // edi
  float m_fExecPosY; // ecx
  int result; // eax
  PalScriptMgr *v8; // esi
  PalScriptMgr *v9; // eax
  float x; // eax
  float v11; // ecx
  PalScriptMgr *v12; // esi
  float v13; // edx
  unsigned int v14; // eax
  PalScriptMgr *v15; // eax
  float v16; // edx
  float v17; // ecx
  PalScriptMgr *v18; // edx
  int v19; // edi
  gbVec3D *RoleName; // eax
  PalScriptMgr *v21; // edi
  float y; // ecx
  float z; // eax
  PalScriptMgr *v24; // ecx
  int v25; // ecx
  gbVec3D v26; // [esp+0xC] [ebp-0x5C] BYREF
  PalScriptMgr *v27; // [esp+0x18] [ebp-0x50]
  _DWORD v28[19]; // [esp+0x1C] [ebp-0x4C] BYREF

  (((CG_Entry *)v28))->CG_Entry::GetCGEntry();
  p_m_pSubScriptB = (PalScriptMgr **)&this->m_pSubScriptB;
  v28[15] = nVal;
  LOBYTE(v28[0]) = 18;
  if ( !this->m_nWaitCount
    || (m_fExecPosZ = this->m_fExecPosZ, m_fExecPosY = this->m_fExecPosY, LODWORD(m_fExecPosZ) == LODWORD(m_fExecPosY)) )
  {
    v8 = (PalScriptMgr *)operator new(0xFBCu);
    if ( p_m_pSubScriptB[11] )
    {
      v14 = (unsigned int)p_m_pSubScriptB[8];
      if ( v14 >= (unsigned int)p_m_pSubScriptB[9] + 4 * (_DWORD)p_m_pSubScriptB[10] - 4 )
      {
        v19 = ((int)(v14 - (_DWORD)p_m_pSubScriptB[4]) >> 2) + 1;
        RoleName = (gbVec3D *)(((RoleSystem *)p_m_pSubScriptB))->RoleSystem::GetRoleName(2 * v19);
        v21 = (PalScriptMgr *)(&RoleName->x + v19);
        *(_DWORD *)&v21->m_bGetSceneScript = (_DWORD)v8;
        (((gbVec3D *)&v26))->gbVec3D::Copy((int)p_m_pSubScriptB[3], RoleName);
        y = v26.y;
        p_m_pSubScriptB[1] = (PalScriptMgr *)LODWORD(v26.x);
        z = v26.z;
        *((float *)p_m_pSubScriptB + 2) = y;
        v24 = (PalScriptMgr *)v27;
        *((float *)p_m_pSubScriptB + 3) = z;
        p_m_pSubScriptB[4] = v24;
        v25 = *(_DWORD *)&v21->m_bGetSceneScript + 4028;
        p_m_pSubScriptB[5] = *(PalScriptMgr **)&v21->m_bGetSceneScript;
        p_m_pSubScriptB[6] = (PalScriptMgr *)v25;
        p_m_pSubScriptB[7] = v8;
        p_m_pSubScriptB[8] = v21;
      }
      else
      {
        v15 = (PalScriptMgr *)(v14 + 4);
        p_m_pSubScriptB[8] = v15;
        *(_DWORD *)&v15->m_bGetSceneScript = (_DWORD)v8;
        (((gbVec3D *)&v26))->gbVec3D::Copy((int)v8, (gbVec3D *)p_m_pSubScriptB[8]);
        v16 = v26.y;
        p_m_pSubScriptB[5] = (PalScriptMgr *)LODWORD(v26.x);
        v17 = v26.z;
        *((float *)p_m_pSubScriptB + 6) = v16;
        v18 = (PalScriptMgr *)v27;
        *((float *)p_m_pSubScriptB + 7) = v17;
        p_m_pSubScriptB[8] = v18;
      }
    }
    else
    {
      p_m_pSubScriptB[10] = (PalScriptMgr *)2;
      v9 = (PalScriptMgr *)operator new(8u);
      p_m_pSubScriptB[9] = v9;
      v9->m_script.m_pData = (char *)&v8->m_bGetSceneScript;
      (((gbVec3D *)&v26))->gbVec3D::Copy((int)(&v8->m_ctrlParabola + 15), (gbVec3D *)&p_m_pSubScriptB[9]->m_script);
      x = v26.x;
      v11 = v26.y;
      v12 = (PalScriptMgr *)v27;
      v13 = v26.z;
      p_m_pSubScriptB[1] = (PalScriptMgr *)LODWORD(v26.x);
      *((float *)p_m_pSubScriptB + 2) = v11;
      *((float *)p_m_pSubScriptB + 3) = v13;
      p_m_pSubScriptB[4] = v12;
      *((float *)p_m_pSubScriptB + 5) = x;
      *((float *)p_m_pSubScriptB + 6) = v11;
      *((float *)p_m_pSubScriptB + 7) = v13;
      p_m_pSubScriptB[8] = v12;
    }
    m_fExecPosZ = *((float *)p_m_pSubScriptB + 7);
    p_m_pSubScriptB[7] = (PalScriptMgr *)(LODWORD(m_fExecPosZ) + 76);
    if ( m_fExecPosZ == 0.0 )
      goto LABEL_16;
    goto LABEL_15;
  }
  LODWORD(this->m_fExecPosZ) = LODWORD(m_fExecPosZ) + 76;
  if ( LODWORD(m_fExecPosZ) + 76 != LODWORD(m_fExecPosY) )
  {
    if ( m_fExecPosZ == 0.0 )
    {
LABEL_16:
      result = (int)(&p_m_pSubScriptB[11]->m_bGetSceneScript + 1);
      p_m_pSubScriptB[11] = (PalScriptMgr *)result;
      return result;
    }
LABEL_15:
    qmemcpy((void *)LODWORD(m_fExecPosZ), v28, 0x4Cu);
    goto LABEL_16;
  }
  if ( m_fExecPosZ != 0.0 )
    qmemcpy((void *)LODWORD(m_fExecPosZ), v28, 0x4Cu);
  (((ScriptVM *)p_m_pSubScriptB))->ScriptVM::GetString();
  result = this->m_nWaitCount + 1;
  this->m_nWaitCount = result;
  return result;
}

// 0x0042E6C0
int PalScriptMgr::CmdRoleMoveDirect(unsigned __int8 pData)
{
  int m_nWaitCount; // eax
  PalScriptMgr **p_m_pSubScriptB; // ebx
  float m_fExecPosZ; // edi
  float m_fExecPosY; // ecx
  int result; // eax
  PalScriptMgr *v8; // esi
  PalScriptMgr *v9; // eax
  float x; // eax
  float v11; // edx
  float v12; // ecx
  PalScriptMgr *v13; // esi
  unsigned int v14; // eax
  PalScriptMgr *v15; // eax
  float v16; // eax
  float v17; // edx
  PalScriptMgr *v18; // eax
  int v19; // edi
  gbVec3D *RoleName; // eax
  PalScriptMgr *v21; // edi
  float y; // edx
  float z; // ecx
  PalScriptMgr *v24; // edx
  int v25; // ecx
  gbVec3D v26; // [esp+0xC] [ebp-0x5C] BYREF
  PalScriptMgr *v27; // [esp+0x18] [ebp-0x50]
  char v28[76]; // [esp+0x1C] [ebp-0x4C] BYREF

  (((CG_Entry *)v28))->CG_Entry::GetCGEntry();
  m_nWaitCount = this->m_nWaitCount;
  p_m_pSubScriptB = (PalScriptMgr **)&this->m_pSubScriptB;
  v28[0] = 19;
  if ( !m_nWaitCount
    || (m_fExecPosZ = this->m_fExecPosZ, m_fExecPosY = this->m_fExecPosY, LODWORD(m_fExecPosZ) == LODWORD(m_fExecPosY)) )
  {
    v8 = (PalScriptMgr *)operator new(0xFBCu);
    if ( p_m_pSubScriptB[11] )
    {
      v14 = (unsigned int)p_m_pSubScriptB[8];
      if ( v14 >= (unsigned int)p_m_pSubScriptB[9] + 4 * (_DWORD)p_m_pSubScriptB[10] - 4 )
      {
        v19 = ((int)(v14 - (_DWORD)p_m_pSubScriptB[4]) >> 2) + 1;
        RoleName = (gbVec3D *)(((RoleSystem *)p_m_pSubScriptB))->RoleSystem::GetRoleName(2 * v19);
        v21 = (PalScriptMgr *)(&RoleName->x + v19);
        *(_DWORD *)&v21->m_bGetSceneScript = (_DWORD)v8;
        (((gbVec3D *)&v26))->gbVec3D::Copy((int)p_m_pSubScriptB[3], RoleName);
        y = v26.y;
        p_m_pSubScriptB[1] = (PalScriptMgr *)LODWORD(v26.x);
        z = v26.z;
        *((float *)p_m_pSubScriptB + 2) = y;
        v24 = (PalScriptMgr *)v27;
        *((float *)p_m_pSubScriptB + 3) = z;
        p_m_pSubScriptB[4] = v24;
        v25 = *(_DWORD *)&v21->m_bGetSceneScript + 4028;
        p_m_pSubScriptB[5] = *(PalScriptMgr **)&v21->m_bGetSceneScript;
        p_m_pSubScriptB[6] = (PalScriptMgr *)v25;
        p_m_pSubScriptB[7] = v8;
        p_m_pSubScriptB[8] = v21;
      }
      else
      {
        v15 = (PalScriptMgr *)(v14 + 4);
        p_m_pSubScriptB[8] = v15;
        *(_DWORD *)&v15->m_bGetSceneScript = (_DWORD)v8;
        (((gbVec3D *)&v26))->gbVec3D::Copy((int)v8, (gbVec3D *)p_m_pSubScriptB[8]);
        v16 = v26.y;
        p_m_pSubScriptB[5] = (PalScriptMgr *)LODWORD(v26.x);
        v17 = v26.z;
        *((float *)p_m_pSubScriptB + 6) = v16;
        v18 = (PalScriptMgr *)v27;
        *((float *)p_m_pSubScriptB + 7) = v17;
        p_m_pSubScriptB[8] = v18;
      }
    }
    else
    {
      p_m_pSubScriptB[10] = (PalScriptMgr *)2;
      v9 = (PalScriptMgr *)operator new(8u);
      p_m_pSubScriptB[9] = v9;
      v9->m_script.m_pData = (char *)&v8->m_bGetSceneScript;
      (((gbVec3D *)&v26))->gbVec3D::Copy((int)(&v8->m_ctrlParabola + 15), (gbVec3D *)&p_m_pSubScriptB[9]->m_script);
      x = v26.x;
      v11 = v26.z;
      v12 = v26.y;
      v13 = (PalScriptMgr *)v27;
      p_m_pSubScriptB[1] = (PalScriptMgr *)LODWORD(v26.x);
      *((float *)p_m_pSubScriptB + 2) = v12;
      *((float *)p_m_pSubScriptB + 3) = v11;
      p_m_pSubScriptB[4] = v13;
      *((float *)p_m_pSubScriptB + 5) = x;
      *((float *)p_m_pSubScriptB + 6) = v12;
      *((float *)p_m_pSubScriptB + 7) = v11;
      p_m_pSubScriptB[8] = v13;
    }
    m_fExecPosZ = *((float *)p_m_pSubScriptB + 7);
    p_m_pSubScriptB[7] = (PalScriptMgr *)(LODWORD(m_fExecPosZ) + 76);
    if ( m_fExecPosZ == 0.0 )
      goto LABEL_16;
    goto LABEL_15;
  }
  LODWORD(this->m_fExecPosZ) = LODWORD(m_fExecPosZ) + 76;
  if ( LODWORD(m_fExecPosZ) + 76 != LODWORD(m_fExecPosY) )
  {
    if ( m_fExecPosZ == 0.0 )
    {
LABEL_16:
      result = (int)(&p_m_pSubScriptB[11]->m_bGetSceneScript + 1);
      p_m_pSubScriptB[11] = (PalScriptMgr *)result;
      return result;
    }
LABEL_15:
    qmemcpy((void *)LODWORD(m_fExecPosZ), v28, 0x4Cu);
    goto LABEL_16;
  }
  if ( m_fExecPosZ != 0.0 )
    qmemcpy((void *)LODWORD(m_fExecPosZ), v28, 0x4Cu);
  (((ScriptVM *)p_m_pSubScriptB))->ScriptVM::GetString();
  result = this->m_nWaitCount + 1;
  this->m_nWaitCount = result;
  return result;
}

// 0x0042EBE0
int PalScriptMgr::ExecuteOpcode()
{
  int result; // eax
  char *m_pScriptBlock; // edi
  PalScriptMgr *p_m_pSubScriptB; // ecx
  int v5; // edx
  char *v6; // eax
  unsigned __int8 v7; // al
  RoleSystem *m_pSceneMgr; // ecx
  int v9; // edx
  char *v10; // edx
  int v11; // ecx
  char *v12; // eax
  int *v13; // eax
  char *v14; // ecx
  RoleSystem *v15; // esi
  CScreenMode *v16; // ecx
  char *v17; // eax
  char *v18; // edi
  int v19; // edx
  PtrArray *SoundList; // eax
  RoleSystem *v21; // esi
  int v22; // ebx
  int v23; // ebp
  int *v24; // edx
  int *p_m_nExecuteOpcode; // eax
  double v26; // st7
  int RolePtr; // ebx
  double v28; // st7
  float v29; // ebp
  __int64 v30; // rax
  double v31; // st7
  int v32; // ecx
  float z; // ecx
  double v34; // st7
  double v35; // st7
  double v36; // st7
  char *v37; // edx
  int v38; // ecx
  char *v39; // eax
  float v40; // eax
  float v41; // edx
  float v42; // ecx
  char *v43; // edi
  float v44; // eax
  float v45; // edx
  char *v46; // eax
  char *v47; // eax
  char *v48; // edx
  int v49; // ecx
  char *v50; // eax
  float y; // ecx
  float v52; // edx
  float x; // eax
  char *v54; // edi
  float v55; // edx
  float v56; // ecx
  char *v57; // edx
  char *v58; // [esp-0x4] [ebp-0x8C]
  char *m_pClearResult; // [esp-0x4] [ebp-0x8C]
  char *v60; // [esp-0x4] [ebp-0x8C]
  char *m_pWaitObj; // [esp-0x4] [ebp-0x8C]
  gbVec3D nVal2; // [esp+0x10] [ebp-0x78] BYREF
  char *v63; // [esp+0x1C] [ebp-0x6C]
  gbVec3D v64; // [esp+0x20] [ebp-0x68] BYREF
  gbVec3D v65; // [esp+0x2C] [ebp-0x5C] BYREF
  char *m_pExecObj; // [esp+0x38] [ebp-0x50]
  gbMatrix4 pMatrix; // [esp+0x3C] [ebp-0x4C] BYREF
  float v68; // [esp+0x7C] [ebp-0xC]
  float v69; // [esp+0x84] [ebp-0x4]

  result = this->m_nWaitCount;
  if ( result )
  {
    while ( 2 )
    {
      LODWORD(v65.x) = this->m_nScriptCamX;
      LODWORD(v65.y) = this->m_nScriptCamY;
      m_pScriptBlock = (char *)this->m_pScriptBlock;
      m_pExecObj = (char *)this->m_pExecObj;
      result = (unsigned __int8)*m_pScriptBlock - 2;
      switch ( *m_pScriptBlock )
      {
        case 2:
          v15 = (RoleSystem *)((RoleSystem *)&stru_C10DF0)->m_teamSlotOverlay.m_teamSlots[154];
          (((RoleSystem *)((RoleSystem *)&stru_C10DF0)->m_teamSlotOverlay.m_teamSlots[154]))->RoleSystem::Notify();
          (((RoleSystem *)v15))->RoleSystem::GetMoveState();
          (((RoleSystem *)v15))->RoleSystem::SetMoveTarget((float *)m_pScriptBlock + 6, 1);
          return result;
        case 3:
          this->PalScriptMgr::SetBigMapState(m_pScriptBlock[60]);
          result = *((_DWORD *)m_pScriptBlock + 16);
          goto LABEL_4;
        case 4:
          (*((PalScriptMgr **)m_pScriptBlock + 16))->PalScriptMgr::Destroy();
          this->m_pClearResult = v17;
          if ( !*((_DWORD *)m_pScriptBlock + 15) )
          {
            v18 = this->m_pScriptBlock + 76;
            v19 = this->m_nWaitCount - 1;
            this->m_pScriptBlock = v18;
            this->m_nWaitCount = v19;
            if ( !v19 || v18 == (char *)this->m_nScriptCamY )
              (((PalScriptMgr *)&this->m_pSubScriptB))->PalScriptMgr::PopScript();
            this->PalScriptMgr::ExecuteOpcode();
          }
          m_pClearResult = (char *)this->m_pClearResult;
          SoundList = (((CScreenMode *)v16))->CScreenMode::GetSoundList();
          (((PtrArray *)SoundList))->PtrArray::SetResolution(0, (int)m_pClearResult);
          return result;
        case 5:
          this->PalScriptMgr::ExecuteScriptByID();
          result = *((_DWORD *)m_pScriptBlock + 15);
LABEL_4:
          if ( !result )
            goto LABEL_5;
          return result;
        case 6:
          v21 = (RoleSystem *)((RoleSystem *)&stru_C10DF0)->m_teamSlotOverlay.m_teamSlots[154];
          (((RoleSystem *)((RoleSystem *)&stru_C10DF0)->m_teamSlotOverlay.m_teamSlots[154]))->RoleSystem::Notify();
          return (((RoleSystem *)v21))->RoleSystem::GetActionByIndex(*((_DWORD *)m_pScriptBlock + 15));
        case 7:
          (*(void ( **)(char *, _DWORD))(*(_DWORD *)this->m_pExecSystem + 24))(this->m_pExecSystem, 0);
          (((gbVisNode *)this->m_pExecSystem))->gbVisNode::SetTimeScale(2.0);
          return result;
        case 8:
          (*((_DWORD *)m_pScriptBlock + 15))->CameraCtrl::AttachToRole();
          goto LABEL_5;
        case 9:
          (((RoleSystem *)this))->RoleSystem::ProcessAction() /* [ROWTABLE] */;
          goto LABEL_5;
        case 10:
          this->m_bOpcodeFlag = m_pScriptBlock[60];
          goto LABEL_5;
        case 11:
          (((RoleSystem *)((RoleSystem *)&stru_C10DF0)->m_teamSlotOverlay.m_teamSlots[154]))->RoleSystem::IsPathComplete((float *)m_pScriptBlock + 3, 1);
          goto LABEL_5;
        case 12:
          v22 = ((RoleSystem *)&stru_C10DF0)->m_teamSlotOverlay.m_teamSlots[154];
          (((RoleSystem *)((RoleSystem *)&stru_C10DF0)->m_teamSlotOverlay.m_teamSlots[154]))->RoleSystem::Notify();
          v23 = 0;
          *(_DWORD *)(v22 + 4552) = this->m_nScriptDepth + 1;
          *(_DWORD *)(v22 + 1480) = *(_DWORD *)(v22 + 160);
          *(_DWORD *)(v22 + 1484) = *(_DWORD *)(v22 + 164);
          *(_DWORD *)(v22 + 1488) = *(_DWORD *)(v22 + 168);
          if ( this->m_nScriptDepth > 0 )
          {
            v24 = (int *)(v22 + 1500);
            p_m_nExecuteOpcode = (int *)&this->m_nExecuteOpcode;
            do
            {
              ++v23;
              *(v24 - 2) = *(p_m_nExecuteOpcode - 2);
              *(v24 - 1) = *(p_m_nExecuteOpcode - 1);
              *v24 = *p_m_nExecuteOpcode;
              p_m_nExecuteOpcode += 3;
              v24 += 3;
            }
            while ( v23 < this->m_nScriptDepth );
          }
          (((PathObj *)(v22 + 1480)))->PathObj::CalcLength();
          v26 = *(float *)(v22 + 4556) * 0.0016666667;
          *((_DWORD *)m_pScriptBlock + 2) = 0;
          *((float *)m_pScriptBlock + 1) = v26;
          *(_DWORD *)(v22 + 1284) = 2;
          (((RoleSystem *)v22))->RoleSystem::UpdateTransform();
          return (((RoleSystem *)v22))->RoleSystem::GetMoveState();
        case 13:
          RolePtr = (((RoleSystem *)this->m_pSceneMgr->m_rect.left))->RoleSystem::GetRolePtr((unsigned __int8)this->m_bExecuteOpcode);
          v28 = this->m_fCamZ - *(float *)(RolePtr + 136);
          LODWORD(v29) = (__int64)((this->m_fCamX - *(float *)(RolePtr + 128)) / g_ScriptSystemData.m_fScriptTileSize2);
          nVal2.x = v29;
          v30 = (__int64)(v28 / g_ScriptSystemData.m_fScriptTileSize2);
          v31 = 0.0;
          LODWORD(nVal2.y) = v30;
          v64.x = ((double)SLODWORD(v29) + 0.5) * g_ScriptSystemData.m_fScriptTileSize2 + *(float *)(RolePtr + 128);
          v64.z = ((double)(int)v30 + 0.5) * g_ScriptSystemData.m_fScriptTileSize2 + *(float *)(RolePtr + 136);
          if ( v29 >= 0.0 )
          {
            v32 = *(_DWORD *)(RolePtr + 152);
            if ( SLODWORD(v29) < v32 && (int)v30 >= 0 && (int)v30 < *(_DWORD *)(RolePtr + 156) )
              v31 = *(float *)(*(_DWORD *)(RolePtr + 160) + 8 * (LODWORD(v29) + v30 * v32));
          }
          result = LODWORD(v64.x);
          z = v64.z;
          *((float *)m_pScriptBlock + 4) = v31;
          *((_DWORD *)m_pScriptBlock + 3) = result;
          *((float *)m_pScriptBlock + 5) = z;
          *((float *)m_pScriptBlock + 4) = *((float *)m_pScriptBlock + 4) - 4.0;
          return result;
        case 14:
          (((RoleSystem *)((RoleSystem *)&stru_C10DF0)->m_teamSlotOverlay.m_teamSlots[154]))->RoleSystem::NotifySceneChange();
          if ( *((_DWORD *)m_pScriptBlock + 16) )
          {
            v7 = m_pScriptBlock[60];
            m_pSceneMgr = (RoleSystem *)this->m_pSceneMgr;
            this->m_bExecuteOpcode = v7;
            this->m_pSceneMgr = (RoleSystem *)(((RoleSystem *)m_pSceneMgr->m_rect.left))->RoleSystem::NotifyPathEnd(v7);
          }
          goto LABEL_5;
        case 15:
          *((_DWORD *)&g_pCameraCtrl->m_nextYAW + 1) = *((_DWORD *)m_pScriptBlock + 15);
          goto LABEL_5;
        case 16:
          if ( *((_DWORD *)m_pScriptBlock + 15) )
          {
            v64.x = g_pCameraCtrl->m_vecLookAt.x - *((float *)m_pScriptBlock + 3);
            v34 = g_pCameraCtrl->m_vecLookAt.y - *((float *)m_pScriptBlock + 4);
            nVal2.x = v64.x;
            v64.y = v34;
            v35 = g_pCameraCtrl->m_vecLookAt.z - *((float *)m_pScriptBlock + 5);
            nVal2.y = v64.y;
            v64.z = v35;
            nVal2.z = v64.z;
            nVal2.x = (((gbVec3D *)&nVal2))->gbVec3D::Length() * 0.02;
            return (((CameraCtrl *)&((GRPinput *)&stru_D8C2B8)->KeyInfo[153]))->CameraCtrl::SetupLerp((int)g_pCameraCtrl, (int *)m_pScriptBlock + 3, SLODWORD(nVal2.x), 1);
          }
          else
          {
            g_pCameraCtrl->m_vecLookAt = *(gbVec3D *)(m_pScriptBlock + 1);
            InputSystem::ProcessKeyboard((InputSystem *)g_pCameraCtrl);
          }
          return result;
        case 17:
          this->m_szScriptFile[5] = m_pScriptBlock[60];
LABEL_5:
          p_m_pSubScriptB = (PalScriptMgr *)&this->m_pSubScriptB;
          v5 = this->m_nWaitCount - 1;
          v6 = this->m_pScriptBlock + 76;
          this->m_pScriptBlock = v6;
          this->m_nWaitCount = v5;
          if ( v5 )
            goto LABEL_17;
          goto LABEL_18;
        case 18:
          this->PalScriptMgr::RunCommand(*((_DWORD *)m_pScriptBlock + 15));
          p_m_pSubScriptB = (PalScriptMgr *)&this->m_pSubScriptB;
          v9 = this->m_nWaitCount - 1;
          v6 = this->m_pScriptBlock + 76;
          this->m_pScriptBlock = v6;
          this->m_nWaitCount = v9;
          if ( !v9 )
            goto LABEL_18;
LABEL_17:
          if ( v6 == (char *)p_m_pSubScriptB->m_script.capacity )
LABEL_18:
            (((PalScriptMgr *)p_m_pSubScriptB))->PalScriptMgr::PopScript();
LABEL_26:
          result = this->m_nWaitCount;
          if ( !result )
            return result;
          continue;
        case 19:
          v64.x = this->m_fCamX;
          v64.z = this->m_fCamZ;
          v64.y = 0.0;
          v64.x = v64.x - *(float *)(((RoleSystem *)&stru_C10DF0)->m_teamSlotOverlay.m_teamSlots[154] + 4);
          v64.y = -*(float *)(((RoleSystem *)&stru_C10DF0)->m_teamSlotOverlay.m_teamSlots[154] + 8);
          v64.z = v64.z - *(float *)(((RoleSystem *)&stru_C10DF0)->m_teamSlotOverlay.m_teamSlots[154] + 12);
          nVal2.x = (((gbVec3D *)&v64))->gbVec3D::Length();
          /* [MISATTRIBUTED] Object3D on PalScriptMgr::this -> fix IDB name of callee */ Object3D::SetTransform((Object3D *)this, &pMatrix);
          if ( v69 <= (double)v68 )
            v36 = v68;
          else
            v36 = v69;
          if ( nVal2.x - v36 * 0.5 <= g_ScriptSystemData.m_fTimerB )
          {
            v48 = this->m_pScriptBlock + 76;
            v49 = this->m_nWaitCount - 1;
            this->m_pScriptBlock = v48;
            this->m_nWaitCount = v49;
            if ( !v49 || v48 == (char *)this->m_nScriptCamY )
            {
              v50 = (char *)this->m_pExecObj;
              this->m_pExecObj = v50 + 4;
              operator delete(*(void **)v50);
              if ( !this->m_nWaitCount )
              {
                (((PalScriptMgr *)&v65))->PalScriptMgr::Get_result();
                y = v65.y;
                v52 = v65.z;
                x = v65.x;
                v54 = (char *)m_pExecObj;
                this->m_nScriptCamX = LODWORD(v65.x);
                *(float *)&this->m_nScriptCamY = y;
                *(float *)&this->m_pScriptBlock = v52;
                this->m_pExecObj = v54;
                this->m_fExecParam = x;
                this->m_fExecPosY = y;
                m_pWaitObj = (char *)this->m_pWaitObj;
                this->m_fExecPosZ = v52;
                this->m_nExecState2 = (int)v54;
                operator delete(m_pWaitObj);
                return this->PalScriptMgr::ExecuteOpcode();
              }
              (((gbVec3D *)&v65))->gbVec3D::Copy(*(_DWORD *)this->m_pExecObj, (gbVec3D *)this->m_pExecObj);
              v55 = v65.y;
              this->m_nScriptCamX = LODWORD(v65.x);
              v56 = v65.z;
              *(float *)&this->m_nScriptCamY = v55;
              v57 = (char *)m_pExecObj;
              *(float *)&this->m_pScriptBlock = v56;
              this->m_pExecObj = v57;
            }
            result = this->PalScriptMgr::ExecuteOpcode();
          }
          else
          {
            while ( this->m_nWaitCount )
            {
              v37 = this->m_pScriptBlock + 76;
              v38 = this->m_nWaitCount - 1;
              this->m_pScriptBlock = v37;
              this->m_nWaitCount = v38;
              if ( !v38 || v37 == (char *)this->m_nScriptCamY )
              {
                v39 = (char *)this->m_pExecObj;
                this->m_pExecObj = v39 + 4;
                operator delete(*(void **)v39);
                if ( this->m_nWaitCount )
                {
                  (((gbVec3D *)&v65))->gbVec3D::Copy(*(_DWORD *)this->m_pExecObj, (gbVec3D *)this->m_pExecObj);
                  v44 = v65.y;
                  this->m_nScriptCamX = LODWORD(v65.x);
                  v45 = v65.z;
                  *(float *)&this->m_nScriptCamY = v44;
                  v46 = (char *)m_pExecObj;
                  *(float *)&this->m_pScriptBlock = v45;
                  this->m_pExecObj = v46;
                }
                else
                {
                  (((PalScriptMgr *)&nVal2))->PalScriptMgr::Get_result();
                  v40 = nVal2.x;
                  v41 = nVal2.z;
                  v42 = nVal2.y;
                  v43 = (char *)v63;
                  this->m_nScriptCamX = LODWORD(nVal2.x);
                  *(float *)&this->m_nScriptCamY = v42;
                  *(float *)&this->m_pScriptBlock = v41;
                  this->m_pExecObj = v43;
                  this->m_fExecParam = v40;
                  this->m_fExecPosY = v42;
                  this->m_fExecPosZ = v41;
                  v60 = (char *)this->m_pWaitObj;
                  this->m_nExecState2 = (int)v43;
                  operator delete(v60);
                }
              }
            }
            v47 = (((PalScript *)g_PAL3_Instance.m_nTodo_140))->PalScript::SetAppName("outdist");
            result = (((PalScriptMgr *)&stru_DBA134))->PalScriptMgr::ShowTextBox(v47);
          }
          break;
        case 21:
          if ( *((_DWORD *)&g_pCameraCtrl->m_nextYAW + 1) )
            (((_Console *)g_pCameraCtrl))->_Console::SetActive(((RoleSystem *)&stru_C10DF0)->m_teamSlotOverlay.m_teamSlots[154]);
          v10 = this->m_pScriptBlock + 76;
          v11 = this->m_nWaitCount - 1;
          this->m_pScriptBlock = v10;
          this->m_nWaitCount = v11;
          if ( !v11 || v10 == (char *)this->m_nScriptCamY )
          {
            v12 = (char *)this->m_pExecObj;
            this->m_pExecObj = v12 + 4;
            operator delete(*(void **)v12);
            if ( this->m_nWaitCount )
            {
              v13 = (int *)this->m_pExecObj;
              v14 = (char *)*v13;
              this->m_nScriptCamX = *v13;
              this->m_nScriptCamY = (int)(v14 + 4028);
              this->m_pScriptBlock = v14;
              this->m_pExecObj = (char *)v13;
            }
            else
            {
              this->m_nScriptCamX = 0;
              this->m_nScriptCamY = 0;
              this->m_pScriptBlock = 0;
              this->m_pExecObj = 0;
              this->m_fExecParam = 0.0;
              v58 = (char *)this->m_pWaitObj;
              this->m_fExecPosY = 0.0;
              this->m_fExecPosZ = 0.0;
              this->m_nExecState2 = 0;
              operator delete(v58);
            }
          }
          goto LABEL_26;
        default:
          return result;
      }
      break;
    }
  }
  return result;
}

// 0x0042F460
void PalScriptMgr::ExecuteFrame(float fVal)
{
  bool IsRunning; // bl
  int m_nScriptCamY; // edx
  char *m_pScriptBlock; // ebp
  double v6; // st7
  int *p_m_fCamX; // esi
  long double v8; // st7
  int v9; // edx
  char m_nCmdType; // al
  int v11; // esi
  double v12; // st7
  int RolePtr; // ebx
  int v14; // eax
  int v15; // ecx
  int v16; // ebp
  bool v17; // zf
  BOOL IsAngleBelowTarget; // eax
  PalScript *v19; // eax
  ScriptVM *v20; // eax
  int v21; // eax
  BOOL IsVisible; // eax
  int v23; // esi
  double v24; // st7
  float v25; // eax
  char *v26; // edx
  int v27; // ecx
  char *v28; // eax
  int *v29; // eax
  char *v30; // ecx
  float pPos; // [esp+0x0] [ebp-0x40]
  int v32; // [esp+0x8] [ebp-0x38]
  char *m_pWaitObj; // [esp+0x8] [ebp-0x38]
  int v34; // [esp+0xC] [ebp-0x34]
  int nFlag; // [esp+0x1C] [ebp-0x24]
  float pfVal; // [esp+0x24] [ebp-0x1C] BYREF
  float v37; // [esp+0x28] [ebp-0x18]
  float v38; // [esp+0x2C] [ebp-0x14]
  int p_DWORD; // [esp+0x30] [ebp-0x10] BYREF
  float v40; // [esp+0x34] [ebp-0xC]
  float v41; // [esp+0x38] [ebp-0x8]
  char *m_pExecObj; // [esp+0x3C] [ebp-0x4]

  if ( this->m_nWaitCount )
  {
    IsRunning = 0;
    p_DWORD = this->m_nScriptCamX;
    m_nScriptCamY = this->m_nScriptCamY;
    v40 = *(float *)&m_nScriptCamY;
    m_pScriptBlock = (char *)this->m_pScriptBlock;
    v6 = fVal + *((float *)m_pScriptBlock + 2);
    m_pExecObj = (char *)this->m_pExecObj;
    *((float *)m_pScriptBlock + 2) = v6;
    if ( v6 >= *((float *)m_pScriptBlock + 1) )
    {
      IsRunning = 1;
      *((_DWORD *)m_pScriptBlock + 2) = *((_DWORD *)m_pScriptBlock + 1);
    }
    *(float *)&nFlag = *((float *)m_pScriptBlock + 2) / *((float *)m_pScriptBlock + 1);
    switch ( *m_pScriptBlock )
    {
      case 1:
        p_m_fCamX = (int *)&this->m_fCamX;
        v8 = (1.0 - cos(*(float *)&nFlag * 3.1415927)) * 0.5;
        this->m_fCamX = *((float *)m_pScriptBlock + 3) * (1.0 - v8) + *((float *)m_pScriptBlock + 6) * v8;
        this->m_fCamY = *((float *)m_pScriptBlock + 4) * (1.0 - v8) + *((float *)m_pScriptBlock + 7) * v8;
        this->m_fCamZ = *((float *)m_pScriptBlock + 5) * (1.0 - v8) + *((float *)m_pScriptBlock + 8) * v8;
        if ( *((_DWORD *)m_pScriptBlock + 15) )
        {
          (((RoleSystem *)((RoleSystem *)&stru_C10DF0)->m_teamSlotOverlay.m_teamSlots[154]))->RoleSystem::SetTargetRotation((gbVec3D *)&this->m_fCamX);
          v9 = ((RoleSystem *)&stru_C10DF0)->m_teamSlotOverlay.m_teamSlots[154];
          *(_DWORD *)(((RoleSystem *)&stru_C10DF0)->m_teamSlotOverlay.m_teamSlots[154] + 160) = (unsigned long)*p_m_fCamX;
          *(float *)(v9 + 164) = this->m_fCamY;
          *(float *)(v9 + 168) = this->m_fCamZ;
        }
        if ( *((_DWORD *)m_pScriptBlock + 16) )
        {
          this->m_nExecuteBlock = *p_m_fCamX;
          this->m_nSavedDataA = LODWORD(this->m_fCamY);
          this->m_nSavedDataB = LODWORD(this->m_fCamZ);
        }
        m_nCmdType = this->m_nCmdType;
        if ( m_nCmdType == 33 || m_nCmdType == 29 )
          (((RoleSystem *)((RoleSystem *)&stru_C10DF0)->m_teamSlotOverlay.m_teamSlots[154]))->RoleSystem::SetMoveSpeed(0.0, 0, v34);
        goto LABEL_40;
      case 2:
        v11 = ((RoleSystem *)&stru_C10DF0)->m_teamSlotOverlay.m_teamSlots[154];
        (((RoleSystem *)((RoleSystem *)&stru_C10DF0)->m_teamSlotOverlay.m_teamSlots[154]))->RoleSystem::PathFollowUpdate();
        if ( *(_DWORD *)(v11 + 1268) == 4 )
        {
          *(_DWORD *)(v11 + 1296) = *(_DWORD *)(v11 + 1308);
          *(_DWORD *)(v11 + 1300) = *(_DWORD *)(v11 + 1312);
          *(_DWORD *)(v11 + 1304) = *(_DWORD *)(v11 + 1316);
          *(_DWORD *)(v11 + 1300) = 0;
          *(_DWORD *)(v11 + 8692) = *(_DWORD *)(v11 + 4);
          *(_DWORD *)(v11 + 8696) = *(_DWORD *)(v11 + 8);
          *(_DWORD *)(v11 + 8700) = *(_DWORD *)(v11 + 12);
          v12 = fVal * *(float *)(v11 + 1296);
          v40 = fVal * *(float *)(v11 + 1300);
          v41 = fVal * *(float *)(v11 + 1304);
          *(float *)(v11 + 8692) = v12 + *(float *)(v11 + 8692);
          *(float *)(v11 + 8696) = v40 + *(float *)(v11 + 8696);
          *(float *)(v11 + 8700) = v41 + *(float *)(v11 + 8700);
          if ( *((_DWORD *)m_pScriptBlock + 15) )
          {
            RolePtr = (((RoleSystem *)this->m_pSceneMgr->m_rect.left))->RoleSystem::GetRolePtr(*(_DWORD *)(v11 + 628));
            if ( !(((RoleSystem *)this->m_pSceneMgr->m_rect.left))->RoleSystem::CheckCollision(*(int **)(v11 + 628), (__int64)((*(float *)(v11 + 8692) - *(float *)(RolePtr + 128)) / g_ScriptSystemData.m_fScriptTileSize2)) )
            {
              (((RoleSystem *)v11))->RoleSystem::NotifyMoveComplete();
              *(_DWORD *)(v11 + 8692) = *(_DWORD *)(v11 + 4);
              *(_DWORD *)(v11 + 8696) = *(_DWORD *)(v11 + 8);
              *(_DWORD *)(v11 + 8700) = *(_DWORD *)(v11 + 12);
            }
          }
          *(_DWORD *)(v11 + 4) = *(_DWORD *)(v11 + 8692);
          *(_DWORD *)(v11 + 8) = *(_DWORD *)(v11 + 8696);
          *(_DWORD *)(v11 + 12) = *(_DWORD *)(v11 + 8700);
          *(_DWORD *)(v11 + 8) = 0;
          (((RoleSystem *)v11))->RoleSystem::UpdatePosition();
          if ( *((_DWORD *)m_pScriptBlock + 16) )
          {
            (((RoleSystem *)v11))->RoleSystem::SetMoveSpeed(0.0, 0, v34);
          }
          else
          {
            v14 = *(_DWORD *)(v11 + 12);
            v15 = *(_DWORD *)(v11 + 4);
            *(_DWORD *)(v11 + 160) = v15;
            *(_DWORD *)(v11 + 168) = v14;
            *(_DWORD *)(v11 + 148) = v15;
            *(_DWORD *)(v11 + 152) = *(_DWORD *)(v11 + 164);
            *(_DWORD *)(v11 + 156) = *(_DWORD *)(v11 + 168);
          }
        }
        IsRunning = *(_DWORD *)(v11 + 1268) != 4;
        if ( *(_DWORD *)(v11 + 1268) == 4 )
          return;
        (((RoleSystem *)v11))->RoleSystem::GetMoveState();
        goto LABEL_40;
      case 3:
        v16 = *((_DWORD *)m_pScriptBlock + 15) - 1;
        if ( v16 )
        {
          if ( v16 == 1 )
          {
            v17 = this->m_bBigMapState == 0;
LABEL_39:
            IsRunning = v17;
          }
        }
        else
        {
          IsRunning = this->m_bBigMapState != 1;
        }
LABEL_40:
        if ( !IsRunning )
          return;
LABEL_41:
        v26 = this->m_pScriptBlock + 76;
        v27 = this->m_nWaitCount - 1;
        this->m_pScriptBlock = v26;
        this->m_nWaitCount = v27;
        if ( v27 && v26 != (char *)this->m_nScriptCamY )
          goto LABEL_46;
        v28 = (char *)this->m_pExecObj;
        this->m_pExecObj = v28 + 4;
        operator delete(*(void **)v28);
        if ( this->m_nWaitCount )
        {
          v29 = (int *)this->m_pExecObj;
          v30 = (char *)*v29;
          this->m_nScriptCamX = *v29;
          this->m_nScriptCamY = (int)(v30 + 4028);
          this->m_pScriptBlock = v30;
          this->m_pExecObj = (char *)v29;
LABEL_46:
          this->PalScriptMgr::ExecuteOpcode();
        }
        else
        {
          this->m_nScriptCamX = 0;
          this->m_nScriptCamY = 0;
          this->m_pScriptBlock = 0;
          this->m_pExecObj = 0;
          this->m_fExecParam = 0.0;
          m_pWaitObj = (char *)this->m_pWaitObj;
          this->m_fExecPosY = 0.0;
          this->m_fExecPosZ = 0.0;
          this->m_nExecState2 = 0;
          operator delete(m_pWaitObj);
          this->PalScriptMgr::ExecuteOpcode();
        }
        break;
      case 4:
        this->PalScriptMgr::ClearAllScript();
        goto LABEL_38;
      case 5:
        LOWORD(m_nScriptCamY) = this->m_nScriptID;
        v32 = m_nScriptCamY;
        v19 = (PalScript *)UISceneUpdate();
        (((PalScript *)v19))->PalScript::SetAction(v32);
        if ( !v20 )
          goto LABEL_41;
        IsRunning = (((ScriptVM *)v20))->ScriptVM::IsRunning();
        goto LABEL_40;
      case 6:
        v21 = (*(int ( **)(int))(*(_DWORD *)(((RoleSystem *)&stru_C10DF0)->m_teamSlotOverlay.m_teamSlots[154] + 56)
                                                    + 4))(((RoleSystem *)&stru_C10DF0)->m_teamSlotOverlay.m_teamSlots[154] + 56);
        IsRunning = v21 == 1;
        if ( v21 != 1 )
          return;
        (((RoleSystem *)((RoleSystem *)&stru_C10DF0)->m_teamSlotOverlay.m_teamSlots[154]))->RoleSystem::Notify();
        goto LABEL_40;
      case 7:
        IsVisible = (((Object3D *)&this->m_nTodo_058))->Object3D::IsVisible();
        IsRunning = IsVisible;
        if ( !IsVisible )
          return;
        if ( *((_DWORD *)m_pScriptBlock + 15) )
        {
          (((gbVisNode *)this->m_pExecSystem))->gbVisNode::SetTimeScale(0.0);
          (*(void ( **)(char *, int))(*(_DWORD *)this->m_pExecSystem + 24))(this->m_pExecSystem, -1082130432);
          (((PalScript *)&this->m_nTodo_058))->PalScript::GetCount(0);
        }
        goto LABEL_40;
      case 12:
        v23 = ((RoleSystem *)&stru_C10DF0)->m_teamSlotOverlay.m_teamSlots[154];
        v24 = *(float *)(((RoleSystem *)&stru_C10DF0)->m_teamSlotOverlay.m_teamSlots[154] + 4556);
        pfVal = 0.0;
        v37 = 0.0;
        v38 = 0.0;
        p_DWORD = 0;
        v40 = 0.0;
        v41 = 0.0;
        pPos = (1.0 - cos(*(float *)&nFlag * 3.1415927)) * 0.5 * v24;
        (((PathObj *)(((RoleSystem *)&stru_C10DF0)->m_teamSlotOverlay.m_teamSlots[154] + 1480)))->PathObj::GetPosition(*pPos,   &pfVal,   &p_DWORD);
        *(float *)(v23 + 4) = pfVal;
        *(float *)(v23 + 8) = v37;
        *(float *)(v23 + 12) = v38;
        *(float *)(v23 + 160) = pfVal;
        *(float *)(v23 + 164) = v37;
        *(float *)(v23 + 168) = v38;
        *(_DWORD *)(v23 + 8) = 0;
        *(_DWORD *)(v23 + 1296) = p_DWORD;
        *(float *)(v23 + 1300) = v40;
        *(float *)(v23 + 1304) = v41;
        (((RoleSystem *)v23))->RoleSystem::SetMoveSpeed(0.0, 0, v34);
        (((RoleSystem *)v23))->RoleSystem::UpdatePosition();
        if ( !IsRunning )
          return;
        (((RoleSystem *)v23))->RoleSystem::GetMoveState();
        (((RoleSystem *)v23))->RoleSystem::Notify();
        goto LABEL_40;
      case 13:
        *((float *)m_pScriptBlock + 7) = *((float *)m_pScriptBlock + 7) - 490.0 * fVal;
        pfVal = *((float *)m_pScriptBlock + 6);
        v25 = *((float *)m_pScriptBlock + 8);
        v37 = *((float *)m_pScriptBlock + 7) * fVal;
        v38 = v25 * fVal;
        this->m_fCamX = pfVal * fVal + this->m_fCamX;
        this->m_fCamY = v37 + this->m_fCamY;
        this->m_fCamZ = v38 + this->m_fCamZ;
        if ( this->m_fCamY > (double)*((float *)m_pScriptBlock + 4) )
          return;
        this->m_fCamY = *((float *)m_pScriptBlock + 4);
        this->m_nExecuteBlock = LODWORD(this->m_fCamX);
        this->m_nSavedDataA = LODWORD(this->m_fCamY);
        this->m_nSavedDataB = LODWORD(this->m_fCamZ);
        goto LABEL_41;
      case 16:
        (((CameraCtrl *)&((GRPinput *)&stru_D8C2B8)->KeyInfo[153]))->CameraCtrl::UpdateTransition(fVal);
        IsAngleBelowTarget = (((CameraCtrl *)&((GRPinput *)&stru_D8C2B8)->KeyInfo[153]))->CameraCtrl::IsAngleBelowTarget();
LABEL_38:
        v17 = !IsAngleBelowTarget;
        goto LABEL_39;
      default:
        goto LABEL_40;
    }
  }
}

// 0x0042FB40
char PalScriptMgr::SetBigMapState(char nState)
{
  char result; // al

  result = nState;
  this->m_nTodo_054 = 0;
  this->m_bBigMapState = nState;
  return result;
}

// 0x0042FCC0
void PalScriptMgr::PopScript()
{
  void **m_needscriptdel; // eax
  char **v3; // eax
  PtrArray *p_m_script; // esi
  char *v5; // ecx
  void *m_nTodo_024; // [esp-0x8] [ebp-0x10]

  m_needscriptdel = (void **)this->m_script.m_needscriptdel;
  this->m_script.m_needscriptdel = (int)(m_needscriptdel + 1);
  operator delete(*m_needscriptdel);
  if ( LODWORD(this->m_fCamY) )
  {
    v3 = (char **)this->m_script.m_needscriptdel;
    p_m_script = (PtrArray *)&this->m_script;
    v5 = (char *)*v3;
    p_m_script->m_pData = *v3;
    p_m_script->capacity = (int)(v5 + 4028);
    p_m_script->m_nSize = (int)v5;
    p_m_script->m_needscriptdel = (int)v3;
  }
  else
  {
    this->m_script.m_pData = 0;
    this->m_script.capacity = 0;
    this->m_script.m_nSize = 0;
    this->m_script.m_needscriptdel = 0;
    this->m_scefile = 0;
    m_nTodo_024 = (void *)this->m_nTodo_024;
    this->m_nTodo_018 = 0.0;
    this->m_nTodo_01C = 0.0;
    this->m_nTodo_020 = 0.0;
    operator delete(m_nTodo_024);
  }
}

// 0x00431E60
PalScriptMgr::PalScriptMgr()
{
  SingletonThunk_00431E70(this);
  atexit((void (__cdecl *)())PtrArray::ConditionalCleanup);
}

// 0x00431EB0
void PalScriptMgr::OpenSCE()
{
  SingletonThunk_00431EC0(this);
  atexit((void ( *)())PalScriptMgr::FindScript);
}

// 0x00431EE0
void PalScriptMgr::FindScript()
{
  if ( (((GRPinput *)&stru_D8C2B8)->m_keyStates[4] & 8) == 0 )
  {
    ((GRPinput *)&stru_D8C2B8)->m_keyStates[4] |= 8u;
    (((PtrArray *)&((GRPinput *)&stru_D8C2B8)->m_mouseMinX))->PtrArray::Remove();
  }
}

// 0x004320A0
void PalScriptMgr::Update(const char *pszName)
{
  int v1; // eax
  unsigned int v2; // kr04_4
  unsigned int v3; // ebp
  IDirectInputDevice8 *m_lpDIDKeyboard; // edi
  IDirectInputDevice8 v5; // al

  (((PtrArray *)&((GRPinput *)&stru_D8C2B8)->m_joystickX))->PtrArray::InsertAt(pszName);
  if ( v1 )
  {
    v2 = strlen(pszName) + 1;
    v3 = v2 - 1;
    if ( v2 - 1 > 0xFFFFFFFD )
      std::_Xlen();
    m_lpDIDKeyboard = (IDirectInputDevice8 *)((GRPinput *)&stru_D8C2B8)->m_lpDIDKeyboard;
    if ( ((GRPinput *)&stru_D8C2B8)->m_lpDIDKeyboard && (v5 = ((GRPinput *)&stru_D8C2B8)->m_lpDIDKeyboard[-1]) != 0 && v5 != 0xFF )
    {
      if ( v2 == 1 )
      {
        ((GRPinput *)&stru_D8C2B8)->m_lpDIDKeyboard[-1] = (IDirectInputDevice8)(*(_BYTE *)&v5 - 1);
        ((GRPinput *)&stru_D8C2B8)->m_lpDIDKeyboard = 0;
        ((GRPinput *)&stru_D8C2B8)->m_lpDIDMouse = 0;
        ((GRPinput *)&stru_D8C2B8)->m_mouseSensitivity = 0.0;
        return;
      }
    }
    else
    {
      if ( v2 == 1 )
      {
        (((std *)1))->std::string::_Tidy();
        return;
      }
      if ( LODWORD(((GRPinput *)&stru_D8C2B8)->m_mouseSensitivity) <= 0x1F && LODWORD(((GRPinput *)&stru_D8C2B8)->m_mouseSensitivity) >= v2 - 1 )
        goto LABEL_15;
      (((std *)1))->std::string::_Tidy();
    }
    GRPinput::PollInputState(&stru_D8C2B8, v3);
    m_lpDIDKeyboard = (IDirectInputDevice8 *)((GRPinput *)&stru_D8C2B8)->m_lpDIDKeyboard;
LABEL_15:
    qmemcpy(m_lpDIDKeyboard, pszName, v3);
    ((GRPinput *)&stru_D8C2B8)->m_lpDIDMouse = (IDirectInputDevice8 *)(v2 - 1);
    ((GRPinput *)&stru_D8C2B8)->m_lpDIDKeyboard[v3] = 0;
  }
}

// 0x00432170
void PalScriptMgr::Destroy()
{
  int *v1; // eax
  int *v2; // edi
  PtrArray *v3; // eax
  int *v4; // esi
  unsigned int nVal; // [esp+0x18] [ebp+0x4]
  char v6; // [esp+0x1C] [ebp+0x8]

  if ( nVal )
  {
    if ( v6 )
      v1 = (int *)PtrArray::CopyRange(&((GRPinput *)&stru_D8C2B8)->m_mouseMinX, nVal, 0);
    else
      v1 = nVal >= 0x64
         ? PtrArray::CopyRange(&((GRPinput *)&stru_D8C2B8)->m_joystickX, nVal, 0)
         : PtrArray::CopyRange(&((GRPinput *)&stru_D8C2B8)->m_mousept.x, nVal, 0);
    v2 = (int *)v1;
    if ( v1 )
    {
      v3 = (PtrArray *)operator new(0x18u);
      if ( v3 )
        v4 = (((PtrArray *)v3))->PtrArray::Reset();
      else
        v4 = 0;
      if ( v4 )
      {
        v4[1] = (int)v2;
        (((PtrArray *)&((GRPinput *)&stru_D8C2B8)->m_keyStates[8]))->PtrArray::SetAt(*(int *)&((GRPinput *)&stru_D8C2B8)->m_keyStates[12], (int)v4);
      }
      else
      {
        FreeScriptInstance(v2);
      }
    }
  }
}

// 0x00432260
const char ** PalScriptMgr::_CON_State(const char *pszName)
{
  int v1; // ecx
  const char ***i; // edx
  const char **result; // eax

  v1 = 0;
  if ( *(int *)&((GRPinput *)&stru_D8C2B8)->m_keyStates[12] <= 0 )
    return 0;
  for ( i = *(const char ****)&((GRPinput *)&stru_D8C2B8)->m_keyStates[8]; ; ++i )
  {
    if ( v1 >= 0 && v1 < *(int *)&((GRPinput *)&stru_D8C2B8)->m_keyStates[12] )
    {
      result = (const char **)*i;
      if ( *i )
      {
        if ( result[1] == pszName )
          break;
      }
    }
    if ( ++v1 >= *(int *)&((GRPinput *)&stru_D8C2B8)->m_keyStates[12] )
      return 0;
  }
  return result;
}

// 0x004322A0
bool PalScriptMgr::IfAnyScriptRunning(int nVal)
{
  bool result; // al

  (((PtrArray *)&this->m_script.capacity))->PtrArray::SetAt(this->m_script.m_nSize, nVal);
  return result;
}

// 0x004322C0
int PalScriptMgr::IsScriptRuning(int pal)
{
  PalScriptMgr *v2; // ebx
  int m_nSize; // eax
  int v4; // eax
  int v6; // ebp
  int v7; // edi
  PtrArray *p_capacity; // ebx
  _DWORD *v9; // esi
  int v10; // esi
  PalScriptMgr *v11; // [esp+0x10] [ebp-0x4]
m_nSize = this->m_script.m_nSize;
  v11 = this;
  if ( m_nSize )
  {
    v6 = 0;
    v7 = 0;
    if ( m_nSize > 0 )
    {
      p_capacity = (PtrArray *)&this->m_script.capacity;
      do
      {
        if ( v7 < 0 || v7 >= p_capacity->capacity )
          v9 = 0;
        else
          v9 = *(_DWORD **)&p_capacity->m_pData[4 * v7];
        if ( (*(int ( **)(_DWORD *))(*v9 + 4))(v9) )
        {
          (*(void ( **)(_DWORD *, int))(*v9 + 8))(v9, pal);
        }
        else
        {
          if ( v9[1] && v9 )
            (*(void ( **)(_DWORD *, int))*v9)(v9, 1);
          if ( v7 >= 0 && v7 < p_capacity->capacity )
            *(_DWORD *)&p_capacity->m_pData[4 * v7] = 0;
          v6 = 1;
        }
        ++v7;
      }
      while ( v7 < v11->m_script.m_nSize );
      if ( v6 )
      {
        v10 = 0;
        while ( v10 < v11->m_script.m_nSize )
        {
          if ( v10 >= 0 && v10 < p_capacity->capacity && *(_DWORD *)&p_capacity->m_pData[4 * v10] )
            ++v10;
          else
            (((PtrArray *)p_capacity))->PtrArray::RemoveAt(v10, 1);
        }
      }
    }
  }
  else
  {
    while ( 1 )
    {
      /* [MISATTRIBUTED] PtrArray on PalScriptMgr::this -> fix IDB name of callee */ PtrArray::~PtrArray((PtrArray *)this);
      if ( v4 == 2 )
        break;
      this = (PalScriptMgr *)this->m_script.m_nSize;
      if ( (int)this > 0 )
        return 0;
    }
    if ( !this->m_script.m_nSize )
      return 1;
  }
  return 0;
}

// 0x00432480
void PalScriptMgr::_CON_ReLoadScript()
{
  PtrArray *v1; // ecx

  this->PalScriptMgr::IfHaveScript();
  (((PtrArray *)v1))->PtrArray::SetSize();
  (((PtrArray *)&((GRPinput *)&stru_D8C2B8)->m_joystickX))->PtrArray::DestroyAll();
}

// 0x004324A0
BOOL PalScriptMgr::_CON_CloseScript()
{
  return *(_DWORD *)&((GRPinput *)&stru_D8C2B8)->m_keyStates[12] > 0;
}

// 0x004324B0
void PalScriptMgr::ClearAllScript()
{
  int v0; // eax
  int *v1; // esi
  int v2; // ecx
  int v3; // [esp+0xC] [ebp+0x4]

  if ( v3 )
  {
    v0 = 0;
    if ( *(int *)&((GRPinput *)&stru_D8C2B8)->m_keyStates[12] > 0 )
    {
      v1 = *(int **)&((GRPinput *)&stru_D8C2B8)->m_keyStates[8];
      do
      {
        if ( v0 < 0 || v0 >= *(int *)&((GRPinput *)&stru_D8C2B8)->m_keyStates[12] )
          v2 = 0;
        else
          v2 = (unsigned long)*v1;
        if ( v2 == v3 )
          break;
        ++v0;
        ++v1;
      }
      while ( v0 < *(int *)&((GRPinput *)&stru_D8C2B8)->m_keyStates[12] );
    }
  }
}

// 0x00432500
int * PalScriptMgr::FindScriptByDesc(const char *pszName, const char *desc)
{
  PalScriptMgr *v2; // ecx
  int *result; // eax
  char Buffer[64]; // [esp+0x0] [ebp-0x40] BYREF

  _snprintf(Buffer, 0x3Fu, "_%s_%s", pszName, desc);
  PtrArray::IsArrayReady();
  (((PalScriptMgr *)v2))->PalScriptMgr::Destroy();
  if ( result )
    ((GRPinput *)&stru_D8C2B8)->m_keyStates[25] = 1;
  return result;
}

// 0x00432550
void PalScriptMgr::IfHaveScript()
{
  int v1; // eax
  int i; // edi
  void *v3; // esi

  v1 = *(_DWORD *)&((GRPinput *)&stru_D8C2B8)->m_keyStates[12];
  for ( i = 0; i < v1; ++i )
  {
    if ( i >= 0 && i < v1 )
    {
      v3 = *(void **)(*(_DWORD *)&((GRPinput *)&stru_D8C2B8)->m_keyStates[8] + 4 * i);
      if ( v3 )
      {
        (*(UIListBox **)(*(_DWORD *)&((GRPinput *)&stru_D8C2B8)->m_keyStates[8] + 4 * i))->UIListBox::RefreshSelection();
        operator delete(v3);
        v1 = *(_DWORD *)&((GRPinput *)&stru_D8C2B8)->m_keyStates[12];
      }
    }
  }
  (((String *)&((GRPinput *)&stru_D8C2B8)->m_keyStates[8]))->String::Assign(0, -1);
}

// 0x00434C40
void PalScriptMgr::NotifyEvent()
{
  const char **v0; // eax
  int nVal; // [esp+0x8] [ebp+0x4]

  if ( nVal )
  {
    v0 = (((PalScriptMgr *)((GRPinput *)&stru_D8C2B8)->KeyInfo[147].CountMode))->PalScriptMgr::_CON_State();
    if ( v0 )
    {
      (((PalScriptMgr *)v0))->PalScriptMgr::IfAnyScriptRunning(nVal);
    }
    else if ( *(_DWORD *)(nVal + 4) )
    {
      (**(void ( ***)(int, int))nVal)(nVal, 1);
    }
  }
}

// 0x00434C80
void * PalScriptMgr::UpdateLoadProgress()
{
  void *result; // eax

  result = (void *)((GRPinput *)&stru_D8C2B8)->KeyInfo[147].CountMode;
  *(_DWORD *)(((GRPinput *)&stru_D8C2B8)->KeyInfo[147].CountMode + 8) = *(_DWORD *)(*(_DWORD *)((GRPinput *)&stru_D8C2B8)->KeyInfo[147].CountMode + 68)
                                                      + *(_DWORD *)(*(_DWORD *)((GRPinput *)&stru_D8C2B8)->KeyInfo[147].CountMode + 72);
  return result;
}

// 0x00434CA0
void PalScriptMgr::InitVtable()
{
  int v1; // [esp+0x4] [ebp+0x4]

  this->m_script.capacity = v1;
  this->m_script.m_pData = (char *)1;
}

// 0x00434CC0
BOOL PalScriptMgr::IsWaitComplete()
{
  return (_BYTE)byte_DBA25C || g_CCBEditorInst.m_dwTrickID[361] == this->m_script.capacity;
}

// 0x00434D20
BOOL PalScriptMgr::IsBlendComplete()
{
  return *(float *)&this->m_script.m_nSize < (double)*(float *)&this->m_script.capacity;
}

// 0x00434D40
void PalScriptMgr::AccumulateTime(float fDelta)
{
  *(float *)&this->m_script.m_nSize = fDelta + *(float *)&this->m_script.m_nSize;
}

// 0x00434D50
void * PalScriptMgr::Destroy_28(char a2)
{
  Array::_nearby_411ba0();
  if ( (a2 & 1) != 0 )
    operator delete(Block);
  return Block;
}

// 0x00450BC0
int PalScriptMgr::ShowTextBox(const char *pszText)
{
  void ( **v3)(PalScriptMgr *, int); // eax
  int result; // eax

  if ( 10 * (strlen(pszText) + 6) >= 0x40 )
    strlen(pszText);
  sub_445FA0(&this->m_fPosZ);
  sub_445DB0(this);
  (((RoleCameraCtrl *)&this->m_fPosZ))->RoleCameraCtrl::SetName(pszText);
  v3 = *(void ( ***)(PalScriptMgr *, int))&this->m_bGetSceneScript;
  this->m_nExecCounter = 0;
  (*v3)(this, 1);
  (((UIScene *)&this->m_fPosZ))->UIScene::SetState();
  return result;
}
