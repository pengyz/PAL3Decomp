#pragma once
// Auto-generated: ScriptObj
#include "pal3/ida_types.h"

class ScriptObj {
public:
    char _tail_000[4]; // +0x0
    // total size: 0x4 (4)

    ~ScriptObj(); // 0x00411CA0
    ScriptObj * _sdtor_22(char a2); // 0x0041BE30
    // Scalar-wrapper: ctors for IDA (Cls)int casts (no init code)
    ScriptObj() {}
    ScriptObj(int v) { *(int*)this = v; }

};
