#include "pal3/ida_defs.h"
#include "globals.h"
#include "pal3/pal3_constants.h"
#include "Script/ScriptSystem.h"
#include "Role/Actor.h"
#include "Render/CScreenMode.h"
#include "GameBase/GRPinput.h"
#include "GameBase/InputSystem.h"
#include "GameBase/PAL3.h"
#include "Script/PalScript.h"
#include "Misc/PtrArray.h"
#include "Render/RenderTarget3.h"
#include "Role/Role.h"
#include "Role/RoleSystem.h"
#include "Scene/SceneMgr.h"
#include "Misc/String.h"
#include "Misc/TxtFile.h"
#include "Misc/UITextArea.h"
#include "UI/UIWnd.h"
#include "Misc/scAsmDecoder.h"
#include "Misc/tagRoleSystemData.h"

// 0x0040C630
void ScriptSystem::Render(gbMatrixStack *pMatrixStack)
{
  scAsmDecoder *v2; // edx
  scAsmDecoder *v3; // ebx
  float *p_m_fCachePosY; // edi
  RenderTarget3 *Instance; // eax
  int m_ptr_4; // edi
  gbRenderEffect *v7; // ecx
  struct gbVec3D v8; // [esp+0xC] [ebp-0x10] BYREF
  int v9; // [esp+0x18] [ebp-0x4]

  v2 = g_SceneMgr.m_nCurrentRoleSlot;
  v3 = 0;
  p_m_fCachePosY = (float *)&((RoleSystem *)&stru_C059A0)->m_fCachePosY;
  do
  {
    if ( v3 != v2 )
    {
      (((RoleSystem *)p_m_fCachePosY))->RoleSystem::RenderRole(pMatrixStack, 0);
      v2 = g_SceneMgr.m_nCurrentRoleSlot;
    }
    p_m_fCachePosY += 2176;
    v3 = (scAsmDecoder *)((char *)v3 + 1);
  }
  while ( (int)p_m_fCachePosY < (int)&unk_C10960 );
  if ( g_fEffectTimer >= 1.2 )
  {
    (((RoleSystem *)(&((RoleSystem *)&stru_C059A0)->m_fCachePosY + 2176 * (_DWORD)v2)))->RoleSystem::RenderRole(pMatrixStack, 0);
  }
  else if ( rand() % 3 )
  {
    (((RoleSystem *)(&((RoleSystem *)&stru_C059A0)->m_fCachePosY + 2176 * (_DWORD)g_SceneMgr.m_nCurrentRoleSlot)))->RoleSystem::RenderRole(pMatrixStack, 0);
  }
  else
  {
    Instance = (((RenderTarget3 *)3))->RenderTarget3::GetInstance();
    m_ptr_4 = (int)Instance->m_ptr_4;
    if ( m_ptr_4 )
    {
      v7 = (gbRenderEffect *)Instance->m_ptr_4;
      v8.x = 0.69999999;
      v8.y = 0.1;
      v8.z = 0.1;
      v9 = 1056964608;
      (((gbRenderEffect *)v7))->gbRenderEffect::SetVariant(6, &v8);
      (((RoleSystem *)(&((RoleSystem *)&stru_C059A0)->m_fCachePosY + 2176 * (_DWORD)g_SceneMgr.m_nCurrentRoleSlot)))->RoleSystem::RenderRole(pMatrixStack, m_ptr_4);
    }
  }
  g_RoleSystemExtra1.RoleSystem::RenderRole(pMatrixStack, 0);
  g_RoleSystemExtra0.RoleSystem::RenderRole(pMatrixStack, 0);
  if ( g_SceneMgr.m_pCurrentScript )
  {
    v8 = *(gbVec3D *)(&((RoleSystem *)&stru_C059A0)->_embed_UIWnd_624.m_benable + 2176 * (_DWORD)g_SceneMgr.m_nCurrentRoleSlot);
    (((gbMatrixStack *)pMatrixStack))->gbMatrixStack::Push();
    v8.y = v8.y + 40.0;
    (((gbMatrixStack *)pMatrixStack))->gbMatrixStack::Translate(*v8);
    (*(void ( **)(_DWORD *, _DWORD))(*g_SceneMgr.m_pCurrentScript + 16))(g_SceneMgr.m_pCurrentScript, 0);
    (((gbMatrixStack *)pMatrixStack))->gbMatrixStack::Pop();
  }
}

// 0x0040C790
int ScriptSystem::Cleanup()
{
  int i; // esi
  void ( ***v2)(void *, int); // ecx
  int result; // eax

  for ( i = 0; i < (int)g_pScriptEventObj; ++i )
  {
    v2 = (void ( ***)(void *, int))g_pScriptObjArray[i];
    if ( v2 )
      (**v2)(v2, 1);
  }
  (((String *)&g_pScriptObjArray))->String::Assign(0, -1);
  return result;
}

// 0x0040C960
void ScriptSystem::Destroy()
{

  float *p_m_fCachePosY; // esi

  (((UITextArea *)&dword_BFDAB0))->UITextArea::Destroy();
  unk_C10968.PalScript::MoveAndHide();
  this->ScriptSystem::Cleanup();
  p_m_fCachePosY = (float *)&((RoleSystem *)&stru_C059A0)->m_fCachePosY;
  do
  {
    (((PalScript *)p_m_fCachePosY))->PalScript::DestroyScript();
    p_m_fCachePosY += 2176;
  }
  while ( (int)p_m_fCachePosY < (int)&unk_C10960 );
}

// 0x0040CB80
RoleSystem * ScriptSystem::GetMainRoleSystem(unsigned __int16 pData)
{
  if ( pData == 5 )
    return &g_RoleSystemMain;
  else
    return (RoleSystem *)(&((RoleSystem *)&stru_C059A0)->m_fCachePosY + 2176 * pData);
}

// 0x0040CBB0
int ScriptSystem::GetScriptContext(unsigned __int16 pData, int nVal)
{
  return g_RoleSlotBuf.m_partyActor.m_dwMatMsg[352 * pData + 2 + nVal];
}

// 0x0040CBD0
int ScriptSystem::PassThrough(unsigned __int16 pData, int nVal, int nVal2)
{
  int result; // eax

  result = nVal2;
  g_RoleSlotBuf.m_partyActor.m_dwMatMsg[352 * pData + 2 + nVal] = nVal2;
  return result;
}

// 0x0040CC00
int ScriptSystem::CheckEventType(unsigned __int16 pData, int nVal)
{
  int result; // eax
  _DWORD *v3; // ecx

  if ( pData == 6 )
  {
    result = 0;
    v3 = (_DWORD *)(4 * nVal + 12601196);
    do
    {
      if ( *((_BYTE *)&((RoleSystem *)&stru_C059A0)->m_nRetryCount + result) )
        *v3 = *(v3 - 12);
      ++result;
      v3 += 352;
    }
    while ( result < 5 );
  }
  else
  {
    result = 4 * (nVal + 352 * pData);
    *(unsigned int *)((char *)&g_RoleSlotBuf.m_partyActor.m_dwMatMsg[2] + result) = *(_DWORD *)((char *)&g_RoleSlotBuf.m_partyActor.m_nAnimFrame
                                                                                                  + result);
  }
  return result;
}

// 0x0040CC60
int ScriptSystem::ClearTimerSlot()
{
  int v0; // ecx
  int result; // eax

  result = v0;
  *(_BYTE *)v0 = HIBYTE(v0);
  *(_DWORD *)(v0 + 4) = 0;
  *(_DWORD *)(v0 + 8) = 0;
  *(_DWORD *)(v0 + 12) = 0;
  *(_BYTE *)(v0 + 20) = HIBYTE(v0);
  *(_DWORD *)(v0 + 24) = 0;
  *(_DWORD *)(v0 + 28) = 0;
  *(_DWORD *)(v0 + 32) = 0;
  *(_DWORD *)(v0 + 16) = -1;
  *(_DWORD *)(v0 + 36) = 0;
  return result;
}

// 0x004101F0
int ScriptSystem::RunWithDelay(float delay, int nVal, int nVal2)
{
  scAsmDecoder *v3; // ebx
  scAsmDecoder *v4; // edi
  unsigned int *v5; // esi
  int v6; // ebp
  __int64 v7; // rax
  int result; // eax
  GRPinput *v9; // eax
  GRPinput *v10; // esi
  CScreenMode *Instance; // eax
  const void *v12; // [esp-0x8] [ebp-0x144]
  int v13; // [esp+0x14] [ebp-0x128]
  void *pData[5]; // [esp+0x1C] [ebp-0x120]
  char Buffer[256]; // [esp+0x30] [ebp-0x10C] BYREF
  int v16; // [esp+0x138] [ebp-0x4]

  v3 = g_SceneMgr.m_nCurrentRoleSlot;
  v4 = 0;
  v13 = 0;
  v5 = (unsigned int *)&g_RoleSlotBuf.m_partyActor.m_dwMatMsg[2];
  do
  {
    if ( *((_BYTE *)&((RoleSystem *)&stru_C059A0)->m_nRetryCount + (_DWORD)v4) && (!(_BYTE)nVal2 || v4 == v3) )
    {
      v6 = (unsigned long)*v5;
      v7 = (__int64)((double)(int)*v5 - (double)(int)*(v5 - 12) * delay);
      *v5 = v7;
      if ( (int)v7 <= 0 )
        *v5 = 1;
      if ( v4 == v3 )
        v13 = (unsigned long)(*v5 - v6);
    }
    v5 += 352;
    v4 = (scAsmDecoder *)((char *)v4 + 1);
  }
  while ( (int)v5 < (int)&((RoleSystem *)&stru_C059A0)->m_teamSlotOverlay.m_teamSlots[174] );
  result = v13;
  if ( v13 < 0 )
  {
    sprintf(Buffer, &dir[20], v13);
    v9 = (GRPinput *)operator new(0x24u);
    v16 = 0;
    if ( v9 )
      v10 = (((GRPinput *)v9))->GRPinput::SetMousePos();
    else
      v10 = 0;
    v16 = -1;
    (((GRPinput *)v10))->GRPinput::SetJoystickPos(Buffer, 0);
    (((PtrArray *)&g_pScriptObjArray))->PtrArray::SetAt((int)g_pScriptEventObj, (int)v10);
    LOBYTE(result) = nVal;
    if ( (_BYTE)nVal )
    {
      pData[0] = "we015";
      pData[1] = "we016";
      pData[2] = "we017";
      pData[3] = "we018";
      pData[4] = "we019";
      v12 = pData[(_DWORD)g_SceneMgr.m_nCurrentRoleSlot];
      Instance = (CScreenMode *)CScreenMode::GetInstance();
      (((CScreenMode *)Instance))->CScreenMode::AudioSetPosition(v12, 1);
    }
  }
  return result;
}

// 0x00410470
int ScriptSystem::RunEvent(int eventId, int nVal)
{
  int result; // eax
  scAsmDecoder *v4; // ecx
  int *v5; // eax
  int v6; // eax
  char *v7; // eax
  char Buffer[32]; // [esp+0x8] [ebp-0x20] BYREF
  int v9; // [esp+0x34] [ebp+0xC]

  LOBYTE(result) = nVal;
  if ( !(_BYTE)nVal || (unsigned int)eventId > 4 || g_nCurrentEventId != eventId )
  {
    memset(&g_nScriptEventParam, 0, 0x20u);
    v4 = g_SceneMgr.m_nCurrentRoleSlot;
    g_nScriptEventParam = v9;
    g_nCurrentEventId = eventId;
    v5 = (int *)(&((RoleSystem *)&stru_C059A0)->m_fCachePosZ + 2176 * (_DWORD)g_SceneMgr.m_nCurrentRoleSlot);
    g_nScriptRolePosX = *v5;
    g_nScriptRolePosY = v5[1];
    g_nScriptRolePosZ = v5[2];
    if ( !v9 )
    {
      v6 = 1408 * (_DWORD)g_SceneMgr.m_nCurrentRoleSlot;
      *((_BYTE *)&g_RoleSlotBuf.m_partyActor.m_Actor + v6 + 4) = 0;
      *((_BYTE *)&g_RoleSlotBuf.m_partyActor.m_Actor + v6 + 5) = 0;
      *((_BYTE *)&g_RoleSlotBuf.m_partyActor.m_Actor + v6 + 6) = 0;
      *((_BYTE *)&g_RoleSlotBuf.m_partyActor.m_Actor + v6 + 7) = 0;
      *((_BYTE *)&g_RoleSlotBuf.m_partyActor.m_nCmdParam + v6) = 0;
    }
    result = 5 * (_DWORD)v4;
    if ( !g_RoleSlotBuf.m_partyActor.m_szTexture[1408 * (_DWORD)v4 + 5] && (unsigned int)eventId <= 4 && !v9 )
    {
      sprintf(Buffer, byte_5861F8, eventId);
      v7 = (((PalScript *)g_PAL3_Instance.m_nTodo_140))->PalScript::SetAppName(Buffer);
      (((InputSystem *)v7))->InputSystem::ProcessFrame();
      result = (int)g_SceneMgr.m_nCurrentRoleSlot;
      *((_BYTE *)&g_RoleSlotBuf.m_partyActor.m_Actor + 1408 * (_DWORD)g_SceneMgr.m_nCurrentRoleSlot + eventId + 4) = 1;
    }
  }
  return result;
}

// 0x00411F60
int ScriptSystem::UpdateTimers(float dt)
{
  int v1; // ecx
  float v2; // ebx
  int v3; // ebp
  int result; // eax
  int v6; // eax
  double v9; // [esp-0x4] [ebp-0x30]
  float v10; // [esp+0x4] [ebp-0x28]
  int v11; // [esp+0x8] [ebp-0x24]
  int v12; // [esp+0xC] [ebp-0x20]
  int v13; // [esp+0x10] [ebp-0x1C]
  int v14; // [esp+0x14] [ebp-0x18]
  int v15; // [esp+0x18] [ebp-0x14]
  int v16; // [esp+0x1C] [ebp-0x10]
  int v17; // [esp+0x20] [ebp-0xC]
  int v18; // [esp+0x24] [ebp-0x8]
  int v19; // [esp+0x28] [ebp-0x4]

  _ESI = v1;
  result = *(_DWORD *)(v1 + 632);
  if ( result )
  {
    if ( *(_DWORD *)(v1 + 144) || *(_DWORD *)(v1 + 1264) == 4 )
      (((Actor *)(v1 + 680)))->Actor::QueryState();
    switch ( *(_DWORD *)(_ESI + 1264) )
    {
      case 0:
        (((RoleSystem *)_ESI))->RoleSystem::SetMoveSpeed(0.0, 0, SHIDWORD(v9));
        return result;
      case 1:
        *(float *)&v9 = dt;
        (((RoleSystem *)_ESI))->RoleSystem::UpdateMoveSubMode(v9, v10);
        if ( result )
          goto LABEL_23;
        return result;
      case 2:
        (((RoleSystem *)_ESI))->RoleSystem::PathFollowUpdate();
        if ( !*(_DWORD *)(_ESI + 1268) )
          goto LABEL_16;
        goto LABEL_13;
      case 3:
        if ( *(_DWORD *)(_ESI + 1268) == 12 )
        {
LABEL_13:
          *(_DWORD *)(_ESI + 1296) = *(_DWORD *)(_ESI + 1308);
          *(_DWORD *)(_ESI + 1300) = *(_DWORD *)(_ESI + 1312);
          *(_DWORD *)(_ESI + 1304) = *(_DWORD *)(_ESI + 1316);
        }
        else
        {
          (((RoleSystem *)_ESI))->RoleSystem::PathFollowUpdate();
          if ( *(_DWORD *)(_ESI + 1268) )
          {
            *(_DWORD *)(_ESI + 1296) = *(_DWORD *)(_ESI + 1308);
            *(_DWORD *)(_ESI + 1300) = *(_DWORD *)(_ESI + 1312);
            *(_DWORD *)(_ESI + 1304) = *(_DWORD *)(_ESI + 1316);
          }
        }
LABEL_16:
        v6 = *(_DWORD *)(_ESI + 1388);
        if ( v6 && v6 != 4 )
          (((RoleSystem *)_ESI))->RoleSystem::ProcessInteraction();
        goto LABEL_23;
      case 4:
        (((RoleSystem *)_ESI))->RoleSystem::UpdateActionState(dt);
        if ( result )
          goto LABEL_23;
        return result;
      case 5:
        (((RoleSystem *)_ESI))->RoleSystem::UpdateTransform(dt);
        goto LABEL_23;
      case 6:
        (((RoleSystem *)_ESI))->RoleSystem::UpdateFollowBehavior(dt);
        goto LABEL_23;
      case 7:
        (((RoleSystem *)_ESI))->RoleSystem::UpdateFollowerMovement(dt);
        goto LABEL_23;
      default:
LABEL_23:
        *(_DWORD *)(_ESI + 1300) = 0;
        __asm
        {
          fld     dword ptr [esi+0x518]
          fld     dword ptr [esi+0x514]
          fld     dword ptr [esi+0x510]
          fld     st
          fmul    st, st(1)
          fld     st(2)
          fmul    st, st(3)
        }
        __asm
        {
          faddp   st(1), st
          fld     st(3)
          fmul    st, st(4)
          faddp   st(1), st
          fcomp   _flt_0_005
          fstp    st
          fnstsw  ax
          fstp    st
        }
        __asm { fstp    st }
        if ( (_AX & 0x4100) == 0 )
        {
          if ( *(_DWORD *)(_ESI + 636) || *(_DWORD *)(_ESI + 1264) == 4 )
          {
            (((RoleSystem *)_ESI))->RoleSystem::ApplyMoveStep(COERCE_DOUBLE(LODWORD(dt) | 0x100000000i64), v3, v2, SBYTE4(v9));
          }
          else
          {
            v14 = *(_DWORD *)(_ESI + 4);
            v15 = *(_DWORD *)(_ESI + 8);
            v17 = *(_DWORD *)(_ESI + 148);
            v16 = *(_DWORD *)(_ESI + 12);
            v18 = *(_DWORD *)(_ESI + 152);
            v19 = *(_DWORD *)(_ESI + 156);
            v11 = *(_DWORD *)(_ESI + 160);
            v12 = *(_DWORD *)(_ESI + 164);
            v13 = *(_DWORD *)(_ESI + 168);
            (((RoleSystem *)_ESI))->RoleSystem::ApplyMoveStep(COERCE_DOUBLE(LODWORD(dt) | 0x100000000i64), v3, v2, SBYTE4(v9));
            __asm
            {
              fld     dword ptr [esi+0x0A4]
              fsub    [esp+0x34+var_20]
              fabs
              fcomp   _flt_45_0
              fnstsw  ax
            }
            if ( (_AX & 0x4100) == 0 )
            {
              *(_DWORD *)(_ESI + 12) = v16;
              *(_DWORD *)(_ESI + 4) = v14;
              *(_DWORD *)(_ESI + 8) = v15;
              *(_DWORD *)(_ESI + 156) = v19;
              *(_DWORD *)(_ESI + 148) = v17;
              *(_DWORD *)(_ESI + 152) = v18;
              *(_DWORD *)(_ESI + 168) = v13;
              *(_DWORD *)(_ESI + 160) = v11;
              *(_DWORD *)(_ESI + 164) = v12;
              (((RoleSystem *)_ESI))->RoleSystem::NotifyMoveComplete();
            }
          }
        }
        result = (*(int ( **)(int))(*(_DWORD *)(_ESI + 56) + 4))(_ESI + 56);
        if ( !result )
          result = (((RoleSystem *)_ESI))->RoleSystem::GetCurrentTile();
        if ( *(_DWORD *)(_ESI + 1264) == 3 )
          LOBYTE(result) = (((RoleSystem *)_ESI))->RoleSystem::ApproachTarget(-1);
        break;
    }
  }
  return result;
}

// 0x00419090
void ScriptSystem::UpdatePositions()
{
  gbVec3D *v1; // eax
  float y; // edx
  float z; // eax
  gbVec3D *v4; // eax
  double v5; // st7
  float v6; // edx
  float v7; // eax
  double v8; // st7
  float v9; // [esp+0x18] [ebp-0x34]
  float v10; // [esp+0x18] [ebp-0x34]
  float v11; // [esp+0x1C] [ebp-0x30]
  float v12; // [esp+0x1C] [ebp-0x30]
  float v13; // [esp+0x20] [ebp-0x2C]
  float v14; // [esp+0x20] [ebp-0x2C]
  gbVec3D v15; // [esp+0x28] [ebp-0x24] BYREF
  float x; // [esp+0x34] [ebp-0x18] BYREF
  float v17; // [esp+0x38] [ebp-0x14]
  float v18; // [esp+0x3C] [ebp-0x10]
  gbVec3D v19; // [esp+0x40] [ebp-0xC] BYREF
  float *v20; // [esp+0x50] [ebp+0x4]

  x = 0.0;
  v17 = 0.0;
  v18 = 0.0;
  v13 = flt_C08188 * 20.0;
  v11 = flt_C08184 * 20.0;
  v9 = flt_C08180 * 20.0;
  v1 = ((gbVec3D *)&v19);
  v15.x = v1->x;
  y = v1->y;
  z = v1->z;
  *v20 = v15.x;
  v15.y = y;
  v20[1] = y;
  v15.z = z;
  v20[2] = z;
  v4 = ((gbVec3D *)&v19);
  v15.x = v4->x;
  v5 = v15.x + *v20;
  v15.y = v4->y;
  v6 = v15.y;
  v7 = v4->z;
  x = v15.x;
  *v20 = v5;
  v8 = v15.y + v20[1];
  v15.z = v7;
  v17 = v6;
  v18 = v7;
  v20[1] = v8;
  v20[2] = v15.z + v20[2];
  v14 = flt_C0817C * -10.0;
  v12 = flt_C08178 * -10.0;
  v10 = flt_C08174 * -10.0;
  v15 = *((gbVec3D *)&v19);
  gbVec3D::operator=(&x, &v15);
  (((gbVec3D *)v20))->gbVec3D::operator+=(&x);
  *v20 = flt_C08164 + *v20;
  v20[1] = flt_C08168 + v20[1];
  v20[2] = flt_C0816C + v20[2];
  v20[1] = unk_C08160.m_fPosY + 60.0;
}

// 0x00419200
int ScriptSystem::SmoothTrackTarget(
        
        float fDeltaTime,
        float fMaxAccel,
        float fVal3,
        float fVal4)
{
  double v6; // st7
  float *p_m_vSrcPos_x; // edi
  double v8; // st6
  double v9; // st7
  double v11; // st6
  double v12; // st7
  double v13; // st7
  float *p_m_vMoveDir_x; // edi
  double v15; // st7
  double v16; // st7
  gbVec3D *v17; // eax
  double v18; // st7
  float z; // eax
  char v21; // c0
  float v22; // [esp+0xC] [ebp-0x20]
  float v23; // [esp+0x10] [ebp-0x1C]
  float v24; // [esp+0x14] [ebp-0x18]
  float v25; // [esp+0x18] [ebp-0x14]
  float v26; // [esp+0x18] [ebp-0x14]
  float y; // [esp+0x18] [ebp-0x14]
  float v28; // [esp+0x1C] [ebp-0x10]
  float v29; // [esp+0x1C] [ebp-0x10]
  float v30; // [esp+0x24] [ebp-0x8]
  float v31; // [esp+0x28] [ebp-0x4]
  _UNKNOWN *retaddr; // [esp+0x2C] [ebp+0x0] BYREF

  if ( fDeltaTime < 0.00050000002 )
    fDeltaTime = 0.00050000002;
  v6 = this->m_vTargetPos - this->m_vDir_x;
  p_m_vSrcPos_x = (float *)&this->m_vSrcPos_x;
  v25 = this->m_fObjects - this->m_vDir_y;
  v8 = this->m_fTargetDir - this->m_vDir_z;
  this->m_vSrcPos_y = v25;
  v28 = v8;
  this->m_vSrcPos_x = v6;
  this->m_vSrcPos_z = v28;
  v9 = (((gbVec3D *)&this->m_vSrcPos_x))->gbVec3D::Length();
  if ( v9 >= 0.0049999999 )
  {
    v11 = (v9 * 0.016666668 - 0.0099999998) * fMaxAccel;
    if ( fMaxAccel < v11 )
      v11 = fMaxAccel;
    v12 = v11 / v9;
    *p_m_vSrcPos_x = v12 * *p_m_vSrcPos_x;
    this->m_vSrcPos_y = v12 * this->m_vSrcPos_y;
    this->m_vSrcPos_z = v12 * this->m_vSrcPos_z;
    v13 = *p_m_vSrcPos_x - this->m_vSavePos1_x;
    v26 = this->m_vSrcPos_y - this->m_vSavePos1_y;
    p_m_vMoveDir_x = (float *)&this->m_vMoveDir_x;
    v29 = this->m_vSrcPos_z - this->m_vSavePos1_z;
    this->m_vMoveDir_y = v26;
    this->m_vMoveDir_x = v13;
    this->m_vMoveDir_z = v29;
    this->m_vMoveDir_x = this->m_vMoveDir_x / fDeltaTime;
    this->m_vMoveDir_y = this->m_vMoveDir_y / fDeltaTime;
    this->m_vMoveDir_z = this->m_vMoveDir_z / fDeltaTime;
    v15 = (((gbVec3D *)&this->m_vMoveDir_x))->gbVec3D::Length();
    if ( v15 > 470.0 )
    {
      v16 = 470.0 / v15;
      *p_m_vMoveDir_x = v16 * *p_m_vMoveDir_x;
      this->m_vMoveDir_y = v16 * this->m_vMoveDir_y;
      this->m_vMoveDir_z = v16 * this->m_vMoveDir_z;
    }
    v30 = fVal4 * this->m_vMoveDir_y;
    v31 = fVal4 * this->m_vMoveDir_z;
    this->m_vSavePos1_x = fVal4 * *p_m_vMoveDir_x + this->m_vSavePos1_x;
    this->m_vSavePos1_y = v30 + this->m_vSavePos1_y;
    this->m_vSavePos1_z = v31 + this->m_vSavePos1_z;
    this->m_nSaveRot_y = this->m_vDir_x;
    this->m_nSaveRot_z = this->m_vDir_y;
    this->m_nSaveDir = LODWORD(this->m_vDir_z);
    v24 = fVal4 * this->m_vSavePos1_z;
    v23 = fVal4 * this->m_vSavePos1_y;
    v22 = fVal4 * this->m_vSavePos1_x;
    v17 = (gbVec3D *)&((gbVec3D *)retaddr);
    v18 = v17->x + this->m_nSaveRot_y;
    y = v17->y;
    z = v17->z;
    this->m_nSaveRot_y = v18;
    this->m_nSaveRot_z = y + this->m_nSaveRot_z;
    *(float *)&this->m_nSaveDir = z + *(float *)&this->m_nSaveDir;
    if ( v21 )
    {
      this->m_nSaveRot_y = this->m_vTargetPos;
      this->m_nSaveRot_z = this->m_fObjects;
      this->m_nSaveDir = LODWORD(this->m_fTargetDir);
    }
    return 1;
  }
  else
  {
    this->m_vDir_x = this->m_vTargetPos;
    this->m_vDir_y = this->m_fObjects;
    this->m_vDir_z = this->m_fTargetDir;
    return 0;
  }
}

// 0x004194C0
int ScriptSystem::UpdateObjects(float dt)
{
  int v1; // ecx
  int v2; // esi
  float *v3; // edi
  gbVec3D *v4; // eax
  double v5; // st7
  double v6; // st7
  double v7; // st7
  double v8; // st7
  int result; // eax
  float v10; // [esp+0xC] [ebp-0x44]
  float v11; // [esp+0xC] [ebp-0x44]
  float v12; // [esp+0x10] [ebp-0x40]
  float v13; // [esp+0x10] [ebp-0x40]
  float v14; // [esp+0x14] [ebp-0x3C]
  float v15; // [esp+0x14] [ebp-0x3C]
  float v16; // [esp+0x18] [ebp-0x38]
  float v17; // [esp+0x1C] [ebp-0x34]
  gbVec3D v18; // [esp+0x20] [ebp-0x30] BYREF
  struct gbVec3D v19; // [esp+0x2C] [ebp-0x24] BYREF
  gbVec3D v20; // [esp+0x38] [ebp-0x18] BYREF
  gbVec3D v21; // [esp+0x44] [ebp-0xC] BYREF
  float dta; // [esp+0x54] [ebp+0x4]

  v2 = v1;
  (((Actor *)(v1 + 680)))->Actor::QueryState();
  if ( (unsigned int)g_SceneMgr.m_nScriptObjectCount <= 2 && *(_DWORD *)(v2 + 1284) != g_SceneMgr.m_nScriptObjectCount )
  {
    *(_DWORD *)(v2 + 1284) = g_SceneMgr.m_nScriptObjectCount;
    (((RoleSystem *)v2))->RoleSystem::UpdatePath(g_SceneMgr.m_nScriptObjectCount);
  }
  v3 = (float *)(v2 + 1344);
  (((ScriptSystem *)v2))->ScriptSystem::UpdatePositions();
  if ( !(((ScriptSystem *)v2))->ScriptSystem::SmoothTrackTarget(dt, 300.0, v16, v17) )
    goto LABEL_9;
  v14 = *(float *)(v2 + 1352) - *(float *)(v2 + 168);
  v12 = *(float *)(v2 + 1348) - *(float *)(v2 + 164);
  v10 = *v3 - *(float *)(v2 + 160);
  v4 = ((gbVec3D *)&v20);
  v5 = *(float *)(v2 + 8700) - *(float *)(v2 + 168);
  v18.x = v4->x;
  v18.y = v4->y;
  v15 = v5;
  v6 = *(float *)(v2 + 8696) - *(float *)(v2 + 164);
  v18.z = v4->z;
  v13 = v6;
  v11 = *(float *)(v2 + 8692) - *(float *)(v2 + 160);
  v19 = *((gbVec3D *)&v21);
  v7 = (((gbVec3D *)&v18))->gbVec3D::Length();
  dta = v7;
  if ( v7 < 0.000049999999 || (v8 = (((gbVec3D *)&v18))->gbVec3D::DotProduct(&v19) / dta, v8 >= 0.0) && v8 - dta > -0.1 )
  {
    *(float *)(v2 + 160) = *v3;
    *(_DWORD *)(v2 + 164) = *(_DWORD *)(v2 + 1348);
    *(_DWORD *)(v2 + 168) = *(_DWORD *)(v2 + 1352);
LABEL_9:
    *(float *)(v2 + 1296) = flt_C08174;
    *(float *)(v2 + 1300) = flt_C08178;
    *(float *)(v2 + 1304) = flt_C0817C;
    (((RoleSystem *)v2))->RoleSystem::UpdatePosition();
    return result;
  }
  *(_DWORD *)(v2 + 160) = *(_DWORD *)(v2 + 8692);
  *(_DWORD *)(v2 + 164) = *(_DWORD *)(v2 + 8696);
  *(_DWORD *)(v2 + 168) = *(_DWORD *)(v2 + 8700);
  (((RoleSystem *)v2))->RoleSystem::UpdatePosition();
  return result;
}

// 0x0041EFA0
void ScriptSystem::Init()
{
  int v1; // edi
  const char *v2; // esi
  int v3; // edi
  const char *v4; // esi
  TxtFile String; // [esp+0x8] [ebp-0x218] BYREF
  int v6; // [esp+0x21C] [ebp-0x4]

  v6 = 0;
  (((PalScript *)&String))->PalScript::LoadFromFile("datascript\\scene.txt");
  (((PalScript *)&String))->PalScript::SetDirectory("role");
  while ( (((PalScript *)&String))->PalScript::HasNext() )
  {
    if ( !_strcmpi(String.m_token, g_LanguageCode) )
      break;
    v1 = 0;
    v2 = (const char *)(&g_RoleSystemData.m_nTodo_118 + 1);
    while ( _strcmpi(String.m_token, v2) )
    {
      v2 += 20;
      ++v1;
      if ( (int)v2 >= (int)&off_58B444 )
        goto LABEL_8;
    }
    (((PalScript *)&String))->PalScript::LoadNext();
    *(&g_RoleSystemData.m_nTodo_118 + 5 * v1) = atof(String.m_token);
LABEL_8:
    ;
  }
  (((PalScript *)&String))->PalScript::SetDirectory((char *)&dword_58B440);
  while ( (((PalScript *)&String))->PalScript::HasNext() )
  {
    if ( !_strcmpi(String.m_token, g_LanguageCode) )
      break;
    v3 = 0;
    v4 = (const char *)(&g_RoleSystemData.m_nEffParamBase0 + 1);
    while ( _strcmpi(String.m_token, v4) )
    {
      v4 += 20;
      ++v3;
      if ( (int)v4 >= (int)((const char *)&g_RoleSystemData.m_nTodo_118 + 4) )
        goto LABEL_16;
    }
    (((PalScript *)&String))->PalScript::LoadNext();
    *((float *)&g_RoleSystemData.m_nEffParamBase0 + 5 * v3) = atof(String.m_token);
LABEL_16:
    ;
  }
  v6 = -1;
  (((PalScript *)&String))->PalScript::Cleanup();
}
