#include "pal3/ida_defs.h"
#include "globals.h"
#include "pal3/pal3_constants.h"
#include "Scene/CameraSystem.h"
#include "Role/RoleSystem.h"

// 0x0041D980
int CameraSystem::BindToRoleSlot(int nVal)
{
  int result; // eax

  result = nVal;
  if ( nVal )
  {
    ((RoleSystem *)&stru_C10DF0)->m_teamSlotOverlay.m_teamSlots[154] = nVal;
    *(_DWORD *)(nVal + 1264) = 2;
  }
  return result;
}
