#pragma once
// Auto-generated: Scene
#include "pal3/ida_types.h"

#include "Misc/PtrArray.h"
#include "Role/Role.h"
#include "Misc/SceneMapObj.h"
#include "Scene/SceneObj.h"
#include "gbengine/gbengine_types.h"
#include "gbengine/gbGeomNode.h"
#include "gbengine/gbVisNode.h"

class Scene {
public:
    char _gap_000[4]; // +0x0
    char * m_pDataBegin; // +0x4
    char * m_pDataEnd; // +0x8
    char * m_pCapacity[29]; // +0xC
    char _gap_010[112]; // +0x10
    int m_nReset; // +0x80
    gbGeomNode * m_geomnode; // +0x84
    gbVisNode * m_lights; // +0x88
    gbAABBox m_aabb; // +0x8C
    PtrArray m_bbArray; // +0xA4
    SceneMapObj m_objmap[2]; // +0xB4
    int m_numobj; // +0xDC
    SceneObj m_obj[256]; // +0xE0
    int m_numnpc; // +0x6F8E0
    Role m_npc[72]; // +0x6F8E4
    char _tail_10C7E4[252]; // +0x10C7E4
    // total size: 0x10C8E0 (1100000)

    void Render2(); // 0x0040C7D0
    int AddRoleEntry(const int * pRoleTriple); // 0x00410990
    double GetTileHeight(int nSceneIdx, int nX, int nY, int *pFlags); // 0x00421230
    static int GetNumObj(); // 0x00456FC0
};
