#include "pal3/ida_defs.h"
#include "globals.h"
#include "pal3/pal3_constants.h"
#include "Scene/Camera.h"
#include "Misc/ARC_PlayerAtt.h"
#include "Role/Actor.h"
#include "Scene/CameraCtrl.h"
#include "GameBase/GRPinput.h"
#include "Script/PalScript.h"
#include "Script/PalScriptMgr.h"
#include "Render/RenderTarget2.h"
#include "Misc/RoleAtt.h"
#include "Role/RoleSystem.h"
#include "Misc/ScriptPoolPage.h"
#include "Misc/UICaption.h"
#include "UI/UIItem.h"
#include "UI/UIListBox.h"
#include "UI/UIScene.h"
#include "Misc/UIScenePanel.h"
#include "Misc/UIStatic.h"
#include "free_functions.h"

// Forward declarations for unnamed functions

// 0x004125D0
void Camera::InitFromScene(const char *pszSceneName)
{
  long double v3; // st7
  gbMatrix4 actionId; // [esp+0x8] [ebp-0x4C] BYREF
  float v5; // [esp+0x48] [ebp-0xC]
  float v6; // [esp+0x50] [ebp-0x4]

  if ( pszSceneName )
  {
    /* [MISATTRIBUTED] PalScript on Camera::this -> fix IDB name of callee */ PalScript::DestroyScript((PalScript *)this);
    (((Actor *)(&this->m_ScriptResult + 69)))->Actor::sub_536D20(pszSceneName, 0);
    *(&this->m_ScriptResult + 220) = 0;
    (((RoleSystem *)this))->RoleSystem::UpdateTransform() /* [ROWTABLE] */;
    (((RoleSystem *)this))->RoleSystem::SetBlendMode(1.0) /* [ROWTABLE] */;
    (((Actor *)(&this->m_ScriptResult + 69)))->Actor::PlayAction((int)&actionId);
    v3 = sqrt(v6 * v6 + v5 * v5) * 0.40000001;
    *(float *)&this->m_nStepRotate = v3;
    if ( v3 < 6.0 )
      *(&this->m_ScriptResult + 263) = 1;
    *(&this->m_ScriptResult + 238) = 0;
  }
}

// 0x0041BE80
Camera::Camera(gbGfxManager *p)
{
  // [AUTO-COMMENTED] (gbCamera *)&this->m_fCameraEyePosition->gbCamera(p);
  this->m_fCameraTimer = 0.0;
  this->m_fLerpSpeed = 0.0;
  this->m_fLerpProgress = 0.0;
  this->m_bLerpActive = (_BYTE)p;
  (((PalScriptMgr *)&this->m_ScriptResult))->PalScriptMgr::Get_result();
  *(&this->m_ScriptResult + 4) = 0;
  *(&this->m_ScriptResult + 5) = 0;
  *(&this->m_ScriptResult + 6) = 0;
  *(&this->m_ScriptResult + 7) = 0;
  *(&this->m_ScriptResult + 8) = 0;
  *(&this->m_ScriptResult + 9) = 0;
  *(&this->m_ScriptResult + 10) = 0;
  *(&this->m_ScriptResult + 19) = 0;
  *(&this->m_ScriptResult + 20) = 0;
  *(&this->m_ScriptResult + 21) = 0;
  *(&this->m_ScriptResult + 22) = 0;
  *(&this->m_ScriptResult + 23) = 0;
  *(&this->m_ScriptResult + 24) = 0;
  *(&this->m_ScriptResult + 25) = 0;
  *(&this->m_ScriptResult + 26) = 0;
  *(&this->m_ScriptResult + 27) = 0;
  *(&this->m_ScriptResult + 28) = 0;
  *(&this->m_ScriptResult + 29) = 0;
  *(&this->m_ScriptResult + 30) = 0;
  *(&this->m_ScriptResult + 31) = 0;
  *(&this->m_ScriptResult + 32) = 0;
  *(&this->m_ScriptResult + 33) = 0;
  this->m_nCameraTick = 0;
  this->m_nPrevCameraTick = 0;
  *(&this->m_ScriptResult + 15) = 0;
  /* [MISATTRIBUTED] ScriptPoolPage on Camera::this -> fix IDB name of callee */ ScriptPoolPage::ScriptPoolPage_Manage((ScriptPoolPage *)this, 0);
  *(&this->m_ScriptResult + 17) = 0;
  *(&this->m_ScriptResult + 18) = 0;
  *(&this->m_ScriptResult + 14) = 0;
  *(&this->m_ScriptResult + 11) = 1;
  *(&this->m_ScriptResult + 34) = 1107296256;
  this;
}

// 0x0041E7D0
int Camera::CheckCollision1(float *pPos, void *pBounds, float *pDist)
{
  int v3; // ebx
  double v4; // st7
  double x; // st7
  float y; // edx
  float z; // ecx
  int result; // eax
  double v9; // st7
  float v10; // ecx
  float v11; // edx
  int v12; // eax
  double v13; // st7
  double v14; // st7
  double v15; // st6
  float v16; // ecx
  struct gbVec3D v17; // [esp+0x10] [ebp-0x3C] BYREF
  struct gbVec3D pTarget[2]; // [esp+0x1C] [ebp-0x30] BYREF
  gbRay v19; // [esp+0x34] [ebp-0x18] BYREF

  *pDist = 0.0;
  v3 = UISceneUpdate() + 492772;
  qmemcpy(&v19, (((CameraCtrl *)&g_pCameraCtrl))->CameraCtrl::GetViewTarget(pTarget, pPos), sizeof(v19));
  v4 = g_pCameraCtrl->m_fCamDist - 300.0;
  v17.x = v19.Direction.x * v4;
  v17.y = v19.Direction.y * v4;
  v19.Origin.x = v17.x + v19.Origin.x;
  v19.Origin.y = v19.Origin.y + v17.y;
  v19.Origin.z = v19.Origin.z + v4 * v19.Direction.z;
  if ( *(int *)v3 <= 1 )
  {
    v12 = UISceneUpdate();
    if ( (((GRPinput *)(v12 + 493104)))->GRPinput::GetState() )
      return 1;
  }
  else
  {
    memset(&v17, 0, sizeof(v17));
    if ( (((GRPinput *)(v3 + 348)))->GRPinput::GetState() )
    {
      x = v17.x;
      y = v17.y;
      z = v17.z;
      *(_DWORD *)pDist = 1;
      *(float *)pBounds = x;
      *((float *)pBounds + 1) = y;
      *((float *)pBounds + 2) = z;
      return 1;
    }
    if ( (((GRPinput *)(v3 + 332)))->GRPinput::GetState() )
    {
      v9 = v17.x;
      v10 = v17.y;
      v11 = v17.z;
      *pDist = 0.0;
      *(float *)pBounds = v9;
      *((float *)pBounds + 1) = v10;
      *((float *)pBounds + 2) = v11;
      return 1;
    }
  }
  if ( !((RoleSystem *)&stru_C10DF0)->m_teamSlotOverlay.m_teamSlots[154] )
    return 0;
  pTarget[0].x = 0.0;
  pTarget[0].y = 1.0;
  pTarget[0].z = 0.0;
  v17 = *(gbVec3D *)(((RoleSystem *)&stru_C10DF0)->m_teamSlotOverlay.m_teamSlots[154] + 160);
  v13 = (((gbRay *)&v19))->gbRay::IntersectPlane(*pTarget,  *v17);
  if ( v13 == 3.4028235e38 )
    return 0;
  pTarget[0].y = v19.Direction.y * v13;
  pTarget[0].z = v19.Direction.z * v13;
  v14 = v19.Direction.x * v13 + v19.Origin.x;
  v17.y = v19.Origin.y + pTarget[0].y;
  v15 = v19.Origin.z + pTarget[0].z;
  *((_DWORD *)pBounds + 1) = LODWORD(v17.y);
  result = 1;
  v17.z = v15;
  v16 = v17.z;
  *(float *)pBounds = v14;
  *((float *)pBounds + 2) = v16;
  return result;
}

// 0x0041EA00
int Camera::CheckCollision2(float *pPos, int rolePtr, void *pBounds)
{
  RoleSystem *v3; // eax
  char *MapNodePtr; // ebx
  double v5; // st7
  int result; // eax
  double v7; // st7
  double v8; // st7
  double v9; // st6
  float v10; // edx
  struct gbVec3D v11; // [esp+0xC] [ebp-0x3C] BYREF
  float pTarget; // [esp+0x18] [ebp-0x30] BYREF
  float v13; // [esp+0x1C] [ebp-0x2C]
  float v14; // [esp+0x20] [ebp-0x28]
  gbRay v15; // [esp+0x30] [ebp-0x18] BYREF

  v3 = (RoleSystem *)UISceneUpdate();
  MapNodePtr = (((RoleSystem *)v3))->RoleSystem::GetMapNodePtr(rolePtr);
  qmemcpy(&v15, (((CameraCtrl *)&g_pCameraCtrl))->CameraCtrl::GetViewTarget(&pTarget, pPos), sizeof(v15));
  v5 = g_pCameraCtrl->m_fCamDist - 100.0;
  v11.x = v15.Direction.x * v5;
  v11.y = v15.Direction.y * v5;
  v15.Origin.x = v11.x + v15.Origin.x;
  v15.Origin.y = v15.Origin.y + v11.y;
  v15.Origin.z = v15.Origin.z + v5 * v15.Direction.z;
  if ( (((GRPinput *)MapNodePtr))->GRPinput::GetState() )
    return 1;
  v11.x = 0.0;
  v11.y = 1.0;
  v11.z = 0.0;
  v7 = (((gbRay *)&v15))->gbRay::IntersectPlane(*v11, * (gbVec3D *)(((RoleSystem *)&stru_C10DF0)->m_teamSlotOverlay.m_teamSlots[154] + 160));
  if ( v7 >= 3.4028235e38 )
    return 0;
  result = 1;
  v11.y = v15.Direction.y * v7;
  v11.z = v15.Direction.z * v7;
  v8 = v15.Direction.x * v7 + v15.Origin.x;
  v13 = v15.Origin.y + v11.y;
  v9 = v15.Origin.z + v11.z;
  *((float *)pBounds + 1) = v13;
  v14 = v9;
  v10 = v14;
  *(float *)pBounds = v8;
  *((float *)pBounds + 2) = v10;
  return result;
}

// 0x0041EE60
char Camera::IsTransitioning()
{
  RoleSystem *v1; // eax
  int RolePtr; // eax
  RoleSystem *v3; // eax
  int *v4; // eax
  char v6; // al
  int v7; // [esp-0xC] [ebp-0x18]
  int v8; // [esp-0x8] [ebp-0x14]
  int v9; // [esp-0x4] [ebp-0x10]
  int v10; // [esp-0x4] [ebp-0x10]

  v9 = *(_DWORD *)(((RoleSystem *)&stru_C10DF0)->m_teamSlotOverlay.m_teamSlots[154] + 628);
  v1 = (RoleSystem *)UISceneUpdate();
  RolePtr = (((RoleSystem *)v1))->RoleSystem::GetRolePtr(v9);
  v10 = (__int64)((*(float *)(((RoleSystem *)&stru_C10DF0)->m_teamSlotOverlay.m_teamSlots[154] + 12) - *(float *)(RolePtr + 136))
                / *(float *)&((RoleSystem *)&stru_C10DF0)->m_teamSlotOverlay.m_teamSlots[144]);
  v8 = (__int64)((*(float *)(((RoleSystem *)&stru_C10DF0)->m_teamSlotOverlay.m_teamSlots[154] + 4) - *(float *)(RolePtr + 128))
               / *(float *)&((RoleSystem *)&stru_C10DF0)->m_teamSlotOverlay.m_teamSlots[144]);
  v7 = *(_DWORD *)(((RoleSystem *)&stru_C10DF0)->m_teamSlotOverlay.m_teamSlots[154] + 628);
  v3 = (RoleSystem *)UISceneUpdate();
  v4 = (((RoleSystem *)v3))->RoleSystem::IsTileInBounds(v7, v8, v10);
  if ( !v4 )
    return 0;
  v6 = *((_BYTE *)v4 + 244);
  return v6 == 44 || v6 == 38;
}

// 0x00439850
void Camera::UpdateCameraLookAt(int nScreenX, int nScreenY)
{
  gbCamera *m_pCamera; // ecx
  double v5; // st7
  float y; // eax
  float z; // edx
  struct gbVec3D v8; // [esp+0xC] [ebp-0x24] BYREF
  struct gbVec3D v9; // [esp+0x18] [ebp-0x18] BYREF
  struct gbVec3D v10; // [esp+0x24] [ebp-0xC] BYREF
  float nScreenXa; // [esp+0x34] [ebp+0x4]

  m_pCamera = (gbCamera *)this->m_pCamera;
  v10.x = 0.0;
  v10.y = 1.0;
  v10.z = 0.0;
  v9.z = 1600.0;
  v8.z = 0.0;
  v5 = (((double)nScreenX + (double)nScreenX) / (double)g_DrvInfo.width - 1.0) * this->m_fFovTan;
  v8.y = (1.0 - ((double)nScreenY + (double)nScreenY) / (double)g_DrvInfo.height) * this->m_fFovTan;
  v9.x = -v5;
  nScreenXa = -v8.y;
  v9.y = nScreenXa;
  v8.y = nScreenXa;
  v8.x = v9.x;
  (((gbCamera *)m_pCamera))->gbCamera::SetLookAt(&v9, &v8, &v10);
  y = v8.y;
  this->m_vRayDir.x = v8.x;
  z = v8.z;
  this->m_vRayDir.y = y;
  this->m_vRayDir.z = z;
  this->m_vRayDir.x = this->m_vRayDir.x - v9.x;
  this->m_vRayDir.y = this->m_vRayDir.y - v9.y;
  this->m_vRayDir.z = this->m_vRayDir.z - v9.z;
  (((gbVec3D *)&this->m_vRayDir))->gbVec3D::Normalize();
}

// 0x00439930
void Camera::UpdateCameraLookAt(int nScreenX, int nScreenY, int nOffsetY)
{
  gbCamera *m_pCamera; // ecx
  double v6; // st7
  float y; // edx
  float z; // eax
  struct gbVec3D v9; // [esp+0xC] [ebp-0x30] BYREF
  struct gbVec3D v10; // [esp+0x18] [ebp-0x24] BYREF
  struct gbVec3D v11; // [esp+0x24] [ebp-0x18] BYREF
  float v12; // [esp+0x34] [ebp-0x8]

  m_pCamera = (gbCamera *)this->m_pCamera;
  v11.x = 0.0;
  v11.y = 1.0;
  v11.z = 0.0;
  v9.z = 1600.0;
  v10.z = 0.0;
  v6 = (((double)nScreenX + (double)nScreenX) / (double)g_DrvInfo.width - 1.0) * this->m_fFovTan;
  v12 = (1.0 - ((double)nScreenY + (double)nScreenY) / (double)g_DrvInfo.height) * this->m_fFovTan;
  v9.y = (float)nOffsetY;
  v9.x = -v6;
  v9.y = v9.y - v12;
  v10.x = v9.x;
  v10.y = -v12;
  (((gbCamera *)m_pCamera))->gbCamera::SetLookAt(&v9, &v10, &v11);
  y = v10.y;
  this->m_vRayDir.x = v10.x;
  z = v10.z;
  this->m_vRayDir.y = y;
  this->m_vRayDir.z = z;
  this->m_vRayDir.x = this->m_vRayDir.x - v9.x;
  this->m_vRayDir.y = this->m_vRayDir.y - v9.y;
  this->m_vRayDir.z = this->m_vRayDir.z - v9.z;
  (((gbVec3D *)&this->m_vRayDir))->gbVec3D::Normalize();
}

// 0x0052BEB0
void Camera::InitUIElements()
{
  int v2; // eax
  int v3; // ecx
  int v4; // edx
  int v5; // ecx
  int v6; // eax
  int v7; // ecx
  int v8; // edx
  int v9; // ecx
  int *v10; // edi
  int v11; // edx
  int v12; // edx
  int v13; // edx
  int v14; // ecx
  int v15; // edx
  int v16; // ebp
  int v17; // eax
  int v18; // eax
  int v19; // eax
  int v20; // edx
  int v21; // ecx
  int v22; // ebp
  int v23; // ecx
  int v24; // ecx
  int v25; // edi
  int v26; // ebp
  int v27; // kr04_4
  int v28; // eax
  double v29; // st7
  int i; // edi
  RoleSystem *v31; // edi
  int *v32; // eax
  int v33; // ebp
  int v34; // edx
  int v35; // edx
  int v36; // ecx
  int v37; // edx
  int v38; // [esp+0x6C] [ebp-0x64]
  int v39; // [esp+0x70] [ebp-0x60] BYREF
  int v40; // [esp+0x74] [ebp-0x5C]
  int v41; // [esp+0x78] [ebp-0x58]
  int v42; // [esp+0x7C] [ebp-0x54]
  int v43; // [esp+0x80] [ebp-0x50] BYREF
  int v44; // [esp+0x84] [ebp-0x4C]
  int v45; // [esp+0x88] [ebp-0x48]
  int v46; // [esp+0x8C] [ebp-0x44]
  int v47; // [esp+0x90] [ebp-0x40] BYREF
  int v48; // [esp+0x94] [ebp-0x3C]
  int v49; // [esp+0x98] [ebp-0x38]
  int v50; // [esp+0x9C] [ebp-0x34]
  _DWORD v51[12]; // [esp+A0h] [ebp-0x30] BYREF

  v2 = *((_DWORD *)&this->m_pLookAtData + 3);
  v3 = *((_DWORD *)&this->m_pLookAtData + 4);
  *((_DWORD *)&this->m_pLookAtData + 1) = v2;
  *((_DWORD *)&this->m_pLookAtData + 2) = v3;
  this->m_pLookAtData = 0;
  this->m_fLookAtProgress = 0.0;
  (((UIListBox *)this))->UIListBox::SetSelTexture(-1, 0, 0, *((_DWORD *)&this->m_pLookAtData + 1), *((_DWORD *)&this->m_pLookAtData + 2)) /* [ROWTABLE] */;
  /* [MISATTRIBUTED] PalScript on Camera::this -> fix IDB name of callee */ PalScript::LoadEncampConfig((PalScript *)this);
  v4 = *(&this->m_ScriptResult + 429);
  v44 = 172;
  v43 = 125;
  v45 = 675;
  v46 = 428;
  (*(void ( **)(int *, int *, int *, Camera *))(v4 + 16))(
    &this->m_ScriptResult + 429,
    &byte_80AC07,
    &v43,
    this);
  LOBYTE(v5) = *((_BYTE *)&this->m_ScriptResult + 12549);
  (((UIStatic *)(&this->m_ScriptResult + 429)))->UIStatic::CreateFromTemplate("SubGame\\Encampment\\Remark.tga", v5);
  v43 += 68;
  v46 -= 50;
  v6 = *(&this->m_ScriptResult + 467);
  v44 += 50;
  v45 -= 68;
  (*(void ( **)(int *, int *, int *, Camera *))(v6 + 16))(
    &this->m_ScriptResult + 467,
    &byte_80AC07,
    &v43,
    this);
  sub_446010(&this->m_ScriptResult + 467);
  SetEnable((UICaption *)(&this->m_ScriptResult + 467));
  v7 = *(&this->m_ScriptResult + 183) + 160;
  v49 = *(&this->m_ScriptResult + 182) + 200;
  v8 = *(&this->m_ScriptResult + 186);
  v50 = v7;
  v9 = *(&this->m_ScriptResult + 187);
  v48 = 160;
  v40 = 160;
  v42 = v9 + 160;
  v10 = (int *)(&this->m_ScriptResult + 273);
  v41 = v8 + 370;
  v11 = *(&this->m_ScriptResult + 273);
  v47 = 200;
  v39 = 370;
  (*(void ( **)(int *, int *, int *, Camera *))(v11 + 16))(
    &this->m_ScriptResult + 273,
    &byte_80AC03,
    &v39,
    this);
  LOBYTE(v12) = *((_BYTE *)&this->m_ScriptResult + 12549);
  (((UIStatic *)(&this->m_ScriptResult + 273)))->UIStatic::CreateFromTemplate("SubGame\\Encampment\\head0.tga", v12);
  v13 = *(&this->m_ScriptResult + 186);
  v39 = v47 + 2;
  v14 = *(&this->m_ScriptResult + 187);
  v40 = v48 + 176;
  v42 = v48 + 176 + v14;
  v41 = v47 + 2 + v13;
  (*(void ( **)(int *, int *, int *, Camera *))(*(&this->m_ScriptResult + 311) + 16))(
    &this->m_ScriptResult + 311,
    &byte_80AC04,
    &v39,
    this);
  LOBYTE(v15) = *((_BYTE *)&this->m_ScriptResult + 12549);
  (((UIStatic *)(&this->m_ScriptResult + 311)))->UIStatic::CreateFromTemplate("SubGame\\Encampment\\head1.tga", v15);
  v16 = v47 + 170 + *(&this->m_ScriptResult + 186);
  v40 = v50 - *(&this->m_ScriptResult + 187) - 4;
  v39 = v47 + 170;
  v41 = v16;
  v17 = *(&this->m_ScriptResult + 349);
  v42 = v50 - 4;
  v18 = (*(int ( **)(int *, int *, int *, Camera *))(v17 + 16))(
          &this->m_ScriptResult + 349,
          &byte_80AC05,
          &v39,
          this);
  LOBYTE(v18) = *((_BYTE *)&this->m_ScriptResult + 12549);
  (((UIStatic *)(&this->m_ScriptResult + 349)))->UIStatic::CreateFromTemplate("SubGame\\Encampment\\head2.tga", v18);
  v39 = v49 - *(&this->m_ScriptResult + 186) - 2;
  v19 = *(&this->m_ScriptResult + 187);
  v41 = v49 - 2;
  v42 = v48 + 176 + v19;
  v40 = v48 + 176;
  (*(void ( **)(int *, int *, int *, Camera *))(*(&this->m_ScriptResult + 387) + 16))(
    &this->m_ScriptResult + 387,
    &byte_80AC06,
    &v39,
    this);
  LOBYTE(v20) = *((_BYTE *)&this->m_ScriptResult + 12549);
  (((UIStatic *)(&this->m_ScriptResult + 387)))->UIStatic::CreateFromTemplate("SubGame\\Encampment\\head3.tga", v20);
  LOBYTE(v21) = *((_BYTE *)&this->m_ScriptResult + 12549);
  (((UIStatic *)(&this->m_ScriptResult + 387)))->UIStatic::CreateFromTemplate("SubGame\\Encampment\\head4.tga", v21);
  v22 = 4;
  do
  {
    (*(void ( **)(int *, _DWORD))*v10)(v10, 0);
    v10 += 38;
    --v22;
  }
  while ( v22 );
  (*(void ( **)(int *, int *, int *, Camera *))(*(&this->m_ScriptResult + 189) + 16))(
    &this->m_ScriptResult + 189,
    &byte_80AC01,
    &v47,
    this);
  LOBYTE(v23) = *((_BYTE *)&this->m_ScriptResult + 12549);
  (((UIStatic *)(&this->m_ScriptResult + 189)))->UIStatic::CreateFromTemplate("SubGame\\Encampment\\TurnTable.tga", v23);
  (**((void ( ***)(int *, _DWORD))&this->m_ScriptResult + 189))(&this->m_ScriptResult + 189, 0);
  v24 = *(&this->m_ScriptResult + 185);
  v25 = *(&this->m_ScriptResult + 184);
  v26 = *(&this->m_ScriptResult + 183) / 2 - v24 / 2 + v48 - 1;
  v27 = *(&this->m_ScriptResult + 182);
  v51[3] = v26 + v24;
  v51[1] = v26;
  v51[0] = v27 / 2 - v25 / 2 + v47 - 2;
  v28 = *(&this->m_ScriptResult + 227);
  v51[2] = v51[0] + v25;
  (*(void ( **)(int *, int *, _DWORD *, Camera *))(v28 + 16))(
    &this->m_ScriptResult + 227,
    &byte_80AC02,
    v51,
    this);
  (((UIStatic *)(&this->m_ScriptResult + 227)))->UIStatic::CreateFromTemplate("SubGame\\Encampment\\Pointer.tga", 0);
  (**((void ( ***)(int *, _DWORD))&this->m_ScriptResult + 227))(&this->m_ScriptResult + 227, 0);
  *(&this->m_ScriptResult + 266) = 2;
  v29 = *((float *)&this->m_ScriptResult + 2447);
  if ( v29 > 0.0 )
  {
    *((float *)&this->m_ScriptResult + 268) = *((float *)&this->m_ScriptResult + 2447);
    *((float *)&this->m_ScriptResult + 272) = v29;
    *((_BYTE *)&this->m_ScriptResult + 1080) = 0;
  }
  else
  {
    *(&this->m_ScriptResult + 268) = 0;
    *((_BYTE *)&this->m_ScriptResult + 1080) = 1;
  }
  *(&this->m_ScriptResult + 269) = 1;
  for ( i = 0; i < 5; ++i )
    (((UIScenePanel *)this))->UIScenePanel::ActivatePanel(i) /* [ROWTABLE] */;
  v51[5] = 245;
  v51[4] = 246;
  v51[6] = 446;
  v51[7] = 345;
  Create__ovl_1((ARC_PlayerAtt *)(&this->m_ScriptResult + 2451));
  (((UIItem *)(&this->m_ScriptResult + 2451)))->UIItem::SetData(31);
  v38 = 0;
  v31 = (RoleSystem *)&g_RoleSlotBuf;
  do
  {
    if ( *((_BYTE *)&((RoleSystem *)&stru_C059A0)->m_nRetryCount + v38) )
    {
      (((RoleSystem *)v31))->RoleSystem::RecalcAggregatedStats(0);
      v32 = (int *)&v31->m_partyActor.m_dwMatMsg[2];
      v33 = 12;
      do
      {
        v34 = *(v32 - 12);
        if ( *v32 < v34 )
        {
          if ( *v32 <= 0 )
            *v32 = 0;
        }
        else
        {
          *v32 = v34;
        }
        ++v32;
        --v33;
      }
      while ( v33 );
    }
    v31 = (RoleSystem *)((char *)v31 + 1408);
    ++v38;
  }
  while ( (int)v31 < (int)&((RoleSystem *)&stru_C059A0)->m_nAnimCopy3 );
  v51[9] = 200;
  v51[8] = 250;
  v51[10] = 550;
  v51[11] = 328;
  Create__ovl_1((ARC_PlayerAtt *)(&this->m_ScriptResult + 2793));
  (((UIItem *)(&this->m_ScriptResult + 2793)))->UIItem::SetData(31);
  v35 = *(&this->m_ScriptResult + 2814) + 28;
  *(&this->m_ScriptResult + 2817) = *(&this->m_ScriptResult + 2813) + 6;
  v36 = *(&this->m_ScriptResult + 2816);
  *(&this->m_ScriptResult + 2818) = v35;
  v37 = *(&this->m_ScriptResult + 2815) - 6;
  *(&this->m_ScriptResult + 2820) = v36 - 38;
  *(&this->m_ScriptResult + 3129) = 0;
  *(&this->m_ScriptResult + 3130) = 22;
  *(&this->m_ScriptResult + 2819) = v37;
  sub_445FA0(&this->m_ScriptResult + 2907);
  SetEnable((UICaption *)(&this->m_ScriptResult + 2907));
  *((_BYTE *)&this->m_ScriptResult + 12540) = 0;
  *(&this->m_ScriptResult + 3136) = 0;
  *((_BYTE *)&this->m_ScriptResult + 12548) = 0;
}
