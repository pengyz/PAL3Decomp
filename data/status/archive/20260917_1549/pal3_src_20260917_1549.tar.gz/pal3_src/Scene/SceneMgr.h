#pragma once
// Auto-generated: SceneMgr
#include "pal3/ida_types.h"

#include "Misc/PathFinder.h"
#include "Misc/PlayerAtts.h"
#include "Role/RoleSystem.h"
#include "gbengine/gbCamera.h"
#include "gbengine/gbGfxManager.h"
#include "gbengine/gbRenderEffect.h"
#include "gbengine/gbSceneGraph.h"
#include "gbengine/gbAudio.h"

class CCBStageRole;
class CEffMgr;
class CGameData;
class CameraCtrl;
class PalScriptMgr;
class Role;

class SceneMgr {
public:
    gbGfxManager * m_pGfxMgr; // +0x0
    gbSceneGraph * m_pSceneRoot; // +0x4
    gbRenderEffect * m_pAddEffect2; // +0x8
    gbRenderEffect * m_pAlphaEffect2; // +0xC
    gbRenderEffect * m_pAddEffect; // +0x10
    gbRenderEffect * m_pAlphaEffect; // +0x14
    gbCamera * m_pCamera; // +0x18
    float m_aSceneSlots; // +0x1C
    float m_nTodo_020[12]; // +0x20
    PlayerAtts m_PlayerAtts; // +0x50
    char _gap_120[364]; // +0x120
    int m_aRoleSlotStat[11]; // +0x28C
    int m_nSlotCount[1]; // +0x2B8
    char _gap_2BC[56]; // +0x2BC
    int m_nSlotMemberCount[1]; // +0x2F4
    char _gap_2F8[108]; // +0x2F8
    int m_aEquipGDB_ArmorData[1]; // +0x364
    int m_aEquipWField_01[1]; // +0x368
    int m_aEquipGDB_ArmorFlag[1]; // +0x36C
    int m_aEquipGDB_WeaponData[1]; // +0x370
    int m_aEquipWField_04[1]; // +0x374
    int m_aEquipGDB_ItemData[1]; // +0x378
    int m_aEquipGDB_WeaponFlag[1]; // +0x37C
    int m_aEquipWField_07[1]; // +0x380
    int m_aEquipGDB_ItemFlag[1]; // +0x384
    int m_aEquipGDB_Acc1Data[1]; // +0x388
    int m_aEquipWField_0A[1]; // +0x38C
    int m_aEquipGDB_Acc2Data[1]; // +0x390
    int m_aEquipGDB_Acc1Flag[1]; // +0x394
    int m_aEquipWField_0D[1]; // +0x398
    int m_aEquipGDB_Acc2Flag[1]; // +0x39C
    char _gap_3A0[4]; // +0x3A0
    int m_aSkillGDB_0F[1]; // +0x3A4
    int m_apSkillData[1]; // +0x3A8
    int m_aScriptDelay[1]; // +0x3AC
    int m_aViewModeParamA[1]; // +0x3B0
    int m_aViewModeParamB[1]; // +0x3B4
    int m_aEquipVal_0[1]; // +0x3B8
    int m_aEquipVal_1[1]; // +0x3BC
    int m_aEquipVal_2[1]; // +0x3C0
    int m_aEquipVal_3[1]; // +0x3C4
    int m_aEquipVal_4[1]; // +0x3C8
    int m_aEquipVal_5[1]; // +0x3CC
    int m_aEquipVal_6[1]; // +0x3D0
    int m_aEquipVal_7[1]; // +0x3D4
    int m_aEquipVal_8[1]; // +0x3D8
    int m_aScriptTransition[1]; // +0x3DC
    int m_aScreenModeParam[1]; // +0x3E0
    int m_aScreenModeParam2[1]; // +0x3E4
    char _gap_3E8[8]; // +0x3E8
    int m_nTodo_3F0[1]; // +0x3F0
    int m_nTodo_3F4[1]; // +0x3F4
    int m_aStatMaxVal_Exp[1]; // +0x3F8
    int m_aStatMaxVal_NextLv[1]; // +0x3FC
    int m_aStatMaxVal_WuLing0[1]; // +0x400
    int m_aStatMaxVal_WuLing1[1]; // +0x404
    int m_aStatMaxVal_WuLing2[1]; // +0x408
    int m_nGDBItemCount[1]; // +0x40C
    int m_nUIDisplayCount[1]; // +0x410
    int m_nGDBRoleCount[1]; // +0x414
    int m_aNPCData[1]; // +0x418
    char _gap_41C[28]; // +0x41C
    int m_aNPCFieldData[1]; // +0x438
    char _gap_43C[60]; // +0x43C
    int m_aNPCPropByType[1]; // +0x478
    char _gap_47C[28]; // +0x47C
    int m_aNPCPropByType2[1]; // +0x498
    char _gap_49C[60]; // +0x49C
    int m_aNPCPropBySlot[1]; // +0x4D8
    char _gap_4DC[132]; // +0x4DC
    int m_RenderBuffer[12]; // +0x560
    char _gap_590[3736]; // +0x590
    int m_nTodo_1428; // +0x1428
    int m_nTodo_142C; // +0x142C
    char _gap_1430[478]; // +0x1430
    BYTE m_nTodo_160E; // +0x160E
    char _gap_160F[1]; // +0x160F
    RoleSystem stru_C059A0; // +0x1610
    char _gap_2914[576]; // +0x2914
    CCBStageRole * m_pCCBStageRoleFind; // +0x2B54
    BYTE m_bRoleSlotValid[8]; // +0x2B58
    int m_nUnk61D8; // +0x2B60
    char _gap_2B64[6000]; // +0x2B64
    UINT m_nScriptObjectCount; // +0x42D4
    char _gap_42D8[33528]; // +0x42D8
    CGameData * m_pGameData; // +0xC5D0
    int _unkC5D4; // +0xC5D4
    CameraCtrl * m_pCameraCtrl; // +0xC5D8
    PalScriptMgr * m_pScriptCtrl; // +0xC5DC
    char _gap_C5E0[128]; // +0xC5E0
    int m_nTodo_C660; // +0xC660
    union { // +0xC67E
        RoleSystem * m_pRoleSystemArrayEnd; // +0xC67E
        struct {
            _BYTE _gap_50814[2]; // +0xC67E
            char _gap_C67F[1];
            int m_partyInitData[100]; // +0xC680
        } ;
    } ;
    char _gap_C812[54]; // +0xC812
    int m_nTodo_C848; // +0xC848
    char _gap_C84C[224]; // +0xC84C
    void * m_pCurrentScript; // +0xC92C
    BYTE m_bFormationReady; // +0xC930
    BYTE m_nSceneTransitionParam2; // +0xC931
    char _gap_C932[6]; // +0xC932
    int m_nCurrentRoleSlot; // +0xC938
    char _gap_C93C[4]; // +0xC93C
    float m_fFadeTimer; // +0xC940
    char _gap_C944[284]; // +0xC944
    PathFinder m_pathFinder; // +0xCA60
    char _gap_CA84[552]; // +0xCA84
    float m_fMoveParam; // +0xCCAC
    char _gap_CCB0[4]; // +0xCCB0
    float m_nField_CCB4; // +0xCCB4
    float m_nField_CCB8; // +0xCCB8
    char _gap_CCBC[44]; // +0xCCBC
    int m_nField_CCE8; // +0xCCE8
    int m_nField_CCEC; // +0xCCEC
    char _gap_CCF0[28]; // +0xCCF0
    float m_fTileSize; // +0xCD0C
    char _gap_CD10[608]; // +0xCD10
    float m_fCamFOV; // +0xCF70
    char _gap_CF74[4]; // +0xCF74
    int m_nField_CF78; // +0xCF78
    int m_nField_CF7C; // +0xCF7C
    char _gap_CF80[36]; // +0xCF80
    float m_vCameraTarget[3]; // +0xCFA4
    char _gap_CFB0[4]; // +0xCFB0
    float m_vCameraPos[3]; // +0xCFB4
    char _gap_CFC0[16]; // +0xCFC0
    float m_vCamLookAt[3]; // +0xCFD0
    char _gap_CFDC[84]; // +0xCFDC
    float m_CamMatrix[4]; // +0xD030
    float m_fCamDist; // +0xD040
    char _gap_D044[8]; // +0xD044
    int m_nField_D04C; // +0xD04C
    char _gap_D050[4]; // +0xD050
    int m_nField_D054; // +0xD054
    char _gap_D058[124]; // +0xD058
    int m_nCollisionFlags; // +0xD0D4
    char _gap_D0D8[300]; // +0xD0D8
    int m_ScriptResult; // +0xD204
    char _gap_D208[104]; // +0xD208
    RoleSystem * m_pControlledRole; // +0xD270
    int m_bCameraActive; // +0xD274
    char _gap_D278[100]; // +0xD278
    float m_nField_D2DC; // +0xD2DC
    float m_nField_D2E0; // +0xD2E0
    char _gap_D2E4[22]; // +0xD2E4
    BYTE m_bPathEnabled; // +0xD2FA
    char _gap_D2FB[1]; // +0xD2FB
    RoleSystem * m_pRoleSystem; // +0xD2FC
    int m_nCameraFlags; // +0xD300
    char _gap_D304[48]; // +0xD304
    float m_fTileSizeSub; // +0xD334
    char _gap_D338[34]; // +0xD338
    BYTE m_bPathBlockEnabled; // +0xD35A
    char _gap_D35B[1]; // +0xD35B
    RoleSystem * m_pRoleSystemPtr; // +0xD35C
    char _gap_D360[4]; // +0xD360
    gbSound2DNode * m_pCurrentBGM; // +0xD364
    float m_fCameraBlendWeight; // +0xD368
    char _gap_D36C[4]; // +0xD36C
    int m_nPartyRoles[6]; // +0xD370
    int m_nPartyCount; // +0xD388
    char _gap_D38C[40]; // +0xD38C
    int m_nMonsterType; // +0xD3B4
    char _gap_D3B8[12]; // +0xD3B8
    Role * m_pCombatRole; // +0xD3C4
    int m_nTodo_D3C8[500]; // +0xD3C8
    char _gap_DB98[1352]; // +0xDB98
    int m_nRoleCount; // +0xE0E0
    char _tail_E0E4[1120]; // +0xE0E4
    // total size: 0xE544 (58692)

    virtual ~SceneMgr() {}

    static int ResetPlayerAtts(); // 0x00408850
    static int InitSceneRoles(); // 0x0040CA40
    static int GetValidPartyCount(); // 0x0040FC70
    int RenderActiveRoles(); // 0x00421C00
    int UINotifyUpdate(); // 0x00421C40
    int * FindRoleByState(char nState); // 0x00422050
    static int ClearInactiveRoles(); // 0x00423500
    static int ResetSceneFlags(); // 0x004236B0
    void FormatStatusCaption(int nVal); // 0x00493E40
    SceneMgr * _scalar_dtor(void *Block, char pData); // 0x004CD930
    CEffMgr * Create(int gfxMgr, int cam, int nVal); // 0x004CDA10
    char RenderAll(); // 0x004CDBF0
    char RenderUpdate(); // 0x004CDC20
    int LoadMainUITexture(); // 0x00528D50
    int * GetCurrentNode(); // 0x0052EC90
};
