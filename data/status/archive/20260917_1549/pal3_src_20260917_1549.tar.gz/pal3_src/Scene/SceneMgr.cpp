#include "pal3/ida_defs.h"
#include "globals.h"
#include "pal3/pal3_constants.h"
#include "Scene/SceneMgr.h"
#include "Combat/CCBStageRole.h"
#include "Effect/CEffMgr.h"
#include "Role/Role.h"
#include "Misc/RoleAtt.h"
#include "Role/RoleSystem.h"
#include "Script/ScriptSystem.h"
#include "Misc/ScriptSystemData.h"
#include "free_functions.h"

// Forward declarations for unnamed functions

// 0x00408850
int SceneMgr::ResetPlayerAtts()
{
  RoleAtt **p_m_pEquipAtt0; // esi
  int result; // eax
  int v2; // [esp+0x10] [ebp-0x4]

  p_m_pEquipAtt0 = (RoleAtt **)&g_RoleSlotBuf.m_partyActor.m_pEquipAtt0;
  v2 = 5;
  do
  {
    *(p_m_pEquipAtt0 - 215) = 0;
    *((_WORD *)p_m_pEquipAtt0 - 428) = 0;
    lstrcpyA((LPSTR)p_m_pEquipAtt0 - 854, unk_C10D38);
    lstrcpyA((LPSTR)p_m_pEquipAtt0 - 342, unk_C10D38);
    lstrcpyA((LPSTR)p_m_pEquipAtt0 - 312, unk_C10D38);
    lstrcpyA((LPSTR)p_m_pEquipAtt0 - 260, unk_C10D38);
    memset(p_m_pEquipAtt0 - 56, 0, 0x30u);
    *(p_m_pEquipAtt0 - 20) = 0;
    *(p_m_pEquipAtt0 - 2) = (RoleAtt *)0xFFFF;
    *(p_m_pEquipAtt0 - 1) = 0;
    *p_m_pEquipAtt0 = 0;
    p_m_pEquipAtt0[1] = (RoleAtt *)0xFFFF;
    p_m_pEquipAtt0[2] = 0;
    p_m_pEquipAtt0[3] = 0;
    p_m_pEquipAtt0[4] = (RoleAtt *)0xFFFF;
    p_m_pEquipAtt0[5] = 0;
    p_m_pEquipAtt0[6] = 0;
    ArraySort((int)(p_m_pEquipAtt0 + 7), 12, 2, 0 /* TODO: (int)exception::exception */);
    p_m_pEquipAtt0[13] = (RoleAtt *)0xFFFF;
    p_m_pEquipAtt0[14] = 0;
    p_m_pEquipAtt0[15] = 0;
    memset(p_m_pEquipAtt0 - 215, 0, 0x580u);
    p_m_pEquipAtt0 += 352;
    result = --v2;
  }
  while ( v2 );
  return result;
}

// 0x0040CA40
int SceneMgr::InitSceneRoles()
{
  int *v0; // esi
  ScriptSystem *v1; // ecx
  int *v2; // eax
  int *v3; // ebp
  int v4; // edx
  bool v5; // zf
  int v6; // ecx
  void **v7; // eax
  int *v8; // ebx
  int *v9; // ebx
  int *v10; // eax
  int *v11; // edi
  int v12; // ecx
  void *v14; // [esp-0x4] [ebp-0x14]

  v0 = (int *)&((RoleSystem *)&stru_C059A0)->m_teamSlotOverlay.m_teamSlots[105];
  do
  {
    if ( *v0 )
      (((RoleSystem *)(v0 - 158)))->RoleSystem::NotifyMoveComplete();
    if ( v0 - 158 != (int *)((RoleSystem *)&stru_C10DF0)->m_teamSlotOverlay.m_teamSlots[154] )
      *v0 = 0;
    (((RoleSystem *)(v0 - 158)))->RoleSystem::NotifySceneChange();
    v1 = (ScriptSystem *)*(v0 - 123);
    v2 = (int *)(v0 - 123);
    if ( v1 )
    {
      v3 = (int *)(v0 - 123);
      do
      {
        v4 = *(v2 - 8) + 16;
        v6 = (unsigned long)(*v3 - 1);
        v5 = *v3 == 1;
        *(v2 - 8) = v4;
        *v3 = v6;
        if ( v5 || v4 == *(v0 - 132) )
        {
          v7 = (void **)*(v0 - 130);
          *(v0 - 130) = (int)(v7 + 1);
          operator delete(*v7);
          v3 = (int *)(v0 - 123);
          if ( *(v0 - 123) )
          {
            v10 = (int *)*(v0 - 130);
            v11 = (int *)(v0 - 133);
            v12 = (unsigned long)*v10;
            *v11 = *v10;
            v11[1] = v12 + 4096;
            v11[2] = v12;
            v11[3] = (int)v10;
          }
          else
          {
            v8 = (int *)(v0 - 133);
            *v8 = 0;
            v8[1] = 0;
            v8[2] = 0;
            v8[3] = 0;
            v9 = (int *)(v0 - 129);
            *(v0 - 129) = 0;
            v14 = (void *)*(v0 - 125);
            v9[1] = 0;
            v9[2] = 0;
            v9[3] = 0;
            operator delete(v14);
          }
        }
        v1 = (ScriptSystem *)*(v0 - 123);
        v2 = (int *)(v0 - 123);
      }
      while ( v1 );
    }
    v0[207] = 0;
    v0 += 2176;
  }
  while ( (int)v0 < (int)&g_SceneMgr.m_nTodo_C848 );
  g_RoleSystemExtra1.m_partyActor.m_pRoleObj = 0;
  return (((ScriptSystem *)v1))->ScriptSystem::Cleanup();
}

// 0x0040FC70
int SceneMgr::GetValidPartyCount()
{
  int result; // eax
  int i; // ecx

  result = 0;
  for ( i = 0; i < 5; ++i )
  {
    if ( *((_BYTE *)&((RoleSystem *)&stru_C059A0)->m_nRetryCount + i) )
      ++result;
  }
  return result;
}

// 0x00421C40
int SceneMgr::UINotifyUpdate()
{
  int v1; // ebx
  int v3; // edi
  RoleSystem *i; // esi

  v1 = ((RoleSystem *)&stru_C10DF0)->m_teamSlotOverlay.m_teamSlots[154];
  v3 = 0;
  if ( this->m_nRoleCount <= 0 )
    return 0;
  for ( i = (RoleSystem *)(&this->m_nRoleCount + 1);
        i->m_nActionState != 4 || !(((RoleSystem *)i))->RoleSystem::AdvancePathStep((float *)(v1 + 4));
        i = (RoleSystem *)((char *)i + 8704) )
  {
    if ( ++v3 >= this->m_nRoleCount )
      return 0;
  }
  return 1;
}

// 0x00423500
int SceneMgr::ClearInactiveRoles()
{
  int result; // eax
  int v1; // edx
  _DWORD *v2; // ecx

  result = UISceneUpdate();
  v1 = 0;
  if ( *(int *)(result + 57568) > 0 )
  {
    v2 = (_DWORD *)(result + 58204);
    do
    {
      if ( *((_BYTE *)v2 - 459) == 2 )
        *v2 = 0;
      ++v1;
      v2 += 2176;
    }
    while ( v1 < *(_DWORD *)(result + 57568) );
  }
  return result;
}

// 0x004236B0
int SceneMgr::ResetSceneFlags()
{
  int result; // eax

  result = 0;
  g_ScriptSystemData.m_nScriptCounter0 = 0;
  g_ScriptSystemData.m_nScriptCounter1 = 0;
  g_ScriptSystemData.m_nScriptFlag = 1;
  return result;
}

// 0x004CDA10
CEffMgr * SceneMgr::Create(int gfxMgr, int cam, int nVal)
{
  gbGfxManager *m_pGfxMgr; // eax
  gbRenderEffect *v6; // eax
  gbGfxManager *v7; // ecx
  gbRenderEffect *v8; // eax
  gbGfxManager *v9; // edx

  this->m_pGfxMgr = (gbGfxManager *)gfxMgr;
  this->m_pCamera = (gbCamera *)cam;
  this->m_pAddEffect = 0;
  this->m_pAlphaEffect = 0;
  this->m_pSceneRoot = (gbSceneGraph *)nVal;
  memset(&this->m_aSceneSlots, 0, 0x900u);
  memset(&this->m_RenderBuffer[239], 0, 0xA000u);
  m_pGfxMgr = (gbGfxManager *)this->m_pGfxMgr;
  *(&this->m_nScriptObjectCount + 6546) = 0;
  *(&this->m_nScriptObjectCount + 6547) = 0;
  *(&this->m_nScriptObjectCount + 6548) = 0;
  *(&this->m_nScriptObjectCount + 6549) = 0;
  *(&this->m_nScriptObjectCount + 6550) = 1065353216;
  v6 = (((gbEffectMgr *)m_pGfxMgr->pEffectMgr))->gbEffectMgr::NewRenderEffect("gfxscript\\AdditiveBlend.gbf", 0);
  v7 = (gbGfxManager *)this->m_pGfxMgr;
  this->m_pAddEffect = v6;
  v8 = (((gbEffectMgr *)v7->pEffectMgr))->gbEffectMgr::NewRenderEffect("gfxscript\\AlphaBlend.gbf", 0);
  v9 = (gbGfxManager *)this->m_pGfxMgr;
  this->m_pAlphaEffect = v8;
  this->m_pAddEffect2 = (((gbEffectMgr *)v9->pEffectMgr))->gbEffectMgr::NewRenderEffect("gfxscript\\AdditiveBlendNoZ.gbf", 0);
  this->m_pAlphaEffect2 = (((gbEffectMgr *)this->m_pGfxMgr->pEffectMgr))->gbEffectMgr::NewRenderEffect((const char *)g_TargetData, 0);
  /* [MISATTRIBUTED] CEffMgr on SceneMgr::this -> fix IDB name of callee */ CEffMgr::InitEffClass((CEffMgr *)this);
  return (CEffMgr *)this;
}

// 0x004CDBF0
char SceneMgr::RenderAll()
{
  int *v1; // esi
  int v2; // edi
  char result; // al

  v1 = (int *)&this->m_RenderBuffer[243];
  v2 = 2048;
  do
  {
    result = *((_BYTE *)v1 - 4);
    if ( result )
      result = (*(int ( **)(int))(*(_DWORD *)*v1 + 24))(*v1);
    v1 += 5;
    --v2;
  }
  while ( v2 );
  return result;
}

// 0x004CDC20
char SceneMgr::RenderUpdate()
{
  int *v1; // esi
  int v2; // edi
  char result; // al

  v1 = (int *)&this->m_RenderBuffer[243];
  v2 = 2048;
  do
  {
    result = *((_BYTE *)v1 - 4);
    if ( result )
      result = (*(int ( **)(int))(*(_DWORD *)*v1 + 16))(*v1);
    v1 += 5;
    --v2;
  }
  while ( v2 );
  return result;
}

// 0x0052EC90
int * SceneMgr::GetCurrentNode()
{
  this->m_PlayerAtts.m_nTodo_0C0 = 0;
  this->m_PlayerAtts.m_nTodo_0C4 = 0;
  this->m_PlayerAtts.m_nTodo_0CC = 0;
  *((_BYTE *)&this->m_PlayerAtts + 212) = 1;
  *((_BYTE *)&this->m_PlayerAtts + 213) = 1;
  *((_BYTE *)&this->m_PlayerAtts + 214) = 0;
  this->m_pGfxMgr = 0;
  this->m_pSceneRoot = 0;
  this->m_pAddEffect2 = 0;
  this->m_pAlphaEffect2 = 0;
  this->m_pAddEffect = 0;
  return (int *)this;
}
