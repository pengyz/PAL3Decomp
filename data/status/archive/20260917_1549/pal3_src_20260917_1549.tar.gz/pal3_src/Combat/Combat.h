#pragma once
// Auto-generated: Combat
#include "pal3/ida_types.h"

class Combat {
public:
    _BYTE _tail_000[4]; // +0x0
    // total size: 0x4 (4)

    int GetSlotCount(); // 0x0040CCD0
    char ReleaseCompletedEffects(); // 0x004CDB60
    char LogMessage(char *a2, int a3, char *format, ...); // 0x004DFD20
    unsigned __int8 HandleControlCmd(int idx); // 0x004F4820
    // Scalar-wrapper: ctors for IDA (Cls)int casts (no init code)
    Combat() {}
    Combat(int v) { *(int*)this = v; }

};
