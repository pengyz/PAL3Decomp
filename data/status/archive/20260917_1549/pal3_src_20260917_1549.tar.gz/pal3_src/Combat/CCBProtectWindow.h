#include "Misc/UIFrameWnd.h"
#pragma once
// Auto-generated: CCBProtectWindow
#include "pal3/ida_types.h"

class UIButton;
class UIProgressBar;
class UIPushButton;
class UIStatic;

class CCBProtectWindow : public UIFrameWnd {
public:
    char _gap_000[72]; // +0x0
    UIStatic * m_pBack; // +0x48
    UIPushButton * m_pWHFace; // +0x4C
    UIPushButton * m_pWPXFace; // +0x50
    UIProgressBar * m_pWHLove; // +0x54
    UIProgressBar * m_pWPXLove; // +0x58
    UIButton * m_pOk; // +0x5C
    char _tail_060[80]; // +0x60
    // total size: 0xB0 (176)

    virtual BOOL ShowAndNotify(int nVal, int nVal2); // 0x00518E30
    virtual void Destroy(); // 0x005164D0
    CCBProtectWindow * _sdtor_19(char a2); // 0x00516100
    char ValidateSlot(unsigned int dwVal); // 0x00449BE0
    void _scalar_dtor(); // 0x00516120
    CCBProtectWindow(); // 0x0051D6E0
    ~CCBProtectWindow(); // 0x0051D6F0
    void Reset(); // 0x0051D700
    virtual int OnCommand(int nVal, int nVal2); // 0x0051F0A0
};
