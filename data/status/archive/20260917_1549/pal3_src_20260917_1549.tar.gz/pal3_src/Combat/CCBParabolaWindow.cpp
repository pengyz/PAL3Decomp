#include "pal3/ida_defs.h"
#include "globals.h"
#include "pal3/pal3_constants.h"
#include "Combat/CCBParabolaWindow.h"
#include "Combat/CCBAIWindow.h"
#include "Combat/CCBControl.h"
#include "Combat/CCBControlWindow.h"
#include "Combat/CCBItemWindow.h"
#include "Combat/CCBLineupWindow.h"
#include "Combat/CCBMagicWindow.h"
#include "Combat/CCBStage.h"
#include "GameBase/GRPinput.h"
#include "Misc/OpenBaseFile.h"
#include "Misc/OpenNULLFile.h"
#include "Scene/SceneObj.h"
#include "Misc/TextureLibDataBase.h"
#include "Misc/UIFrameWnd.h"
#include "UI/UIListBox.h"
#include "Misc/UIPushButton.h"
#include "Misc/UIStatic.h"
#include "UI/UIWnd.h"
#include "Misc/_Texture_Info.h"
#include "free_functions.h"

// Forward declarations for unnamed functions

// 0x00440BE0
gbVFileSystem * CCBParabolaWindow::LoadResourceEx(const char *pszName, char pData)
{
  int v4; // edi
  CCBParabolaWindow *v5; // esi
  int ( **vftable)(gbGfxManager *, CHAR *); // ebp
  CHAR *v7; // eax
  gbVFileSystem *result; // eax
  OpenBaseFile v9; // [esp+0x10] [ebp-0x114] BYREF
  char Buffer[260]; // [esp+0x14] [ebp-0x110] BYREF
  int v11; // [esp+0x120] [ebp-0x4]

  v4 = 0;
  v11 = 0;
  v5 = this + 1;
  do
  {
    if ( (*(void **)(v5)) )
      (((gbRefObject *)(*(void **)(v5))))->gbRefObject::Release();
    sprintf(Buffer, "%s%d.tga", pszName, v4);
    if ( pData )
    {
      vftable = (int ( **)(gbGfxManager *, CHAR *))(*(void **)(gfxMgr));
      v7 = (((_Texture_Info *)&stru_1894B78))->_Texture_Info::_CalculateUV(Buffer);
      (*(void **)(v5)) = (void *)vftable[2](gfxMgr, v7);
      v5->m_wndcolor.Color = (unsigned int)((TextureLibDataBase *)&stru_1894B78)->TextureLibDataBase::CreateParentData(Buffer);
    }
    else
    {
    }
    if ( (*(void **)(v5)) )
      (((gbTexture *)(*(void **)(v5))))->gbTexture::LoadTexture(1);
    ++v4;
    v5 = (CCBParabolaWindow *)((char *)v5 + 4);
  }
  while ( v4 < 2 );
  v11 = -1;
  // [AUTO-COMMENTED] (OpenNULLFile *)&v9->OpenNULLFile();
  return result;
}

// 0x0051B710
CCBParabolaWindow::CCBParabolaWindow(
        
        CCBParabolaWindow **thisa,
        int *pnVal,
        int nVal)
{
  UIStatic **p_m_wndcolor; // edi
  CCBLineupWindow *v6; // ecx
  CCBLineupWindow *v7; // ecx
  char v8; // al
  UIStatic **p_m_id; // ebx
  int i; // edi
  char v11; // al
  int v12; // eax
  int v13; // ecx

  (((CCBItemWindow *)this))->CCBItemWindow::Create(1879048197, (tagRECT *)thisa, (int)pnVal) /* [ROWTABLE] */;
  this[1].m_childs.m_pData = (char *)pnVal;
  p_m_wndcolor = (UIStatic **)&this[1].m_wndcolor;
  (((CCBLineupWindow *)v6))->CCBLineupWindow::Destroy();
  if ( v8 == 1 )
  {
    *thisa = 0;
    thisa[2] = (CCBParabolaWindow *)230;
    thisa[1] = 0;
    thisa[3] = (CCBParabolaWindow *)250;
    p_m_wndcolor->Create(240,
      thisa,
      this);
    (*p_m_wndcolor)->UIStatic::CreateFromTemplate(&unk_5DF73C, 0);
    p_m_wndcolor->ShowWindow(1);
  }
  p_m_id = (UIStatic **)&this[1].m_id;
  for ( i = 0; i < 5; ++i )
  {
    (((CCBLineupWindow *)v7))->CCBLineupWindow::Destroy();
    if ( v11 )
    {
      v12 = g_nUnkTable_268[i + 1];
      v13 = g_nUnkTable_24C[i + 1];
      *thisa = (CCBParabolaWindow *)v13;
      thisa[1] = (CCBParabolaWindow *)v12;
      thisa[2] = (CCBParabolaWindow *)(v13 + 40);
      thisa[3] = (CCBParabolaWindow *)(v12 + 38);
      p_m_id->Create(g_nPropIDs_241[i],
        thisa,
        this);
      (*p_m_id)->UIStatic::CreateFromTemplate(*(_UNKNOWN **)((char *)&off_570284 + i * 4), 0);
      (((UIFrameWnd *)*p_m_id))->UIFrameWnd::SetTextureByName((&off_570298)[i], 0);
      p_m_id->ShowWindow(1);
    }
    ++p_m_id;
  }
}

// 0x0051B810
CCBParabolaWindow::~CCBParabolaWindow()
{
  unsigned int Color; // ecx
  void **p_m_id; // esi
  int v4; // edi

  this->Destroy();
  Color = this[1].m_wndcolor.Color;
  if ( Color )
  {
    (*(void (**)(unsigned int, int))(*(_DWORD *)Color + 20))(Color, 1);
    this[1].m_wndcolor.Color = 0;
  }
  p_m_id = (void **)&this[1].m_id;
  v4 = 5;
  do
  {
    if ( *p_m_id )
    {
      (*(void (**)(void *, int))(*(_DWORD *)*p_m_id + 20))(*p_m_id, 1);
      *p_m_id = 0;
    }
    ++p_m_id;
    --v4;
  }
  while ( v4 );
}

// 0x0051B920
void CCBParabolaWindow::Destroy()
{
  int v2; // ecx
  CCBMagicWindow *v3; // [esp+0x0] [ebp-0x4]

  (((CCBControlWindow *)this))->CCBControlWindow::Render(v3) /* [ROWTABLE] */;
  v2 = *((_DWORD *)&this[1].m_id + (int)this[1].m_pfather);
  (*(void ( **)(int))(*(_DWORD *)v2 + 4))(v2);
}

// 0x0051B950
bool CCBParabolaWindow::OnMessage(int msg, int wparam, int lparam)
{
  int *v4; // eax
  _BYTE a2[16]; // [esp+0x8] [ebp-0x10] BYREF

  v4 = (int *)sub_445FE0(a2);
  return wparam >= *v4 && wparam < v4[2] && lparam >= v4[1] && lparam < v4[3];
}

// 0x0051C880

// ---- synthesized vtable stubs (unresolved slots) ----
// [VFTABLE-STUB] original: ((int ( *)(UIStatic *, int))m_pBack->__vftable->_sdtor_call_dtor)(m_pBack, 1)
static int pal3_vtbl_unk_0(UIStatic *, int);
// [VFTABLE-STUB] original: ((int ( *)(UIStatic *, int))m_pDescription->__vftable->_sdtor_call_dtor)(m_pDescription, 1)
static int pal3_vtbl_unk_1(UIStatic *, int);
// [VFTABLE-STUB] original: ((int ( *)(UIListBox *, int))m_pItemList->__vftable->_sdtor_call_dtor)(m_pItemList, 1)
static int pal3_vtbl_unk_2(UIListBox *, int);
// [VFTABLE-STUB] original: ((int ( *)(UIStatic *, int))v15->__vftable->_sdtor_call_dtor)(v15, 1)
static int pal3_vtbl_unk_3(UIStatic *, int);
// [VFTABLE-STUB] original: ((int ( *)(UIStatic *, int))v16->__vftable->_sdtor_call_dtor)(v16, 1)
static int pal3_vtbl_unk_4(UIStatic *, int);
// [VFTABLE-STUB] original: ((int ( *)(UIListBox *, int))v17->__vftable->_sdtor_call_dtor)(v17, 1)
static int pal3_vtbl_unk_5(UIListBox *, int);

int CCBParabolaWindow::Destroy_c880()
{
  int result; // eax
  LONG *p_right; // edi
  int v4; // ebx
  UIStatic *m_pBack; // ecx
  UIStatic *m_pDescription; // ecx
  UIListBox *m_pItemList; // ecx
  void *vftable; // ecx
  unsigned int Color; // ecx
  unsigned int v10; // ecx
  void *m_id; // ecx
  LONG left; // ecx
  LONG top; // ecx
  gbTexture *m_pbktex; // ecx
  UIStatic *v15; // ecx
  UIStatic *v16; // ecx
  UIListBox *v17; // ecx

  result = this->Destroy();
  p_right = (LONG *)&this[1].m_rect.right;
  v4 = 11;
  do
  {
    if ( *p_right )
    {
      result = (*(int ( **)(LONG, int))(*(_DWORD *)*p_right + 20))(*p_right, 1);
      *p_right = 0;
    }
    ++p_right;
    --v4;
  }
  while ( v4 );
  m_pBack = (UIStatic *)this->m_pBack;
  if ( m_pBack )
  {
    result = pal3_vtbl_unk_0(m_pBack, 1) /* [VFTABLE-STUB] */;
    this->m_pBack = 0;
  }
  m_pDescription = (UIStatic *)this->m_pDescription;
  if ( m_pDescription )
  {
    result = pal3_vtbl_unk_1(m_pDescription, 1) /* [VFTABLE-STUB] */;
    this->m_pDescription = 0;
  }
  m_pItemList = (UIListBox *)this->m_pItemList;
  if ( m_pItemList )
  {
    result = pal3_vtbl_unk_2(m_pItemList, 1) /* [VFTABLE-STUB] */;
    this->m_pItemList = 0;
  }
  vftable = (*(void **)&(this[1]));
  if ( vftable )
  {
    result = (*((int ( **)(void *, int))vftable->ShowWindow + 5))(vftable, 1);
    (*(void **)&(this[1])) = (void *)(0);
  }
  Color = this[1].m_fontcolor.Color;
  if ( Color )
  {
    result = (*(int ( **)(unsigned int, int))(*(_DWORD *)Color + 20))(Color, 1);
    this[1].m_fontcolor.Color = 0;
  }
  v10 = this[1].m_wndcolor.Color;
  if ( v10 )
  {
    result = (*(int ( **)(unsigned int, int))(*(_DWORD *)v10 + 20))(v10, 1);
    this[1].m_wndcolor.Color = 0;
  }
  m_id = this[1].m_id;
  if ( m_id )
  {
    result = (*(int ( **)(void *, int))(*(_DWORD *)m_id + 20))(m_id, 1);
    this[1].m_id = 0;
  }
  left = this[1].m_rect.left;
  if ( left )
  {
    result = (*(int ( **)(LONG, int))(*(_DWORD *)left + 20))(left, 1);
    this[1].m_rect.left = 0;
  }
  top = this[1].m_rect.top;
  if ( top )
  {
    result = (*(int ( **)(LONG, int))(*(_DWORD *)top + 20))(top, 1);
    this[1].m_rect.top = 0;
  }
  m_pbktex = this[1].m_pbktex;
  if ( m_pbktex )
  {
    result = (unsigned long)m_pbktex->UpdateTexture(1);
    this[1].m_pbktex = 0;
  }
  v15 = (UIStatic *)this[1].m_pBack;
  if ( v15 )
  {
    result = pal3_vtbl_unk_3(v15, 1) /* [VFTABLE-STUB] */;
    this[1].m_pBack = 0;
  }
  v16 = (UIStatic *)this[1].m_pDescription;
  if ( v16 )
  {
    result = pal3_vtbl_unk_4(v16, 1) /* [VFTABLE-STUB] */;
    this[1].m_pDescription = 0;
  }
  v17 = (UIListBox *)this[1].m_pItemList;
  if ( v17 )
  {
    result = pal3_vtbl_unk_5(v17, 1) /* [VFTABLE-STUB] */;
    this[1].m_pItemList = 0;
  }
  return result;
}

static int pal3_vtbl_unk_0(UIStatic *, int)
{
    return 0;
}
static int pal3_vtbl_unk_1(UIStatic *, int)
{
    return 0;
}
static int pal3_vtbl_unk_2(UIListBox *, int)
{
    return 0;
}
static int pal3_vtbl_unk_3(UIStatic *, int)
{
    return 0;
}
static int pal3_vtbl_unk_4(UIStatic *, int)
{
    return 0;
}
static int pal3_vtbl_unk_5(UIListBox *, int)
{
    return 0;
}


// 0x0051C9F0
BOOL CCBParabolaWindow::Update(int deltatime, int haveinput)
{
  if ( this->m_bvisible == 1 && g_Input.KeyInfo[16].PressTime == 1 && (g_Input.KeyInfo[16].Data & 0xF) == 1 )
    CCBControl::SetParam(*(CCBControl **)(this->m_pfather[17].m_fontcolor.Color + 8), 513, -1);
  return (((SceneObj *)this))->SceneObj::Update(deltatime, haveinput) /* [ROWTABLE] */;
}

// 0x0051CA50
CCBAIWindow * CCBParabolaWindow::ToggleSlots(int nVal)
{
  int v3; // edi
  LONG *p_right; // esi
  void ( ***v5)(_DWORD, int); // ecx

  if ( nVal == 1 )
  {
    LOBYTE(this[2].m_wndcolor.Color) = 0;
    v3 = 0;
    p_right = (LONG *)&this[1].m_rect.right;
    do
    {
      v5 = (void ( ***)(_DWORD, int))*p_right;
      if ( this[2].m_fontcolor.Color == v3 )
        (**v5)(v5, 1);
      else
        (**v5)(v5, 0);
      ++v3;
      ++p_right;
    }
    while ( v3 < 5 );
  }
  return (CCBAIWindow *)this->UIWnd::ShowWindow(nVal);
}

// 0x0051CAA0
void CCBParabolaWindow::Render()
{
  LONG left; // ebx
  CCBMagicWindow *v3; // [esp+0x0] [ebp-0x18]

  (((CCBControlWindow *)this))->CCBControlWindow::Render(v3) /* [ROWTABLE] */;
  left = this->m_rect.left;
  CCBStage_AddTextLabel(left + 105);
  CCBStage_AddTextLabel(left + 117);
  CCBStage_AddTextLabel(left + 107);
}
