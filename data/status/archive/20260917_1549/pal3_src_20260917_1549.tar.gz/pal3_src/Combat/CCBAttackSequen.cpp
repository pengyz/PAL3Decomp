#include "pal3/ida_defs.h"
#include "globals.h"
#include "pal3/pal3_constants.h"
#include "Combat/CCBAttackSequen.h"
#include "Combat/CCBRoleState.h"
#include "Combat/CCBStage.h"
#include "Combat/CCBSystem.h"
#include "Combat/CCBUI.h"
#include "Role/NPC.h"
#include "Misc/UIStatic.h"
#include "UI/UIWnd.h"
#include "Misc/tagCmdData.h"
#include "free_functions.h"

// Forward declarations for unnamed functions

// 0x004DB5C0
int CCBAttackSequen::ResetTimers()
{
  float *v2; // eax
  int v3; // ecx
  float *p_fLastTime; // eax
  int v5; // ecx

  if ( this->m_bPause || !this->m_bEnable )
  {
    p_fLastTime = (float *)&this->m_Sequen[0].fLastTime;
    v5 = 11;
    do
    {
      *(p_fLastTime - 1) = 0.0;
      p_fLastTime += 10;
      --v5;
      *(p_fLastTime - 10) = this->m_pCBSystem->m_fTimeFund;
    }
    while ( v5 );
  }
  else
  {
    v2 = (float *)&this->m_Sequen[0].fLastTime;
    v3 = 11;
    do
    {
      if ( *((_BYTE *)v2 + 31) )
        *(v2 - 1) = 0.0;
      else
        *(v2 - 1) = this->m_pCBSystem->m_fTimeFund - *v2;
      v2 += 10;
      --v3;
      *(v2 - 10) = this->m_pCBSystem->m_fTimeFund;
    }
    while ( v3 );
  }
  this->CCBAttackSequen::ProcessQueue();
  this->CCBAttackSequen::CheckComplete();
  return this->CCBAttackSequen::AdvanceStep();
}

// 0x004DB910
double CCBAttackSequen::SetPause(char bPause)
{
  double result; // st7

  this->m_bPause = bPause;
  return result;
}

// 0x004DBA60
char CCBAttackSequen::ProcessQueue()
{
  int v2; // ebx
  int *p_nSlot2; // esi
  __int64 v4; // rax
  int v5; // edi

  v2 = 0;
  p_nSlot2 = (int *)&this->m_Sequen[0].nSlot2;
  do
  {
    LOBYTE(v4) = *((_BYTE *)p_nSlot2 + 12);
    if ( (_BYTE)v4 )
    {
      LOBYTE(v4) = (((CCBRoleState *)this->m_pCBSystem->m_pRoleState))->CCBRoleState::IsRoleAlive(v2);
      if ( (_BYTE)v4 )
      {
        if ( *((_BYTE *)p_nSlot2 + 10) )
        {
          v4 = (__int64)((double)*((unsigned __int8 *)p_nSlot2 + 9) * (*((float *)p_nSlot2 - 6) * 50.0)
                       + (double)*p_nSlot2);
          *p_nSlot2 = v4;
          if ( (int)v4 > 11500 )
            *p_nSlot2 = 11500;
        }
        else
        {
          v5 = *(p_nSlot2 - 1);
          v4 = (__int64)(*((float *)p_nSlot2 - 6) * 50.0 * (double)*((unsigned __int8 *)p_nSlot2 + 8) + (double)v5);
          *(p_nSlot2 - 1) = v4;
          if ( (int)v4 >= 11500 )
          {
            if ( v5 < 11500 )
              ++p_nSlot2[1];
            *(p_nSlot2 - 1) = 11500;
          }
        }
      }
    }
    ++v2;
    p_nSlot2 += 10;
  }
  while ( v2 < 11 );
  return v4;
}

// 0x004DBB20
char CCBAttackSequen::CheckComplete()
{
  int v2; // edi
  _BYTE *p_bSlot2Running; // esi
  char result; // al
  double v5; // st7

  v2 = 76;
  p_bSlot2Running = (_BYTE *)&this->m_Sequen[0].bSlot2Running;
  do
  {
    result = p_bSlot2Running[2];
    if ( result )
    {
      if ( *p_bSlot2Running )
        v5 = (double)*(int *)(p_bSlot2Running - 10) * 0.0078260871 + 659.0;
      else
        v5 = (double)*(int *)(p_bSlot2Running - 14) * 0.017130435 + 460.0;
      result = sub_445D20(*(_DWORD **)((char *)((void **)(this->m_pUI)) + v2), (__int64)v5, 8);
    }
    v2 += 4;
    p_bSlot2Running += 40;
  }
  while ( v2 < 120 );
  return result;
}

// 0x004DBB80
int CCBAttackSequen::CalcTurnOrder()
{
  int v2; // ebp
  int v3; // ebx
  _BYTE *p_bSlot2Running; // esi
  CCBRoleState *m_pRole; // eax
  int result; // eax
  int *p_nSlot1; // ecx
  int *v8; // ecx
  int SpeedBonus; // ebp
  int v10; // ebx
  int i; // esi
  CCBRoleState *v12; // ecx
  int v13; // ebp
  int *v14; // ebx
  int v15; // esi
  int v16; // ecx
  int v17; // [esp+0x10] [ebp-0x4]

  v2 = 0;
  v3 = 0;
  p_bSlot2Running = (_BYTE *)&this->m_Sequen[0].bSlot2Running;
  do
  {
    if ( this->m_pRole->m_pObjMsgBuffer[v3 + 153] )
    {
      p_bSlot2Running[2] = 1;
      *p_bSlot2Running = 0;
      *(p_bSlot2Running - 2) = /* [MISATTRIBUTED] CCBSystem on CCBAttackSequen::this -> fix IDB name of callee */ CCBSystem::CalcSpeed((CCBSystem *)this, v2, 0);
      *(p_bSlot2Running - 1) = /* [MISATTRIBUTED] CCBSystem on CCBAttackSequen::this -> fix IDB name of callee */ CCBSystem::CalcSpeed((CCBSystem *)this, v2, 1);
      *(_DWORD *)(p_bSlot2Running - 10) = 0;
      *(_DWORD *)(p_bSlot2Running - 6) = 0;
    }
    v3 += 892;
    ++v2;
    p_bSlot2Running += 40;
  }
  while ( v3 < 9812 );
  m_pRole = (CCBRoleState *)this->m_pRole;
  if ( m_pRole->m_pObjMsgBuffer[113] )
  {
    result = 0;
    p_nSlot1 = (int *)&this->m_Sequen[0].nSlot1;
    do
    {
      if ( this->m_pRole->m_pObjMsgBuffer[result + 153] )
      {
        if ( result < 4460 )
          *p_nSlot1 = 0;
        else
          *p_nSlot1 = 11500;
      }
      result += 892;
      p_nSlot1 += 10;
    }
    while ( result < 9812 );
  }
  else if ( m_pRole->m_pObjMsgBuffer[112] )
  {
    result = 0;
    v8 = (int *)&this->m_Sequen[0].nSlot1;
    do
    {
      if ( this->m_pRole->m_pObjMsgBuffer[result + 153] )
      {
        if ( (unsigned int)result >= 0x116C )
          *v8 = 0;
        else
          *v8 = 11500;
      }
      result += 892;
      v8 += 10;
    }
    while ( result < 9812 );
  }
  else
  {
    SpeedBonus = 0;
    v10 = 0;
    for ( i = 0; i < 9812; i += 892 )
    {
      v12 = (CCBRoleState *)this->m_pRole;
      if ( v12->m_pObjMsgBuffer[i + 153] && (((CCBRoleState *)v12))->CCBRoleState::GetSpeedBonus(v10) > SpeedBonus )
        SpeedBonus = (((CCBRoleState *)this->m_pRole))->CCBRoleState::GetSpeedBonus(v10);
      ++v10;
    }
    v13 = 0;
    result = 0;
    v17 = 0;
    v14 = (int *)&this->m_Sequen[0].nSlot1;
    do
    {
      if ( this->m_pRole->m_pObjMsgBuffer[result + 153] )
      {
        ++*(_DWORD *)&g_TempBuffer1024[912];
        g_nCombatRandSeed = 214013 * g_nCombatRandSeed + 2531011;
        v15 = ((int)g_nCombatRandSeed >> 16) & 0x7FFF;
        v16 = 319 * (((CCBRoleState *)this->m_pRole))->CCBRoleState::GetSpeedBonus(v13);
        result = v17;
        *v14 = v15 % 638 + 2 * v16;
      }
      result += 892;
      ++v13;
      v14 += 10;
      v17 = result;
    }
    while ( result < 9812 );
  }
  return result;
}

// 0x004DBD40

// ---- synthesized vtable stubs (unresolved slots) ----
// [VFTABLE-STUB] original: (***(void ( ****)(_DWORD, _DWORD))((char *)&this->m_pUI->__vftable + v3))( *(vtbl_0056AE2C **)((char *)&this->m_pUI->__vftable + v3), 0)
static void pal3_vtbl_unk_0(_DWORD, _DWORD);
// [VFTABLE-STUB] original: (***(void ( ****)(_DWORD, int))((char *)&m_pUI->__vftable + v3))( *(vtbl_0056AE2C **)((char *)&m_pUI->__vftable + v3), 1)
static void pal3_vtbl_unk_1(_DWORD, int);

int CCBAttackSequen::AdvanceStep()
{
  int v1; // ebx
  int v3; // esi
  CCBRoleState *m_pRole; // ecx
  CCBUI *m_pUI; // eax
  int result; // eax
  int roleIdx; // [esp+0x1C] [ebp-0x8]

  v1 = 0;
  roleIdx = 0;
  v3 = 76;
  do
  {
    m_pRole = (CCBRoleState *)this->m_pRole;
    if ( m_pRole->m_pObjMsgBuffer[v1 + 153] )
    {
      if ( !(((CCBRoleState *)m_pRole))->CCBRoleState::IsRoleAlive(roleIdx) || this->m_pRole->m_info.depend_scenename[v1 + 26] == 1 )
      {
        pal3_vtbl_unk_0(*(void **)((char *)((void **)(this->m_pUI)) + v3), 0) /* [VFTABLE-STUB] */;
      }
      else
      {
        m_pUI = (CCBUI *)this->m_pUI;
        if ( m_pUI->m_pAttackSequenBack->m_bvisible == 1 )
          pal3_vtbl_unk_1(*(void **)((char *)((void **)(m_pUI)) + v3), 1) /* [VFTABLE-STUB] */;
        if ( *(_BYTE *)(*(_DWORD *)((char *)this->m_pCBSystem->m_pStage + v3 - 52) + 280) )
          sub_446030(*(_DWORD **)((char *)((void **)(this->m_pUI)) + v3));
        NPC::UpdateAnim(*(NPC **)((char *)((void **)(this->m_pUI)) + v3));
      }
    }
    v3 += 4;
    result = roleIdx + 1;
    v1 += 892;
    ++roleIdx;
  }
  while ( v3 < 120 );
  return result;
}

static void pal3_vtbl_unk_0(_DWORD, _DWORD)
{
    
}
static void pal3_vtbl_unk_1(_DWORD, int)
{
    
}


// 0x005270C0
int CCBAttackSequen::FindSequenceSlot(int nVal)
{
  int result; // eax
  int v3; // edx
  int *p_nIndex; // esi
  int *v5; // edx

  result = 0;
  v3 = 0;
  p_nIndex = (int *)&this->m_Sequen[10].nIndex;
  do
  {
    if ( !*((_BYTE *)&this[32].m_Sequen[10].nIndex + v3 + 1) )
    {
      ++result;
      p_nIndex[3] = 0;
      *(_BYTE *)p_nIndex = 0;
    }
    ++v3;
    p_nIndex += 62;
  }
  while ( v3 < 5 );
  v5 = (int *)(&this->m_Sequen[8].nSlot1 + 62 * nVal);
  v5[20] = 1;
  *((_BYTE *)v5 + 68) = 1;
  if ( result )
  {
    if ( *((_BYTE *)&this[32].m_Sequen[10].nIndex + nVal + 1) )
      return -1;
  }
  return result;
}
