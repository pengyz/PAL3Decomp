#include "pal3/ida_defs.h"
#include "globals.h"
#include "pal3/pal3_constants.h"
#include "Combat/CCBMagicWindow.h"
#include "Combat/CCBItemWindow.h"
#include "Combat/CCBLineupWindow.h"
#include "Combat/CCBSkillWindow.h"
#include "Scene/CameraCtrl.h"
#include "Misc/RoleCameraCtrl.h"
#include "UI/UIListBox.h"
#include "Misc/UIProgressBar.h"
#include "Misc/UIPushButton.h"
#include "UI/UIScene.h"
#include "Misc/UIScrollBar.h"
#include "Misc/UIStatic.h"
#include "UI/UIWnd.h"
#include "free_functions.h"

// Forward declarations for unnamed functions

// 0x0051B9F0
CCBMagicWindow::CCBMagicWindow(int nVal, int nVal2, int *p_DWORD)
{
  int v4; // eax
  int *v5; // eax
  int v6; // [esp-0x14] [ebp-0x40]
  int v7; // [esp-0x10] [ebp-0x3C]
  int v8; // [esp-0xC] [ebp-0x38]
  int v9; // [esp-0x8] [ebp-0x34]
  int v10[4]; // [esp+0xC] [ebp-0x20] BYREF
  _BYTE a2[16]; // [esp+0x1C] [ebp-0x10] BYREF

  v4 = g_nUnkTable_24C[nVal];
  v6 = v4 + 9;
  v7 = g_nUnkTable_268[nVal] + 232;
  v8 = v4 + 49;
  v9 = g_nUnkTable_268[nVal] + 270;
  v5 = (int *)sub_445FE0(a2);
  if ( CCBLineupWindow::SetFaceLineup(*v5, v5[1], v5[2], v5[3], v6, v7, v8, v9, v10) )
    *p_DWORD = (v10[3] - v10[1]) * (v10[2] - v10[0]);
  else
    *p_DWORD = 0;
}

// 0x0051BAB0
CCBMagicWindow::~CCBMagicWindow()
{
  int v2; // edi
  int i; // esi
  char v5; // al
  int p_DWORD; // [esp+0x10] [ebp-0x4] BYREF

  v2 = 0;
  p_DWORD = 0;
  for ( i = 1; i < 7; ++i )
  {
    if ( v5 )
    {
      if ( p_DWORD > v2 )
        v2 = p_DWORD;
    }
  }
}

// 0x0051BB00
void CCBMagicWindow::Reset(int nVal, int nVal2)
{
  UIStatic **p_m_pBack; // eax
  int v4; // esi

  p_m_pBack = (UIStatic **)&this->m_pBack;
  v4 = 5;
  do
  {
    if ( *p_m_pBack == (UIStatic *)nVal2 )
      *p_m_pBack = (UIStatic *)*((_DWORD *)&this->m_pBack + nVal);
    ++p_m_pBack;
    --v4;
  }
  while ( v4 );
  *((_DWORD *)&this->m_pBack + nVal) = nVal2;
  (((RoleCameraCtrl *)this))->RoleCameraCtrl::InitViewSlots() /* [ROWTABLE] */;
}

// 0x0051BB40
bool CCBMagicWindow::Create(int rc)
{
  bool result; // al

  result = rc;
  this->m_pButtonEarth = (UIPushButton *)rc;
  return result;
}

// 0x0051BB90
UIListBox * CCBMagicWindow::ForbidPage()
{
  this->CCBMagicWindow::ClearMagicData();
  return (UIListBox *)this;
}

// 0x0051BC50
int CCBMagicWindow::ClearMagicData()
{
  int result; // eax

  result = 0;
  this->m_pBack = 0;
  this->m_pMagicList[0] = 0;
  this->m_pMagicList[1] = 0;
  this->m_pMagicList[2] = 0;
  this->m_pMagicList[3] = 0;
  this->m_pMagicList[4] = 0;
  this->m_pMagicList[5] = 0;
  this->m_pButtonWater = 0;
  return result;
}

// 0x0051BC70
bool CCBMagicWindow::CreateButton(int *ppButton, int id)
{
  UIStatic **p_m_pBack; // edi
  CCBLineupWindow *v5; // ecx
  CCBLineupWindow *v6; // ecx
  char v7; // al
  UIScene **v8; // edi
  CCBLineupWindow *v9; // ecx
  void *v10; // eax
  UIScene *v11; // eax
  UIScene **v12; // edi
  CCBLineupWindow *v13; // ecx
  void *v14; // eax
  UIScene *v15; // eax
  UIScene **v16; // edi
  CCBLineupWindow *v17; // ecx
  void *v18; // eax
  UIScene *v19; // eax
  UIListBox **m_pMagicList; // edi
  CCBLineupWindow *v21; // ecx
  UIStatic **v22; // edi
  CCBLineupWindow *v23; // ecx
  UIStatic **v24; // edi
  CCBLineupWindow *v25; // ecx
  UIPushButton **p_m_pButtonWater; // edi
  _BYTE a2[16]; // [esp+0x3C] [ebp-0x10] BYREF

  (((CCBItemWindow *)this))->CCBItemWindow::Create(1879048198, (tagRECT *)ppButton, id) /* [ROWTABLE] */;
  p_m_pBack = (UIStatic **)&this->m_pBack;
  (((CCBLineupWindow *)v5))->CCBLineupWindow::Destroy();
  if ( v7 == 1 )
  {
    *ppButton = 0;
    ppButton[2] = 230;
    ppButton[1] = 0;
    ppButton[3] = 200;
    p_m_pBack->Create(272,
      ppButton,
      this);
    (*p_m_pBack)->UIStatic::CreateFromTemplate(&unk_5DF718, 0);
    p_m_pBack->ShowWindow(1);
  }
  v8 = (UIScene **)&this->m_pMagicList[3];
  if ( (((CCBLineupWindow *)v6))->CCBLineupWindow::Render((int *)&this->m_pMagicList[3]) == 1 )
  {
    *ppButton = 27;
    ppButton[1] = 57;
    ppButton[2] = 211;
    ppButton[3] = 95;
    v8->Create(g_nPropIDs_241[8],
      ppButton,
      this);
    v10 = sub_445FE0(a2);
    sub_43FEC0(v10);
    UIScene::GetChildCount(*v8);
    UIScene::GetChildAt(*v8);
    sub_43FDB0((float *)*v8, 48);
    (*v8)->UIWnd::GetHeight(23);
    (*v8)->UIWnd::GetWidth(11);
    (*v8)->UIWnd::GetPosition(5);
    UIScene::SetTextParam(*v8);
    v11 = (UIScene *)*v8;
    v11->m_pTexture = (gbTexture *)10;
    *(_DWORD *)&v11->m_bOverlayRender = 9;
    (((UIScrollBar *)*v8))->UIScrollBar::SetRange(100.0);
    (((UIProgressBar *)*v8))->UIProgressBar::FindChildByName(100.0);
    (*v8)->m_nRectY = 1077936128;
    v8->ShowWindow(1);
  }
  v12 = (UIScene **)&this->m_pMagicList[4];
  if ( (((CCBLineupWindow *)v9))->CCBLineupWindow::Render((int *)&this->m_pMagicList[4]) == 1 )
  {
    *ppButton = 27;
    ppButton[1] = 94;
    ppButton[2] = 211;
    ppButton[3] = 132;
    v12->Create(g_nPropIDs_241[9],
      ppButton,
      this);
    v14 = sub_445FE0(a2);
    sub_43FEC0(v14);
    UIScene::GetChildCount(*v12);
    UIScene::GetChildAt(*v12);
    sub_43FDB0((float *)*v12, 48);
    (*v12)->UIWnd::GetHeight(23);
    (*v12)->UIWnd::GetWidth(11);
    (*v12)->UIWnd::GetPosition(5);
    UIScene::SetTextParam(*v12);
    v15 = (UIScene *)*v12;
    v15->m_pTexture = (gbTexture *)10;
    *(_DWORD *)&v15->m_bOverlayRender = 9;
    (((UIScrollBar *)*v12))->UIScrollBar::SetRange(100.0);
    (((UIProgressBar *)*v12))->UIProgressBar::FindChildByName(100.0);
    (*v12)->m_nRectY = 1077936128;
    v12->ShowWindow(1);
  }
  v16 = (UIScene **)&this->m_pMagicList[5];
  if ( (((CCBLineupWindow *)v13))->CCBLineupWindow::Render((int *)&this->m_pMagicList[5]) == 1 )
  {
    *ppButton = 27;
    ppButton[1] = 132;
    ppButton[2] = 211;
    ppButton[3] = 170;
    v16->Create(g_nPropIDs_241[10],
      ppButton,
      this);
    v18 = sub_445FE0(a2);
    sub_43FEC0(v18);
    UIScene::GetChildCount(*v16);
    UIScene::GetChildAt(*v16);
    sub_43FDB0((float *)*v16, 48);
    (*v16)->UIWnd::GetHeight(23);
    (*v16)->UIWnd::GetWidth(11);
    (*v16)->UIWnd::GetPosition(5);
    UIScene::SetTextParam(*v16);
    v19 = (UIScene *)*v16;
    v19->m_pTexture = (gbTexture *)10;
    *(_DWORD *)&v19->m_bOverlayRender = 9;
    (((UIScrollBar *)*v16))->UIScrollBar::SetRange(100.0);
    (((UIProgressBar *)*v16))->UIProgressBar::FindChildByName(100.0);
    (*v16)->m_nRectY = 1077936128;
    v16->ShowWindow(1);
  }
  m_pMagicList = (UIListBox **)this->m_pMagicList;
  if ( (((CCBLineupWindow *)v17))->CCBLineupWindow::OnMessage((int *)this->m_pMagicList) == 1 )
  {
    *ppButton = 37;
    ppButton[1] = 57;
    ppButton[2] = 69;
    ppButton[3] = 89;
    ((void ( *)(UIListBox *, int, int *, CCBMagicWindow *, void *, _DWORD))(*m_pMagicList)->__vftable[1].ShowWindow)(
      *m_pMagicList,
      g_nPropIDs_241[5],
      ppButton,
      this,
      &unk_5DF6F4,
      0);
    (((UIStatic *)*m_pMagicList))->UIStatic::SetText();
    m_pMagicList->ShowWindow(1);
  }
  v22 = (UIStatic **)&this->m_pMagicList[1];
  if ( (((CCBLineupWindow *)v21))->CCBLineupWindow::OnMessage((int *)&this->m_pMagicList[1]) == 1 )
  {
    *ppButton = 37;
    ppButton[1] = 94;
    ppButton[2] = 69;
    ppButton[3] = 126;
    ((void ( *)(UIStatic *, int, int *, CCBMagicWindow *, void *, _DWORD))(*v22)->__vftable[1].ShowWindow)(
      *v22,
      g_nPropIDs_241[6],
      ppButton,
      this,
      &unk_5DF6D0,
      0);
    UIStatic::SetText(*v22);
    v22->ShowWindow(1);
  }
  v24 = (UIStatic **)&this->m_pMagicList[2];
  if ( (((CCBLineupWindow *)v23))->CCBLineupWindow::OnMessage((int *)&this->m_pMagicList[2]) == 1 )
  {
    *ppButton = 37;
    ppButton[1] = 132;
    ppButton[2] = 69;
    ppButton[3] = 164;
    ((void ( *)(UIStatic *, int, int *, CCBMagicWindow *, void *, _DWORD))(*v24)->__vftable[1].ShowWindow)(
      *v24,
      g_nPropIDs_241[7],
      ppButton,
      this,
      &unk_5DF6AC,
      0);
    UIStatic::SetText(*v24);
    v24->ShowWindow(1);
  }
  p_m_pButtonWater = (UIPushButton **)&this->m_pButtonWater;
  (((CCBLineupWindow *)v25))->CCBLineupWindow::Update((int *)&this->m_pButtonWater);
  *ppButton = 68;
  ppButton[2] = 160;
  ppButton[1] = 170;
  ppButton[3] = 196;
  ((void ( *)(UIPushButton *, int, int *, CCBMagicWindow *, void *, int, _DWORD))(*p_m_pButtonWater)->__vftable[1].ShowWindow)(
    *p_m_pButtonWater,
    282,
    ppButton,
    this,
    &unk_5DF59C,
    1,
    0);
  p_m_pButtonWater->ShowWindow(1);
  return 1;
}

// 0x0051C210
UIListBox * CCBMagicWindow::GetActivePage()
{
  (((CCBSkillWindow *)this))->CCBSkillWindow::Reset() /* [ROWTABLE] */;
  return (UIListBox *)this;
}
