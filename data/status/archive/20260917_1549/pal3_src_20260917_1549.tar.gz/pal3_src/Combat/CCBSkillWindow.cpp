#include "pal3/ida_defs.h"
#include "globals.h"
#include "pal3/pal3_constants.h"
#include "Combat/CCBSkillWindow.h"
#include "Combat/CCBControl.h"
#include "Combat/CCBItemWindow.h"
#include "Combat/CCBLineupWindow.h"
#include "Combat/CCBMagicWindow.h"
#include "Data/CGameData.h"
#include "Render/CScreenMode.h"
#include "GameBase/GRPinput.h"
#include "Scene/SceneObj.h"
#include "UI/UIListBox.h"
#include "Misc/UIPushButton.h"
#include "UI/UIScene.h"
#include "Misc/UIStatic.h"
#include "UI/UIWnd.h"
#include "free_functions.h"

// Forward declarations for unnamed functions

// 0x0051B860
int CCBSkillWindow::OnMessage(int nVal, int nVal2, int nVal3)
{
  CScreenMode *Instance; // eax

  if ( nVal == 1001 )
  {
    Instance = (CScreenMode *)CScreenMode::GetInstance();
    (((CScreenMode *)Instance))->CScreenMode::AudioSetPosition("wa001", 1);
    CCBControl::SetParam(*(CCBControl **)(this->m_pfather[17].m_fontcolor.Color + 8), nVal2, nVal3);
  }
  return (((CGameData *)this))->CGameData::OnMessage(nVal, nVal2, nVal3) /* [ROWTABLE] */;
}

// 0x0051BBE0
CCBSkillWindow * CCBSkillWindow::Destroy_11(char a2)
{
  (((CCBSkillWindow *)Block))->CCBSkillWindow::~CCBSkillWindow();
  if ( (a2 & 1) != 0 )
    operator delete(Block);
  return Block;
}

// 0x0051BC00
CCBSkillWindow::~CCBSkillWindow()
{
  /* [MISATTRIBUTED] CCBMagicWindow on CCBSkillWindow::this -> fix IDB name of callee */ CCBMagicWindow::ClearMagicData((CCBMagicWindow *)this);
  (((UIListBox *)this))->UIListBox::~UIListBox() /* [ROWTABLE] */;
}

// 0x0051C110

// ---- synthesized vtable stubs (unresolved slots) ----
// [VFTABLE-STUB] original: ((void ( *)(UIStatic *, int))m_pBack->__vftable->_sdtor_call_dtor)(m_pBack, 1)
static void pal3_vtbl_unk_0(UIStatic *, int);
// [VFTABLE-STUB] original: ((void ( *)(UIStatic *, int))m_pDescription->__vftable->_sdtor_call_dtor)(m_pDescription, 1)
static void pal3_vtbl_unk_1(UIStatic *, int);
// [VFTABLE-STUB] original: ((void ( *)(UIListBox *, int))v4->__vftable->_sdtor_call_dtor)(v4, 1)
static void pal3_vtbl_unk_2(UIListBox *, int);

void CCBSkillWindow::Destroy()
{
  UIStatic *m_pBack; // ecx
  UIStatic *m_pDescription; // ecx
  UIListBox *v4; // ecx
  void *vftable; // ecx
  unsigned int Color; // ecx
  unsigned int v7; // ecx
  void *m_id; // ecx
  LONG left; // ecx

  this->Destroy();
  m_pBack = (UIStatic *)this->m_pBack;
  if ( m_pBack )
  {
    pal3_vtbl_unk_0(m_pBack, 1) /* [VFTABLE-STUB] */;
    this->m_pBack = 0;
  }
  m_pDescription = (UIStatic *)this->m_pDescription;
  if ( m_pDescription )
  {
    pal3_vtbl_unk_1(m_pDescription, 1) /* [VFTABLE-STUB] */;
    this->m_pDescription = 0;
  }
  v4 = (UIListBox *)this->m_pSkillList[0];
  if ( v4 )
  {
    pal3_vtbl_unk_2(v4, 1) /* [VFTABLE-STUB] */;
    this->m_pSkillList[0] = 0;
  }
  vftable = (*(void **)&(this[1]));
  if ( vftable )
  {
    (*((void ( **)(void *, int))vftable->ShowWindow + 5))(vftable, 1);
    (*(void **)&(this[1])) = (void *)(0);
  }
  Color = this[1].m_fontcolor.Color;
  if ( Color )
  {
    (*(void ( **)(unsigned int, int))(*(_DWORD *)Color + 20))(Color, 1);
    this[1].m_fontcolor.Color = 0;
  }
  v7 = this[1].m_wndcolor.Color;
  if ( v7 )
  {
    (*(void ( **)(unsigned int, int))(*(_DWORD *)v7 + 20))(v7, 1);
    this[1].m_wndcolor.Color = 0;
  }
  m_id = this[1].m_id;
  if ( m_id )
  {
    (*(void ( **)(void *, int))(*(_DWORD *)m_id + 20))(m_id, 1);
    this[1].m_id = 0;
  }
  left = this[1].m_rect.left;
  if ( left )
  {
    (*(void ( **)(LONG, int))(*(_DWORD *)left + 20))(left, 1);
    this[1].m_rect.left = 0;
  }
}

static void pal3_vtbl_unk_0(UIStatic *, int)
{
    
}
static void pal3_vtbl_unk_1(UIStatic *, int)
{
    
}
static void pal3_vtbl_unk_2(UIListBox *, int)
{
    
}


// 0x0051C1B0
BOOL CCBSkillWindow::SetActivePage(int n, int nVal)
{
  if ( this->m_bvisible == 1
    && (g_Input.KeyInfo[16].PressTime == 1 && (g_Input.KeyInfo[16].Data & 0xF) == 1 || g_Input.KeyInfo[17].PressTime == 1) )
  {
    CCBControl::SetParam(*(CCBControl **)(this->m_pfather[17].m_fontcolor.Color + 8), 272, -1);
  }
  return (((SceneObj *)this))->SceneObj::Update(n, nVal) /* [ROWTABLE] */;
}

// 0x0051C2D0
void CCBSkillWindow::Reset()
{
  (*(void **)&(this[2])) = (void *)(0);
  this[2].m_fontcolor.Color = -1;
  this->m_pBack = 0;
  this->m_pDescription = 0;
  this->m_pSkillList[0] = 0;
  (*(void **)&(this[1])) = (void *)(0);
  this[1].m_fontcolor.Color = 0;
  this[1].m_wndcolor.Color = 0;
  this[1].m_id = 0;
  this[1].m_rect.left = 0;
  this[1].m_rect.top = 0;
  memset(&this[1].m_rect.right, 0, 0x2Cu);
  this[1].m_pbktex = 0;
  this[1].m_pBack = 0;
  this[1].m_pDescription = 0;
  this[1].m_pSkillList[0] = 0;
}

// 0x0051C330

// ---- synthesized vtable stubs (unresolved slots) ----
// [VFTABLE-STUB] original: (*((void ( **)(vtbl_0056AE2C *, int, int *, CCBSkillWindow *))v24->__vftable->ShowWindow + 4))( v24->__vftable, 516, pRect, this)
static void pal3_vtbl_unk_0(void *, int, int *, CCBSkillWindow *);
// [VFTABLE-STUB] original: (*(void ( **)(vtbl_0056AE2C *, int))v24->__vftable->ShowWindow)(v24->__vftable, 1)
static void pal3_vtbl_unk_1(void *, int);

bool CCBSkillWindow::Create(int *pRect, int parent)
{
  UIStatic **p_m_pBack; // ebx
  CCBLineupWindow *v5; // ecx
  CCBLineupWindow *v6; // ecx
  void **v7; // ebp
  UIStatic **p_right; // ebx
  UIStatic **v9; // ebx
  CCBLineupWindow *v10; // ecx
  void *v11; // eax
  UIStatic **p_m_pDescription; // ebx
  CCBLineupWindow *v13; // ecx
  void *v14; // eax
  UIListBox **m_pSkillList; // ebx
  CCBLineupWindow *v16; // ecx
  void *v17; // eax
  gbTexture **p_m_pbktex; // ebx
  CCBLineupWindow *v19; // ecx
  UIStatic **v20; // ebx
  CCBLineupWindow *v21; // ecx
  UIListBox **v22; // ebx
  CCBLineupWindow *v23; // ecx
  CCBSkillWindow *v24; // ebx
  CCBLineupWindow *v25; // ecx
  gbColorQuad *p_m_fontcolor; // ebx
  CCBLineupWindow *v27; // ecx
  gbColorQuad *p_m_wndcolor; // ebx
  CCBLineupWindow *v29; // ecx
  void **p_m_id; // ebx
  CCBLineupWindow *v31; // ecx
  tagRECT *p_m_rect; // ebx
  CCBLineupWindow *v33; // ecx
  LONG *p_top; // ebx
  CCBLineupWindow *v35; // ecx
  _BYTE a2[16]; // [esp+C8h] [ebp-0x10] BYREF

  (((CCBItemWindow *)this))->CCBItemWindow::Create(512, (tagRECT *)pRect, parent) /* [ROWTABLE] */;
  (*(void **)&(this[2])) = (void *)parent;
  p_m_pBack = (UIStatic **)&this->m_pBack;
  (((CCBLineupWindow *)v5))->CCBLineupWindow::Destroy();
  *pRect = 0;
  pRect[2] = 256;
  pRect[1] = 0;
  pRect[3] = 256;
  p_m_pBack->Create(513,
    pRect,
    this);
  (((UIStatic *)this->m_pBack))->UIStatic::CreateFromTemplate(&unk_5DF580, 0);
  p_m_pBack->ShowWindow(1);
  v7 = (void **)&off_570310;
  p_right = (UIStatic **)&this[1].m_rect.right;
  do
  {
    (((CCBLineupWindow *)v6))->CCBLineupWindow::Destroy();
    *pRect = 15;
    pRect[2] = 79;
    pRect[1] = -15;
    pRect[3] = 113;
    p_right->Create(528,
      pRect,
      this);
    (*p_right++)->UIStatic::CreateFromTemplate(*v7++, 0);
  }
  while ( (int)v7 < (int)&dword_570324 );
  (**(void ( ***)(LONG, int))this[1].m_rect.right)(this[1].m_rect.right, 1);
  v9 = (UIStatic **)&this[1].m_pBack;
  (((CCBLineupWindow *)v10))->CCBLineupWindow::Render((int *)&this[1].m_pBack);
  *pRect = 83;
  pRect[2] = 168;
  pRect[1] = 46;
  pRect[3] = 58;
  v9->Create(545, pRect, this);
  v11 = sub_445FE0(a2);
  sub_43FEC0(v11);
  (((UIScene *)this[1].m_pBack))->UIScene::GetChildCount();
  (((UIScene *)this[1].m_pBack))->UIScene::GetChildAt();
  sub_43FD90((float *)this[1].m_pBack, 3);
  sub_43FDB0((float *)this[1].m_pBack, -2);
  v9->ShowWindow(1);
  p_m_pDescription = (UIStatic **)&this[1].m_pDescription;
  (((CCBLineupWindow *)v13))->CCBLineupWindow::Render((int *)&this[1].m_pDescription);
  *pRect = 86;
  pRect[2] = 171;
  pRect[1] = 71;
  pRect[3] = 83;
  p_m_pDescription->Create(546,
    pRect,
    this);
  v14 = sub_445FE0(a2);
  sub_43FEC0(v14);
  (((UIScene *)this[1].m_pDescription))->UIScene::GetChildCount();
  (((UIScene *)this[1].m_pDescription))->UIScene::GetChildAt();
  sub_43FD90((float *)this[1].m_pDescription, 3);
  sub_43FDB0((float *)this[1].m_pDescription, -2);
  p_m_pDescription->ShowWindow(1);
  m_pSkillList = (UIListBox **)this[1].m_pSkillList;
  (((CCBLineupWindow *)v16))->CCBLineupWindow::Render((int *)this[1].m_pSkillList);
  *pRect = 84;
  pRect[2] = 169;
  pRect[1] = 97;
  pRect[3] = 109;
  m_pSkillList->Create(547,
    pRect,
    this);
  v17 = sub_445FE0(a2);
  sub_43FEC0(v17);
  (((UIScene *)this[1].m_pSkillList[0]))->UIScene::GetChildCount();
  (((UIScene *)this[1].m_pSkillList[0]))->UIScene::GetChildAt();
  sub_43FD90((float *)this[1].m_pSkillList[0], 3);
  sub_43FDB0((float *)this[1].m_pSkillList[0], -2);
  m_pSkillList->ShowWindow(1);
  p_m_pbktex = (gbTexture **)&this[1].m_pbktex;
  (((CCBLineupWindow *)v19))->CCBLineupWindow::Destroy();
  *pRect = 66;
  pRect[2] = 130;
  pRect[1] = 42;
  pRect[3] = 109;
  (*((void ( **)(gbTexture *, int, int *, CCBSkillWindow *))(*(void **)((*p_m_pbktex))) + 4))(
    *p_m_pbktex,
    544,
    pRect,
    this);
  (((UIStatic *)this[1].m_pbktex))->UIStatic::CreateFromTemplate(&unk_5DF450, 0);
  (*(void ( **)(gbTexture *, int))(*(void **)((*p_m_pbktex))))(*p_m_pbktex, 1);
  v20 = (UIStatic **)&this->m_pDescription;
  (((CCBLineupWindow *)v21))->CCBLineupWindow::Destroy();
  *pRect = 136;
  pRect[2] = 200;
  pRect[1] = 134;
  pRect[3] = 166;
  v20->Create(514, pRect, this);
  v20->ShowWindow(1);
  (((UIScene *)this->m_pDescription))->UIScene::SetShow(0);
  sub_446010(this->m_pDescription);
  v22 = (UIListBox **)this->m_pSkillList;
  (((CCBLineupWindow *)v23))->CCBLineupWindow::Destroy();
  *pRect = 51;
  pRect[2] = 115;
  pRect[1] = 134;
  pRect[3] = 166;
  v22->Create(515, pRect, this);
  v22->ShowWindow(1);
  (((UIScene *)this->m_pSkillList[0]))->UIScene::SetShow(0);
  sub_446010(this->m_pSkillList[0]);
  v24 = this + 1;
  (((CCBLineupWindow *)v25))->CCBLineupWindow::Destroy();
  *pRect = 51;
  pRect[2] = 115;
  pRect[1] = 108;
  pRect[3] = 140;
  pal3_vtbl_unk_0((*(void **)(v24)), 516, pRect, this) /* [VFTABLE-STUB] */;
  pal3_vtbl_unk_1((*(void **)(v24)), 1) /* [VFTABLE-STUB] */;
  (((UIScene *)(*(void **)&(this[1]))))->UIScene::SetShow(0);
  sub_446010((*(void **)&(this[1])));
  p_m_fontcolor = (gbColorQuad *)&this[1].m_fontcolor;
  (((CCBLineupWindow *)v27))->CCBLineupWindow::Destroy();
  *pRect = 136;
  pRect[2] = 200;
  pRect[1] = 108;
  pRect[3] = 140;
  (*(void ( **)(unsigned int, int, int *, CCBSkillWindow *))(*(_DWORD *)p_m_fontcolor->Color + 16))(
    p_m_fontcolor->Color,
    517,
    pRect,
    this);
  (**(void ( ***)(unsigned int, int))p_m_fontcolor->Color)(p_m_fontcolor->Color, 1);
  (((UIScene *)this[1].m_fontcolor.Color))->UIScene::SetShow(0);
  sub_446010((void *)this[1].m_fontcolor.Color);
  p_m_wndcolor = (gbColorQuad *)&this[1].m_wndcolor;
  (((CCBLineupWindow *)v29))->CCBLineupWindow::Destroy();
  pRect[2] = 115;
  *pRect = 51;
  pRect[1] = 160;
  pRect[3] = 192;
  (*(void ( **)(unsigned int, int, int *, CCBSkillWindow *))(*(_DWORD *)p_m_wndcolor->Color + 16))(
    p_m_wndcolor->Color,
    518,
    pRect,
    this);
  (**(void ( ***)(unsigned int, int))p_m_wndcolor->Color)(p_m_wndcolor->Color, 1);
  (((UIScene *)this[1].m_wndcolor.Color))->UIScene::SetShow(0);
  sub_446010((void *)this[1].m_wndcolor.Color);
  p_m_id = (void **)&this[1].m_id;
  (((CCBLineupWindow *)v31))->CCBLineupWindow::Destroy();
  *pRect = 136;
  pRect[2] = 200;
  pRect[1] = 160;
  pRect[3] = 192;
  (*(void ( **)(void *, int, int *, CCBSkillWindow *))(*(_DWORD *)*p_m_id + 16))(*p_m_id, 519, pRect, this);
  (**(void ( ***)(void *, int))*p_m_id)(*p_m_id, 1);
  (((UIScene *)this[1].m_id))->UIScene::SetShow(0);
  sub_446010(this[1].m_id);
  p_m_rect = (tagRECT *)&this[1].m_rect;
  (((CCBLineupWindow *)v33))->CCBLineupWindow::Destroy();
  *pRect = 0;
  pRect[2] = 187;
  pRect[1] = 211;
  pRect[3] = 243;
  (*(void ( **)(LONG, int, int *, CCBSkillWindow *))(*(_DWORD *)p_m_rect->left + 16))(
    p_m_rect->left,
    529,
    pRect,
    this);
  (**(void ( ***)(LONG, int))p_m_rect->left)(p_m_rect->left, 1);
  (((UIScene *)this[1].m_rect.left))->UIScene::SetShow(0);
  sub_446010((void *)this[1].m_rect.left);
  p_top = (LONG *)&this[1].m_rect.top;
  (((CCBLineupWindow *)v35))->CCBLineupWindow::Destroy();
  *pRect = 0;
  pRect[2] = 187;
  pRect[1] = 0;
  pRect[3] = 32;
  (*(void ( **)(LONG, int, int *, CCBSkillWindow *))(*(_DWORD *)*p_top + 16))(*p_top, 530, pRect, this);
  (**(void ( ***)(LONG, int))*p_top)(*p_top, 1);
  (((UIScene *)this[1].m_rect.top))->UIScene::SetShow(0);
  sub_446010((void *)this[1].m_rect.top);
  return 1;
}

static void pal3_vtbl_unk_0(void *, int, int *, CCBSkillWindow *)
{
    
}
static void pal3_vtbl_unk_1(void *, int)
{
    
}

