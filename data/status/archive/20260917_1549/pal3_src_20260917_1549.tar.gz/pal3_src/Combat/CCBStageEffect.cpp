#include "pal3/ida_defs.h"
#include "globals.h"
#include "pal3/pal3_constants.h"
#include "Combat/CCBStageEffect.h"
#include "Combat/CCBStage.h"
#include "GameBase/Logger.h"
#include "Misc/OpenBaseFile.h"
#include "Misc/OpenNULLFile.h"
#include "Misc/tagStageRoleData.h"

// 0x00508E30
CCBStageEffect::CCBStageEffect()
{
  gbVFile *v1; // eax
  gbVFile *v2; // esi
  OpenBaseFile v3; // [esp+0x24] [ebp-0x810] BYREF
  char pExceptionObject[1024]; // [esp+0x28] [ebp-0x80C] BYREF
  char ArgList; // [esp+0x428] [ebp-0x40C] BYREF
  int v6; // [esp+0x830] [ebp-0x4]

  v6 = 0;
  v1 = (((gbVFileSystem *)g_pVFileSys))->gbVFileSystem::OpenFile("cbdata\\efflinker.dat", 0x201u);
  v2 = (gbVFile *)v1;
  if ( !v1 )
  {
    qmemcpy(
      pExceptionObject,
      (((Logger *)&ArgList))->Logger::FormatException(aCouldnTOpenEff, aDProjectPal3Co_2, 366),
      sizeof(pExceptionObject));
    _CxxThrowException(pExceptionObject, (_ThrowInfo *)&_TI1_AV_Exception__);
  }
  (((gbVFileSystem *)g_pVFileSys))->gbVFileSystem::Seek(v1, 0, 1);
  (((gbVFileSystem *)g_pVFileSys))->gbVFileSystem::Read();
  (((gbVFileSystem *)g_pVFileSys))->gbVFileSystem::CloseFile(v2);
  dword_17AB584 = 1;
  v6 = -1;
  // [AUTO-COMMENTED] (OpenNULLFile *)&v3->OpenNULLFile();
}

// 0x00508F30
CCBStageEffect::~CCBStageEffect()
{
  gbVFile *v2; // eax
  gbVFile *v3; // esi
  OpenBaseFile v4; // [esp+0x24] [ebp-0x810] BYREF
  char pExceptionObject[1024]; // [esp+0x28] [ebp-0x80C] BYREF
  char ArgList; // [esp+0x428] [ebp-0x40C] BYREF
  int v7; // [esp+0x830] [ebp-0x4]

  v7 = 0;
  v2 = (((gbVFileSystem *)g_pVFileSys))->gbVFileSystem::OpenFile("cbdata\\efflinker.dat", 0x202u);
  v3 = (gbVFile *)v2;
  if ( !v2 )
  {
    qmemcpy(
      pExceptionObject,
      (((Logger *)&ArgList))->Logger::FormatException(aCouldnTOpenCbE, aDProjectPal3Co_2, 390),
      sizeof(pExceptionObject));
    _CxxThrowException(pExceptionObject, (_ThrowInfo *)&_TI1_AV_Exception__);
  }
  (((gbVFileSystem *)g_pVFileSys))->gbVFileSystem::Seek(v2, 0, 1);
  (((gbVFileSystem *)g_pVFileSys))->gbVFileSystem::Write(this->m_Linker, 0x5A00u, v3);
  (((gbVFileSystem *)g_pVFileSys))->gbVFileSystem::CloseFile(v3);
  v7 = -1;
  // [AUTO-COMMENTED] (OpenNULLFile *)&v4->OpenNULLFile();
}

// 0x00509050
// attributes: thunk
bool CCBStageEffect::Create()
{
  return this->CCBStageEffect::Destroy();
}

// 0x00509060
bool CCBStageEffect::Destroy()
{
  bool result; // al

  result = 0;
  g_StageRoleData.m_nEffParamBase4 = 1094713344;
  return result;
}

// 0x00509070
// attributes: thunk
void CCBStageEffect::Init()
{
  this->CCBStageEffect::GetLinkerIndex();
}

// 0x00509080
void CCBStageEffect::GetLinkerIndex()
{
  g_StageRoleData.m_nEffParamBase0 = 12.0 + 12.0;
}

// 0x00509090
// attributes: thunk
void CCBStageEffect::PreLoadEffGroup()
{
  compiler_init_005090A0(this);
}

// 0x005090E0
// attributes: thunk
void CCBStageEffect::LoadLinker()
{
  (((CCBStage *)this))->CCBStage::Proceed() /* [ROWTABLE] */;
}
