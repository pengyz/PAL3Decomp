#include "pal3/ida_defs.h"
#include "globals.h"
#include "pal3/pal3_constants.h"
#include "Combat/Combat.h"
#include "Combat/CCBControl.h"
#include "Combat/CCBSystem.h"
#include "Effect/CEffMgr.h"
#include "Role/RoleSystem.h"
#include "Misc/tagCmdData.h"
#include "free_functions.h"

// 0x0040CCD0
int Combat::GetSlotCount()
{
  int result; // eax

  result = (int)this[1];
  if ( result )
    return (*(_DWORD *)&this[2] - result) / 12;
  return result;
}

// 0x004CDB60
char Combat::ReleaseCompletedEffects()
{
  /* [MISATTRIBUTED] CEffMgr on Combat::this -> fix IDB name of callee */ CEffMgr::ReleaseCompletedEffects((CEffMgr *)this);
  return 1;
}

// 0x004DFD20
char Combat::LogMessage(char *a2, int a3, char *format, ...)
{
  int v4; // eax
  va_list ArgList; // [esp+0x14] [ebp+0x14] BYREF

  va_start(ArgList, format);
  LOBYTE(v4) = *(&g_RoleSystemCombat.m_teamSlotsB.combat.m_bWPARAM + 1);
  if ( *(&g_RoleSystemCombat.m_teamSlotsB.combat.m_bWPARAM + 1) )
  {
    vsprintf((char *const)&this[70 * *(_DWORD *)&this[4] + 6], format, ArgList);
    *(float *)&this[70 * *(_DWORD *)&this[4] + 71] = ((double)(int)a2 + (double)(int)a2) / (double)g_DrvInfo.width - 1.0;
    *(float *)&this[70 * *(_DWORD *)&this[4] + 72] = 1.0 - ((double)a3 + (double)a3) / (double)g_DrvInfo.height;
    this[70 * *(_DWORD *)&this[4] + 5] = (Combat)3;
    this[70 * *(_DWORD *)&this[4] + 74] = (Combat)1098907648;
    this[70 * *(_DWORD *)&this[4] + 70] = this[2];
    v4 = *(_DWORD *)&this[4] + 1;
    this[4] = (Combat)v4;
  }
  return v4;
}

// 0x004F4820
unsigned __int8 Combat::HandleControlCmd(int idx)
{
  CCBControl *v3; // ecx
  int v4; // eax
  _BYTE *v5; // ecx
  unsigned __int8 result; // al

  v3 = *(CCBControl **)(*(_DWORD *)&this[130] + 8);
  if ( v3->m_bActive && (((CCBControl *)v3))->CCBControl::GetControl() == idx )
  {
    (*(CCBControl **)(*(_DWORD *)&this[130] + 8))->CCBControl::GetState();
    v4 = 24;
    v5 = (char *)&this[144] + 1;
    do
    {
      if ( *v5 )
      {
        *(_BYTE *)(*(_DWORD *)(*(_DWORD *)&this[131] + v4) + 280) = 0;
        *(_BYTE *)(*(_DWORD *)(*(_DWORD *)&this[131] + v4) + 274) = 0;
      }
      v4 += 4;
      v5 += 892;
    }
    while ( v4 < 68 );
  }
  result = (*(CCBSystem **)(*(_DWORD *)&this[130] + 12))->CCBSystem::IsCmdEmpty(idx);
  if ( !result && !this[137]._tail_000[1] )
    return (unsigned __int8)(*(CCBSystem **)(*(_DWORD *)&this[130] + 12))->CCBSystem::GetCmdPtr(idx);
  return result;
}
