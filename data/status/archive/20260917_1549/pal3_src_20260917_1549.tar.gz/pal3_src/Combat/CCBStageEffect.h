#pragma once
// Auto-generated: CCBStageEffect
#include "pal3/ida_types.h"

#include "gbengine/gbRenderEffect.h"
#include "gbengine/gbengine_internal.h"
#include "Misc/tagEffLinker.h"

class CCBStage;
class CCBSystem;

class CCBStageEffect {
public:
    double m_DeltaTime; // +0x0
    CCBStage * m_pStage; // +0x8
    CCBSystem * m_pCBSystem; // +0xC
    gbVolModNode m_EnvLight; // +0x10
    gbVolModNode m_Light[10]; // +0xEC
    gbRenderEffect * m_pGeomFlashEffect; // +0x984
    gbRenderEffect * m_pGeomFlashEffect_t; // +0x988
    tagEffLinker m_Linker[4]; // +0x98C
    char _tail_A7C[16]; // +0xA7C
    // total size: 0xA8C (2700)

    CCBStageEffect(); // 0x00508E30
    ~CCBStageEffect(); // 0x00508F30
    bool Create(); // 0x00509050
    bool Destroy(); // 0x00509060
    void Init(); // 0x00509070
    void GetLinkerIndex(); // 0x00509080
    void PreLoadEffGroup(); // 0x00509090
    void LoadLinker(); // 0x005090E0
};
