#include "Misc/UIFrameWnd.h"
#pragma once
// Auto-generated: CCBSkillWindow
#include "pal3/ida_types.h"

class UIListBox;
class UIStatic;

class CCBSkillWindow : public UIFrameWnd {
public:
    char _gap_000[72]; // +0x0
    UIStatic * m_pBack; // +0x48
    UIStatic * m_pDescription; // +0x4C
    UIListBox * m_pSkillList[1]; // +0x50
    // total size: 0x54 (84)

    virtual BOOL SetActivePage(int n, int nVal); // 0x0051C1B0
    virtual void Destroy(); // 0x0051C110
    virtual CCBSkillWindow * Destroy_11(char a2); // 0x0051BBE0
    virtual int OnMessage(int nVal, int nVal2, int nVal3); // 0x0051B860
    ~CCBSkillWindow(); // 0x0051BC00
    void Reset(); // 0x0051C2D0
    bool Create(int *pRect, int parent); // 0x0051C330
};
