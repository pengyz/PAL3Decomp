#include "Misc/UIFrameWnd.h"
#pragma once
// Auto-generated: CCBParabolaWindow
#include "pal3/ida_types.h"

#include "gbengine/gbVFileSystem.h"

class CCBAIWindow;
class CCBSkillWindow;
class UIListBox;
class UIStatic;
class UIWnd;

class CCBParabolaWindow : public UIFrameWnd {
public:
    char _gap_000[72]; // +0x0
    UIStatic * m_pBack; // +0x48
    UIStatic * m_pDescription; // +0x4C
    UIListBox * m_pItemList; // +0x50
    // total size: 0x54 (84)

    virtual CCBAIWindow * ToggleSlots(int nVal); // 0x0051CA50
    virtual void Render(); // 0x0051CAA0
    virtual BOOL Update(int deltatime, int haveinput); // 0x0051C9F0
    virtual int Destroy_c880(); // 0x0051C880
    UIWnd * _scalar_dtor(CCBSkillWindow *Block, char pData); // 0x0051C260
    gbVFileSystem * LoadResourceEx(const char *pszName, char pData); // 0x00440BE0
    CCBParabolaWindow(CCBParabolaWindow **thisa, int *pnVal, int nVal); // 0x0051B710
    ~CCBParabolaWindow(); // 0x0051B810
    void Destroy(); // 0x0051B920
    bool OnMessage(int msg, int wparam, int lparam); // 0x0051B950
    void _scalar_dtor(); // 0x0051C280
};
