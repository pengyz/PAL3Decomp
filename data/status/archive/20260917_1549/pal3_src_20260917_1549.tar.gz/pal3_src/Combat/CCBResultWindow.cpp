#include "pal3/ida_defs.h"
#include "globals.h"
#include "pal3/pal3_constants.h"
#include "Combat/CCBResultWindow.h"
#include "Combat/CCBControl.h"
#include "Combat/CCBUI.h"
#include "Data/CGameData.h"
#include "Render/CScreenMode.h"
#include "GameBase/GRPinput.h"
#include "Scene/SceneObj.h"
#include "Misc/UIProgressBar.h"
#include "UI/UIScene.h"
#include "Misc/UIStatic.h"
#include "UI/UIWnd.h"
#include "free_functions.h"

// Forward declarations for unnamed functions

// 0x0043BE30
CCBResultWindow::~CCBResultWindow()
{
  ReleaseTexture((UIScene *)this);
  this->UIWnd::~UIWnd();
}

// 0x00442E10
void CCBResultWindow::ctor()
{
  sub_4422E0(this);
  this->m_pMP = (UIProgressBar *)1056964608;
  this->m_pHGM = 0;
  this->m_pHP = 0;
  this->m_pGP = 0;
  this->m_pUI = 0;
  LOBYTE(this->m_nIndex) = 0;
  *(_DWORD *)&this->m_bClosed = 0;
  this->m_pFace[9] = (UIStatic *)21;
}

// 0x00443190
void CCBResultWindow::Create()
{
  this->CCBResultWindow::ctor();
}

// 0x00444A20
CCBResultWindow::CCBResultWindow()
{
  UIProgressBar *m_pHGM_high; // eax

  sub_4422E0(this);
  this->m_pUI = (CCBUI *)1065353216;
  LOBYTE(this->m_nIndex) = 0;
  BYTE1(this->m_nIndex) = 0;
  BYTE2(this->m_nIndex) = 0;
  *(_DWORD *)&this->m_bClosed = 0;
  this->m_pMP = (UIProgressBar *)6;
  this->m_pHGM = (UIStatic *)-1;
  m_pHGM_high = (UIProgressBar *)HIBYTE(this->m_pHGM);
  this->m_pGP = m_pHGM_high;
  this->m_pHP = m_pHGM_high;
}

// 0x00444D10
int CCBResultWindow::StartAnim()
{
  int result; // eax

  BYTE1(this->m_nIndex) = 1;
  BYTE2(this->m_nIndex) = 0;
  return result;
}

// 0x00444D20
void CCBResultWindow::SetDirty()
{
  BYTE2(this->m_nIndex) = 1;
}

// 0x00515CE0
int CCBResultWindow::FindChildByID(int nID)
{
  int result; // eax
  int v3; // edx

  result = (int)&this->m_pUI;
  v3 = 0;
  while ( !*(_BYTE *)(result + 20) || *(_DWORD *)result != nID )
  {
    ++v3;
    result += 88;
    if ( v3 >= 1024 )
    {
      LOBYTE(result) = 0;
      return result;
    }
  }
  LOBYTE(result) = 1;
  return result;
}

// 0x00519360
void CCBResultWindow::ShowLineupWindow(BOOL bShow)
{
  /* [MISATTRIBUTED] CCBUI on CCBResultWindow::this -> fix IDB name of callee */ CCBUI::Release((CCBUI *)this);
  if ( bShow )
    operator delete(this);
}

// 0x00519510

// ---- synthesized vtable stubs (unresolved slots) ----
// [VFTABLE-STUB] original: ((void ( *)(UIStatic *, int))m_pBack->__vftable->_sdtor_call_dtor)(m_pBack, 1)
static void pal3_vtbl_unk_0(UIStatic *, int);
// [VFTABLE-STUB] original: ((void ( *)(UIStatic *, int))m_pWind->__vftable->_sdtor_call_dtor)(m_pWind, 1)
static void pal3_vtbl_unk_1(UIStatic *, int);
// [VFTABLE-STUB] original: ((void ( *)(UIStatic *, int))m_pThunder->__vftable->_sdtor_call_dtor)(m_pThunder, 1)
static void pal3_vtbl_unk_2(UIStatic *, int);
// [VFTABLE-STUB] original: ((void ( *)(UIStatic *, int))m_pWater->__vftable->_sdtor_call_dtor)(m_pWater, 1)
static void pal3_vtbl_unk_3(UIStatic *, int);
// [VFTABLE-STUB] original: ((void ( *)(UIStatic *, int))m_pFire->__vftable->_sdtor_call_dtor)(m_pFire, 1)
static void pal3_vtbl_unk_4(UIStatic *, int);
// [VFTABLE-STUB] original: ((void ( *)(UIStatic *, int))m_pEarth->__vftable->_sdtor_call_dtor)(m_pEarth, 1)
static void pal3_vtbl_unk_5(UIStatic *, int);
// [VFTABLE-STUB] original: ((void ( *)(UIStatic *, int))m_pDouble->__vftable->_sdtor_call_dtor)(m_pDouble, 1)
static void pal3_vtbl_unk_6(UIStatic *, int);
// [VFTABLE-STUB] original: ((void ( *)(UIStatic *, int))m_pEXP->__vftable->_sdtor_call_dtor)(m_pEXP, 1)
static void pal3_vtbl_unk_7(UIStatic *, int);
// [VFTABLE-STUB] original: ((void ( *)(UIStatic *, int))m_pLevel->__vftable->_sdtor_call_dtor)(m_pLevel, 1)
static void pal3_vtbl_unk_8(UIStatic *, int);
// [VFTABLE-STUB] original: ((void ( *)(UIStatic *, int))v11->__vftable->_sdtor_call_dtor)(v11, 1)
static void pal3_vtbl_unk_9(UIStatic *, int);
// [VFTABLE-STUB] original: ((void ( *)(UIStatic *, int))v12->__vftable->_sdtor_call_dtor)(v12, 1)
static void pal3_vtbl_unk_10(UIStatic *, int);

void CCBResultWindow::Destroy()
{
  UIStatic *m_pBack; // ecx
  UIStatic *m_pWind; // ecx
  UIStatic *m_pThunder; // ecx
  UIStatic *m_pWater; // ecx
  UIStatic *m_pFire; // ecx
  UIStatic *m_pEarth; // ecx
  UIStatic *m_pDouble; // ecx
  UIStatic *m_pEXP; // ecx
  UIStatic *m_pLevel; // ecx
  UIStatic *v11; // ecx
  UIStatic *v12; // ecx

  this->Destroy();
  m_pBack = (UIStatic *)this->m_pBack;
  if ( m_pBack )
  {
    pal3_vtbl_unk_0(m_pBack, 1) /* [VFTABLE-STUB] */;
    this->m_pBack = 0;
  }
  m_pWind = (UIStatic *)this->m_pWind;
  if ( m_pWind )
  {
    pal3_vtbl_unk_1(m_pWind, 1) /* [VFTABLE-STUB] */;
    this->m_pWind = 0;
  }
  m_pThunder = (UIStatic *)this->m_pThunder;
  if ( m_pThunder )
  {
    pal3_vtbl_unk_2(m_pThunder, 1) /* [VFTABLE-STUB] */;
    this->m_pThunder = 0;
  }
  m_pWater = (UIStatic *)this->m_pWater;
  if ( m_pWater )
  {
    pal3_vtbl_unk_3(m_pWater, 1) /* [VFTABLE-STUB] */;
    this->m_pWater = 0;
  }
  m_pFire = (UIStatic *)this->m_pFire;
  if ( m_pFire )
  {
    pal3_vtbl_unk_4(m_pFire, 1) /* [VFTABLE-STUB] */;
    this->m_pFire = 0;
  }
  m_pEarth = (UIStatic *)this->m_pEarth;
  if ( m_pEarth )
  {
    pal3_vtbl_unk_5(m_pEarth, 1) /* [VFTABLE-STUB] */;
    this->m_pEarth = 0;
  }
  m_pDouble = (UIStatic *)this->m_pDouble;
  if ( m_pDouble )
  {
    pal3_vtbl_unk_6(m_pDouble, 1) /* [VFTABLE-STUB] */;
    this->m_pDouble = 0;
  }
  m_pEXP = (UIStatic *)this->m_pEXP;
  if ( m_pEXP )
  {
    pal3_vtbl_unk_7(m_pEXP, 1) /* [VFTABLE-STUB] */;
    this->m_pEXP = 0;
  }
  m_pLevel = (UIStatic *)this->m_pLevel;
  if ( m_pLevel )
  {
    pal3_vtbl_unk_8(m_pLevel, 1) /* [VFTABLE-STUB] */;
    this->m_pLevel = 0;
  }
  v11 = (UIStatic *)this->m_pFace[0];
  if ( v11 )
  {
    pal3_vtbl_unk_9(v11, 1) /* [VFTABLE-STUB] */;
    this->m_pFace[0] = 0;
  }
  v12 = (UIStatic *)this->m_pFace[1];
  if ( v12 )
  {
    pal3_vtbl_unk_10(v12, 1) /* [VFTABLE-STUB] */;
    this->m_pFace[1] = 0;
  }
}

static void pal3_vtbl_unk_0(UIStatic *, int)
{
    
}
static void pal3_vtbl_unk_1(UIStatic *, int)
{
    
}
static void pal3_vtbl_unk_2(UIStatic *, int)
{
    
}
static void pal3_vtbl_unk_3(UIStatic *, int)
{
    
}
static void pal3_vtbl_unk_4(UIStatic *, int)
{
    
}
static void pal3_vtbl_unk_5(UIStatic *, int)
{
    
}
static void pal3_vtbl_unk_6(UIStatic *, int)
{
    
}
static void pal3_vtbl_unk_7(UIStatic *, int)
{
    
}
static void pal3_vtbl_unk_8(UIStatic *, int)
{
    
}
static void pal3_vtbl_unk_9(UIStatic *, int)
{
    
}
static void pal3_vtbl_unk_10(UIStatic *, int)
{
    
}


// 0x005195E0
int CCBResultWindow::OnMessage(int pt, unsigned int area, int nVal)
{
  CScreenMode *Instance; // eax

  if ( pt == 1001 )
  {
    if ( area >= 0x103 && area <= 0x10C )
    {
      Instance = (CScreenMode *)CScreenMode::GetInstance();
      (((CScreenMode *)Instance))->CScreenMode::AudioSetPosition("wa001", 1);
    }
    CCBControl::SetParam(*(CCBControl **)(this->m_pfather[17].m_fontcolor.Color + 8), area, nVal);
  }
  else if ( pt == 1007 && nVal != -1 )
  {
    CCBControl::SetParam(*(CCBControl **)(this->m_pfather[17].m_fontcolor.Color + 8), area, nVal);
  }
  return (((CGameData *)this))->CGameData::OnMessage(pt, area, nVal) /* [ROWTABLE] */;
}

// 0x00519660
BOOL CCBResultWindow::IsImbibeNimbusNotFinish(int nVal, int nVal2)
{
  if ( this->m_bvisible == 1
    && (g_Input.KeyInfo[16].PressTime == 1 && (g_Input.KeyInfo[16].Data & 0xF) == 1 || g_Input.KeyInfo[17].PressTime == 1) )
  {
    CCBControl::SetParam(*(CCBControl **)(this->m_pfather[17].m_fontcolor.Color + 8), g_nSkillItemIDTable[15], -1);
  }
  return (((SceneObj *)this))->SceneObj::Update(nVal, nVal2) /* [ROWTABLE] */;
}
