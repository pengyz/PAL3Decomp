#include "pal3/ida_defs.h"
#include "globals.h"
#include "pal3/pal3_constants.h"
#include "Combat/CCBProtectWindow.h"
#include "Combat/CCBUI.h"
#include "Misc/SceneInfo.h"
#include "Scene/SceneObj.h"
#include "Misc/UIButton.h"
#include "Misc/UIProgressBar.h"
#include "Misc/UIPushButton.h"
#include "Misc/UIStatic.h"
#include "UI/UIWnd.h"
#include "free_functions.h"

// Forward declarations for unnamed functions
int sub_519180(...);

// 0x00449BE0
char CCBProtectWindow::ValidateSlot(unsigned int dwVal)
{
  char result; // al

  result = dwVal;
  if ( dwVal <= 0x25 )
    return (((SceneInfo *)&this[2].m_wndcolor))->SceneInfo::ProcessCollision(*((_DWORD *)&this[2].m_pOk + 119 * dwVal + 20), (int)(((void **)&(this[3])))[119 * dwVal]);
  return result;
}

// 0x005164D0

// ---- synthesized vtable stubs (unresolved slots) ----
// [VFTABLE-STUB] original: ((void ( *)(UIStatic *, int))m_pBack->__vftable->_sdtor_call_dtor)(m_pBack, 1)
static void pal3_vtbl_unk_0(UIStatic *, int);
// [VFTABLE-STUB] original: ((void ( *)(UIWnd *, int))m_pfather->__vftable->_sdtor_call_dtor)(m_pfather, 1)
static void pal3_vtbl_unk_1(UIWnd *, int);
// [VFTABLE-STUB] original: ((void ( *)(UIStatic *, int))v48->__vftable->_sdtor_call_dtor)(v48, 1)
static void pal3_vtbl_unk_2(UIStatic *, int);
// [VFTABLE-STUB] original: ((void ( *)(UIPushButton *, int))m_pWHFace->__vftable->_sdtor_call_dtor)(m_pWHFace, 1)
static void pal3_vtbl_unk_3(UIPushButton *, int);
// [VFTABLE-STUB] original: ((void ( *)(UIPushButton *, int))m_pWPXFace->__vftable->_sdtor_call_dtor)(m_pWPXFace, 1)
static void pal3_vtbl_unk_4(UIPushButton *, int);
// [VFTABLE-STUB] original: ((void ( *)(UIProgressBar *, int))m_pWHLove->__vftable->_sdtor_call_dtor)(m_pWHLove, 1)
static void pal3_vtbl_unk_5(UIProgressBar *, int);

void CCBProtectWindow::Destroy()
{
  UIStatic *m_pBack; // ecx
  UIPushButton **p_m_pWHFace; // esi
  int v4; // edi
  void *m_id; // ecx
  _DWORD *v6; // esi
  int v7; // edi
  int v8; // ecx
  int v9; // ecx
  int v10; // ecx
  int v11; // ecx
  int v12; // ecx
  int v13; // ecx
  int v14; // ecx
  int v15; // ecx
  int v16; // ecx
  int v17; // ecx
  int v18; // ecx
  int v19; // ecx
  int v20; // ecx
  int v21; // ecx
  int v22; // ecx
  int v23; // ecx
  int v24; // ecx
  int v25; // ecx
  int v26; // ecx
  int v27; // ecx
  int v28; // ecx
  int v29; // ecx
  LONG left; // ecx
  LONG top; // ecx
  int v32; // ecx
  int v33; // ecx
  LONG bottom; // ecx
  UIWnd *m_pfather; // ecx
  char *m_pData; // ecx
  int capacity; // ecx
  int m_nSize; // ecx
  int m_needscriptdel; // ecx
  int m_bcreateok; // ecx
  int m_bvisible; // ecx
  UIButton **v42; // esi
  int v43; // edi
  int v44; // ecx
  int m_benable; // ecx
  int m_bfocus; // ecx
  gbTexture *m_pbktex; // ecx
  UIStatic *v48; // ecx
  UIPushButton *m_pWHFace; // ecx
  UIPushButton *m_pWPXFace; // ecx
  UIProgressBar *m_pWHLove; // ecx
  UIProgressBar **p_m_pWPXLove; // esi
  int v53; // edi

  this->Destroy();
  m_pBack = (UIStatic *)this->m_pBack;
  if ( m_pBack )
  {
    pal3_vtbl_unk_0(m_pBack, 1) /* [VFTABLE-STUB] */;
    this->m_pBack = 0;
  }
  p_m_pWHFace = (UIPushButton **)&this->m_pWHFace;
  v4 = 11;
  do
  {
    if ( *p_m_pWHFace )
    {
      delete p_m_pWHFace;
      *p_m_pWHFace = 0;
    }
    ++p_m_pWHFace;
    --v4;
  }
  while ( v4 );
  m_id = this[6].m_id;
  if ( m_id )
  {
    (*(void ( **)(void *, int))(*(_DWORD *)m_id + 20))(m_id, 1);
    this[6].m_id = 0;
  }
  v6 = (_DWORD *)(&this[5].m_pOk + 12);
  v7 = 4;
  do
  {
    v8 = *(v6 - 225);
    if ( v8 )
    {
      (*(void ( **)(int, int))(*(_DWORD *)v8 + 20))(v8, 1);
      *(v6 - 225) = 0;
    }
    if ( *v6 )
    {
      (*(void ( **)(_DWORD, int))(*(_DWORD *)*v6 + 20))(*v6, 1);
      *v6 = 0;
    }
    v9 = (unsigned long)v6[4];
    if ( v9 )
    {
      (*(void ( **)(int, int))(*(_DWORD *)v9 + 20))(v9, 1);
      v6[4] = 0;
    }
    v10 = (unsigned long)v6[8];
    if ( v10 )
    {
      (*(void ( **)(int, int))(*(_DWORD *)v10 + 20))(v10, 1);
      v6[8] = 0;
    }
    v11 = *(v6 - 211);
    if ( v11 )
    {
      (*(void ( **)(int, int))(*(_DWORD *)v11 + 20))(v11, 1);
      *(v6 - 211) = 0;
    }
    v12 = *(v6 - 200);
    if ( v12 )
    {
      (*(void ( **)(int, int))(*(_DWORD *)v12 + 20))(v12, 1);
      *(v6 - 200) = 0;
    }
    v13 = *(v6 - 189);
    if ( v13 )
    {
      (*(void ( **)(int, int))(*(_DWORD *)v13 + 20))(v13, 1);
      *(v6 - 189) = 0;
    }
    v14 = *(v6 - 178);
    if ( v14 )
    {
      (*(void ( **)(int, int))(*(_DWORD *)v14 + 20))(v14, 1);
      *(v6 - 178) = 0;
    }
    v15 = *(v6 - 145);
    if ( v15 )
    {
      (*(void ( **)(int, int))(*(_DWORD *)v15 + 20))(v15, 1);
      *(v6 - 145) = 0;
    }
    v16 = *(v6 - 134);
    if ( v16 )
    {
      (*(void ( **)(int, int))(*(_DWORD *)v16 + 20))(v16, 1);
      *(v6 - 134) = 0;
    }
    v17 = *(v6 - 167);
    if ( v17 )
    {
      (*(void ( **)(int, int))(*(_DWORD *)v17 + 20))(v17, 1);
      *(v6 - 167) = 0;
    }
    v18 = *(v6 - 156);
    if ( v18 )
    {
      (*(void ( **)(int, int))(*(_DWORD *)v18 + 20))(v18, 1);
      *(v6 - 156) = 0;
    }
    v19 = *(v6 - 123);
    if ( v19 )
    {
      (*(void ( **)(int, int))(*(_DWORD *)v19 + 20))(v19, 1);
      *(v6 - 123) = 0;
    }
    v20 = *(v6 - 112);
    if ( v20 )
    {
      (*(void ( **)(int, int))(*(_DWORD *)v20 + 20))(v20, 1);
      *(v6 - 112) = 0;
    }
    v21 = *(v6 - 101);
    if ( v21 )
    {
      (*(void ( **)(int, int))(*(_DWORD *)v21 + 20))(v21, 1);
      *(v6 - 101) = 0;
    }
    v22 = *(v6 - 90);
    if ( v22 )
    {
      (*(void ( **)(int, int))(*(_DWORD *)v22 + 20))(v22, 1);
      *(v6 - 90) = 0;
    }
    v23 = *(v6 - 79);
    if ( v23 )
    {
      (*(void ( **)(int, int))(*(_DWORD *)v23 + 20))(v23, 1);
      *(v6 - 79) = 0;
    }
    v24 = *(v6 - 68);
    if ( v24 )
    {
      (*(void ( **)(int, int))(*(_DWORD *)v24 + 20))(v24, 1);
      *(v6 - 68) = 0;
    }
    v25 = *(v6 - 57);
    if ( v25 )
    {
      (*(void ( **)(int, int))(*(_DWORD *)v25 + 20))(v25, 1);
      *(v6 - 57) = 0;
    }
    v26 = *(v6 - 46);
    if ( v26 )
    {
      (*(void ( **)(int, int))(*(_DWORD *)v26 + 20))(v26, 1);
      *(v6 - 46) = 0;
    }
    v27 = *(v6 - 35);
    if ( v27 )
    {
      (*(void ( **)(int, int))(*(_DWORD *)v27 + 20))(v27, 1);
      *(v6 - 35) = 0;
    }
    v28 = *(v6 - 24);
    if ( v28 )
    {
      (*(void ( **)(int, int))(*(_DWORD *)v28 + 20))(v28, 1);
      *(v6 - 24) = 0;
    }
    v29 = *(v6 - 13);
    if ( v29 )
    {
      (*(void ( **)(int, int))(*(_DWORD *)v29 + 20))(v29, 1);
      *(v6 - 13) = 0;
    }
    ++v6;
    --v7;
  }
  while ( v7 );
  left = this[6].m_rect.left;
  if ( left )
  {
    (*(void ( **)(LONG, int))(*(_DWORD *)left + 20))(left, 1);
    this[6].m_rect.left = 0;
  }
  top = this[6].m_rect.top;
  if ( top )
  {
    (*(void ( **)(LONG, int))(*(_DWORD *)top + 20))(top, 1);
    this[6].m_rect.top = 0;
  }
  v32 = *((_DWORD *)&this[5].m_pOk + 10);
  if ( v32 )
  {
    (*(void ( **)(int, int))(*(_DWORD *)v32 + 20))(v32, 1);
    *((_DWORD *)&this[5].m_pOk + 10) = 0;
  }
  v33 = *((_DWORD *)&this[5].m_pOk + 11);
  if ( v33 )
  {
    (*(void ( **)(int, int))(*(_DWORD *)v33 + 20))(v33, 1);
    *((_DWORD *)&this[5].m_pOk + 11) = 0;
  }
  bottom = this[6].m_rect.bottom;
  if ( bottom )
  {
    (*(void ( **)(LONG, int))(*(_DWORD *)bottom + 20))(bottom, 1);
    this[6].m_rect.bottom = 0;
  }
  m_pfather = this[6].m_pfather;
  if ( m_pfather )
  {
    pal3_vtbl_unk_1(m_pfather, 1) /* [VFTABLE-STUB] */;
    this[6].m_pfather = 0;
  }
  m_pData = this[6].m_childs.m_pData;
  if ( m_pData )
  {
    (*(void ( **)(char *, int))(*(_DWORD *)m_pData + 20))(m_pData, 1);
    this[6].m_childs.m_pData = 0;
  }
  capacity = this[6].m_childs.capacity;
  if ( capacity )
  {
    (*(void ( **)(int, int))(*(_DWORD *)capacity + 20))(capacity, 1);
    this[6].m_childs.capacity = 0;
  }
  m_nSize = this[6].m_childs.m_nSize;
  if ( m_nSize )
  {
    (*(void ( **)(int, int))(*(_DWORD *)m_nSize + 20))(m_nSize, 1);
    this[6].m_childs.m_nSize = 0;
  }
  m_needscriptdel = this[6].m_childs.m_needscriptdel;
  if ( m_needscriptdel )
  {
    (*(void ( **)(int, int))(*(_DWORD *)m_needscriptdel + 20))(m_needscriptdel, 1);
    this[6].m_childs.m_needscriptdel = 0;
  }
  m_bcreateok = this[6].m_bcreateok;
  if ( m_bcreateok )
  {
    (*(void ( **)(int, int))(*(_DWORD *)m_bcreateok + 20))(m_bcreateok, 1);
    this[6].m_bcreateok = 0;
  }
  m_bvisible = this[6].m_bvisible;
  if ( m_bvisible )
  {
    (*(void ( **)(int, int))(*(_DWORD *)m_bvisible + 20))(m_bvisible, 1);
    this[6].m_bvisible = 0;
  }
  v42 = (UIButton **)(&this->m_pOk + 16);
  v43 = 5;
  do
  {
    v44 = (int)*(v42 - 5);
    if ( v44 )
    {
      (*(void ( **)(int, int))(*(_DWORD *)v44 + 20))(v44, 1);
      *(v42 - 5) = 0;
    }
    if ( *v42 )
    {
      delete v42;
      *v42 = 0;
    }
    ++v42;
    --v43;
  }
  while ( v43 );
  m_benable = this[6].m_benable;
  if ( m_benable )
  {
    (*(void ( **)(int, int))(*(_DWORD *)m_benable + 20))(m_benable, 1);
    this[6].m_benable = 0;
  }
  m_bfocus = this[6].m_bfocus;
  if ( m_bfocus )
  {
    (*(void ( **)(int, int))(*(_DWORD *)m_bfocus + 20))(m_bfocus, 1);
    this[6].m_bfocus = 0;
  }
  m_pbktex = this[6].m_pbktex;
  if ( m_pbktex )
  {
    m_pbktex->UpdateTexture(1);
    this[6].m_pbktex = 0;
  }
  v48 = (UIStatic *)this[6].m_pBack;
  if ( v48 )
  {
    pal3_vtbl_unk_2(v48, 1) /* [VFTABLE-STUB] */;
    this[6].m_pBack = 0;
  }
  m_pWHFace = (UIPushButton *)this[6].m_pWHFace;
  if ( m_pWHFace )
  {
    pal3_vtbl_unk_3(m_pWHFace, 1) /* [VFTABLE-STUB] */;
    this[6].m_pWHFace = 0;
  }
  m_pWPXFace = (UIPushButton *)this[6].m_pWPXFace;
  if ( m_pWPXFace )
  {
    pal3_vtbl_unk_4(m_pWPXFace, 1) /* [VFTABLE-STUB] */;
    this[6].m_pWPXFace = 0;
  }
  m_pWHLove = (UIProgressBar *)this[6].m_pWHLove;
  if ( m_pWHLove )
  {
    pal3_vtbl_unk_5(m_pWHLove, 1) /* [VFTABLE-STUB] */;
    this[6].m_pWHLove = 0;
  }
  p_m_pWPXLove = (UIProgressBar **)&this[6].m_pWPXLove;
  v53 = 4;
  do
  {
    if ( *p_m_pWPXLove )
    {
      delete p_m_pWPXLove;
      *p_m_pWPXLove = 0;
    }
    ++p_m_pWPXLove;
    --v53;
  }
  while ( v53 );
}

static void pal3_vtbl_unk_0(UIStatic *, int)
{
    
}
static void pal3_vtbl_unk_1(UIWnd *, int)
{
    
}
static void pal3_vtbl_unk_2(UIStatic *, int)
{
    
}
static void pal3_vtbl_unk_3(UIPushButton *, int)
{
    
}
static void pal3_vtbl_unk_4(UIPushButton *, int)
{
    
}
static void pal3_vtbl_unk_5(UIProgressBar *, int)
{
    
}


// 0x00518E30
BOOL CCBProtectWindow::ShowAndNotify(int nVal, int nVal2)
{
  sub_519180();
  /* [MISATTRIBUTED] CCBUI on CCBProtectWindow::this -> fix IDB name of callee */ CCBUI::ShowDialogWindow((CCBUI *)this);
  /* [MISATTRIBUTED] CCBUI on CCBProtectWindow::this -> fix IDB name of callee */ CCBUI::HideAll((CCBUI *)this);
  return (((SceneObj *)this))->SceneObj::Update(nVal, nVal2) /* [ROWTABLE] */;
}

// 0x0051D6E0
CCBProtectWindow::CCBProtectWindow()
{
  dword_17AD59C = 1094713344;
}

// 0x0051D6F0
// attributes: thunk
CCBProtectWindow::~CCBProtectWindow()
{
  this->CCBProtectWindow::Reset();
}

// 0x0051D700
void CCBProtectWindow::Reset()
{
  flt_17AD598 = 12.0 + 12.0;
}

// 0x0051F0A0
int CCBProtectWindow::OnCommand(int nVal, int nVal2)
{
  UIButton *v4; // eax
  const void *v5; // esi
  LONG v6; // edx
  void *v7; // eax
  LONG v8; // ecx
  LONG v9; // edx

  v4 = (UIButton *)*((_DWORD *)&this[45].m_pOk + 8);
  v5 = (const void *)*((_DWORD *)&this[45].m_pOk + 9);
  v6 = *((_DWORD *)&this[1863].m_pOk + 16);
  this[1963].m_pWHLove = (UIProgressBar *)*((_DWORD *)&this[1863].m_pOk + 10);
  this[1963].m_pOk = v4;
  v7 = (void *)*((_DWORD *)&this[1863].m_pOk + 13);
  qmemcpy(&this[1963].m_pOk + 1, v5, 0xDCu);
  v8 = *((_DWORD *)&this[1863].m_pOk + 14);
  this[2883].m_rect.right = v6;
  v9 = *((_DWORD *)&this[1863].m_pOk + 15);
  this[2883].m_id = v7;
  this[2883].m_rect.left = v8;
  this[2883].m_rect.top = v9;
  StopSceneScripts((const char *)nVal);
  (((SceneObj *)this))->SceneObj::Update(nVal, nVal2) /* [ROWTABLE] */;
  return 1;
}
