#pragma once
// Auto-generated: CCBStage
#include "pal3/ida_types.h"

#include "gbengine/gbengine_types.h"
#include "gbengine/gbGfxManager.h"
#include "gbengine/gbengine_internal.h"
#include "gbengine/gbengine_types.h"

class Actor;
class CCBCamControl;
class CCBDisplayChain;
class CCBEditor;
class CCBProtectWindow;
class CCBRoleState;
class CCBStageCam;
class CCBStageEffect;
class CCBStageRole;
class CCBStageScene;
class CCBStageShadow;
class CCBSystem;
class ECBStageTaskState;
class tagRoleState;

class CCBStage {
public:
    // vtable (2 methods, order matches binary layout)

    CCBSystem * m_pCBSystem; // +0x0
    CCBRoleState * m_pRoleState; // +0x4
    CCBEditor * m_pEditor; // +0x8
    CCBStageCam * m_pCam; // +0xC
    CCBCamControl * m_pCamControl; // +0x10
    CCBStageScene * m_pScene; // +0x14
    CCBStageRole * m_pRole[11]; // +0x18
    char _gap_01C[40]; // +0x1C
    Actor * m_TempStorageNGH; // +0x44
    Actor * m_NGHVariance; // +0x48
    Actor * m_TempStorageWPX; // +0x4C
    Actor * m_WPXVariance; // +0x50
    CCBDisplayChain * m_pDisplayChain; // +0x54
    CCBStageShadow * m_pShadow; // +0x58
    CCBStageEffect * m_pEffect; // +0x5C
    int m_BFARole; // +0x60
    int m_BFARound; // +0x64
    tagPOINT m_ptMousePos; // +0x68
    int m_nSelectedRole; // +0x70
    BYTE m_bRoleSelected[11]; // +0x74
    BYTE m_bHideSceneAndRole; // +0x7F
    float m_fDamageNumPosY[5]; // +0x80
    int m_nTodo_094; // +0x94
    BYTE m_nStageStatus; // +0x98
    BYTE m_bFlag99; // +0x99
    BYTE m_bFlag9A; // +0x9A
    BYTE m_bFlag9B; // +0x9B
    int m_nTaskCount; // +0x9C
    int m_nClearRoleAllTask; // +0xA0
    int m_nRoleSlot; // +0xA4
    BYTE m_nForceDelTask; // +0xA8
    char _gap_0A9[3]; // +0xA9
    float m_fMusicVolume; // +0xAC
    BYTE m_bPaused; // +0xB0
    char _gap_0B1[3]; // +0xB1
    int m_nTask; // +0xB4
    int m_nCurTask; // +0xB8
    int m_nCurSubTask; // +0xBC
    int m_Task; // +0xC0
    int m_RoleSlots; // +0xC4
    char _gap_0C8[73]; // +0xC8
    BYTE m_bAllDone; // +0x111
    char _gap_112[6]; // +0x112
    BYTE m_nActiveRoleIndex; // +0x118
    char _gap_119[3]; // +0x119
    int m_nActiveIdx; // +0x11C
    int m_CamAngles; // +0x120
    int m_nTodo_124; // +0x124
    gbColorQuad m_CamParams; // +0x128
    char _gap_12C[96]; // +0x12C
    int m_nActionIdx; // +0x18C
    int m_TargetPos; // +0x190
    char _gap_194[44]; // +0x194
    int m_nTurnCounter; // +0x1C0
    float m_fRotPitch; // +0x1C4
    float m_fRotYaw; // +0x1C8
    char _gap_1CC[4]; // +0x1CC
    float m_fTimeAccum; // +0x1D0
    float m_fTimerRaw; // +0x1D4
    char _gap_1D8[8]; // +0x1D8
    float m_fAccumX; // +0x1E0
    float m_fAccumY; // +0x1E4
    float m_fAllDone; // +0x1E8
    float m_ActionAngles; // +0x1EC
    float m_fTurnDelay; // +0x1F0
    int m_nActionTimer; // +0x1F4
    float m_ActionCmds; // +0x1F8
    float m_nTodo_1FC; // +0x1FC
    float m_pSubStage; // +0x200
    int m_nSubStageState; // +0x204
    int m_nTodo_208; // +0x208
    int m_nTodo_20C; // +0x20C
    char _gap_210[16]; // +0x210
    char * m_pController; // +0x220
    float m_fTurnProgress; // +0x224
    float m_fPrevRotX; // +0x228
    float m_fPrevRotY; // +0x22C
    int m_nTurnCount; // +0x230
    int m_nCmdCount; // +0x234
    int m_nTurnPhase; // +0x238
    int m_nLastAction; // +0x23C
    int m_nTurnIndex; // +0x240
    int m_nResetState; // +0x244
    int m_CmdQueue; // +0x248
    char _gap_24C[18]; // +0x24C
    short m_TurnFlags; // +0x25E
    char _gap_260[16]; // +0x260
    int m_TurnData; // +0x270
    char _gap_274[249]; // +0x274
    char m_nTodo_36D; // +0x36D
    char _gap_36E[22]; // +0x36E
    int m_hTask; // +0x384
    int m_hTaskParam; // +0x388
    char _gap_38C[484]; // +0x38C
    int m_nTodo_570; // +0x570
    int m_nTodo_574; // +0x574
    int m_RoleData; // +0x578
    char _gap_57C[76]; // +0x57C
    int m_nTodo_5C8; // +0x5C8
    char _gap_5CC[1268]; // +0x5CC
    int m_TaskQueue; // +0xAC0
    int m_TaskState; // +0xAC4
    int m_nTaskExist; // +0xAC8
    int m_DamageData; // +0xACC
    char _gap_AD0[28]; // +0xAD0
    BYTE m_nTaskState; // +0xAEC
    char _gap_AED[1707]; // +0xAED
    void * m_nTodo_1198; // +0x1198
    int m_nSlotCounter; // +0x119C
    char _gap_11A0[72]; // +0x11A0
    int m_TurnBuffer; // +0x11E8
    char _gap_11EC[1980]; // +0x11EC
    int m_nAllDone; // +0x19A8
    char _gap_19AC[12]; // +0x19AC
    float m_fCurPosX; // +0x19B8
    float m_fCurPosY; // +0x19BC
    float m_fCurPosZ; // +0x19C0
    char _gap_19C4[12]; // +0x19C4
    float m_fTargetPosX; // +0x19D0
    float m_fTargetPosY; // +0x19D4
    float m_fTargetPosZ; // +0x19D8
    float m_fVelX; // +0x19DC
    float m_fVelY; // +0x19E0
    float m_fVelZ; // +0x19E4
    float m_fAngleDegrees; // +0x19E8
    float m_fCombatAnimY; // +0x19EC
    char _gap_19F0[4]; // +0x19F0
    int m_nBattleResult; // +0x19F4
    int m_nActionFilterA; // +0x19F8
    int m_nActionFilterB; // +0x19FC
    char _gap_1A00[8]; // +0x1A00
    int m_nDoneCount; // +0x1A08
    int m_nTotalCount; // +0x1A0C
    char _gap_1A10[1380]; // +0x1A10
    float m_fTurnTimer; // +0x1F74
    int m_nTurnSlot0; // +0x1F78
    int m_nTurnSlot1; // +0x1F7C
    int m_nTurnSlot2; // +0x1F80
    int m_nTurnSlot3; // +0x1F84
    int m_nTurnSlot4; // +0x1F88
    int m_nTurnSlot5; // +0x1F8C
    char _gap_1F90[1536]; // +0x1F90
    int m_nResultSlot0; // +0x2590
    int m_nResultSlot1; // +0x2594
    char _gap_2598[398376]; // +0x2598
    char m_EditDescBuf[2000]; // +0x639C0
    void * m_nTodo_64190; // +0x64190
    char _gap_64194[263956]; // +0x64194
    int m_nTodo_A48A8; // +0xA48A8
    char _gap_A48AC[20]; // +0xA48AC
    UINT m_dwAniFlagOver; // +0xA48C0
    // total size: 0xA48C4 (673988)

    virtual int OnMessage(int nVal, int nVal2, int nVal3); // 0x0051F1B0
    void Init(int thisa); // 0x0040CC90
    char * GetAlive(int *pConfig); // 0x0040CCF0
    int PassCmd(void *p_DWORD); // 0x0040CF60
    int CheckValid(int nVal); // 0x0040D010
    int * GetByIndex(int *p_DWORD); // 0x0040DCF0
    int Find(char *String1); // 0x0040DD30
    void Reset(); // 0x0040DD80
    int RandomizePositions(); // 0x0044CFF0
    char sub_00459fa0(int thisa, unsigned __int8 pData); // 0x00459FA0
    char sub_0045a020(int thisa, unsigned __int8 pData); // 0x0045A020
    char sub_0045a0a0(int thisa, unsigned __int8 pData); // 0x0045A0A0
    char sub_0045a120(int thisa, unsigned __int8 pData); // 0x0045A120
    char sub_0045a1a0(int thisa, unsigned __int8 pData); // 0x0045A1A0
    int GetReadyCount(); // 0x004C5C20
    int GetActiveTaskCount(); // 0x004D1EF0
    int GetTaskParam(int nVal, int nVal2); // 0x004D4D30
    char SetTaskState(int nVal); // 0x004D4D70
    int * InitStage(int nVal); // 0x004DF6B0
    char IsInitialized(); // 0x004DF700
    void ResetRoundState(); // 0x004DF710
    int CountActiveActions(); // 0x004DFA10
    int InitRound(); // 0x004DFAA0
    int UpdateTurnFlags(const char *pszName, float fVal, float fVal2, float fVal3); // 0x004DFB70
    int InitSlotFlags(const char *pszName, int nVal, int nVal2, int nVal3); // 0x004DFC40
    int AddTextLabel(int nVal, int nVal2); // 0x004DFE00
    int EndTurnAndAdvance(); // 0x004DFED0
    int AssignSlotData(char pData); // 0x004DFF90
    __int64 CalculateTurnOrder(float fVal, int nVal); // 0x004DFFF0
    void SetupCamControl(); // 0x004E0010
    int * ResetAndSetSystem(int nVal); // 0x004E02F0
    int ResetTurnSlots(); // 0x004E0340
    char SyncTimeScale(); // 0x004E0380
    char DestroyDialog(); // 0x004E03F0
    char CreatePreviewDialog(); // 0x004E0430
    bool ProcessAction(HWND pData); // 0x004E0530
    static void CreatePreview(float fVal); // 0x004E05B0
    BOOL DestroyPreviewWindow(); // 0x004E0650
    void InitUIByName(); // 0x004E2C50
    bool FindThreadByParam(int nVal, unsigned int dwVal); // 0x004F06C0
    CCBStageRole * GetRole(int index); // 0x004F4AA0
    char CheckGDBTypeCompat(unsigned int *pdwVal); // 0x004F6CD0
    CCBStage(int pCBSystem); // 0x004FB9A0
    ~CCBStage(); // 0x004FB9F0
    bool Create(); // 0x004FBE50
    bool Destroy(); // 0x004FBF90
    void Update(); // 0x004FC0A0
    int Update_c150(); // 0x004FC150
    static void EditorUpdate(float fVal); // 0x004FC3A0
    void Render(); // 0x004FC6F0
    int GetRoleIndex(int nameCrc, const void *pData, char a4); // 0x004FC700
    int GetRoleName(int nameCrc, int nVal, int nVal2, int nVal3, int nVal4, int *p_DWORD, int nVal5, int nVal6); // 0x004FC7D0
    void Procced(int nVal); // 0x004FC8B0
    char GetStageRole(int idx); // 0x004FC8F0
    char GetStageRoleByIdx(int idx); // 0x004FC940
    bool IsDoTask(int eTask); // 0x004FC980
    bool EndTask(int nIndex); // 0x004FC9A0
    char * DelTask(int nIndex, _BYTE *p_BYTE, int *p_DWORD); // 0x004FC9C0
    bool ForceDelTask(int nIndex); // 0x004FCA00
    void GetTask(); // 0x004FCA80
    char GetTaskID(int nIndex, int nVal); // 0x004FCBD0
    static char GetTaskState(int nIndex, bool *bFinished, unsigned int *dwReturn); // 0x004FCC10
    static char GetTaskState(int nIndex, ECBStageTaskState *State); // 0x004FCC50
    bool IsTaskFinished(int nIndex); // 0x004FCD00
    static unsigned __int8 * IsTaskValidButNotFinish(unsigned __int8 *result, int eTask, int nVal); // 0x004FCD50
    bool IsTaskExist(unsigned int dwTaskID); // 0x004FCDA0
    void DoTask(int nVal); // 0x004FCDE0
    bool StartSubTask(int n); // 0x004FCE00
    static bool IsSubTaskFinished(int n, int nSub); // 0x004FCE70
    bool IsAllSubTaskFinished(int n); // 0x004FCFB0
    bool IsTaskValid(int n); // 0x004FD0B0
    static bool IsSubTaskValid(int n, int nSub); // 0x004FD1A0
    bool IsIdle(int nVal); // 0x004FD290
    bool HasNormalAttackRole(int nRoleIndex); // 0x004FD3D0
    void ClearRoleAllTask(int nRoleIndex); // 0x004FD880
    void EndRoleAllTask(int nRoleIndex); // 0x004FDA10
    int GetRoleTaskNum(int nRoleIndex); // 0x004FDB10
    void SelectRole(int nRoleIndex); // 0x004FDD90
    unsigned int ProcWait(int formal); // 0x004FDFC0
    unsigned int ProcShowFiveLineup(int formal); // 0x004FE290
    unsigned int ProcShowEnemyFiveLineup(); // 0x004FE540
    unsigned int ProcFiveLienupFadeIn(int formal); // 0x004FE550
    unsigned int ProcFiveLienupFadeOut(int formal); // 0x004FE600
    unsigned int ProcShowSneakAttackState(unsigned int  a_74); // 0x004FE660
    void HandleKeyCtrl(int n); // 0x004FECE0
    bool HandleKeyFriend(int Selected); // 0x004FEE60
    int sub_4FEEF0(void *thisa); // 0x004FEEF0
    unsigned int ProcShowName(unsigned int formal); // 0x004FEFB0
    unsigned int ProcShowItemName(int formal); // 0x004FF1B0
    unsigned int ProcShowDamage(unsigned int formal); // 0x004FF3D0
    int ProcTaskSlot(int nVal); // 0x004FF560
    unsigned int ProcShowCost(int formal); // 0x004FF5C0
    unsigned int ProcShowCombatDialog(int formal); // 0x004FF740
    unsigned int ProcGrabStageRole(unsigned int formal); // 0x004FF840
    int TaskExecAttack(int nVal); // 0x004FFA90
    int TaskExecCommand(int nVal); // 0x004FFCB0
    int TaskResetToIdle(int nVal); // 0x004FFED0
    int TaskExecMagicEffect(int nVal); // 0x004FFF60
    int TaskExecSkill(int nVal); // 0x00500220
    int TaskWaitIdle(int nVal); // 0x005004B0
    int TaskExecItem(int nVal); // 0x00500550
    int TaskForceEnd(int nVal); // 0x005007A0
    int ExecuteRoleTask(int nVal); // 0x00500840
    int ClearTaskForRole(int nVal); // 0x005009C0
    int ClearTaskForRoleAll(int nVal); // 0x00500AD0
    int TaskExecAction(int nVal); // 0x00500C20
    int TaskResolveAction(int nState); // 0x00500D50
    int TaskMoveToStart(int nVal); // 0x005011B0
    int TaskBlendToReady(int nVal); // 0x00501330
    int TaskBlendToEnd(int nVal); // 0x00501410
    int TaskEnterGuard(int nVal); // 0x005014E0
    int SetupCombatAction(int nVal); // 0x005015C0
    int TaskReturnToIdle(int nVal); // 0x00501CF0
    int TaskShowLevelUp(int nVal); // 0x00501E60
    int TaskShowSkillLearned(int nVal); // 0x00501F30
    int ProcessRoleEffect(int nVal); // 0x005024D0
    int ResetAll(); // 0x00503020
    int CalcSneakAttackVariance(); // 0x00503680
    int UpdatePhysics(); // 0x00503CF0
    int ResetTurnData(int **a2, struct gbGfxManager *p); // 0x00503FA0
    int ResetTurnSystem(); // 0x005040D0
    int ClearTurnSlot(int nVal); // 0x00504420
    bool GetTurnSlotData(int nVal); // 0x00504440
    bool HasTurnChanged(float *pfVal); // 0x00504460
    char ProcessTurn(); // 0x005045B0
    int * GetNextActiveTask(); // 0x005049F0
    char ScanTurnSlots(); // 0x00504A80
    char ClearActionSlot(int nVal); // 0x00504AB0
    char EnqueueCommand(int nVal, int nVal2, int nVal3, int nVal4, int nVal5, float fVal, const void *pData, const void *pData2); // 0x00504B50
    int ProcessQueuedCommand(int nVal); // 0x00504C50
    int ClearAll(); // 0x00504E30
    void _CCBStageRole(int nVal, int nVal2, int *p_DWORD); // 0x00508930
    void Proceed(); // 0x005090F0
    void SetAlive(bool bAlive); // 0x00509130
    void SetMaxBlend(); // 0x00509140
    void SetVisible(); // 0x00509180
    void SetPause(); // 0x00509190
    void OnChangeAction(); // 0x005091D0
    int CheckAction(); // 0x005091E0
    void OnPlayAction(); // 0x00509220
    bool IsUnderMouse(); // 0x00509270
    bool IsCollideRay(); // 0x00509280
    void GetRoleRadius(); // 0x00509290
    int GetRoleHeight(); // 0x005092A0
    CCBStage * GetOBBox(int nVal); // 0x005092B0
    int GetRotAngle(); // 0x00509410
    bool IsIdle(unsigned int dwVal); // 0x00509540
    bool IsAtInitPos(); // 0x00509690
    bool IsAtProtectPos(int index, int nAttacker, int nVal); // 0x005096D0
    bool IsTaskFinished(int nVal, BOOL fpTask); // 0x005099A0
    void IsDoTask(gbMatrixStack *fpTask); // 0x00509B90
    static int Grab(int dwStageTaskID, bool bNormal); // 0x0050A180
    void Release(char dwStageTaskID); // 0x0050A1A0
    void TryRelease(); // 0x0050A1B0
    void ForceRelease(char pData); // 0x0050A1F0
    void DangerForceRelease(char pData); // 0x0050A200
    bool IsGrabedBy(); // 0x0050A210
    void GetPointerPos(); // 0x0050A260
    void SetBladeTime(int fBladeTime); // 0x0050A2B0
    bool CheckViewTarget(); // 0x0050A4B0
    bool LoadAction(gbRay nActIndex); // 0x0050A500
    int GetStatus(int index); // 0x0050A520
    float * GetWorldPos(); // 0x0050A560
    double AddTask(float *fp); // 0x0050A5D0
    bool ForceDelTaskByPFN(); // 0x0050A6F0
    bool ForceEndTaskByPFN(); // 0x0050A700
    bool EndTask(int fp, int dwTaskID); // 0x0050A770
    bool DelTask(int nIndex); // 0x0050A8E0
    bool DelAllTask(int nVal, char pData); // 0x0050A8F0
    char GetCurrentTask(int nVal); // 0x0050A920
    int GetCurrentTaskIndex(); // 0x0050A960
    bool IsReady(int idx); // 0x0050A980
    tagRoleState * DoTask(gbVec3D *dwMsg); // 0x0050A9B0
    void ClearBadPushTask(float fVal); // 0x0050AA60
    double PushBackAllTask(); // 0x0050AAE0
    void ClearAniMsg(char pData, float fVal); // 0x0050AB10
    void SetParam(int pParam, char dw1); // 0x0050AC50
    char GetProperCurAction(int nVal, int nVal2, int nVal3, int nVal4, int nVal5, int *pnVal, const void *pData, int nVal6); // 0x0050AD30
    char ProcTransportRun(unsigned int dwMsg, int nVal, int nVal2, int nVal3, int *pnVal, const void *pData, int nVal4); // 0x0050B070
    void SetForceFinishThrowingWeapon(int bForce); // 0x0050B290
    char GetCurrentState(); // 0x0050B330
    unsigned int ProcCatchED(); // 0x0050B360
    char FindFreeSlot(int a2); // 0x0050B430
    char CountValidTasks(); // 0x0050B4C0
    int FindNextTask(); // 0x0050B4F0
    void GetTaskState(); // 0x0050B530
    char ProcPursueRole(int formal, int nVal, char pData); // 0x0050B580
    unsigned int ProcTurn(); // 0x0050BBD0
    unsigned int ProcTurnToRole(int formal); // 0x0050BCD0
    unsigned int ProcBlock(int dwMsg); // 0x0050C320
    unsigned int ProcMagic(unsigned int dwMsg); // 0x0050C970
    unsigned int ProcUseRecoverItem(float dwMsg); // 0x0050CDE0
    int CheckAllDone(); // 0x0050D440
    int UpdateSlotTimer(int nVal); // 0x0050DA90
    int ProcessCommand(); // 0x0050E0D0
    int UpdateTaskNormals(int nVal); // 0x0050E160
    int CalcFacingAngle(int nVal); // 0x0050E360
    int ResolveActionEffect(int nVal); // 0x0050E550
    int ProcessSlotAction(int nVal); // 0x0050EB00
    int CheckPushState(int nVal); // 0x0050EDA0
    int OnPhysicalHit(int nVal); // 0x0050EE70
    int UpdateActionTimers(float fVal); // 0x0050EF60
    int AnimCallback_Attack(int nVal); // 0x0050F080
    int AnimCallback_UseItem(int nVal); // 0x0050F150
    int OnMagicHit(int nVal); // 0x0050F200
    int AnimCallback_Throw(int nVal, int nVal2); // 0x0050F310
    int AnimCallback_CastMagic(int nVal); // 0x0050F410
    int AnimCallback_WaitCmd(int nVal); // 0x0050F4C0
    int AnimCallback_MoveTo(int nVal); // 0x0050F590
    int ClearTaskIfMatch(int nVal); // 0x0050FA20
    int SetActionVisible(char nActIndex); // 0x00518E10
    CCBProtectWindow * Create_d710(); // 0x0051D710
    static void CCBProtectWindow_Destroy(); // 0x0051DD80
    void ShowWindow(); // 0x0051DDA0
    int UpdateWeaponSlots(); // 0x0051F070
    int SetWeaponSlotA(); // 0x0051F080
    int SetWeaponSlotB(); // 0x0051F090
    static bool CheckActionValid(int nVal); // 0x00521A80
    int DispatchUpdate(unsigned __int8 nFlag); // 0x00521E60
    int DispatchUpdateAll(unsigned __int8 nFlag); // 0x00521F30
    CCBStage * CCBStageRole(); // 0x00522030
    int * ClearRoleState(); // 0x005220E0
    void CleanupScript(); // 0x00522120
    int GetWeaponSlotPtr(int nVal); // 0x00523090
    int sub_525090(void *thisa); // 0x00525090
    void PlaySound(char *name, int nVal); // 0x0053E310
    unsigned int PauseSound(); // 0x0053E9C0
    unsigned int ResumeSound(); // 0x0053EA10
};
