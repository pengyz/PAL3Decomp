#include "pal3/ida_defs.h"
#include "globals.h"
#include "pal3/pal3_constants.h"
#include "Combat/CCBUI.h"
#include "Misc/ARC_PlayerAtt.h"
#include "Role/Actor.h"
#include "Misc/ArcLocaleRole.h"
#include "Combat/CCBAI.h"
#include "Combat/CCBAIWindow.h"
#include "Combat/CCBAttackSequen.h"
#include "Combat/CCBCamControl.h"
#include "Combat/CCBControl.h"
#include "Combat/CCBControlWindow.h"
#include "Misc/CCBFiveNimbusWindow.h"
#include "Combat/CCBItemWindow.h"
#include "Combat/CCBLineupWindow.h"
#include "Combat/CCBMagicWindow.h"
#include "Combat/CCBParabolaWindow.h"
#include "Combat/CCBProtectWindow.h"
#include "Combat/CCBResultWindow.h"
#include "Combat/CCBRoleState.h"
#include "Combat/CCBSkillWindow.h"
#include "Combat/CCBStage.h"
#include "Combat/CCBStageCam.h"
#include "Combat/CCBStageEffect.h"
#include "Combat/CCBStageRole.h"
#include "Combat/CCBStageScene.h"
#include "Combat/CCBSystem.h"
#include "Misc/CCBUI_funcptr_t.h"
#include "Combat/CCCTData.h"
#include "Effect/CEffMgr.h"
#include "Effect/CEffSParticle.h"
#include "Effect/CEffect.h"
#include "Effect/CEffectSystem.h"
#include "Render/CScreenMode.h"
#include "Combat/CUtil.h"
#include "Scene/Camera.h"
#include "Combat/Combat.h"
#include "GameBase/GRPinput.h"
#include "GameBase/Logger.h"
#include "Misc/MUIDialog.h"
#include "Role/NPC.h"
#include "Misc/NameSys.h"
#include "GameBase/PAL3.h"
#include "Data/PAL_GDB.h"
#include "Script/PalScript.h"
#include "Script/PalScriptMgr.h"
#include "Misc/PlayerMgr.h"
#include "UI/PropUI.h"
#include "Misc/PtrArray.h"
#include "Role/Role.h"
#include "Role/RoleSystem.h"
#include "Misc/SaleUI.h"
#include "Scene/SceneObj.h"
#include "Misc/UIButton.h"
#include "Misc/UICaption.h"
#include "Misc/UIFrameWnd.h"
#include "UI/UIItem.h"
#include "UI/UIListBox.h"
#include "UI/UINote.h"
#include "Misc/UIProgressBar.h"
#include "Misc/UIPushButton.h"
#include "Misc/UIRoleDialog.h"
#include "Misc/UIRoleSelect.h"
#include "UI/UIScene.h"
#include "Misc/UIScrollBar.h"
#include "Misc/UIStatic.h"
#include "Misc/UIStaticCB.h"
#include "UI/UIWnd.h"
#include "Misc/_PlugInfo.h"
#include "Misc/tag17A7BData.h"
#include "Misc/tagCmdData.h"
#include "Misc/tagEffMgrData.h"
#include "Misc/tagRoleState.h"
#include "Misc/tagUITask.h"
#include "free_functions.h"

// Forward declarations for unnamed functions
int sub_4CE030(...);
int sub_4CE5C0(...);
int sub_511630(...);
int sub_516170(...);
int sub_51A400(...);
void __cdecl todo_401800(void);

// 0x00441040
void CCBUI::SetTooltip(const char *szText)
{
  if ( szText )
    strncpy((char *)&this->m_pAttackSequenFace[4], szText, 0x7Fu);
  else
    memset(&this->m_pAttackSequenFace[4], 0, 0x80u);
}

// 0x00441070
void CCBUI::SetRect(RECT *pRect)
{
  this->m_pAttackSequenBack = (UIStatic *)pRect->left;
}

// 0x00441380
int CCBUI::ShowEffect(int nY, int nWidth, int nHeight)
{
  return sub_445FA0(&this->m_pAttackSequenBack);
}

// 0x004420B0

// ---- synthesized vtable stubs (unresolved slots) ----
// [VFTABLE-STUB] original: ((int ( *)(UIStatic **, int))this->m_pAttackSequenBack->__vftable)(&this->m_pAttackSequenBack, v2)
static int pal3_vtbl_unk_0(UIStatic **, int);

int CCBUI::VirtualCall()
{
  int v2; // [esp+0x4] [ebp+0x4]

  return pal3_vtbl_unk_0(&this->m_pAttackSequenBack, v2) /* [VFTABLE-STUB] */;
}

static int pal3_vtbl_unk_0(UIStatic **, int)
{
    return 0;
}


// 0x00442170
void CCBUI::SetTargetPos(gbVec3D *pPos, gbVec3D *pDir)
{
  float y; // ebx
  UIStatic *v4; // eax
  LONG left; // edx

  *(gbVec3D *)&this->m_pRoleStateDefenceInc[3] = *pPos;
  this->m_pRoleStateDefenceInc[6] = (UIStatic *)LODWORD(pPos[1].x);
  *(gbVec3D *)&this->m_pRoleStateDefenceInc[7] = *pDir;
  this->m_pRoleStateDefenceInc[10] = (UIStatic *)LODWORD(pDir[1].x);
  y = pDir->y;
  v4 = (UIStatic *)(LODWORD(pPos[1].x) - LODWORD(pPos->y));
  if ( (int)v4 <= LODWORD(pDir[1].x) - LODWORD(y) )
    v4 = (UIStatic *)(LODWORD(pDir[1].x) - LODWORD(y));
  left = this->m_rect.left;
  this->m_pRoleStatePanel[2] = v4;
  this->m_pRoleStateDefenceDec[0] = (UIStatic *)(LODWORD(pPos->x) - left);
}

// 0x004421F0
void CCBUI::SetCurPlayer(int nPlayer)
{
  this->m_pRoleStateDefenceDec[0] = (UIStatic *)nPlayer;
}

// 0x00442200
int CCBUI::SetRoleStatePointers(int nVal)
{
  int v2; // edx
  int result; // eax

  v2 = this->m_rect.top - (int)this->m_pRoleStateDefenceDec[3] / 2;
  this->m_pRoleStateDefenceDec[1] = (UIStatic *)nVal;
  result = v2 + nVal;
  this->m_pRoleStateFace[4] = (UIStatic *)(v2 + nVal);
  this->m_pRoleStateFace[3] = (UIStatic *)(v2 + nVal);
  return result;
}

// 0x00442230
int CCBUI::SetSelection(int nItemIndex)
{
  UIStatic *v2; // edx
  UIStatic *v3; // esi
  int result; // eax
  UIStatic *v5; // [esp+0xC] [ebp+0x8]

  v2 = (UIStatic *)this->m_pRoleStateDefenceInc[6];
  v3 = (UIStatic *)this->m_pRoleStateDefenceDec[1];
  this->m_pRoleStateDefenceDec[2] = (UIStatic *)nItemIndex;
  this->m_pRoleStateDefenceDec[3] = v5;
  result = (int)v3 + (_DWORD)v2 + (int)v5 / 2;
  this->m_pRoleStateFace[4] = (UIStatic *)result;
  this->m_pRoleStateFace[3] = (UIStatic *)result;
  return result;
}

// 0x00459F30
__int16 CCBUI::ForwardToPlayerMgr(_WORD *p_WORD)
{
  __int16 result; // ax

  (((SaleUI *)this[1].m_pRoleStateBlank[3]))->SaleUI::LoadState(p_WORD);
  (((PropUI *)this[1].m_pRoleStateBlank[4]))->PropUI::UpdateItemList(p_WORD);
  qmemcpy(&this[1].m_pRoleStateBlank[5][3].m_mouseoff, p_WORD, 0x4460u);
  result = p_WORD[1];
  LOWORD(this->m_pRoleStatePanel[3]) = result;
  return result;
}

// 0x00460A00
bool CCBUI::RollProbability(float fProb)
{
  int fProba; // [esp+0xC] [ebp+0x8]
  float fProbb; // [esp+0xC] [ebp+0x8]

  fProba = (__int64)(fProb * 100.0);
  if ( fProba <= 0 )
    return 0;
  fProbb = (double)fProba * 10.24;
  ++*(_DWORD *)&g_TempBuffer1024[912];
  g_nCombatRandSeed = 214013 * g_nCombatRandSeed + 2531011;
  return (((int)g_nCombatRandSeed >> 16) & 0x3FF) < (int)fProbb;
}

// 0x00469D00
int CCBUI::SetItemData(int nCol, int nRow, int nData, int nFlags)
{
  gbColorQuad *p_m_fontcolor; // eax
  LONG *p_top; // ecx
  unsigned int Color; // edx
  int result; // eax

  this->m_wndcolor.Color = nRow;
  p_m_fontcolor = (gbColorQuad *)&this->m_fontcolor;
  p_top = (LONG *)&this->m_rect.top;
  p_m_fontcolor->Color = nCol;
  *(p_top - 2) = nData;
  *(p_top - 1) = nFlags;
  *p_top = p_m_fontcolor->Color;
  p_top[1] = p_m_fontcolor[1].Color;
  Color = p_m_fontcolor[2].Color;
  result = p_m_fontcolor[3].Color;
  p_top[2] = Color;
  p_top[3] = result;
  return result;
}

// 0x00469D40
unsigned __int8 CCBUI::IsAddMode()
{
  return (unsigned __int8)this[1].m_pRoleStateBlank[9];
}

// 0x004AA9C0
void CCBUI::CreatePanelUI()
{
  int v2; // eax
  UIStatic *v3; // eax
  int v4; // esi
  UIStatic **v5; // edi
  unsigned int v6; // ecx
  int v7; // eax
  int v8; // esi
  int v9; // edi
  int v10; // ecx
  int v11; // eax
  int v12; // ecx
  int v13; // eax
  int v14; // eax
  int v15; // ecx
  int v16; // ecx
  int v17; // edx
  CScreenMode *Instance; // eax
  const void *v19; // [esp-0x10] [ebp-0x1E4]
  const CHAR *v20; // [esp-0x4] [ebp-0x1D8]
  CHAR v21[128]; // [esp+0x4] [ebp-0x1D0] BYREF
  char Buffer[253]; // [esp+0x84] [ebp-0x150] BYREF
  __int16 v23; // [esp+0x181] [ebp-0x53]
  char v24; // [esp+0x183] [ebp-0x51]
  CHAR String1[64]; // [esp+0x184] [ebp-0x50] BYREF
  float v26; // [esp+0x1C4] [ebp-0x10]
  unsigned int a2; // [esp+0x1C8] [ebp-0xC]
  int v28; // [esp+0x1CC] [ebp-0x8]
  float v29; // [esp+0x1D0] [ebp-0x4]

  if ( SLODWORD(this[8].m_Task[14].param.fEndX) > 0 )
  {
    switch ( g_nFiveNimbusCount )
    {
      case 0:
        lstrcpyA(String1, (LPCSTR)g_bSlotFlag);
        break;
      case 1:
        v20 = (const CHAR *)&g_bSlotFlag[256];
        goto LABEL_8;
      case 2:
        lstrcpyA(String1, byte_DC3F3C);
        break;
      case 3:
        lstrcpyA(String1, (LPCSTR)&g_bSlotFlag[512]);
        break;
      case 4:
        v20 = byte_DC403C;
LABEL_8:
        lstrcpyA(String1, v20);
        break;
      default:
        break;
    }
    v2 = dword_C10CC4;
    if ( dword_C10CC4 < 0 )
      v2 = 0;
    dword_C10CC4 = v2 + 1;
    if ( v2 + 1 >= 9 )
      dword_C10CC4 = 9;
    memset(this->m_pAttackSequenFace, 0, 0x100u);
    if ( *((_BYTE *)&g_nRoleParam + g_nFiveNimbusCount) || *((_BYTE *)&g_nRoleState + g_nFiveNimbusCount + 1) )
      *((_BYTE *)&g_nActorState + g_nFiveNimbusCount) = 1;
    lstrcpyA(v21, byte_DCF43C);
    v3 = (UIStatic *)this[8].m_pRoleStateForbid[0];
    v4 = 0;
    if ( (int)v3 > 0 )
    {
      v5 = (UIStatic **)&this->m_pRoleStateStable[1];
      v6 = (unsigned __int8)g_nActorState;
      a2 = (unsigned __int8)g_nActorState;
      while ( *(_QWORD *)(v5 - 1) != __PAIR64__(BYTE1(g_nActorState), v6)
           || *(_QWORD *)(v5 + 1) != __PAIR64__(BYTE2(g_nActorState), HIBYTE(g_nActorState))
           || v5[3] != (UIStatic *)(unsigned __int8)g_nActor_DE5F9C )
      {
        ++v4;
        v5 += 190;
        if ( v4 >= (int)v3 )
          goto LABEL_25;
        v6 = a2;
      }
      lstrcpyA(v21, (LPCSTR)&this->m_pRoleStateStable[190 * v4 + 5]);
    }
LABEL_25:
    v7 = (int)this->m_pRoleStateSpeedDec[3];
    v8 = 0;
    v9 = 0;
    a2 = 0;
    v26 = 0.0;
    if ( v7 > 0 )
    {
      v10 = (int)this->m_pRoleStateSpeedDec[2];
      if ( v10 > 0 )
        a2 = v7 / v10;
    }
    v11 = (int)this->m_pRoleStateSpeedDec[4];
    if ( v11 > 0 )
    {
      v12 = (int)this->m_pRoleStateSpeedDec[7];
      if ( v12 > 0 )
        v9 = v11 / v12;
    }
    v13 = (int)this->m_pRoleStateSpeedDec[6];
    if ( v13 > 0 )
    {
      v28 = (int)this->m_pRoleStateSpeedDec[8];
      if ( v28 > 0 )
        v26 = ((double)v28 * 0.0099999998 + 0.89999998) * (double)(v13 / v28) * 0.2;
    }
    v14 = (int)this->m_pRoleStateSpeedDec[5];
    if ( v14 > 0 )
    {
      v15 = (int)this->m_pRoleStateSpeedDec[7];
      if ( v15 > 0 )
        v8 = v14 / v15;
    }
    v16 = (int)this->m_pRoleStateSpeedDec[1];
    v28 = (int)this->m_pRoleStateSpeedDec[2] / 2;
    v17 = *(_DWORD *)&g_RoleSlotBuf.m_partyActor.m_curact[15] + v16 / 5 - v28;
    v28 = v17;
    if ( v17 > 0 )
    {
      if ( v17 > 20 )
        v28 = 20;
    }
    else
    {
      v28 = 1;
    }
    v29 = ((double)dword_C10CC4 * 0.02 + 1.0) * (double)(int)(a2 + v9 + v8 + (int)v26);
    a2 = (int)v29;
    v29 = _pal3_coerce_f32(sub_4A8230(a2, dword_C10CC4));
    memset(Buffer, 0, sizeof(Buffer));
    v23 = 0;
    v24 = 0;
    LOBYTE(this->m_pAttackSequenFace[0]) = 0;
    sprintf(Buffer, "      %s   %s", (const char *)&dword_DC933C, String1);
    while ( lstrlenA(Buffer) < 22 )
      lstrcatA(Buffer, " ");
    lstrcatA((LPSTR)this->m_pAttackSequenFace, Buffer);
    sprintf(Buffer, "%s %d", (const char *)&dword_DCE93C, v28);
    lstrcatA((LPSTR)this->m_pAttackSequenFace, Buffer);
    lstrcatA((LPSTR)this->m_pAttackSequenFace, aN);
    sprintf(Buffer, "      %s     %d", (const char *)&dword_DCFE3C, v29);
    lstrcatA((LPSTR)this->m_pAttackSequenFace, Buffer);
    lstrcatA((LPSTR)this->m_pAttackSequenFace, aN);
    sprintf(Buffer, "      %s %s", (const char *)&dword_DC923C, v21);
    lstrcatA((LPSTR)this->m_pAttackSequenFace, Buffer);
    SetEnable((UICaption *)&this[151].m_Task[11].param.fSpeed);
    (((UIRoleSelect *)&this[151].m_Task[5].fExpectEndTime))->UIRoleSelect::SetByte(1);
    v19 = (const void *)off_5CF1F0;
    Instance = (CScreenMode *)CScreenMode::GetInstance();
    (((CScreenMode *)Instance))->CScreenMode::AudioSetPosition(v19, 1);
  }
}

// 0x004AB2B0
void CCBUI::DestroyDynamic(int nVal)
{
  UIListBox *p_fEndX; // ebx
  int v4; // ebp
  int *v5; // edi
  int v6; // eax
  int v7; // esi
  int *v8; // ebp
  int *v9; // edi
  int *v10; // esi
  int v11; // edx
  int v12; // eax
  int v13; // ebp
  int v14; // eax
  char *m_pAttackSequenFace; // esi
  int v16; // edi
  char *v17; // [esp+0x10] [ebp-0x44]
  int v18; // [esp+0x14] [ebp-0x40] BYREF
  int *v19; // [esp+0x18] [ebp-0x3C]
  CCBUI *v20; // [esp+0x1C] [ebp-0x38]
  int v21; // [esp+0x20] [ebp-0x34]
  int v22; // [esp+0x24] [ebp-0x30]
  int SkillNum; // [esp+0x28] [ebp-0x2C]
  int v24; // [esp+0x2C] [ebp-0x28] BYREF
  int v25; // [esp+0x30] [ebp-0x24]
  int i; // [esp+0x34] [ebp-0x20]
  char v27; // [esp+0x38] [ebp-0x1C]
  void *Block; // [esp+0x3C] [ebp-0x18]
  int *p_DWORD2; // [esp+0x40] [ebp-0x14]
  int v30; // [esp+0x44] [ebp-0x10]
  int v31; // [esp+0x50] [ebp-0x4]
  unsigned int nVala; // [esp+0x58] [ebp+0x4]
v27 = nVal;
  Block = 0;
  p_DWORD2 = 0;
  v30 = 0;
  p_fEndX = (UIListBox *)&this[149].m_Task[3].param.fEndX;
  v31 = 0;
  v21 = 0xFFFF;
  v22 = 0;
  SkillNum = 0;
  v4 = 0;
  if ( (((UIListBox *)&this[149].m_Task[3].param.fEndX))->UIListBox::GetItemData() > 0 )
  {
    v5 = (int *)&this[8].m_pRoleStateForbid[8];
    do
    {
      v6 = (unsigned long)*v5;
      v22 = (unsigned long)v5[1];
      v21 = v6;
      SkillNum = (((PAL_GDB *)&g_pGDB))->PAL_GDB::GDB_GetSkillNum(v6);
      RoleSystem::CheckVisible();
      ++v4;
      v5 += 4;
    }
    while ( v4 < (((UIListBox *)p_fEndX))->UIListBox::GetItemData() );
  }
  v19 = (int *)p_DWORD2;
  if ( ((char *)p_DWORD2 - (_BYTE *)Block) / 12 > 16 )
  {
    v7 = nVal;
    (((ArcLocaleRole *)Block))->ArcLocaleRole::ParseLocaleData((char *)p_DWORD2, nVal);
    v8 = (int *)((char *)Block + 192);
    SortTripletsByField((int *)Block, (int *)Block + 48, nVal);
    if ( (char *)Block + 192 != (char *)v19 )
    {
      v9 = (int *)((char *)Block + 180);
      v17 = (char *)Block + 180;
      while ( 1 )
      {
        v18 = v7;
        v10 = (int *)v8;
        v24 = (unsigned long)*v8;
        v25 = (unsigned long)v8[1];
        for ( i = v8[2]; sub_4AB560(&v18, (int)&v24, (int)v9); v9 -= 3 )
        {
          *v10 = *v9;
          v10[1] = (unsigned long)v9[1];
          v10[2] = (unsigned long)v9[2];
          v10 = (int *)v9;
        }
        v11 = v25;
        v12 = i;
        *v10 = v24;
        v10[1] = v11;
        v10[2] = v12;
        v8 += 3;
        v17 += 12;
        if ( v8 == v19 )
          break;
        v9 = (int *)v17;
        v7 = nVal;
      }
    }
  }
  else
  {
    SortTripletsByField((int *)Block, p_DWORD2, nVal);
  }
  (((UIListBox *)p_fEndX))->UIListBox::ClearAll();
  nVala = 0;
  v13 = 0;
  while ( Block && nVala < ((char *)p_DWORD2 - (_BYTE *)Block) / 12 )
  {
    v21 = *(_DWORD *)((char *)Block + v13);
    v22 = *(_DWORD *)((char *)Block + v13 + 4);
    SkillNum = *(_DWORD *)((char *)Block + v13 + 8);
    v14 = (((UIListBox *)p_fEndX))->UIListBox::SetItemOffset((char *)(SkillNum + 4), 0);
    m_pAttackSequenFace = (char *)this->m_pAttackSequenFace;
    v16 = v14;
    sprintf((char *const)this->m_pAttackSequenFace, &dir[20], v22);
    (((UIListBox *)p_fEndX))->UIListBox::SetMouseMoveSel(1, v16, m_pAttackSequenFace, 0);
    sprintf(m_pAttackSequenFace, &dir[20], *(_DWORD *)(SkillNum + 624));
    (((UIListBox *)p_fEndX))->UIListBox::SetMouseMoveSel(2, v16, m_pAttackSequenFace, 0);
    sprintf(m_pAttackSequenFace, &dir[20], *(_DWORD *)(SkillNum + 608) / 2);
    (((UIListBox *)p_fEndX))->UIListBox::SetMouseMoveSel(3, v16, m_pAttackSequenFace, 0);
    v13 += 12;
    ++nVala;
  }
  operator delete(Block);
}

// 0x004DC220
char CCBUI::IsActive()
{
  /* [MISATTRIBUTED] CCBSystem on CCBUI::this -> fix IDB name of callee */ CCBSystem::ClearAllPointers((CCBSystem *)this);
  /* [MISATTRIBUTED] CCBRoleState on CCBUI::this -> fix IDB name of callee */ CCBRoleState::UpdatePanel((CCBRoleState *)this, 0);
  return 1;
}

// 0x004E04C0
int CCBUI::StepFrame()
{
  int result; // eax

  (((CCBSystem *)(*(void **)(this))))->CCBSystem::ProcAI(*(float *)&g_RoleSystemCombat.m_teamSlotOverlay.m_teamSlots[287]);
  if ( LOBYTE(this->__vftable[4]._sdtor_call_dtor) != *((_BYTE *)&g_RoleSystemCombat.m_teamSlotsB.combat.g_hCBStageCamDlg
                                                      + 4) )
    (((CCBSystem *)(*(void **)(this))))->CCBSystem::SetRenderFlag(*((char *)&g_RoleSystemCombat.m_teamSlotsB.combat.g_hCBStageCamDlg + 4));
  BYTE2(this->__vftable[4]._sdtor_call_dtor) = unk_5D87F0;
  if ( g_RoleSystemCombat.m_teamSlotsB.combat.m_bWPARAM )
  {
    (((CCBSystem *)(*(void **)(this))))->CCBSystem::GetRenderFlag();
    g_RoleSystemCombat.m_teamSlotsB.combat.m_bWPARAM = 0;
  }
  this->CCBUI::ResetAllSlots();
  this->CCBUI::UpdateDisplay();
  this->CCBUI::UpdateAnimation();
  LOBYTE(result) = this->CCBUI::UpdateState();
  return result;
}

// 0x004E0690
char CCBUI::ResetAllSlots()
{
  char result; // al
  int FullConfig; // eax
  char Buffer[128]; // [esp+0x8] [ebp-0x80] BYREF

  result = *(&g_RoleSystemCombat.m_teamSlotsB.combat.m_bWPARAM + 10);
  if ( *(&g_RoleSystemCombat.m_teamSlotsB.combat.m_bWPARAM + 10) )
  {
    CCBStageScene_Update();
    (*((CCBStageScene **)this->__vftable->_sdtor_call_dtor + 5))->CCBStageScene::ShowRoleIndex();
    result = (((CCBSystem *)(*(void **)(this))))->CCBSystem::CreateObj(&ppUI, 0, 0x40u);
    *(&g_RoleSystemCombat.m_teamSlotsB.combat.m_bWPARAM + 10) = 0;
  }
  if ( *(&g_RoleSystemCombat.m_teamSlotsB.combat.m_bWPARAM + 12) )
    *(&g_RoleSystemCombat.m_teamSlotsB.combat.m_bWPARAM + 12) = 0;
  if ( *(&g_RoleSystemCombat.m_teamSlotsB.combat.m_bWPARAM + 11) )
    *(&g_RoleSystemCombat.m_teamSlotsB.combat.m_bWPARAM + 11) = 0;
  if ( *(&g_RoleSystemCombat.m_teamSlotsB.combat.m_bWPARAM + 13) )
  {
    FullConfig = (*((CIniFile **)this->__vftable->_sdtor_call_dtor + 3))->CIniFile::LoadFullConfig();
    sprintf(Buffer, &unk_5D8848, FullConfig);
    result = (((CCBSystem *)(*(void **)(this))))->CCBSystem::CreateObj((CCBUI **)Buffer, 0, 0x40u);
    *(&g_RoleSystemCombat.m_teamSlotsB.combat.m_bWPARAM + 13) = 0;
  }
  return result;
}

// 0x004E0740
char CCBUI::UpdateDisplay()
{
  _BYTE *vftable; // eax
  int v3; // edi
  int i; // esi
  int ( *Create)(int, int); // ecx
  int v6; // edi
  int v7; // esi
  int ( *v8)(int, int); // ecx
  HWND DlgItem; // eax

  LOBYTE(vftable) = *((_BYTE *)&g_RoleSystemCombat.m_teamSlotsB.combat.g_hCBStageCamDlg + 5);
  if ( *((_BYTE *)&g_RoleSystemCombat.m_teamSlotsB.combat.g_hCBStageCamDlg + 5) )
  {
    v3 = 0;
    for ( i = 0; i < 4460; i += 892 )
    {
      vftable = (*(void **)(this));
      Create = this->__vftable->Create;
      if ( *((_BYTE *)Create + i + 577) )
      {
        vftable = (((CCBRoleState *)Create))->CCBRoleState::InitUI(v3);
        vftable[837] = 0;
      }
      ++v3;
    }
    *((_WORD *)&g_RoleSystemCombat.m_teamSlotsB.combat.g_hCBStageCamDlg + 2) = 0;
  }
  else
  {
    v6 = 0;
    v7 = 0;
    while ( 1 )
    {
      v8 = this->__vftable->Create;
      if ( *((_BYTE *)v8 + v7 + 577) )
      {
        vftable = (((CCBRoleState *)v8))->CCBRoleState::InitUI(v6);
        if ( !vftable[837] )
          break;
      }
      v7 += 892;
      ++v6;
      if ( v7 >= 4460 )
      {
        if ( !*((_BYTE *)&g_RoleSystemCombat.m_teamSlotsB.combat.g_hCBStageCamDlg + 4) )
        {
          *((_BYTE *)&g_RoleSystemCombat.m_teamSlotsB.combat.g_hCBStageCamDlg + 4) = 1;
          sprintf(&g_RoleSystemCombat.m_teamSlotOverlay.m_state.m_CCBStageCamBuffer, "%s", &unk_5D8884);
          DlgItem = GetDlgItem(hDlg, 1004);
          SendMessageA(DlgItem, 0xCu, 0, (LPARAM)&g_RoleSystemCombat.m_teamSlotOverlay.m_teamSlots[218]);
          LOBYTE(vftable) = (((CCBSystem *)(*(void **)(this))))->CCBSystem::ProcFlee(*((char *)&g_RoleSystemCombat.m_teamSlotsB.combat.g_hCBStageCamDlg + 4));
        }
        return (char)vftable;
      }
    }
  }
  return (char)vftable;
}

// 0x004E0820
char CCBUI::UpdateAnimation()
{
  char result; // al

  result = *(&g_RoleSystemCombat.m_teamSlotsB.combat.m_bWPARAM + 14);
  if ( *(&g_RoleSystemCombat.m_teamSlotsB.combat.m_bWPARAM + 14) )
  {
    *(&g_RoleSystemCombat.m_teamSlotsB.combat.m_bWPARAM + 14) = 0;
    (((CCBStage *)this))->CCBStage::InitUIByName() /* [ROWTABLE] */;
  }
  if ( *(&g_RoleSystemCombat.m_teamSlotsB.combat.m_bWPARAM + 15) )
  {
    *(&g_RoleSystemCombat.m_teamSlotsB.combat.m_bWPARAM + 15) = 0;
    result = /* [MISATTRIBUTED] CCBRoleState on CCBUI::this -> fix IDB name of callee */ CCBRoleState::SyncRoleUIData((CCBRoleState *)this);
  }
  if ( *(&g_RoleSystemCombat.m_teamSlotsB.combat.m_bWPARAM + 16) )
  {
    *(&g_RoleSystemCombat.m_teamSlotsB.combat.m_bWPARAM + 16) = 0;
    result = this->CCBUI::UpdateDebugStatus();
  }
  if ( *(&g_RoleSystemCombat.m_teamSlotsB.combat.m_bWPARAM + 18) )
  {
    *(&g_RoleSystemCombat.m_teamSlotsB.combat.m_bWPARAM + 18) = 0;
    this->CCBUI::InitUI_4E3D90();
  }
  if ( *(&g_RoleSystemCombat.m_teamSlotsB.combat.m_bWPARAM + 17) )
  {
    *(&g_RoleSystemCombat.m_teamSlotsB.combat.m_bWPARAM + 17) = 0;
    result = this->CCBUI::InitUI();
  }
  if ( *((_BYTE *)&g_RoleSystemCombat.m_teamSlotsB.combat.m_nCCBUIIdx + 4) )
  {
    *((_BYTE *)&g_RoleSystemCombat.m_teamSlotsB.combat.m_nCCBUIIdx + 4) = 0;
    result = /* [MISATTRIBUTED] CCBRoleState on CCBUI::this -> fix IDB name of callee */ CCBRoleState::UpdateDebugDialog((CCBRoleState *)this);
  }
  if ( *((_BYTE *)&g_RoleSystemCombat.m_teamSlotsB.combat.m_nCCBUIIdx + 5) )
  {
    *((_BYTE *)&g_RoleSystemCombat.m_teamSlotsB.combat.m_nCCBUIIdx + 5) = 0;
    result = /* [MISATTRIBUTED] CCBRoleState on CCBUI::this -> fix IDB name of callee */ CCBRoleState::ApplyDebugEdits((CCBRoleState *)this);
  }
  if ( g_RoleSystemCombat.m_teamSlotsB.combat.m_bCommandEdited )
  {
    g_RoleSystemCombat.m_teamSlotsB.combat.m_bCommandEdited = 0;
    result = this->CCBUI::PopulateCommandList();
  }
  if ( *(&g_RoleSystemCombat.m_teamSlotsB.combat.m_bCommandEdited + 2) )
  {
    *(&g_RoleSystemCombat.m_teamSlotsB.combat.m_bCommandEdited + 2) = 0;
    result = this->CCBUI::ShowCommandDetails();
  }
  if ( *(&g_RoleSystemCombat.m_teamSlotsB.combat.m_bCommandEdited + 1) )
  {
    *(&g_RoleSystemCombat.m_teamSlotsB.combat.m_bCommandEdited + 1) = 0;
    result = this->CCBUI::CloseCommandDialog();
  }
  if ( *(&g_RoleSystemCombat.m_teamSlotsB.combat.m_bCommandEdited + 4) )
  {
    *(&g_RoleSystemCombat.m_teamSlotsB.combat.m_bCommandEdited + 4) = 0;
    result = (unsigned __int8)/* [MISATTRIBUTED] PAL_GDB on CCBUI::this -> fix IDB name of callee */ PAL_GDB::SetupSkillConfig((PAL_GDB *)this);
  }
  if ( *(&g_RoleSystemCombat.m_teamSlotsB.combat.m_bCommandEdited + 3) )
  {
    *(&g_RoleSystemCombat.m_teamSlotsB.combat.m_bCommandEdited + 3) = 0;
    result = this->CCBUI::ApplyCommandEdit();
  }
  if ( *(&g_RoleSystemCombat.m_teamSlotsB.combat.m_bCommandEdited + 5) )
  {
    *(&g_RoleSystemCombat.m_teamSlotsB.combat.m_bCommandEdited + 5) = 0;
    result = this->CCBUI::ShowSkillDetails();
  }
  if ( *(&g_RoleSystemCombat.m_teamSlotsB.combat.m_bCommandEdited + 6) )
  {
    *(&g_RoleSystemCombat.m_teamSlotsB.combat.m_bCommandEdited + 6) = 0;
    result = CCBRoleState::GetTargetCommand();
  }
  if ( *(&g_RoleSystemCombat.m_teamSlotsB.combat.m_bCommandEdited + 7) )
  {
    *(&g_RoleSystemCombat.m_teamSlotsB.combat.m_bCommandEdited + 7) = 0;
    result = /* [MISATTRIBUTED] PAL_GDB on CCBUI::this -> fix IDB name of callee */ PAL_GDB::RefreshPartyDialog((PAL_GDB *)this);
  }
  if ( *(&g_RoleSystemCombat.m_teamSlotsB.combat.m_bCommandEdited + 8) )
  {
    *(&g_RoleSystemCombat.m_teamSlotsB.combat.m_bCommandEdited + 8) = 0;
    return /* [MISATTRIBUTED] PAL_GDB on CCBUI::this -> fix IDB name of callee */ PAL_GDB::PopulateAvailableRoles((PAL_GDB *)this);
  }
  return result;
}

// 0x004E0980
char CCBUI::UpdateState()
{
  char result; // al
  int v2; // esi
  HWND DlgItem; // edi

  result = g_RoleSystemCombat.m_teamSlotsB.combat.m_nCombatViewMode;
  v2 = *((_DWORD *)this->__vftable->_sdtor_call_dtor + 4);
  if ( g_RoleSystemCombat.m_teamSlotsB.combat.m_nCombatViewMode == 4 )
  {
    DlgItem = GetDlgItem(g_hMainWnd, 1201);
    result = *(_BYTE *)(v2 + 430012);
    if ( result )
    {
      unk_5D8808 = 1;
      sprintf(
        &g_RoleSystemCombat.m_teamSlotOverlay.m_state.m_CCBStageCamBuffer,
        "%03d-%03d",
        *(_DWORD *)(v2 + 430032),
        *(_DWORD *)(v2 + 430036));
      return SendMessageA(DlgItem, 0xCu, 0, (LPARAM)&g_RoleSystemCombat.m_teamSlotOverlay.m_teamSlots[218]);
    }
    else if ( unk_5D8808 == 1 )
    {
      unk_5D8808 = 0;
      sprintf(&g_RoleSystemCombat.m_teamSlotOverlay.m_state.m_CCBStageCamBuffer, "Stopped");
      return SendMessageA(DlgItem, 0xCu, 0, (LPARAM)&g_RoleSystemCombat.m_teamSlotOverlay.m_teamSlots[218]);
    }
  }
  return result;
}

// 0x004E0A60
int CCBUI::DlgProcEditorMain(CCBUI *a1, HWND hDlg, UINT uMsg, WORD wParam, LPARAM lParam)
{
  HWND DlgItem; // ebx
  HWND v7; // ebp
  HWND v8; // edi
  int result; // eax
  void (__stdcall *v10)(HWND, UINT, WPARAM, LPARAM); // esi
  double v11; // st7
  bool v12; // zf
  LPARAM v13; // [esp+0x4] [ebp-0x18]
  HWND hWnd; // [esp+0x18] [ebp-0x4]
  HWND hDlga; // [esp+0x24] [ebp+0x8]

  DlgItem = GetDlgItem(hDlg, 1001);
  v7 = GetDlgItem(hDlg, 1003);
  hDlga = GetDlgItem(hDlg, 1004);
  hWnd = GetDlgItem(hDlg, 1005);
  v8 = GetDlgItem(hDlg, 1010);
  if ( uMsg > 0x110 )
  {
    if ( uMsg == 273 )
    {
      if ( wParam > 0x3F1u )
      {
        switch ( wParam )
        {
          case 0x3F3u:
            if ( !g_RoleSystemCombat.m_teamSlotsB.combat.m_nCombatViewMode )
              return 0;
            (((CCBSystem *)a1->__vftable->Destroy))->CCBSystem::SetThreadFlag(1);
            if ( g_hMainWnd )
              DestroyWindow(g_hMainWnd);
            g_RoleSystemCombat.m_teamSlotsB.combat.m_nCombatViewMode = 0;
            g_hMainWnd = CreateDialogParamA(hInstance, (LPCSTR)0x69, (HWND)b, (DLGPROC)CCBUI::CloseDialog, 0);
            ShowWindow(g_hMainWnd, 4);
            result = 0;
            break;
          case 0x3F4u:
            g_RoleSystemCombat.m_teamSlotsB.combat.m_bWPARAM = 1;
            result = 0;
            break;
          case 0x3F5u:
            *(&g_RoleSystemCombat.m_teamSlotsB.combat.m_bWPARAM + 1) = *(&g_RoleSystemCombat.m_teamSlotsB.combat.m_bWPARAM
                                                                       + 1) == 0;
            return 0;
          case 0x3F6u:
            if ( g_RoleSystemCombat.m_teamSlotsB.combat.m_nCombatViewMode == 5 )
              return 0;
            (((CCBUI *)a1))->CCBUI::StartMagicThread();
            if ( g_hMainWnd )
              DestroyWindow(g_hMainWnd);
            g_RoleSystemCombat.m_teamSlotsB.combat.m_nCombatViewMode = 5;
            g_hMainWnd = CreateDialogParamA(hInstance, (LPCSTR)0x71, (HWND)b, (DLGPROC)CCBStageCam::StoreCurrentView, 0);
            ShowWindow(g_hMainWnd, 4);
            (((CCBStageCam *)a1))->CCBStageCam::sub_4E95A0(g_hMainWnd);
            result = 0;
            break;
          case 0x3F7u:
            g_RoleSystemCombat.m_teamSlotOverlay.m_teamSlots[287] = 0;
            v13 = 0;
            goto LABEL_25;
          case 0x3F8u:
            if ( g_RoleSystemCombat.m_teamSlotsB.combat.m_nCombatViewMode == 6 )
              return 0;
            (((CCBUI *)a1))->CCBUI::StartMagicThread();
            if ( g_hMainWnd )
              DestroyWindow(g_hMainWnd);
            g_RoleSystemCombat.m_teamSlotsB.combat.m_nCombatViewMode = 6;
            g_hMainWnd = CreateDialogParamA(hInstance, (LPCSTR)0x72, (HWND)b, CCBUI::_nearby_4eb230, 0);
            ShowWindow(g_hMainWnd, 4);
            (((CCBCamControl *)a1))->CCBCamControl::sub_4EB6F0(g_hMainWnd);
            result = 0;
            break;
          default:
            return 0;
        }
        return result;
      }
      if ( wParam == 1009 )
      {
        if ( g_RoleSystemCombat.m_teamSlotsB.combat.m_nCombatViewMode != 1 )
        {
          (((CCBUI *)a1))->CCBUI::StartMagicThread();
          if ( g_hMainWnd )
            DestroyWindow(g_hMainWnd);
          g_RoleSystemCombat.m_teamSlotsB.combat.m_nCombatViewMode = 1;
          g_hMainWnd = CreateDialogParamA(hInstance, (LPCSTR)0x68, (HWND)b, (DLGPROC)CCBUI::DlgProcEffect, 0);
          ShowWindow(g_hMainWnd, 4);
          return 0;
        }
      }
      else
      {
        if ( wParam <= 0x3ECu )
        {
          switch ( wParam )
          {
            case 0x3ECu:
              v12 = *((_BYTE *)&g_RoleSystemCombat.m_teamSlotsB.combat.g_hCBStageCamDlg + 4) != 0;
              *((_BYTE *)&g_RoleSystemCombat.m_teamSlotsB.combat.g_hCBStageCamDlg + 4) = *((_BYTE *)&g_RoleSystemCombat.m_teamSlotsB.combat.g_hCBStageCamDlg
                                                                                         + 4) == 0;
              if ( v12 )
              {
                *((_BYTE *)&g_RoleSystemCombat.m_teamSlotsB.combat.g_hCBStageCamDlg + 5) = 1;
                sprintf(&g_RoleSystemCombat.m_teamSlotOverlay.m_state.m_CCBStageCamBuffer, "%s", &unk_5D88E0);
              }
              else
              {
                sprintf(&g_RoleSystemCombat.m_teamSlotOverlay.m_state.m_CCBStageCamBuffer, "%s", &unk_5D8884);
              }
              SendMessageA(hDlga, 0xCu, 0, (LPARAM)&g_RoleSystemCombat.m_teamSlotOverlay.m_teamSlots[218]);
              return 0;
            case 1u:
              EndDialog(hDlg, 1);
              DestroyWindow((HWND)b);
              return 0;
            case 2u:
              return 1;
          }
          if ( wParam != 1003 )
            return 0;
          g_RoleSystemCombat.m_teamSlotOverlay.m_teamSlots[287] = 1065353216;
          v13 = (__int64)(1.0 * 100.0);
LABEL_25:
          v10 = (void ( *)(HWND, UINT, WPARAM, LPARAM))SendMessageA;
          SendMessageA(DlgItem, 0x405u, 1u, v13);
          v11 = *(float *)&g_RoleSystemCombat.m_teamSlotOverlay.m_teamSlots[287];
LABEL_16:
          sprintf((char *const)&g_RoleSystemCombat.m_teamSlotOverlay.m_state + 1128, "Speed%1.2f", v11);
          v10(v7, 0xCu, 0, (LPARAM)&g_RoleSystemCombat.m_teamSlotOverlay.m_teamSlots[282]);
          return 0;
        }
        if ( wParam == 1005 )
        {
          v12 = unk_5D87F0 != 0;
          unk_5D87F0 = unk_5D87F0 == 0;
          if ( v12 )
            sprintf(&g_RoleSystemCombat.m_teamSlotOverlay.m_state.m_CCBStageCamBuffer, "%s", &unk_5D88C8);
          else
            sprintf(&g_RoleSystemCombat.m_teamSlotOverlay.m_state.m_CCBStageCamBuffer, "%s", &unk_5D88D4);
          SendMessageA(hWnd, 0xCu, 0, (LPARAM)&g_RoleSystemCombat.m_teamSlotOverlay.m_teamSlots[218]);
          return 0;
        }
        if ( wParam == 1006 )
        {
          if ( g_RoleSystemCombat.m_teamSlotsB.combat.m_nCombatViewMode != 2 )
          {
            (((CCBSystem *)a1->__vftable->Destroy))->CCBSystem::SetThreadFlag(1);
            (((CCBUI *)a1->__vftable->Render))->CCBUI::CreateResultWindow(1);
            if ( g_hMainWnd )
              DestroyWindow(g_hMainWnd);
            g_RoleSystemCombat.m_teamSlotsB.combat.m_nCombatViewMode = 2;
            g_hMainWnd = CreateDialogParamA(hInstance, (LPCSTR)0x6A, (HWND)b, CCBUI::CombatDlgProcThunk, 0);
            ShowWindow(g_hMainWnd, 4);
            (((CCBRoleState *)a1))->CCBRoleState::UpdateDebugTreeView();
            return 0;
          }
        }
        else if ( wParam == 1007 && g_RoleSystemCombat.m_teamSlotsB.combat.m_nCombatViewMode != 4 )
        {
          (((CCBUI *)a1))->CCBUI::StartMagicThread();
          if ( g_hMainWnd )
            DestroyWindow(g_hMainWnd);
          g_RoleSystemCombat.m_teamSlotsB.combat.m_nCombatViewMode = 4;
          g_hMainWnd = CreateDialogParamA(hInstance, (LPCSTR)0x6E, (HWND)b, (DLGPROC)PAL_GDB::DlgProcCamera, 0);
          ShowWindow(g_hMainWnd, 4);
          *(&g_RoleSystemCombat.m_teamSlotsB.combat.m_bCommandEdited + 9) = 1;
          return 0;
        }
      }
    }
    else if ( uMsg == 276 )
    {
      v10 = (void ( *)(HWND, UINT, WPARAM, LPARAM))SendMessageA;
      v11 = (double)SendMessageA(DlgItem, 0x400u, 0, 0) / 100.0;
      *(float *)&g_RoleSystemCombat.m_teamSlotOverlay.m_teamSlots[287] = v11;
      goto LABEL_16;
    }
    return 0;
  }
  if ( uMsg != 272 )
  {
    if ( uMsg == 16 )
    {
      EndDialog(hDlg, wParam);
      DestroyWindow((HWND)b);
      return 1;
    }
    return 0;
  }
  SetWindowPos(hDlg, 0, 0, 600, 801, 130, 0x80u);
  SendMessageA(DlgItem, 0x407u, 0, 0);
  SendMessageA(DlgItem, 0x408u, 0, 2000);
  SendMessageA(DlgItem, 0x405u, 1u, (__int64)(*(float *)&g_RoleSystemCombat.m_teamSlotOverlay.m_teamSlots[287] * 100.0));
  sprintf(
    (char *const)&g_RoleSystemCombat.m_teamSlotOverlay.m_state + 1128,
    "Speed%1.2f",
    *(float *)&g_RoleSystemCombat.m_teamSlotOverlay.m_teamSlots[287]);
  SendMessageA(v7, 0xCu, 0, (LPARAM)&g_RoleSystemCombat.m_teamSlotOverlay.m_teamSlots[282]);
  if ( *((_BYTE *)&g_RoleSystemCombat.m_teamSlotsB.combat.g_hCBStageCamDlg + 4) )
    sprintf(&g_RoleSystemCombat.m_teamSlotOverlay.m_state.m_CCBStageCamBuffer, "%s", &unk_5D8884);
  else
    sprintf(&g_RoleSystemCombat.m_teamSlotOverlay.m_state.m_CCBStageCamBuffer, "%s", &unk_5D88E0);
  SendMessageA(hDlga, 0xCu, 0, (LPARAM)&g_RoleSystemCombat.m_teamSlotOverlay.m_teamSlots[218]);
  if ( unk_5D87F0 )
    sprintf(&g_RoleSystemCombat.m_teamSlotOverlay.m_state.m_CCBStageCamBuffer, "%s", &unk_5D88D4);
  else
    sprintf(&g_RoleSystemCombat.m_teamSlotOverlay.m_state.m_CCBStageCamBuffer, "%s", &unk_5D88C8);
  SendMessageA(hWnd, 0xCu, 0, (LPARAM)&g_RoleSystemCombat.m_teamSlotOverlay.m_teamSlots[218]);
  sprintf(
    &g_RoleSystemCombat.m_teamSlotOverlay.m_state.m_CCBStageCamBuffer,
    "%s Build %s %s Release",
    "PAL3 COMBAT SYSTEM 1.03",
    "Jan  5 2004",
    "16:42:29");
  SendMessageA(v8, 0xCu, 0, (LPARAM)&g_RoleSystemCombat.m_teamSlotOverlay.m_teamSlots[218]);
  return 0;
}

// 0x004E10E0
int CCBUI::CloseDialog(HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
  if ( uMsg == 16 )
  {
    EndDialog(hDlg, (unsigned __int16)wParam);
    return 1;
  }
  else
  {
    if ( uMsg == 272 )
    {
      SetWindowPos(hDlg, 0, 800, 0, 224, 730, 0x80u);
    }
    else if ( uMsg == 273 && (unsigned __int16)wParam == 1 )
    {
      EndDialog(hDlg, 1);
      return 0;
    }
    return 0;
  }
}

// 0x004E1160
int CCBUI::DlgProcEffect(HWND hDlg, UINT msg, WPARAM wParam, LPARAM lParam)
{
  return (((CEffectSystem *)g_RoleSystemCombat.m_teamSlotOverlay.m_teamSlots[217]))->CEffectSystem::CreateEffectChain((CCBUI *)g_RoleSystemCombat.m_teamSlotOverlay.m_teamSlots[217], hDlg, msg, wParam, lParam);
}

// 0x004E16F0
unsigned __int8 * CCBUI::PopulateSceneList(HWND hDlg)
{
  LPARAM v2; // esi
  HWND DlgItem; // ebp
  unsigned __int8 *result; // eax
  HANDLE FirstFileA; // eax
  HANDLE hFindFile; // [esp+0x10] [ebp-0x270]
  LPARAM lParam[10]; // [esp+0x14] [ebp-0x26C] BYREF
  CHAR Filename[260]; // [esp+0x3C] [ebp-0x244] BYREF
  _WIN32_FIND_DATAA FindFileData; // [esp+0x140] [ebp-0x140] BYREF

  v2 = 0;
  DlgItem = GetDlgItem(hDlg, 1203);
  memset(lParam, 0, sizeof(lParam));
  SendMessageA(DlgItem, 0x1009u, 0, 0);
  memset(Filename, 0, sizeof(Filename));
  GetModuleFileNameA(0, Filename, 0x104u);
  result = _mbsrchr((const unsigned __int8 *)Filename, 0x5Cu);
  if ( result )
  {
    _mbsrchr((const unsigned __int8 *)Filename, 0x5Cu)[1] = 0;
    lstrcatA(Filename, "basedata\\cbscene\\*.");
    FirstFileA = FindFirstFileA(Filename, &FindFileData);
    hFindFile = FirstFileA;
    if ( FirstFileA == (HANDLE)-1 )
    {
      return (unsigned __int8 *)MessageBoxA((HWND)b, &unk_5D88FC, 0, 0);
    }
    else
    {
      for ( result = (unsigned __int8 *)FindNextFileA(FirstFileA, &FindFileData);
            result;
            result = (unsigned __int8 *)FindNextFileA(hFindFile, &FindFileData) )
      {
        if ( !_mbsrchr((const unsigned __int8 *)FindFileData.cFileName, 0x2Eu) )
        {
          lParam[0] = 1;
          lParam[5] = (LPARAM)&g_RoleSystemCombat.m_teamSlotOverlay.m_teamSlots[218];
          lParam[1] = v2;
          lParam[2] = 0;
          sprintf(&g_RoleSystemCombat.m_teamSlotOverlay.m_state.m_CCBStageCamBuffer, "%03d", v2);
          SendMessageA(DlgItem, 0x1007u, 0, (LPARAM)lParam);
          lParam[5] = (LPARAM)FindFileData.cFileName;
          lParam[2] = 1;
          SendMessageA(DlgItem, 0x1006u, 0, (LPARAM)lParam);
          ++v2;
        }
      }
    }
  }
  return result;
}

// 0x004E1870
unsigned __int8 * CCBUI::LoadSceneByIndex(int nVal)
{
  unsigned __int8 *result; // eax
  HANDLE FirstFileA; // eax
  void *v5; // ebx
  int v6; // edi
  int v7; // [esp+0xC] [ebp-0x248]
  CHAR Filename[260]; // [esp+0x10] [ebp-0x244] BYREF
  struct _WIN32_FIND_DATAA FindFileData; // [esp+0x114] [ebp-0x140] BYREF

  memset(Filename, 0, sizeof(Filename));
  v7 = 0;
  GetModuleFileNameA(0, Filename, 0x104u);
  result = _mbsrchr((const unsigned __int8 *)Filename, 0x5Cu);
  if ( result )
  {
    _mbsrchr((const unsigned __int8 *)Filename, 0x5Cu)[1] = 0;
    lstrcatA(Filename, "basedata\\cbscene\\*.");
    FirstFileA = FindFirstFileA(Filename, &FindFileData);
    v5 = FirstFileA;
    if ( FirstFileA == (HANDLE)-1 )
    {
      return (unsigned __int8 *)MessageBoxA((HWND)b, &unk_5D88FC, 0, 0);
    }
    else
    {
      for ( result = (unsigned __int8 *)FindNextFileA(FirstFileA, &FindFileData);
            result;
            result = (unsigned __int8 *)FindNextFileA(v5, &FindFileData) )
      {
        if ( !_mbsrchr((const unsigned __int8 *)FindFileData.cFileName, 0x2Eu) )
        {
          if ( v7 == nVal )
          {
            v6 = *((_DWORD *)this->__vftable->_sdtor_call_dtor + 5);
            if ( strcmp(FindFileData.cFileName, (const char *)(v6 + 345)) )
            {
              sub_511630(v6);
              (*((CCBStageScene **)this->__vftable->_sdtor_call_dtor + 5))->CCBStageScene::LoadModel(FindFileData.cFileName);
              strcpy((char *)&((RoleSystem *)&stru_C10DF0)->m_teamSlotOverlay.m_state.m_nTodo_704 + 556, FindFileData.cFileName);
            }
          }
          ++v7;
        }
      }
    }
  }
  return result;
}

// 0x004E1A10
int CCBUI::CombatDlgProcThunk(HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
  return (((CCBRoleState *)g_RoleSystemCombat.m_teamSlotOverlay.m_teamSlots[217]))->CCBRoleState::CombatDialogProc(g_RoleSystemCombat.m_teamSlotOverlay.m_teamSlots[217], hDlg, uMsg, wParam, lParam);
}

// 0x004E1F70
int CCBUI::SettingsDialogProc(HWND hDlg, unsigned int dwVal, WPARAM pData, LPARAM a5)
{
  HWND v5; // eax
  HWND DlgItem; // eax
  HWND v7; // ebx
  HWND v8; // eax
  HWND v9; // ebx
  HWND v10; // eax
  HWND v11; // ebx
  HWND v12; // eax
  HWND v13; // ebx
  HWND v14; // eax
  HWND v15; // ebx
  HWND v16; // eax
  HWND v17; // ebx
  HWND v18; // eax
  HWND v19; // ebx
  HWND v20; // eax
  HWND v21; // ebx
  HWND v22; // eax
  HWND v23; // edi
  unsigned int v25; // [esp+0x8] [ebp-0x28]
  LPARAM lParam[2]; // [esp+0xC] [ebp-0x24] BYREF
  LPARAM v27[3]; // [esp+0x14] [ebp-0x1C] BYREF
  void *v28; // [esp+0x20] [ebp-0x10]
  int v29; // [esp+0x28] [ebp-0x8]
  int v30; // [esp+0x2C] [ebp-0x4]

  v5 = 0;
  v25 = 0;
  lParam[1] = 1;
  lParam[0] = 1;
  if ( dwVal > 0x110 )
  {
    if ( dwVal == 273 )
    {
      if ( (unsigned __int16)pData > 0x428u )
      {
        if ( (unsigned __int16)pData == 1065 )
        {
          unk_5D87F8 = 3;
          goto LABEL_32;
        }
        if ( (unsigned __int16)pData == 1066 )
        {
          unk_5D87F8 = 4;
          goto LABEL_32;
        }
      }
      else
      {
        switch ( (unsigned __int16)pData )
        {
          case 0x428u:
            unk_5D87F8 = 2;
            goto LABEL_32;
          case 1u:
            *(&g_RoleSystemCombat.m_teamSlotsB.combat.m_bWPARAM + 18) = 1;
            EndDialog(hDlg, 1);
            return 1;
          case 0x426u:
            unk_5D87F8 = 0;
            goto LABEL_32;
          case 0x427u:
            unk_5D87F8 = 1;
LABEL_32:
            *(_WORD *)(&g_RoleSystemCombat.m_teamSlotsB.combat.m_bWPARAM + 17) = 257;
            break;
        }
      }
    }
    return 0;
  }
  if ( dwVal != 272 )
  {
    if ( dwVal != 2 )
    {
      if ( dwVal != 78 || pData != 1114 || *(_DWORD *)(a5 + 8) != -551 )
        return 0;
      DlgItem = GetDlgItem(hDlg, 1114);
      g_RoleSystemCombat.m_teamSlotsB.combat.m_nCCBUISelectedRole = SendMessageA(DlgItem, 0x130Bu, 0, 0);
      goto LABEL_32;
    }
    return 1;
  }
  if ( ::g_EffMgr.roleIdx <= 4 )
    v25 = ::g_EffMgr.roleIdx;
  switch ( ::g_EffMgr.roleIdx )
  {
    case 0u:
      v5 = GetDlgItem(hDlg, 1062);
      break;
    case 1u:
      v5 = GetDlgItem(hDlg, 1063);
      break;
    case 2u:
      v5 = GetDlgItem(hDlg, 1064);
      break;
    case 3u:
      v5 = GetDlgItem(hDlg, 1065);
      break;
    case 4u:
      v5 = GetDlgItem(hDlg, 1066);
      break;
    default:
      break;
  }
  SendMessageA(v5, 0xF1u, 1u, 0);
  v7 = GetDlgItem(hDlg, 1087);
  v8 = GetDlgItem(hDlg, 1102);
  SendMessageA(v7, 0x469u, (WPARAM)v8, 0);
  SendMessageA(v7, 0x465u, 0, 65540);
  SendMessageA(v7, 0x46Du, 0xAu, 0);
  SendMessageA(v7, 0x46Bu, 1u, (LPARAM)lParam);
  v9 = GetDlgItem(hDlg, 1088);
  v10 = GetDlgItem(hDlg, 1103);
  SendMessageA(v9, 0x469u, (WPARAM)v10, 0);
  SendMessageA(v9, 0x465u, 0, 65540);
  SendMessageA(v9, 0x46Du, 0xAu, 0);
  SendMessageA(v9, 0x46Bu, 1u, (LPARAM)lParam);
  v11 = GetDlgItem(hDlg, 1089);
  v12 = GetDlgItem(hDlg, 1105);
  SendMessageA(v11, 0x469u, (WPARAM)v12, 0);
  SendMessageA(v11, 0x465u, 0, 65540);
  SendMessageA(v11, 0x46Du, 0xAu, 0);
  SendMessageA(v11, 0x46Bu, 1u, (LPARAM)lParam);
  v13 = GetDlgItem(hDlg, 1090);
  v14 = GetDlgItem(hDlg, 1106);
  SendMessageA(v13, 0x469u, (WPARAM)v14, 0);
  SendMessageA(v13, 0x465u, 0, 65540);
  SendMessageA(v13, 0x46Du, 0xAu, 0);
  SendMessageA(v13, 0x46Bu, 1u, (LPARAM)lParam);
  v15 = GetDlgItem(hDlg, 1091);
  v16 = GetDlgItem(hDlg, 1107);
  SendMessageA(v15, 0x469u, (WPARAM)v16, 0);
  SendMessageA(v15, 0x465u, 0, 65540);
  SendMessageA(v15, 0x46Du, 0xAu, 0);
  SendMessageA(v15, 0x46Bu, 1u, (LPARAM)lParam);
  v17 = GetDlgItem(hDlg, 1092);
  v18 = GetDlgItem(hDlg, 1109);
  SendMessageA(v17, 0x469u, (WPARAM)v18, 0);
  SendMessageA(v17, 0x465u, 0, 65540);
  SendMessageA(v17, 0x46Du, 0xAu, 0);
  SendMessageA(v17, 0x46Bu, 1u, (LPARAM)lParam);
  v19 = GetDlgItem(hDlg, 1093);
  v20 = GetDlgItem(hDlg, 1110);
  SendMessageA(v19, 0x469u, (WPARAM)v20, 0);
  SendMessageA(v19, 0x465u, 0, 65540);
  SendMessageA(v19, 0x46Du, 0xAu, 0);
  SendMessageA(v19, 0x46Bu, 1u, (LPARAM)lParam);
  v21 = GetDlgItem(hDlg, 1094);
  v22 = GetDlgItem(hDlg, 1112);
  SendMessageA(v21, 0x469u, (WPARAM)v22, 0);
  SendMessageA(v21, 0x465u, 0, 65540);
  SendMessageA(v21, 0x46Du, 0xAu, 0);
  SendMessageA(v21, 0x46Bu, 1u, (LPARAM)lParam);
  v23 = GetDlgItem(hDlg, 1114);
  SendMessageA(v23, 0x1331u, 0, 10);
  SendMessageA(v23, 0x1329u, 0, 1310730);
  v27[0] = 1;
  v29 = 0;
  v30 = 0;
  v28 = (void *)&unk_5D8964;
  SendMessageA(v23, 0x1307u, 0, (LPARAM)v27);
  v28 = (void *)&unk_5D8960;
  SendMessageA(v23, 0x1307u, 1u, (LPARAM)v27);
  v28 = (void *)&unk_5D895C;
  SendMessageA(v23, 0x1307u, 2u, (LPARAM)v27);
  v28 = (void *)&unk_5D8958;
  SendMessageA(v23, 0x1307u, 3u, (LPARAM)v27);
  v28 = (void *)&unk_5D8954;
  SendMessageA(v23, 0x1307u, 4u, (LPARAM)v27);
  v28 = (void *)&unk_5D8950;
  SendMessageA(v23, 0x1307u, 5u, (LPARAM)v27);
  unk_5D87F8 = v25;
  *(_WORD *)(&g_RoleSystemCombat.m_teamSlotsB.combat.m_bWPARAM + 17) = 1;
  return 1;
}

// 0x004E2430
int CCBUI::HandleWindowMessage(HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
  if ( uMsg == 272 )
  {
    *((_BYTE *)&g_RoleSystemCombat.m_teamSlotsB.combat.m_nCCBUIIdx + 4) = 1;
  }
  else if ( uMsg == 273 )
  {
    if ( (unsigned __int16)wParam == 1 )
    {
      EndDialog(g_RoleSystemCombat.m_teamSlotsB.combat.g_hCombatDlg1, 0);
      g_RoleSystemCombat.m_teamSlotsB.combat.g_hCombatDlg1 = 0;
      return 0;
    }
    if ( (unsigned __int16)wParam == 2 )
    {
      *((_BYTE *)&g_RoleSystemCombat.m_teamSlotsB.combat.m_nCCBUIIdx + 5) = 1;
      return 0;
    }
  }
  return 0;
}

// 0x004E2490
int CCBUI::DlgProcMain(HWND hDlg, UINT msg, WPARAM wParam, LPARAM lParam)
{
  return (((CCBUI *)g_RoleSystemCombat.m_teamSlotOverlay.m_teamSlots[217]))->CCBUI::CommandEditDialogProc((int *)g_RoleSystemCombat.m_teamSlotOverlay.m_teamSlots[217], hDlg, msg, wParam, lParam);
}

// 0x004E24C0
int CCBUI::CommandEditDialogProc(int *p_DWORD, HWND hDlg, int nVal, int nVal2, int nVal3)
{
  HWND DlgItem; // ebp
  HWND v7; // ebx
  HWND v8; // edi
  int v10; // edi
  int j; // esi
  int *v12; // eax
  int SlotCount; // edi
  int i; // esi
  int *TargetRole; // eax
  LRESULT v16; // eax
  LRESULT v17; // eax
  signed int SkillID; // ebp
  signed int v19; // edi
  int ItemID; // eax
  int SkillNum; // eax
  int v22; // [esp+0x10] [ebp-0x174] BYREF
  int v23; // [esp+0x14] [ebp-0x170]
  int v24; // [esp+0x18] [ebp-0x16C]
  LPARAM lParam[8]; // [esp+0x1C] [ebp-0x168] BYREF
  HWND v26; // [esp+0x3C] [ebp-0x148]
  HWND hWnd; // [esp+0x40] [ebp-0x144]
  LPARAM v28[10]; // [esp+0x44] [ebp-0x140] BYREF
  char pOut[12]; // [esp+0x6C] [ebp-0x118] BYREF
  char v30[12]; // [esp+0x78] [ebp-0x10C] BYREF
  char Buffer[256]; // [esp+0x84] [ebp-0x100] BYREF

  DlgItem = GetDlgItem(hDlg, 1142);
  v7 = GetDlgItem(hDlg, 1146);
  hWnd = GetDlgItem(hDlg, 1040);
  v26 = GetDlgItem(hDlg, 1149);
  v8 = GetDlgItem(hDlg, 1086);
  if ( nVal == 78 )
  {
    if ( nVal2 == 1142 )
    {
      if ( *(_DWORD *)(nVal3 + 8) == -2 && *(_DWORD *)(nVal3 + 12) != -1 )
      {
        unk_5D8800 = *(_DWORD *)(nVal3 + 12);
        *(&g_RoleSystemCombat.m_teamSlotsB.combat.m_bCommandEdited + 2) = 1;
        EnableWindow(hWnd, 1);
        EnableWindow(v26, 1);
        EnableWindow(v8, 1);
      }
    }
    else if ( nVal2 == 1146 && *(_DWORD *)(nVal3 + 8) == -3 && *(_DWORD *)(nVal3 + 12) != -1 )
    {
      index = *(_DWORD *)(nVal3 + 12);
      *(&g_RoleSystemCombat.m_teamSlotsB.combat.m_bCommandEdited + 4) = 1;
      return 0;
    }
    return 0;
  }
  if ( nVal != 272 )
  {
    if ( nVal == 273 )
    {
      if ( (unsigned __int16)nVal2 > 0x412u )
      {
        switch ( (unsigned __int16)nVal2 )
        {
          case 0x413u:
            v22 = 0xFFFF;
            v23 = 0;
            v24 = 0;
LABEL_25:
            SlotCount = (((Combat *)&((RoleSystem *)&stru_C059A0)->m_fAnimSpeed))->Combat::GetSlotCount();
            for ( i = 0; i < SlotCount; ++i )
            {
              TargetRole = (int *)(((CCBAI *)&((RoleSystem *)&stru_C059A0)->m_fAnimSpeed))->CCBAI::GetTargetRole(v30);
              v22 = (unsigned long)*TargetRole;
              v23 = (unsigned long)TargetRole[1];
              v24 = (unsigned long)TargetRole[2];
              if ( *(_BYTE *)(v24 + 612) == 1 )
              {
                (((CCBStage *)&((RoleSystem *)&stru_C059A0)->m_fAnimSpeed))->CCBStage::PassCmd(&v22);
                goto LABEL_25;
              }
            }
            goto LABEL_10;
          case 0x43Eu:
            *(&g_RoleSystemCombat.m_teamSlotsB.combat.m_bCommandEdited + 3) = 1;
            return 0;
          case 0x47Du:
            *(&g_RoleSystemCombat.m_teamSlotsB.combat.m_bCommandEdited + 5) = 1;
            return 0;
        }
      }
      else
      {
        switch ( (unsigned __int16)nVal2 )
        {
          case 0x412u:
            v22 = 0xFFFF;
            v23 = 0;
            v24 = 0;
LABEL_14:
            v10 = (((Combat *)&((RoleSystem *)&stru_C059A0)->m_fAnimSpeed))->Combat::GetSlotCount();
            for ( j = 0; j < v10; ++j )
            {
              v12 = (int *)(((CCBAI *)&((RoleSystem *)&stru_C059A0)->m_fAnimSpeed))->CCBAI::GetTargetRole(pOut);
              v22 = (unsigned long)*v12;
              v23 = (unsigned long)v12[1];
              v24 = (unsigned long)v12[2];
              if ( *(_BYTE *)(v24 + 612) == 2 )
              {
                (((CCBStage *)&((RoleSystem *)&stru_C059A0)->m_fAnimSpeed))->CCBStage::PassCmd(&v22);
                goto LABEL_14;
              }
            }
            goto LABEL_10;
          case 1u:
            *(&g_RoleSystemCombat.m_teamSlotsB.combat.m_bCommandEdited + 1) = 1;
            return 0;
          case 0x410u:
            *(&g_RoleSystemCombat.m_teamSlotsB.combat.m_bCommandEdited + 6) = 1;
            return 0;
          case 0x411u:
            (((CCBStage *)&((RoleSystem *)&stru_C059A0)->m_fAnimSpeed))->CCBStage::Reset();
LABEL_10:
            (((CCBUI *)p_DWORD))->CCBUI::PopulateCommandList();
            return 0;
        }
      }
    }
    return 0;
  }
  memset(lParam, 0, sizeof(lParam));
  g_RoleSystemCombat.m_teamSlotsB.combat.m_bCommandEdited = 1;
  v16 = SendMessageA(DlgItem, 0x1037u, 0, 0);
  LOBYTE(v16) = v16 | 0x21;
  SendMessageA(DlgItem, 0x1036u, 0, v16);
  v17 = SendMessageA(v7, 0x1037u, 0, 0);
  LOBYTE(v17) = v17 | 0x21;
  SendMessageA(v7, 0x1036u, 0, v17);
  lParam[0] = 7;
  lParam[1] = 0;
  lParam[2] = 120;
  lParam[3] = (LPARAM)"Name";
  SendMessageA(DlgItem, 0x101Bu, 0, (LPARAM)lParam);
  lParam[1] = 1;
  lParam[2] = 50;
  lParam[3] = (LPARAM)&g_pCombatUIData;
  SendMessageA(DlgItem, 0x101Bu, 1u, (LPARAM)lParam);
  lParam[2] = 50;
  lParam[3] = (LPARAM)&unk_5D8940;
  SendMessageA(DlgItem, 0x101Bu, 2u, (LPARAM)lParam);
  lParam[2] = 50;
  lParam[3] = (LPARAM)&unk_5D893C;
  SendMessageA(DlgItem, 0x101Bu, 3u, (LPARAM)lParam);
  lParam[2] = 50;
  lParam[3] = (LPARAM)&unk_5D8938;
  SendMessageA(DlgItem, 0x101Bu, 4u, (LPARAM)lParam);
  lParam[2] = 145;
  lParam[3] = (LPARAM)"Name";
  SendMessageA(v7, 0x101Bu, 0, (LPARAM)lParam);
  SkillID = (((PAL_GDB *)&g_pGDB))->PAL_GDB::GDB_GetSkillID();
  memset(v28, 0, sizeof(v28));
  v19 = 0;
  v28[0] = 1;
  v28[2] = 0;
  v28[5] = (LPARAM)Buffer;
  if ( SkillID <= 0 )
    return 0;
  do
  {
    ItemID = (((PAL_GDB *)&g_pGDB))->PAL_GDB::GetItemID(v19);
    SkillNum = (((PAL_GDB *)&g_pGDB))->PAL_GDB::GDB_GetSkillNum(ItemID);
    sprintf(Buffer, "%03d%s", v19, (const char *)(SkillNum + 4));
    v28[1] = v19;
    v28[2] = 0;
    SendMessageA(v7, 0x1007u, 0, (LPARAM)v28);
    ++v19;
  }
  while ( v19 < SkillID );
  return 0;
}

// 0x004E2AE0
LRESULT CCBUI::HandleRoleStateDialog(int nVal)
{
  LRESULT result; // eax
  HWND DlgItem; // ebx
  void *vftable; // edx
  tagRoleState *inited; // eax
  void *v7; // eax
  tagRoleState *v8; // eax
  void *v9; // ecx
  tagRoleState *v10; // eax
  LPARAM lParam[10]; // [esp+0xC] [ebp-A8h] BYREF
  char Buffer[128]; // [esp+0x34] [ebp-0x80] BYREF

  result = g_RoleSystemCombat.m_teamSlotsB.combat.m_nCombatViewMode;
  if ( g_RoleSystemCombat.m_teamSlotsB.combat.m_nCombatViewMode == 2 )
  {
    DlgItem = GetDlgItem(g_hMainWnd, 1000);
    result = g_RoleSystemCombat.m_teamSlotsB.combat.m_nCombatViewMode;
    if ( g_RoleSystemCombat.m_teamSlotsB.combat.m_nCombatViewMode == 2 )
    {
      vftable = (*(void **)(this));
      memset(lParam, 0, sizeof(lParam));
      lParam[0] = 1;
      lParam[1] = nVal;
      lParam[5] = (LPARAM)Buffer;
      lParam[2] = 2;
      inited = (((CCBRoleState *)vftable->Create))->CCBRoleState::InitUI(nVal);
      sprintf(Buffer, &dir[20], inited->nHP);
      SendMessageA(DlgItem, 0x1006u, 0, (LPARAM)lParam);
      v7 = (*(void **)(this));
      lParam[2] = 3;
      v8 = (((CCBRoleState *)v7->Create))->CCBRoleState::InitUI(nVal);
      sprintf(Buffer, &dir[20], v8->nGP);
      SendMessageA(DlgItem, 0x1006u, 0, (LPARAM)lParam);
      v9 = (*(void **)(this));
      lParam[2] = 4;
      v10 = (((CCBRoleState *)v9->Create))->CCBRoleState::InitUI(nVal);
      sprintf(Buffer, &dir[20], v10->nMP);
      return SendMessageA(DlgItem, 0x1006u, 0, (LPARAM)lParam);
    }
  }
  return result;
}

// 0x004E3780
char CCBUI::UpdateDebugStatus()
{
  HWND DlgItem; // ebp
  HWND v3; // edi
  char result; // al
  int v5; // edi
  int SlotState; // eax
  int v7; // eax
  int ActionTypeBySlot; // eax
  int v9; // eax
  int v10; // eax
  int RoleCount; // eax
  HWND hWnd; // [esp+0x10] [ebp-0x20]
  HWND v13; // [esp+0x14] [ebp-0x1C]
  HWND v14; // [esp+0x18] [ebp-0x18]
  HWND v15; // [esp+0x1C] [ebp-0x14]
  HWND v16; // [esp+0x20] [ebp-0x10]
  HWND v17; // [esp+0x24] [ebp-0xC]
  HWND v18; // [esp+0x28] [ebp-0x8]
  HWND v19; // [esp+0x2C] [ebp-0x4]

  GetDlgItem(g_hMainWnd, 1024);
  DlgItem = GetDlgItem(g_hMainWnd, 1026);
  hWnd = GetDlgItem(g_hMainWnd, 1032);
  v13 = GetDlgItem(g_hMainWnd, 1025);
  v14 = GetDlgItem(g_hMainWnd, 1033);
  v15 = GetDlgItem(g_hMainWnd, 1027);
  v16 = GetDlgItem(g_hMainWnd, 1034);
  v3 = GetDlgItem(g_hMainWnd, 1028);
  GetDlgItem(g_hMainWnd, 1029);
  v17 = GetDlgItem(g_hMainWnd, 1030);
  v18 = GetDlgItem(g_hMainWnd, 1031);
  GetDlgItem(g_hMainWnd, 1035);
  v19 = GetDlgItem(g_hMainWnd, 1036);
  result = g_EffMgr.roleIdx;
  if ( g_EffMgr.roleIdx <= 0xA )
  {
    result = *(_BYTE *)(this->m_fontcolor.Color + 892 * g_EffMgr.roleIdx + 577);
    if ( result )
    {
      SendMessageA(v3, 0xDu, 0x14u, (LPARAM)&g_RoleSystemCombat.m_teamSlotOverlay.m_teamSlots[218]);
      v5 = atoi(&g_RoleSystemCombat.m_teamSlotOverlay.m_state.m_CCBStageCamBuffer);
      SlotState = (((CCBRoleState *)this->m_fontcolor.Color))->CCBRoleState::GetSlotState(g_EffMgr.roleIdx, v5);
      sprintf(&g_RoleSystemCombat.m_teamSlotOverlay.m_state.m_CCBStageCamBuffer, &dir[20], SlotState);
      SendMessageA(DlgItem, 0xCu, 0, (LPARAM)&g_RoleSystemCombat.m_teamSlotOverlay.m_teamSlots[218]);
      SendMessageA(hWnd, 0xCu, 0, (LPARAM)&g_RoleSystemCombat.m_teamSlotOverlay.m_teamSlots[218]);
      v7 = (((CCBRoleState *)this->m_fontcolor.Color))->CCBRoleState::CalcSpeedByLevel(g_EffMgr.roleIdx, v5);
      sprintf(&g_RoleSystemCombat.m_teamSlotOverlay.m_state.m_CCBStageCamBuffer, &dir[20], v7);
      SendMessageA(v13, 0xCu, 0, (LPARAM)&g_RoleSystemCombat.m_teamSlotOverlay.m_teamSlots[218]);
      SendMessageA(v14, 0xCu, 0, (LPARAM)&g_RoleSystemCombat.m_teamSlotOverlay.m_teamSlots[218]);
      ActionTypeBySlot = (((CCBRoleState *)this->m_fontcolor.Color))->CCBRoleState::GetActionTypeBySlot(g_EffMgr.roleIdx, v5);
      sprintf(&g_RoleSystemCombat.m_teamSlotOverlay.m_state.m_CCBStageCamBuffer, &dir[20], ActionTypeBySlot);
      SendMessageA(v15, 0xCu, 0, (LPARAM)&g_RoleSystemCombat.m_teamSlotOverlay.m_teamSlots[218]);
      SendMessageA(v16, 0xCu, 0, (LPARAM)&g_RoleSystemCombat.m_teamSlotOverlay.m_teamSlots[218]);
      v9 = (((CCBRoleState *)this->m_fontcolor.Color))->CCBRoleState::CalcDefenseByLevel(g_EffMgr.roleIdx, v5);
      sprintf(&g_RoleSystemCombat.m_teamSlotOverlay.m_state.m_CCBStageCamBuffer, &dir[20], v9);
      SendMessageA(v17, 0xCu, 0, (LPARAM)&g_RoleSystemCombat.m_teamSlotOverlay.m_teamSlots[218]);
      v10 = (((CCBRoleState *)this->m_fontcolor.Color))->CCBRoleState::CalcDamage(g_EffMgr.roleIdx, v5);
      sprintf(&g_RoleSystemCombat.m_teamSlotOverlay.m_state.m_CCBStageCamBuffer, &dir[20], v10);
      SendMessageA(v18, 0xCu, 0, (LPARAM)&g_RoleSystemCombat.m_teamSlotOverlay.m_teamSlots[218]);
      RoleCount = (((CCBRoleState *)this->m_fontcolor.Color))->CCBRoleState::GetRoleCount(v5);
      sprintf(&g_RoleSystemCombat.m_teamSlotOverlay.m_state.m_CCBStageCamBuffer, &dir[20], RoleCount);
      return SendMessageA(v19, 0xCu, 0, (LPARAM)&g_RoleSystemCombat.m_teamSlotOverlay.m_teamSlots[218]);
    }
  }
  return result;
}

// 0x004E3A20
LRESULT CCBUI::InitUI()
{
  HWND v1; // ebp
  HWND DlgItem; // edi
  int v3; // ebx
  char v4; // bl
  int RoleNum; // eax
  HWND v6; // eax
  void (__stdcall *v7)(HWND, UINT, WPARAM, LPARAM); // ebx
  int j; // ebp
  int v9; // edi
  char v10; // bl
  char *v11; // edi
  HWND v12; // eax
  LRESULT result; // eax
  int v14; // [esp-0x4] [ebp-0x2C]
  int v15; // [esp-0x4] [ebp-0x2C]
  char v16; // [esp+0x13] [ebp-0x15]
  HWND hWnd; // [esp+0x14] [ebp-0x14]
  int i; // [esp+0x18] [ebp-0x10]
  char *lParam; // [esp+0x20] [ebp-0x8]
  int v21; // [esp+0x24] [ebp-0x4]

  v1 = 0;
  DlgItem = 0;
  hWnd = 0;
  unk_5D87FC = unk_5D87F8;
  g_RoleSystemCombat.m_teamSlotsB.combat.m_nCCBUIIdx = g_RoleSystemCombat.m_teamSlotsB.combat.m_nCCBUISelectedRole;
  for ( i = 0; i < 8; ++i )
  {
    v3 = (((CCBRoleState *)this->m_fontcolor.Color))->CCBRoleState::InitUI(unk_5D87F8)->dwSkillID[8
                                                                                            * g_RoleSystemCombat.m_teamSlotsB.combat.m_nCCBUISelectedRole
                                                                                            + 7
                                                                                            + i];
    v16 = *((_BYTE *)&(((CCBRoleState *)this->m_fontcolor.Color))->CCBRoleState::InitUI(unk_5D87F8)->dwMagicID[7][2 * g_RoleSystemCombat.m_teamSlotsB.combat.m_nCCBUISelectedRole + 1]
          + i);
    v21 = (unsigned __int8)(((CCBRoleState *)this->m_fontcolor.Color))->CCBRoleState::InitUI(unk_5D87F8)->bMagicMastered[8][8 * g_RoleSystemCombat.m_teamSlotsB.combat.m_nCCBUISelectedRole + 4 + i]
        + 1;
    if ( v3 )
    {
      RoleNum = (((PAL_GDB *)&g_pGDB))->PAL_GDB::GDB_GetRoleNum(v3);
      v4 = v16;
      lParam = (char *)(RoleNum + 28);
    }
    else
    {
      lParam = (char *)&unk_5D89B0;
      v4 = 0;
      v21 = 0;
    }
    switch ( i )
    {
      case 0:
        DlgItem = GetDlgItem(g_RoleSystemCombat.m_teamSlotsB.combat.dwInitParam, 1052);
        v6 = GetDlgItem(g_RoleSystemCombat.m_teamSlotsB.combat.dwInitParam, 1102);
        goto LABEL_15;
      case 1:
        DlgItem = GetDlgItem(g_RoleSystemCombat.m_teamSlotsB.combat.dwInitParam, 1054);
        v14 = 1103;
        goto LABEL_14;
      case 2:
        DlgItem = GetDlgItem(g_RoleSystemCombat.m_teamSlotsB.combat.dwInitParam, 1055);
        v6 = GetDlgItem(g_RoleSystemCombat.m_teamSlotsB.combat.dwInitParam, 1105);
        goto LABEL_15;
      case 3:
        DlgItem = GetDlgItem(g_RoleSystemCombat.m_teamSlotsB.combat.dwInitParam, 1056);
        v6 = GetDlgItem(g_RoleSystemCombat.m_teamSlotsB.combat.dwInitParam, 1106);
        goto LABEL_15;
      case 4:
        DlgItem = GetDlgItem(g_RoleSystemCombat.m_teamSlotsB.combat.dwInitParam, 1057);
        v14 = 1107;
        goto LABEL_14;
      case 5:
        DlgItem = GetDlgItem(g_RoleSystemCombat.m_teamSlotsB.combat.dwInitParam, 1058);
        v6 = GetDlgItem(g_RoleSystemCombat.m_teamSlotsB.combat.dwInitParam, 1109);
        goto LABEL_15;
      case 6:
        DlgItem = GetDlgItem(g_RoleSystemCombat.m_teamSlotsB.combat.dwInitParam, 1060);
        v6 = GetDlgItem(g_RoleSystemCombat.m_teamSlotsB.combat.dwInitParam, 1110);
        goto LABEL_15;
      case 7:
        DlgItem = GetDlgItem(g_RoleSystemCombat.m_teamSlotsB.combat.dwInitParam, 1061);
        v14 = 1112;
LABEL_14:
        v6 = GetDlgItem(g_RoleSystemCombat.m_teamSlotsB.combat.dwInitParam, v14);
LABEL_15:
        v1 = v6;
        break;
      default:
        break;
    }
    if ( v4 )
    {
      v7 = (void ( *)(HWND, UINT, WPARAM, LPARAM))SendMessageA;
      SendMessageA(DlgItem, 0xF1u, 1u, 0);
    }
    else
    {
      SendMessageA(DlgItem, 0xF1u, 0, 0);
      v7 = (void ( *)(HWND, UINT, WPARAM, LPARAM))SendMessageA;
    }
    v7(DlgItem, 0xCu, 0, (LPARAM)lParam);
    sprintf(&g_RoleSystemCombat.m_teamSlotOverlay.m_state.m_CCBStageCamBuffer, &dir[20], v21);
    v7(v1, 0xCu, 0, (LPARAM)&g_RoleSystemCombat.m_teamSlotOverlay.m_teamSlots[218]);
  }
  for ( j = 0; j < 6; ++j )
  {
    v9 = *(&(((CCBRoleState *)this->m_fontcolor.Color))->CCBRoleState::InitUI(unk_5D87F8)->nCombatEXP + j);
    v10 = *((_BYTE *)&(((CCBRoleState *)this->m_fontcolor.Color))->CCBRoleState::InitUI(unk_5D87F8)->dwSkillID[5] + j);
    if ( v9 )
    {
      v11 = (char *)((((PAL_GDB *)&g_pGDB))->PAL_GDB::GDB_GetRoleNum(v9) + 28);
    }
    else
    {
      v11 = (char *)&unk_5D89B0;
      v10 = 0;
    }
    switch ( j )
    {
      case 0:
        v12 = GetDlgItem(g_RoleSystemCombat.m_teamSlotsB.combat.dwInitParam, 1075);
        goto LABEL_32;
      case 1:
        v12 = GetDlgItem(g_RoleSystemCombat.m_teamSlotsB.combat.dwInitParam, 1047);
        goto LABEL_32;
      case 2:
        v15 = 1048;
        goto LABEL_31;
      case 3:
        v12 = GetDlgItem(g_RoleSystemCombat.m_teamSlotsB.combat.dwInitParam, 1049);
        goto LABEL_32;
      case 4:
        v12 = GetDlgItem(g_RoleSystemCombat.m_teamSlotsB.combat.dwInitParam, 1050);
        goto LABEL_32;
      case 5:
        v15 = 1051;
LABEL_31:
        v12 = GetDlgItem(g_RoleSystemCombat.m_teamSlotsB.combat.dwInitParam, v15);
LABEL_32:
        hWnd = v12;
        break;
      default:
        break;
    }
    SendMessageA(hWnd, 0xCu, 0, (LPARAM)v11);
    if ( v10 )
      result = SendMessageA(hWnd, 0xF1u, 1u, 0);
    else
      result = SendMessageA(hWnd, 0xF1u, 0, 0);
  }
  return result;
}

// 0x004E3D90
void CCBUI::InitUI_4E3D90()
{
  CCBUI *v1; // ebx
  HWND DlgItem; // edi
  HWND v3; // ebp
  HWND v4; // eax
  bool v5; // bl
  char v6; // bl
  int j; // edi
  int v8; // ebp
  HWND v9; // eax
  int v10; // [esp-0x4] [ebp-0x28]
  int v11; // [esp-0x4] [ebp-0x28]
  bool v12; // [esp+0x13] [ebp-0x11]
  HWND hWnd; // [esp+0x14] [ebp-0x10]
  int i; // [esp+0x18] [ebp-0xC]
  unsigned int nVal; // [esp+0x20] [ebp-0x4]
DlgItem = 0;
  v3 = 0;
  hWnd = 0;
  for ( i = 0; i < 8; ++i )
  {
    nVal = (((CCBRoleState *)this->m_fontcolor.Color))->CCBRoleState::InitUI(unk_5D87FC)->dwSkillID[8
                                                                                            * g_RoleSystemCombat.m_teamSlotsB.combat.m_nCCBUIIdx
                                                                                            + 7
                                                                                            + i];
    (((CCBRoleState *)this->m_fontcolor.Color))->CCBRoleState::InitUI(unk_5D87FC);
    (((CCBRoleState *)this->m_fontcolor.Color))->CCBRoleState::InitUI(unk_5D87FC);
    if ( nVal )
    {
      (((PAL_GDB *)&g_pGDB))->PAL_GDB::GDB_GetRoleNum(nVal);
      switch ( i )
      {
        case 0:
          DlgItem = GetDlgItem(g_RoleSystemCombat.m_teamSlotsB.combat.dwInitParam, 1052);
          v4 = GetDlgItem(g_RoleSystemCombat.m_teamSlotsB.combat.dwInitParam, 1102);
          goto LABEL_13;
        case 1:
          DlgItem = GetDlgItem(g_RoleSystemCombat.m_teamSlotsB.combat.dwInitParam, 1054);
          v10 = 1103;
          goto LABEL_12;
        case 2:
          DlgItem = GetDlgItem(g_RoleSystemCombat.m_teamSlotsB.combat.dwInitParam, 1055);
          v4 = GetDlgItem(g_RoleSystemCombat.m_teamSlotsB.combat.dwInitParam, 1105);
          goto LABEL_13;
        case 3:
          DlgItem = GetDlgItem(g_RoleSystemCombat.m_teamSlotsB.combat.dwInitParam, 1056);
          v4 = GetDlgItem(g_RoleSystemCombat.m_teamSlotsB.combat.dwInitParam, 1106);
          goto LABEL_13;
        case 4:
          DlgItem = GetDlgItem(g_RoleSystemCombat.m_teamSlotsB.combat.dwInitParam, 1057);
          v10 = 1107;
          goto LABEL_12;
        case 5:
          DlgItem = GetDlgItem(g_RoleSystemCombat.m_teamSlotsB.combat.dwInitParam, 1058);
          v4 = GetDlgItem(g_RoleSystemCombat.m_teamSlotsB.combat.dwInitParam, 1109);
          goto LABEL_13;
        case 6:
          DlgItem = GetDlgItem(g_RoleSystemCombat.m_teamSlotsB.combat.dwInitParam, 1060);
          v4 = GetDlgItem(g_RoleSystemCombat.m_teamSlotsB.combat.dwInitParam, 1110);
          goto LABEL_13;
        case 7:
          DlgItem = GetDlgItem(g_RoleSystemCombat.m_teamSlotsB.combat.dwInitParam, 1061);
          v10 = 1112;
LABEL_12:
          v4 = GetDlgItem(g_RoleSystemCombat.m_teamSlotsB.combat.dwInitParam, v10);
LABEL_13:
          v3 = v4;
          break;
        default:
          break;
      }
      v5 = SendMessageA(DlgItem, 0xF0u, 0, 0) == 1;
      *((_BYTE *)&(((CCBRoleState *)this->m_fontcolor.Color))->CCBRoleState::InitUI(unk_5D87FC)->dwMagicID[7][2 * g_RoleSystemCombat.m_teamSlotsB.combat.m_nCCBUIIdx + 1]
      + i) = v5;
      SendMessageA(v3, 0xDu, 2u, (LPARAM)&g_RoleSystemCombat.m_teamSlotOverlay.m_teamSlots[218]);
      v6 = atoi(&g_RoleSystemCombat.m_teamSlotOverlay.m_state.m_CCBStageCamBuffer) - 1;
      (((CCBRoleState *)this->m_fontcolor.Color))->CCBRoleState::InitUI(unk_5D87FC)->bMagicMastered[8][8
                                                                                                 * g_RoleSystemCombat.m_teamSlotsB.combat.m_nCCBUIIdx
                                                                                                 + 4
                                                                                                 + i] = v6;
}
  }
  for ( j = 0; j < 6; ++j )
  {
    v8 = *(&(((CCBRoleState *)this->m_fontcolor.Color))->CCBRoleState::InitUI(unk_5D87FC)->nCombatEXP + j);
    (((CCBRoleState *)this->m_fontcolor.Color))->CCBRoleState::InitUI(unk_5D87FC);
    if ( v8 )
    {
      switch ( j )
      {
        case 0:
          v9 = GetDlgItem(g_RoleSystemCombat.m_teamSlotsB.combat.dwInitParam, 1075);
          goto LABEL_26;
        case 1:
          v9 = GetDlgItem(g_RoleSystemCombat.m_teamSlotsB.combat.dwInitParam, 1047);
          goto LABEL_26;
        case 2:
          v11 = 1048;
          goto LABEL_25;
        case 3:
          v9 = GetDlgItem(g_RoleSystemCombat.m_teamSlotsB.combat.dwInitParam, 1049);
          goto LABEL_26;
        case 4:
          v9 = GetDlgItem(g_RoleSystemCombat.m_teamSlotsB.combat.dwInitParam, 1050);
          goto LABEL_26;
        case 5:
          v11 = 1051;
LABEL_25:
          v9 = GetDlgItem(g_RoleSystemCombat.m_teamSlotsB.combat.dwInitParam, v11);
LABEL_26:
          hWnd = v9;
          break;
        default:
          break;
      }
      v12 = SendMessageA(hWnd, 0xF0u, 0, 0) == 1;
      *((_BYTE *)&(((CCBRoleState *)this->m_fontcolor.Color))->CCBRoleState::InitUI(unk_5D87FC)->dwSkillID[5] + j) = v12;
    }
  }
}

// 0x004E4A80
LRESULT CCBUI::PopulateCommandList()
{
  HWND DlgItem; // ebx
  LPARAM v2; // ebp
  int *TargetRole; // eax
  int v4; // edi
  int SkillNum; // eax
  int ItemPrice; // eax
  int ItemWeight; // eax
  int ItemData; // eax
  int v10; // [esp-0x4] [ebp-0x17C]
  int SlotCount; // [esp+0x14] [ebp-0x164]
  HWND v13; // [esp+0x18] [ebp-0x160]
  HWND v14; // [esp+0x1C] [ebp-0x15C]
  HWND v15; // [esp+0x20] [ebp-0x158]
  HWND v16; // [esp+0x24] [ebp-0x154]
  HWND v17; // [esp+0x28] [ebp-0x150]
  HWND v18; // [esp+0x2C] [ebp-0x14C]
  HWND hWnd; // [esp+0x30] [ebp-0x148]
  HWND v20; // [esp+0x34] [ebp-0x144]
  LPARAM lParam[11]; // [esp+0x38] [ebp-0x140] BYREF
  int v22; // [esp+0x64] [ebp-0x114]
  int v23; // [esp+0x68] [ebp-0x110]
  char pOut[12]; // [esp+0x6C] [ebp-0x10C] BYREF
  char Buffer[256]; // [esp+0x78] [ebp-0x100] BYREF

  DlgItem = GetDlgItem(g_RoleSystemCombat.m_teamSlotsB.combat.g_hCombatDlg2, 1142);
  GetDlgItem(g_RoleSystemCombat.m_teamSlotsB.combat.g_hCombatDlg2, 1146);
  hWnd = GetDlgItem(g_RoleSystemCombat.m_teamSlotsB.combat.g_hCombatDlg2, 1040);
  v15 = GetDlgItem(g_RoleSystemCombat.m_teamSlotsB.combat.g_hCombatDlg2, 1149);
  v18 = GetDlgItem(g_RoleSystemCombat.m_teamSlotsB.combat.g_hCombatDlg2, 1086);
  v17 = GetDlgItem(g_RoleSystemCombat.m_teamSlotsB.combat.g_hCombatDlg2, 1145);
  v13 = GetDlgItem(g_RoleSystemCombat.m_teamSlotsB.combat.g_hCombatDlg2, 1143);
  v20 = GetDlgItem(g_RoleSystemCombat.m_teamSlotsB.combat.g_hCombatDlg2, 1144);
  v14 = GetDlgItem(g_RoleSystemCombat.m_teamSlotsB.combat.g_hCombatDlg2, 1147);
  v16 = GetDlgItem(g_RoleSystemCombat.m_teamSlotsB.combat.g_hCombatDlg2, 1148);
  SlotCount = (((Combat *)&((RoleSystem *)&stru_C059A0)->m_fAnimSpeed))->Combat::GetSlotCount();
  (((PAL_GDB *)&g_pGDB))->PAL_GDB::GDB_GetSkillID();
  v2 = 0;
  memset(lParam, 0, 0x28u);
  SendMessageA(DlgItem, 0x1009u, 0, 0);
  lParam[0] = 1;
  lParam[2] = 0;
  lParam[5] = (LPARAM)Buffer;
  if ( SlotCount > 0 )
  {
    do
    {
      TargetRole = (int *)(((CCBAI *)&((RoleSystem *)&stru_C059A0)->m_fAnimSpeed))->CCBAI::GetTargetRole(pOut);
      v4 = (unsigned long)*TargetRole;
      v10 = (unsigned long)*TargetRole;
      v22 = (unsigned long)TargetRole[1];
      v23 = (unsigned long)TargetRole[2];
      SkillNum = (((PAL_GDB *)&g_pGDB))->PAL_GDB::GDB_GetSkillNum(v10);
      sprintf(Buffer, "%s", SkillNum + 4);
      lParam[1] = v2;
      lParam[2] = 0;
      SendMessageA(DlgItem, 0x1007u, 0, (LPARAM)lParam);
      lParam[2] = 1;
      sprintf(Buffer, &dir[20], v22);
      SendMessageA(DlgItem, 0x1006u, 0, (LPARAM)lParam);
      lParam[2] = 2;
      ItemPrice = /* [MISATTRIBUTED] PAL_GDB on CCBUI::this -> fix IDB name of callee */ PAL_GDB::GetItemPrice((PAL_GDB *)this, v4);
      sprintf(Buffer, &dir[20], ItemPrice);
      SendMessageA(DlgItem, 0x1006u, 0, (LPARAM)lParam);
      lParam[2] = 3;
      ItemWeight = /* [MISATTRIBUTED] PAL_GDB on CCBUI::this -> fix IDB name of callee */ PAL_GDB::GetItemWeight((PAL_GDB *)this, v4);
      sprintf(Buffer, &dir[20], ItemWeight);
      SendMessageA(DlgItem, 0x1006u, 0, (LPARAM)lParam);
      lParam[2] = 4;
      ItemData = /* [MISATTRIBUTED] PAL_GDB on CCBUI::this -> fix IDB name of callee */ PAL_GDB::GetItemData((PAL_GDB *)this, v4);
      sprintf(Buffer, &dir[20], ItemData);
      SendMessageA(DlgItem, 0x1006u, 0, (LPARAM)lParam);
      ++v2;
    }
    while ( v2 < SlotCount );
  }
  EnableWindow(hWnd, 0);
  EnableWindow(v15, 0);
  EnableWindow(v18, 0);
  SendMessageA(v17, 0xCu, 0, (LPARAM)unk_C10D38);
  SendMessageA(v13, 0xCu, 0, (LPARAM)unk_C10D38);
  SendMessageA(v20, 0xCu, 0, (LPARAM)unk_C10D38);
  SendMessageA(v14, 0xCu, 0, (LPARAM)unk_C10D38);
  return SendMessageA(v16, 0xCu, 0, (LPARAM)unk_C10D38);
}

// 0x004E4D70
LRESULT CCBUI::ShowCommandDetails()
{
  HWND DlgItem; // edi
  HWND v3; // ebp
  int *TargetRole; // eax
  int v5; // esi
  int SkillNum; // eax
  int ItemPrice; // eax
  int ItemWeight; // eax
  int ItemData; // eax
  HWND v11; // [esp+0x10] [ebp-0x124]
  HWND v12; // [esp+0x14] [ebp-0x120]
  HWND hWnd; // [esp+0x18] [ebp-0x11C]
  int v14; // [esp+0x20] [ebp-0x114]
  char pOut[12]; // [esp+0x28] [ebp-0x10C] BYREF
  char lParam[256]; // [esp+0x34] [ebp-0x100] BYREF

  GetDlgItem(g_RoleSystemCombat.m_teamSlotsB.combat.g_hCombatDlg2, 1142);
  GetDlgItem(g_RoleSystemCombat.m_teamSlotsB.combat.g_hCombatDlg2, 1146);
  DlgItem = GetDlgItem(g_RoleSystemCombat.m_teamSlotsB.combat.g_hCombatDlg2, 1145);
  v3 = GetDlgItem(g_RoleSystemCombat.m_teamSlotsB.combat.g_hCombatDlg2, 1143);
  hWnd = GetDlgItem(g_RoleSystemCombat.m_teamSlotsB.combat.g_hCombatDlg2, 1144);
  v12 = GetDlgItem(g_RoleSystemCombat.m_teamSlotsB.combat.g_hCombatDlg2, 1147);
  v11 = GetDlgItem(g_RoleSystemCombat.m_teamSlotsB.combat.g_hCombatDlg2, 1148);
  TargetRole = (int *)(((CCBAI *)&((RoleSystem *)&stru_C059A0)->m_fAnimSpeed))->CCBAI::GetTargetRole(pOut);
  v5 = (unsigned long)*TargetRole;
  v14 = (unsigned long)TargetRole[1];
  SkillNum = (((PAL_GDB *)&g_pGDB))->PAL_GDB::GDB_GetSkillNum(*TargetRole);
  sprintf(lParam, "%s", SkillNum + 4);
  SendMessageA(DlgItem, 0xCu, 0, (LPARAM)lParam);
  sprintf(lParam, &dir[20], v14);
  SendMessageA(v3, 0xCu, 0, (LPARAM)lParam);
  ItemPrice = /* [MISATTRIBUTED] PAL_GDB on CCBUI::this -> fix IDB name of callee */ PAL_GDB::GetItemPrice((PAL_GDB *)this, v5);
  sprintf(lParam, &dir[20], ItemPrice);
  SendMessageA(hWnd, 0xCu, 0, (LPARAM)lParam);
  ItemWeight = /* [MISATTRIBUTED] PAL_GDB on CCBUI::this -> fix IDB name of callee */ PAL_GDB::GetItemWeight((PAL_GDB *)this, v5);
  sprintf(lParam, &dir[20], ItemWeight);
  SendMessageA(v12, 0xCu, 0, (LPARAM)lParam);
  ItemData = /* [MISATTRIBUTED] PAL_GDB on CCBUI::this -> fix IDB name of callee */ PAL_GDB::GetItemData((PAL_GDB *)this, v5);
  sprintf(lParam, &dir[20], ItemData);
  return SendMessageA(v11, 0xCu, 0, (LPARAM)lParam);
}

// 0x004E4F00
int CCBUI::ApplyCommandEdit()
{
  HWND DlgItem; // ebx
  HWND v3; // ebp
  int *TargetRole; // eax
  int v5; // ebx
  int v6; // ebp
  int v7; // esi
  int result; // eax
  gbColorQuad *i; // edx
  void **v10; // ecx
  HWND hWnda; // [esp+0x10] [ebp-0x120]
  void *hWnd; // [esp+0x10] [ebp-0x120]
  int p_DWORD; // [esp+0x14] [ebp-0x11C] BYREF
  int v14; // [esp+0x18] [ebp-0x118]
  int v15; // [esp+0x1C] [ebp-0x114]
  HWND v16; // [esp+0x20] [ebp-0x110]
  char pOut[12]; // [esp+0x24] [ebp-0x10C] BYREF
  char lParam[256]; // [esp+0x30] [ebp-0x100] BYREF

  v14 = 0;
  v15 = 0;
  p_DWORD = 0xFFFF;
  DlgItem = GetDlgItem(g_RoleSystemCombat.m_teamSlotsB.combat.g_hCombatDlg2, 1143);
  v3 = GetDlgItem(g_RoleSystemCombat.m_teamSlotsB.combat.g_hCombatDlg2, 1144);
  hWnda = GetDlgItem(g_RoleSystemCombat.m_teamSlotsB.combat.g_hCombatDlg2, 1147);
  v16 = GetDlgItem(g_RoleSystemCombat.m_teamSlotsB.combat.g_hCombatDlg2, 1148);
  TargetRole = (int *)(((CCBAI *)&((RoleSystem *)&stru_C059A0)->m_fAnimSpeed))->CCBAI::GetTargetRole(pOut);
  p_DWORD = (unsigned long)*TargetRole;
  v14 = (unsigned long)TargetRole[1];
  v15 = (unsigned long)TargetRole[2];
  (((PAL_GDB *)&g_pGDB))->PAL_GDB::GDB_GetSkillNum(p_DWORD);
  SendMessageA(DlgItem, 0xDu, 0x14u, (LPARAM)lParam);
  v5 = atoi(lParam);
  SendMessageA(v3, 0xDu, 0x14u, (LPARAM)lParam);
  v6 = atoi(lParam);
  SendMessageA(hWnda, 0xDu, 0x14u, (LPARAM)lParam);
  hWnd = (void *)atoi(lParam);
  SendMessageA(v16, 0xDu, 0x14u, (LPARAM)lParam);
  v7 = atoi(lParam);
  (((CCBStage *)&((RoleSystem *)&stru_C059A0)->m_fAnimSpeed))->CCBStage::PassCmd(&p_DWORD);
  if ( v5 > 0 )
  {
    v14 = v5;
    (((CCBStage *)&((RoleSystem *)&stru_C059A0)->m_fAnimSpeed))->CCBStage::GetAlive(&p_DWORD);
  }
  result = 0;
  for ( i = &this->m_wndcolor; ; i += 4 )
  {
    if ( i->Color == p_DWORD )
    {
      v10 = ((void **)(this)) + 4 * result;
      goto LABEL_10;
    }
    if ( !i->Color )
      break;
    if ( ++result >= 500 )
    {
      g_RoleSystemCombat.m_teamSlotsB.combat.m_bCommandEdited = 1;
      return result;
    }
  }
  v10 = ((void **)(this)) + 4 * result;
  v10[2] = (void *)p_DWORD;
LABEL_10:
  result = 16 * (result + 1);
  v10[3] = (void *)v6;
  *(void **)((char *)((void **)(this)) + result) = hWnd;
  v10[5] = (void *)v7;
  g_RoleSystemCombat.m_teamSlotsB.combat.m_bCommandEdited = 1;
  return result;
}

// 0x004E5170
int CCBUI::ShowSkillDetails()
{
  HWND DlgItem; // edi
  HWND v2; // ebx
  HWND v3; // ebp
  int *TargetRole; // eax
  __int16 *SkillNum; // esi
  HWND hWnd; // [esp+0x10] [ebp-0x120]
  HWND v8; // [esp+0x14] [ebp-0x11C]
  int v9; // [esp+0x1C] [ebp-0x114]
  char pOut[12]; // [esp+0x24] [ebp-0x10C] BYREF
  char lParam[256]; // [esp+0x30] [ebp-0x100] BYREF

  GetDlgItem(g_RoleSystemCombat.m_teamSlotsB.combat.g_hCombatDlg2, 1142);
  GetDlgItem(g_RoleSystemCombat.m_teamSlotsB.combat.g_hCombatDlg2, 1146);
  DlgItem = GetDlgItem(g_RoleSystemCombat.m_teamSlotsB.combat.g_hCombatDlg2, 1145);
  v2 = GetDlgItem(g_RoleSystemCombat.m_teamSlotsB.combat.g_hCombatDlg2, 1143);
  v3 = GetDlgItem(g_RoleSystemCombat.m_teamSlotsB.combat.g_hCombatDlg2, 1144);
  hWnd = GetDlgItem(g_RoleSystemCombat.m_teamSlotsB.combat.g_hCombatDlg2, 1147);
  v8 = GetDlgItem(g_RoleSystemCombat.m_teamSlotsB.combat.g_hCombatDlg2, 1148);
  TargetRole = (int *)(((CCBAI *)&((RoleSystem *)&stru_C059A0)->m_fAnimSpeed))->CCBAI::GetTargetRole(pOut);
  v9 = (unsigned long)TargetRole[1];
  SkillNum = (__int16 *)(((PAL_GDB *)&g_pGDB))->PAL_GDB::GDB_GetSkillNum(*TargetRole);
  sprintf(lParam, "%s", SkillNum + 2);
  SendMessageA(DlgItem, 0xCu, 0, (LPARAM)lParam);
  sprintf(lParam, &dir[20], v9);
  SendMessageA(v2, 0xCu, 0, (LPARAM)lParam);
  sprintf(lParam, &dir[20], SkillNum[322]);
  SendMessageA(v3, 0xCu, 0, (LPARAM)lParam);
  sprintf(lParam, &dir[20], SkillNum[323]);
  SendMessageA(hWnd, 0xCu, 0, (LPARAM)lParam);
  sprintf(lParam, &dir[20], SkillNum[324]);
  return SendMessageA(v8, 0xCu, 0, (LPARAM)lParam);
}

// 0x004E53C0
LRESULT CCBUI::SendWindowMessage(HWND hWnd, LPARAM lParam)
{
  return SendMessageA(hWnd, 0xCu, 0, lParam);
}

// 0x004E53E0
LRESULT CCBUI::FormatCombatBuffer(HWND hWnd, int nVal)
{
  sprintf(&g_RoleSystemCombat.m_teamSlotOverlay.m_state.m_CCBStageCamBuffer, "%lu", nVal);
  return SendMessageA(hWnd, 0xCu, 0, (LPARAM)&g_RoleSystemCombat.m_teamSlotOverlay.m_teamSlots[218]);
}

// 0x004E5490
int CCBUI::StartMagicThread()
{
  CCBControl *Update_2ff0; // ecx
  int v3; // edx
  int result; // eax

  (((CCBSystem *)this->__vftable->Destroy))->CCBSystem::SetThreadFlag(0);
  (((CCBUI *)this->__vftable->Render))->CCBUI::CreateMagicWindow();
  Update_2ff0 = (CCBControl *)this->__vftable->Update_2ff0;
  if ( Update_2ff0->m_bActive )
    (((CCBControl *)Update_2ff0))->CCBControl::GetState();
  v3 = 0;
  for ( result = 24; result < 68; result += 4 )
  {
    if ( *((_BYTE *)this->__vftable->Create + v3 + 577) )
    {
      *(_BYTE *)(*(_DWORD *)((char *)this->__vftable->_sdtor_call_dtor + result) + 280) = 0;
      *(_BYTE *)(*(_DWORD *)((char *)this->__vftable->_sdtor_call_dtor + result) + 274) = 0;
    }
    v3 += 892;
  }
  return result;
}

// 0x004EA4A0
LRESULT CCBUI::_nearby_4ea4a0(HWND hDlg, int a3)
{
  int v4; // esi
  HWND *v5; // edi
  int v6; // ecx
  LPARAM v7; // eax
  LRESULT result; // eax
  _DWORD v9[13]; // [esp+0x10] [ebp-0x34] BYREF

  v9[0] = (unsigned long)GetDlgItem(hDlg, 1264);
  v9[1] = (unsigned long)GetDlgItem(hDlg, 1263);
  v9[2] = (unsigned long)GetDlgItem(hDlg, 1265);
  v9[3] = (unsigned long)GetDlgItem(hDlg, 1266);
  v9[4] = (unsigned long)GetDlgItem(hDlg, 1267);
  v9[5] = (unsigned long)GetDlgItem(hDlg, 1268);
  v9[6] = (unsigned long)GetDlgItem(hDlg, 1269);
  v9[7] = (unsigned long)GetDlgItem(hDlg, 1270);
  v9[8] = (unsigned long)GetDlgItem(hDlg, 1271);
  v9[9] = (unsigned long)GetDlgItem(hDlg, 1272);
  v9[10] = (unsigned long)GetDlgItem(hDlg, 1273);
  v9[11] = (unsigned long)GetDlgItem(hDlg, 1274);
  v9[12] = (unsigned long)GetDlgItem(hDlg, 1275);
  v4 = 0;
  v5 = (HWND *)v9;
  do
  {
    v6 = *((_DWORD *)this->__vftable[1].Create + 18 * a3 + 24);
    v7 = (*(int ( **)(int, int))(*(_DWORD *)v6 + 40))(v6, v4);
    result = CCBUI::SendWindowMessage(*v5, v7);
    ++v4;
    ++v5;
  }
  while ( v4 < 13 );
  return result;
}

// 0x004EA5C0
int CCBUI::DlgProcCameraEdit(CCBCamControl *a1, HWND hDlg, UINT uMsg, WORD wParam, LPARAM lParam)
{
  int v7; // ecx
  int v8; // eax
  char *v9; // edx
  _BYTE *v10; // edi
  bool v11; // zf
  HWND hWnd; // [esp+0x8] [ebp-0x4]
  HWND hDlga; // [esp+0x14] [ebp+0x8]

  hDlga = GetDlgItem(hDlg, 1225);
  hWnd = GetDlgItem(hDlg, 1226);
  if ( uMsg == 272 )
  {
    v7 = -1;
    if ( a1->m_CamEntries[1405] == -1 )
    {
      v8 = (unsigned long)a1->m_CamEntries[1404];
      if ( v8 != -1 )
      {
        v9 = (char *)a1->m_CCT->m_Pool[0].StartPos.yaw.p + 72 * v8;
        v10 = (_BYTE *)v9 + 58;
        do
        {
          if ( !v7 )
            break;
          v11 = *v10++ == 0;
          --v7;
        }
        while ( !v11 );
        if ( -v7 == 2 )
          (((CCBUI *)hDlga))->CCBUI::SendWindowMessage((LPARAM)(v9 + 28));
        else
          (((CCBUI *)hDlga))->CCBUI::SendWindowMessage((LPARAM)(v9 + 58));
        EditBoxSetInt(hWnd, a1->m_CamEntries[1404]);
      }
    }
    (((CCBUI *)a1))->CCBUI::_nearby_4ea6d0(hDlg, a1->m_CamEntries[1405]);
  }
  else if ( uMsg == 273 )
  {
    if ( wParam == 1 )
    {
      if ( (((CCBUI *)a1))->CCBUI::_nearby_4eac10(hDlg, a1->m_CamEntries[1405]) )
      {
        (((CCBStageCam *)a1))->CCBStageCam::sub_4E95A0(g_hMainWnd);
        EndDialog(hDlg, 1);
        goto LABEL_8;
      }
    }
    else if ( wParam == 2 )
    {
      EndDialog(hDlg, 2);
LABEL_8:
      g_RoleSystemCombat.m_teamSlotsB.combat.g_hCBStageCamDlg = 0;
      return 0;
    }
  }
  return 0;
}

// 0x004EA6D0
char CCBUI::_nearby_4ea6d0(HWND hDlg, int a3)
{
  _DWORD *v4; // ebx
  int EffSlot; // eax
  int v6; // edx
  int v7; // edi
  LRESULT v8; // eax
  BOOL v9; // edx
  BOOL v10; // ecx
  HWND v12; // [esp+0x10] [ebp-0x1A4]
  HWND v13; // [esp+0x14] [ebp-0x1A0]
  HWND v14; // [esp+0x18] [ebp-0x19C]
  HWND v15; // [esp+0x1C] [ebp-0x198]
  HWND v16; // [esp+0x20] [ebp-0x194]
  HWND v17; // [esp+0x24] [ebp-0x190]
  HWND v18; // [esp+0x28] [ebp-0x18C]
  HWND v19; // [esp+0x2C] [ebp-0x188]
  HWND v20; // [esp+0x30] [ebp-0x184]
  HWND v21; // [esp+0x34] [ebp-0x180]
  HWND v22; // [esp+0x38] [ebp-0x17C]
  HWND v23; // [esp+0x3C] [ebp-0x178]
  HWND v24; // [esp+0x40] [ebp-0x174]
  HWND v25; // [esp+0x44] [ebp-0x170]
  HWND v26; // [esp+0x48] [ebp-0x16C]
  HWND v27; // [esp+0x4C] [ebp-0x168]
  HWND v28; // [esp+0x50] [ebp-0x164]
  HWND v29; // [esp+0x54] [ebp-0x160]
  HWND DlgItem; // [esp+0x58] [ebp-0x15C]
  HWND v31; // [esp+0x5C] [ebp-0x158]
  HWND hWnd; // [esp+0x60] [ebp-0x154]
  HWND v33; // [esp+0x64] [ebp-0x150]
  HWND v34; // [esp+0x68] [ebp-0x14C]
  HWND v35; // [esp+0x6C] [ebp-0x148]
  HWND v36; // [esp+0x70] [ebp-0x144]
  HWND v37; // [esp+0x74] [ebp-0x140]
  HWND v38; // [esp+0x78] [ebp-0x13C]
  HWND v39; // [esp+0x7C] [ebp-0x138]
  HWND v40; // [esp+0x80] [ebp-0x134]
  HWND v41; // [esp+0x84] [ebp-0x130]
  HWND v42; // [esp+0x88] [ebp-0x12C]
  HWND v43; // [esp+0x8C] [ebp-0x128]
  HWND v44; // [esp+0x90] [ebp-0x124]
  HWND v45; // [esp+0x94] [ebp-0x120]
  HWND v46; // [esp+0x98] [ebp-0x11C]
  _DWORD v47[70]; // [esp+0x9C] [ebp-0x118] BYREF

  DlgItem = GetDlgItem(hDlg, 1225);
  v14 = GetDlgItem(hDlg, 1226);
  v16 = GetDlgItem(hDlg, 1207);
  v46 = GetDlgItem(hDlg, 1206);
  v18 = GetDlgItem(hDlg, 1227);
  hWnd = GetDlgItem(hDlg, 1228);
  v40 = GetDlgItem(hDlg, 1248);
  v20 = GetDlgItem(hDlg, 1229);
  v21 = GetDlgItem(hDlg, 1216);
  v19 = GetDlgItem(hDlg, 1217);
  v17 = GetDlgItem(hDlg, 1221);
  v42 = GetDlgItem(hDlg, 1218);
  v28 = GetDlgItem(hDlg, 1219);
  v38 = GetDlgItem(hDlg, 1220);
  v12 = GetDlgItem(hDlg, 1244);
  v13 = GetDlgItem(hDlg, 1245);
  v15 = GetDlgItem(hDlg, 1230);
  v26 = GetDlgItem(hDlg, 1222);
  v34 = GetDlgItem(hDlg, 1232);
  v22 = GetDlgItem(hDlg, 1231);
  v44 = GetDlgItem(hDlg, 1233);
  v24 = GetDlgItem(hDlg, 1234);
  v36 = GetDlgItem(hDlg, 1224);
  v23 = GetDlgItem(hDlg, 1223);
  v25 = GetDlgItem(hDlg, 1235);
  v27 = GetDlgItem(hDlg, 1236);
  v29 = GetDlgItem(hDlg, 1237);
  v31 = GetDlgItem(hDlg, 1247);
  v33 = GetDlgItem(hDlg, 1238);
  v35 = GetDlgItem(hDlg, 1239);
  v37 = GetDlgItem(hDlg, 1240);
  v39 = GetDlgItem(hDlg, 1241);
  v41 = GetDlgItem(hDlg, 1242);
  v43 = GetDlgItem(hDlg, 1243);
  v45 = GetDlgItem(hDlg, 1246);
  v4 = v47;
  if ( a3 == -1 )
  {
    EffSlot = (int)this[3].m_pAttackSequenFace[3];
    if ( EffSlot == -1 )
      return EffSlot;
    v6 = *((_DWORD *)this->__vftable[1].Create + 18 * EffSlot + 23);
    memset(v47, 0, sizeof(v47));
    v47[51] = -1;
    v47[42] = 1;
    v47[43] = 1;
    v47[44] = 1;
    v47[50] = 1065353216;
  }
  else
  {
    v4 = (_DWORD *)(280 * a3 + 24433456);
    LOBYTE(EffSlot) = g_EffTable[280 * a3 + 212];
    if ( !(_BYTE)EffSlot )
      return EffSlot;
    v6 = *(_DWORD *)&g_EffTable[280 * a3];
  }
  EffSlot = (((CEffMgr *)this->__vftable[1].Create))->CEffMgr::FindEffSlot(v6);
  v7 = EffSlot;
  if ( EffSlot != -1 )
  {
    this->CCBUI::_nearby_4ea4a0(hDlg, EffSlot);
    (((CCBUI *)DlgItem))->CCBUI::SendWindowMessage((LPARAM)this->__vftable[1].Create + 72 * v7 + 28);
    EditBoxSetInt(v14, v7);
    (((CCBUI *)v46))->CCBUI::SendWindowMessage((LPARAM)(v4 + 10));
    v8 = (((CCBUI *)v16))->CCBUI::SendWindowMessage((LPARAM)(v4 + 1));
    LOBYTE(v8) = *((_BYTE *)v4 + 213);
    EditBoxSetReadOnly(hWnd, v8);
    LOBYTE(v9) = *((_BYTE *)v4 + 214);
    EditBoxSetReadOnly(v18, v9);
    LOBYTE(v10) = *((_BYTE *)v4 + 215);
    EditBoxSetReadOnly(v40, v10);
    EditBoxSetInt(v20, v4[52]);
    (((CCBUI *)v34))->CCBUI::FormatCombatBuffer(HIBYTE(v4[51]));
    (((CCBUI *)v22))->CCBUI::FormatCombatBuffer(*((unsigned __int8 *)v4 + 206));
    (((CCBUI *)v44))->CCBUI::FormatCombatBuffer(*((unsigned __int8 *)v4 + 205));
    (((CCBUI *)v24))->CCBUI::FormatCombatBuffer((unsigned __int8)v4[51]);
    EditBoxSetFloat(v36, *((float *)v4 + 45));
    EditBoxSetFloat(v26, *((float *)v4 + 50));
    EditBoxSetFloat(v42, *((float *)v4 + 46));
    EditBoxSetFloat(v28, *((float *)v4 + 47));
    EditBoxSetFloat(v38, *((float *)v4 + 48));
    EditBoxSetFloat(v12, *((float *)v4 + 54));
    EditBoxSetFloat(v13, *((float *)v4 + 49));
    EditBoxSetFloat(v15, *((float *)v4 + 55));
    EditBoxSetInt(v17, v4[44]);
    EditBoxSetInt(v19, v4[43]);
    EditBoxSetInt(v21, v4[42]);
    EditBoxSetFloat(v23, *((float *)v4 + 56));
    EditBoxSetFloat(v25, *((float *)v4 + 57));
    EditBoxSetFloat(v27, *((float *)v4 + 58));
    EditBoxSetFloat(v29, *((float *)v4 + 59));
    EditBoxSetFloat(v31, *((float *)v4 + 60));
    EditBoxSetFloat(v33, *((float *)v4 + 61));
    EditBoxSetFloat(v35, *((float *)v4 + 62));
    EditBoxSetFloat(v37, *((float *)v4 + 63));
    EditBoxSetFloat(v39, *((float *)v4 + 64));
    EditBoxSetFloat(v41, *((float *)v4 + 65));
    EditBoxSetFloat(v43, *((float *)v4 + 66));
    LOBYTE(EffSlot) = EditBoxSetFloat(v45, *((float *)v4 + 67));
  }
  return EffSlot;
}

// 0x004EAC10
char CCBUI::_nearby_4eac10(HWND hDlg, int a3)
{
  HWND v3; // ebx
  HWND v4; // ebp
  char *EditBoxText; // eax
  int v6; // esi
  int v7; // edi
  int v8; // ebx
  const char *v9; // eax
  int v10; // edi
  char *v11; // ecx
  UIStatic *v12; // ecx
  char *v13; // eax
  const char *v15; // ebx
  const char *v16; // eax
  int *v17; // esi
  int v18; // edx
  const char **v19; // ecx
  HWND v21; // [esp+0x14] [ebp-0x198]
  HWND v22; // [esp+0x18] [ebp-0x194]
  HWND v23; // [esp+0x1C] [ebp-0x190]
  HWND DlgItem; // [esp+0x20] [ebp-0x18C]
  HWND v25; // [esp+0x24] [ebp-0x188]
  HWND v26; // [esp+0x28] [ebp-0x184]
  HWND v27; // [esp+0x2C] [ebp-0x180]
  HWND v28; // [esp+0x30] [ebp-0x17C]
  HWND v29; // [esp+0x34] [ebp-0x178]
  HWND v30; // [esp+0x38] [ebp-0x174]
  HWND v31; // [esp+0x3C] [ebp-0x170]
  HWND v32; // [esp+0x40] [ebp-0x16C]
  HWND v33; // [esp+0x44] [ebp-0x168]
  HWND v34; // [esp+0x48] [ebp-0x164]
  HWND v35; // [esp+0x4C] [ebp-0x160]
  HWND v36; // [esp+0x50] [ebp-0x15C]
  HWND v37; // [esp+0x54] [ebp-0x158]
  HWND v38; // [esp+0x58] [ebp-0x154]
  HWND v39; // [esp+0x5C] [ebp-0x150]
  HWND v40; // [esp+0x60] [ebp-0x14C]
  HWND v41; // [esp+0x64] [ebp-0x148]
  HWND v42; // [esp+0x68] [ebp-0x144]
  HWND v43; // [esp+0x6C] [ebp-0x140]
  HWND v44; // [esp+0x70] [ebp-0x13C]
  HWND v45; // [esp+0x74] [ebp-0x138]
  HWND v46; // [esp+0x78] [ebp-0x134]
  HWND v47; // [esp+0x7C] [ebp-0x130]
  HWND v48; // [esp+0x80] [ebp-0x12C]
  HWND v49; // [esp+0x84] [ebp-0x128]
  HWND v50; // [esp+0x88] [ebp-0x124]
  HWND v51; // [esp+0x8C] [ebp-0x120]
  HWND hWnd; // [esp+0x90] [ebp-0x11C]
  const char *EditorTaskDescription; // [esp+0x94] [ebp-0x118] BYREF
  char nIndex[36]; // [esp+0x98] [ebp-0x114] BYREF
  char v55[128]; // [esp+BCh] [ebp-F0h] BYREF
  int v56; // [esp+0x13C] [ebp-0x70]
  int v57; // [esp+0x140] [ebp-0x6C]
  int v58; // [esp+0x144] [ebp-0x68]
  float Float; // [esp+0x148] [ebp-0x64]
  float v60; // [esp+0x14C] [ebp-0x60]
  float v61; // [esp+0x150] [ebp-0x5C]
  float v62; // [esp+0x154] [ebp-0x58]
  float v63; // [esp+0x158] [ebp-0x54]
  float v64; // [esp+0x15C] [ebp-0x50]
  int v65; // [esp+0x160] [ebp-0x4C]
  int Int; // [esp+0x164] [ebp-0x48]
  char v67; // [esp+0x168] [ebp-0x44]
  bool IsModified; // [esp+0x169] [ebp-0x43]
  bool v69; // [esp+0x16A] [ebp-0x42]
  bool v70; // [esp+0x16B] [ebp-0x41]
  float v71; // [esp+0x16C] [ebp-0x40]
  float v72; // [esp+0x170] [ebp-0x3C]
  float v73; // [esp+0x174] [ebp-0x38]
  float v74; // [esp+0x178] [ebp-0x34]
  float v75; // [esp+0x17C] [ebp-0x30]
  float v76; // [esp+0x180] [ebp-0x2C]
  float v77; // [esp+0x184] [ebp-0x28]
  float v78; // [esp+0x188] [ebp-0x24]
  float v79; // [esp+0x18C] [ebp-0x20]
  float v80; // [esp+0x190] [ebp-0x1C]
  float v81; // [esp+0x194] [ebp-0x18]
  float v82; // [esp+0x198] [ebp-0x14]
  float v83; // [esp+0x19C] [ebp-0x10]
  float v84; // [esp+0x1A0] [ebp-0xC]

  DlgItem = GetDlgItem(hDlg, 1225);
  v51 = GetDlgItem(hDlg, 1207);
  v49 = GetDlgItem(hDlg, 1206);
  v3 = GetDlgItem(hDlg, 1227);
  v4 = GetDlgItem(hDlg, 1228);
  hWnd = GetDlgItem(hDlg, 1248);
  v38 = GetDlgItem(hDlg, 1229);
  v23 = GetDlgItem(hDlg, 1216);
  v22 = GetDlgItem(hDlg, 1217);
  v21 = GetDlgItem(hDlg, 1221);
  v42 = GetDlgItem(hDlg, 1218);
  v32 = GetDlgItem(hDlg, 1219);
  v48 = GetDlgItem(hDlg, 1220);
  v34 = GetDlgItem(hDlg, 1244);
  v44 = GetDlgItem(hDlg, 1245);
  v36 = GetDlgItem(hDlg, 1230);
  v30 = GetDlgItem(hDlg, 1222);
  v46 = GetDlgItem(hDlg, 1232);
  v26 = GetDlgItem(hDlg, 1231);
  v40 = GetDlgItem(hDlg, 1233);
  v28 = GetDlgItem(hDlg, 1234);
  v50 = GetDlgItem(hDlg, 1224);
  v25 = GetDlgItem(hDlg, 1223);
  v27 = GetDlgItem(hDlg, 1235);
  v29 = GetDlgItem(hDlg, 1236);
  v31 = GetDlgItem(hDlg, 1237);
  v33 = GetDlgItem(hDlg, 1247);
  v35 = GetDlgItem(hDlg, 1238);
  v37 = GetDlgItem(hDlg, 1239);
  v39 = GetDlgItem(hDlg, 1240);
  v41 = GetDlgItem(hDlg, 1241);
  v43 = GetDlgItem(hDlg, 1242);
  v45 = GetDlgItem(hDlg, 1243);
  v47 = GetDlgItem(hDlg, 1246);
  IsModified = EditBoxIsModified(v4);
  v69 = EditBoxIsModified(v3);
  v70 = EditBoxIsModified(hWnd);
  Int = EditBoxGetInt(v38);
  v67 = 1;
  if ( (byte_1895559 & 1) == 0 )
  {
    LOBYTE(byte_1895559) = byte_1895559 | 1;
    (((CEffMgr *)&g_pCEffMgrBackup))->CEffMgr::Reset();
    atexit(todo_401800);
  }
  EditBoxText = GetEditBoxText(DlgItem);
  EditorTaskDescription = (((CEffSParticle *)&g_pCEffMgrBackup))->CEffSParticle::GetEditorTaskDescription((int)EditBoxText);
  v6 = EditBoxGetInt(v46) << 24;
  v7 = EditBoxGetInt(v26) << 16;
  v8 = EditBoxGetInt(v40) << 8;
  v65 = v6 | v7 | v8 | EditBoxGetInt(v28);
  Float = EditBoxGetFloat(v50);
  v64 = EditBoxGetFloat(v30);
  v60 = EditBoxGetFloat(v42);
  v61 = EditBoxGetFloat(v32);
  v62 = EditBoxGetFloat(v48);
  v71 = EditBoxGetFloat(v34);
  v63 = EditBoxGetFloat(v44);
  v72 = EditBoxGetFloat(v36);
  v58 = EditBoxGetInt(v21);
  v57 = EditBoxGetInt(v22);
  v56 = EditBoxGetInt(v23);
  v73 = EditBoxGetFloat(v25);
  v74 = EditBoxGetFloat(v27);
  v75 = EditBoxGetFloat(v29);
  v76 = EditBoxGetFloat(v31);
  v77 = EditBoxGetFloat(v33);
  v78 = EditBoxGetFloat(v35);
  v79 = EditBoxGetFloat(v37);
  v80 = EditBoxGetFloat(v39);
  v81 = EditBoxGetFloat(v41);
  v82 = EditBoxGetFloat(v43);
  v83 = EditBoxGetFloat(v45);
  v84 = EditBoxGetFloat(v47);
  strcpy(v55, GetEditBoxText(v49));
  strcpy(nIndex, GetEditBoxText(v51));
  if ( (byte_1895559 & 1) == 0 )
  {
    LOBYTE(byte_1895559) = byte_1895559 | 1;
    (((CEffMgr *)&g_pCEffMgrBackup))->CEffMgr::Reset();
    atexit(todo_401800);
  }
  v9 = (((CEffSParticle *)&g_pCEffMgrBackup))->CEffSParticle::GetEditorTaskDescription((int)nIndex);
  v10 = a3;
  if ( a3 == -1 )
  {
    v11 = (char *)&g_EffTable[36];
    do
    {
      if ( v11[176] && *(const char **)v11 == v9 )
      {
        MessageBoxA((HWND)b, &unk_5D8BE4, Caption, 0);
        return 0;
      }
      v11 += 280;
    }
    while ( (int)v11 < (int)((char *)&g_17A7BData.m_nEffParam1C + 4) );
    v12 = 0;
    v13 = (char *)&g_EffTable[212];
    while ( *v13 )
    {
      v13 += 280;
      v12 = (UIStatic *)((char *)v12 + 1);
      if ( (int)v13 >= (int)&g_EffTaskEnd )
        return 0;
    }
    v10 = (int)v12;
    this[3].m_pAttackSequenFace[4] = v12;
  }
  else
  {
    v15 = *(const char **)&g_EffTable[280 * a3 + 36];
    if ( (byte_1895559 & 1) == 0 )
    {
      LOBYTE(byte_1895559) = byte_1895559 | 1;
      (((CEffMgr *)&g_pCEffMgrBackup))->CEffMgr::Reset();
      atexit(todo_401800);
    }
    v16 = (((CEffSParticle *)&g_pCEffMgrBackup))->CEffSParticle::GetEditorTaskDescription((int)nIndex);
    if ( v16 != v15 )
    {
      v17 = (int *)&g_nSaveSlot1;
      do
      {
        v18 = *(v17 - 1);
        if ( v18 > 0 )
        {
          v19 = (const char **)v17;
          do
          {
            if ( *v19 == v15 )
              *v19 = v16;
            ++v19;
            --v18;
          }
          while ( v18 );
        }
        v17 += 3985;
      }
      while ( (int)v17 < (int)&g_EffTable[4] );
    }
  }
  if ( v10 == -1 )
    return 0;
  sub_4CE030(&EditorTaskDescription, v10);
  return 1;
}

// 0x004EB230
INT_PTR CCBUI::_nearby_4eb230(HWND hDlg, UINT a2, WPARAM a3, LPARAM a4)
{
  return (((CCBUI *)g_RoleSystemCombat.m_teamSlotOverlay.m_teamSlots[217]))->CCBUI::DlgProcCameraConfig(hDlg, a2, a3, a4);
}

// 0x004EB260
int CCBUI::DlgProcCameraConfig(CCBCamControl *a1, HWND hDlg, UINT uMsg, WORD wParam, LPARAM lParam)
{
  HWND v5; // edi
  HWND DlgItem; // ebp
  HWND v7; // ebx
  int v8; // eax
  int v9; // eax
  LRESULT v11; // eax
  LRESULT v12; // eax
  int v13; // eax
  int v14; // eax
  LPARAM lParama[8]; // [esp+0x10] [ebp-0x20] BYREF

  v5 = hDlg;
  DlgItem = GetDlgItem(hDlg, 1276);
  v7 = GetDlgItem(hDlg, 1278);
  if ( uMsg != 78 )
  {
    if ( uMsg == 272 )
    {
      SetWindowPos(hDlg, 0, 800, 0, 224, 730, 0x80u);
      v11 = SendMessageA(DlgItem, 0x1037u, 0, 0);
      LOBYTE(v11) = v11 | 0x21;
      SendMessageA(DlgItem, 0x1036u, 0, v11);
      memset(lParama, 0, sizeof(lParama));
      lParama[0] = 7;
      lParama[1] = 0;
      lParama[2] = 30;
      lParama[3] = (LPARAM)&unk_5D8A58;
      SendMessageA(DlgItem, 0x101Bu, 0, (LPARAM)lParama);
      lParama[1] = 1;
      lParama[2] = 42;
      lParama[3] = (LPARAM)&unk_5D8B04;
      SendMessageA(DlgItem, 0x101Bu, 1u, (LPARAM)lParama);
      lParama[1] = 1;
      lParama[2] = 86;
      lParama[3] = (LPARAM)&unk_5D8C14;
      SendMessageA(DlgItem, 0x101Bu, 2u, (LPARAM)lParama);
      v12 = SendMessageA(v7, 0x1037u, 0, 0);
      LOBYTE(v12) = v12 | 0x21;
      SendMessageA(v7, 0x1036u, 0, v12);
      lParama[0] = 7;
      lParama[1] = 0;
      lParama[2] = 30;
      lParama[3] = (LPARAM)&unk_5D8A58;
      SendMessageA(v7, 0x101Bu, 0, (LPARAM)lParama);
      lParama[1] = 1;
      lParama[2] = 108;
      lParama[3] = (LPARAM)&unk_5D8C0C;
      SendMessageA(v7, 0x101Bu, 1u, (LPARAM)lParama);
      lParama[1] = 1;
      lParama[2] = 30;
      lParama[3] = (LPARAM)&unk_5D8C08;
      SendMessageA(v7, 0x101Bu, 2u, (LPARAM)lParama);
      lParama[1] = 1;
      lParama[2] = 30;
      lParama[3] = (LPARAM)&unk_5D8C04;
      SendMessageA(v7, 0x101Bu, 3u, (LPARAM)lParama);
      return 0;
    }
    if ( uMsg != 273 )
      return 0;
    switch ( wParam )
    {
      case 0x41Fu:
        ((void ( *)(_DWORD))sub_4CE5C0)((_inline_tagCam_yaw)a1->m_CCT->m_Pool[0].StartPos.yaw.p);
        break;
      case 0x421u:
        if ( a1->m_CamEntries[1793] != -1 )
        {
          (((CEffect *)a1->m_CCT->m_Pool[0].StartPos.yaw.p))->CEffect::Render(a1->m_CamEntries[1793]);
          (((CEffMgr *)a1->m_CCT->m_Pool[0].StartPos.yaw.p))->CEffMgr::Init(a1->m_CamEntries[1793], 0, 0, 0, 0);
          a1->m_CCT->m_Pool[0].StartPos.yaw.p->m_fTimer = 0.0;
        }
        break;
      case 0x4BAu:
        (*(CCBStageEffect **)(*(_DWORD *)&a1->m_CCT->m_Pool[0].bValid + 76))->CCBStageEffect::~CCBStageEffect();
        break;
      case 0x4BBu:
        if ( MessageBoxA((HWND)b, &unk_5D8B14, &unk_5D8B3C, 1u) == 1 )
        {
          (((CCBCamControl *)a1))->CCBCamControl::sub_4EB6F0(hDlg);
        }
        v5 = hDlg;
        break;
      case 0x4D0u:
        if ( a1->m_nCurCamIdx == -1 )
        {
          MessageBoxA((HWND)b, &unk_5D8C20, "Warning", 0);
        }
        else
        {
          (((CCBCamControl *)a1))->CCBCamControl::ReadCameraDialog(hDlg);
          (((CCBCamControl *)a1))->CCBCamControl::sub_4EB8D0(hDlg);
        }
        break;
      case 0x4D5u:
        (((CEffMgr *)a1->m_CCT->m_Pool[0].StartPos.yaw.p))->CEffMgr::ReleaseCompletedEffects();
        break;
      case 0x508u:
        (((PAL_GDB *)a1))->PAL_GDB::ShowDetailPanel(hDlg);
        break;
      default:
        break;
    }
  }
  if ( wParam == 1276 )
  {
    v13 = *(_DWORD *)(lParam + 8);
    if ( v13 == -3 || v13 == -2 )
    {
      v14 = *(_DWORD *)(lParam + 12);
      if ( v14 != -1 )
      {
        a1->m_CamEntries[1793] = v14;
        return 0;
      }
      a1->m_CamEntries[1793] = -1;
    }
    return 0;
  }
  if ( wParam != 1278 )
    return 0;
  v8 = *(_DWORD *)(lParam + 8);
  if ( v8 != -3 && v8 != -2 )
    return 0;
  v9 = *(_DWORD *)(lParam + 12);
  if ( v9 == -1 )
  {
    a1->m_nCurCamIdx = -1;
  }
  else
  {
    a1->m_nCurCamIdx = v9;
    (((CCBCamControl *)a1))->CCBCamControl::ShowCameraDialog(v5);
  }
  return 0;
}

// 0x005160A0
int * CCBUI::ctor(int nVal)
{
  sub_516170(this);
  this->m_pSkillWindow = (CCBSkillWindow *)nVal;
  return (int *)this;
}

// 0x00517650

// ---- synthesized vtable stubs (unresolved slots) ----
// [VFTABLE-STUB] original: ((void (*)(UIStatic *, int, int *, CCBUI *))v3->__vftable->Create)(v3, 1, &v8, this)
static void pal3_vtbl_unk_0(UIStatic *, int, int *, CCBUI *);
// [VFTABLE-STUB] original: ((void (*)(UIStatic *, int, int *, CCBUI *))v7->__vftable->Create)(v7, *v4, &v8, this)
static void pal3_vtbl_unk_1(UIStatic *, int, int *, CCBUI *);

CCBUI::~CCBUI()
{
  void *v2; // eax
  UIStatic *v3; // eax
  int *v4; // esi
  UIStatic **p_pPanel; // edi
  void *v6; // eax
  UIStatic *v7; // eax
  int v8; // [esp+0x10] [ebp-0x1C] BYREF
  int v9; // [esp+0x14] [ebp-0x18]
  int v10; // [esp+0x18] [ebp-0x14]
  int v11; // [esp+0x1C] [ebp-0x10]
  int v12; // [esp+0x28] [ebp-0x4]

  v2 = (void *)operator new(0x98u);
  v12 = 0;
  if ( v2 )
    sub_4422E0(v2);
  else
    v3 = 0;
  v12 = -1;
  this->m_pAttackSequenBack = v3;
  if ( v3 )
  {
    v8 = 483;
    v9 = 10;
    v10 = 803;
    v11 = 42;
    pal3_vtbl_unk_0(v3, 1, &v8, this) /* [VFTABLE-STUB] */;
    (((UIStatic *)this->m_pAttackSequenBack))->UIStatic::CreateFromTemplate(&unk_5DF2C0, 0);
    v8 = 480;
    v10 = 544;
    v9 = 8;
    v11 = 72;
    v4 = (int *)&g_nSkillItemIDTable[5];
    p_pPanel = (UIStatic **)&this->pPanel;
    do
    {
      v6 = (void *)operator new(0x98u);
      v12 = 1;
      if ( v6 )
        sub_4422E0(v6);
      else
        v7 = 0;
      v12 = -1;
      *p_pPanel = v7;
      if ( !v7 )
        break;
      pal3_vtbl_unk_1(v7, *v4, &v8, this) /* [VFTABLE-STUB] */;
      (*p_pPanel)->UIStatic::CreateFromTemplate(&unk_5DF2A0, 0);
      ++v4;
      ++p_pPanel;
    }
    while ( (int)v4 < (int)&g_nSkillItemIDTable[16] );
  }
}

static void pal3_vtbl_unk_0(UIStatic *, int, int *, CCBUI *)
{
    
}
static void pal3_vtbl_unk_1(UIStatic *, int, int *, CCBUI *)
{
    
}


// 0x005177B0

// ---- synthesized vtable stubs (unresolved slots) ----
// [VFTABLE-STUB] original: ((void ( *)(UIProgressBar *, int, int *, CCBUI *))v8->__vftable->Create)(v8, 784, &v10, this)
static void pal3_vtbl_unk_0(UIProgressBar *, int, int *, CCBUI *);
// [VFTABLE-STUB] original: ((void ( *)(UIProgressBar *, int, int *, CCBUI *))v9->__vftable->Create)(v9, 1024, &v10, this)
static void pal3_vtbl_unk_1(UIProgressBar *, int, int *, CCBUI *);

void CCBUI::Reset()
{
  UIStatic *v2; // eax
  UIProgressBar *v3; // eax
  UIStatic *v4; // eax
  UIProgressBar *v5; // eax
  UIStatic *v6; // eax
  UIProgressBar *v7; // eax
  UIProgressBar *v8; // ecx
  UIProgressBar *v9; // ecx
  int v10; // [esp+0x30] [ebp-0x820] BYREF
  int v11; // [esp+0x34] [ebp-0x81C]
  int v12; // [esp+0x38] [ebp-0x818]
  int v13; // [esp+0x3C] [ebp-0x814]
  UIStatic *v14; // [esp+0x40] [ebp-0x810]
  char pExceptionObject[1024]; // [esp+0x44] [ebp-0x80C] BYREF
  char ArgList; // [esp+0x444] [ebp-0x40C] BYREF
  int v17; // [esp+0x84C] [ebp-0x4]

  v2 = (UIStatic *)operator new(0x9Cu);
  v14 = (UIStatic *)v2;
  v17 = 0;
  if ( v2 )
    v3 = (UIProgressBar *)(((UIStatic *)v2))->UIStatic::CtorWithFlag();
  else
    v3 = 0;
  this->m_pRoleStateGP[2] = v3;
  v4 = (UIStatic *)operator new(0x9Cu);
  v14 = (UIStatic *)v4;
  v17 = 1;
  if ( v4 )
    v5 = (UIProgressBar *)(((UIStatic *)v4))->UIStatic::CtorWithFlag();
  else
    v5 = 0;
  this->m_pRoleStateGP[3] = v5;
  v6 = (UIStatic *)operator new(0x98u);
  v14 = (UIStatic *)v6;
  v17 = 2;
  if ( v6 )
    sub_4422E0(v6);
  else
    v7 = 0;
  v8 = (UIProgressBar *)this->m_pRoleStateGP[2];
  v17 = -1;
  this->m_pRoleStateMP[0] = v7;
  if ( !v8 || !this->m_pRoleStateGP[3] || !v7 )
  {
    qmemcpy(
      pExceptionObject,
      (((Logger *)&ArgList))->Logger::FormatException((char *)&g_EffMgrData.m_nEffParam_0338 + 16, aDProjectPal3Co_7, 719),
      sizeof(pExceptionObject));
    _CxxThrowException(pExceptionObject, (_ThrowInfo *)&_TI1_AV_Exception__);
  }
  v10 = 300;
  v11 = 30;
  v12 = 461;
  v13 = 87;
  pal3_vtbl_unk_0(v8, 784, &v10, this) /* [VFTABLE-STUB] */;
  (((UIStatic *)this->m_pRoleStateGP[2]))->UIStatic::CreateFromTemplate(&unk_5DEFD4, 0);
  (((UIScene *)this->m_pRoleStateGP[2]))->UIScene::SetShow(1);
  sub_446010(this->m_pRoleStateGP[2]);
  ((void ( *)(UIProgressBar *, _DWORD))this->m_pRoleStateGP[2]->__vftable->ShowWindow)(
    this->m_pRoleStateGP[2],
    0);
  ((void ( *)(UIProgressBar *, int, int *, CCBUI *))this->m_pRoleStateGP[3]->__vftable->Create)(
    this->m_pRoleStateGP[3],
    784,
    &v10,
    this);
  (((UIStatic *)this->m_pRoleStateGP[3]))->UIStatic::CreateFromTemplate(&unk_5DEFB4, 0);
  (((UIScene *)this->m_pRoleStateGP[3]))->UIScene::SetShow(1);
  sub_446010(this->m_pRoleStateGP[3]);
  ((void ( *)(UIProgressBar *, _DWORD))this->m_pRoleStateGP[3]->__vftable->ShowWindow)(
    this->m_pRoleStateGP[3],
    0);
  v9 = (UIProgressBar *)this->m_pRoleStateMP[0];
  v10 = 100;
  v11 = 100;
  v12 = 356;
  v13 = 228;
  pal3_vtbl_unk_1(v9, 1024, &v10, this) /* [VFTABLE-STUB] */;
  (((UIStatic *)this->m_pRoleStateMP[0]))->UIStatic::CreateFromTemplate(&unk_5DEF9C, 0);
  (((UIScene *)this->m_pRoleStateMP[0]))->UIScene::SetShow(1);
  sub_446010(this->m_pRoleStateMP[0]);
  ((void ( *)(UIProgressBar *, _DWORD))this->m_pRoleStateMP[0]->__vftable->ShowWindow)(
    this->m_pRoleStateMP[0],
    0);
  (((UIFrameWnd *)this->m_pRoleStateMP[0]))->UIFrameWnd::SetPosition(5,   63);
  (((UIFrameWnd *)this->m_pRoleStateMP[0]))->UIFrameWnd::SetFrameParam(190);
}

static void pal3_vtbl_unk_0(UIProgressBar *, int, int *, CCBUI *)
{
    
}
static void pal3_vtbl_unk_1(UIProgressBar *, int, int *, CCBUI *)
{
    
}


// 0x00517B30
bool CCBUI::CreateCombatPanel()
{
  UIStatic **p_m_pResultWaterLvup; // esi
  bool result; // al
  CCBUI *v4; // ecx
  int v5; // [esp+0x8] [ebp-0x10] BYREF
  int v6; // [esp+0xC] [ebp-0xC]
  int v7; // [esp+0x10] [ebp-0x8]
  int v8; // [esp+0x14] [ebp-0x4]

  p_m_pResultWaterLvup = (UIStatic **)&this->m_pResultWaterLvup;
  result = /* [MISATTRIBUTED] CCBAIWindow on CCBUI::this -> fix IDB name of callee */ CCBAIWindow::Update((CCBAIWindow *)this, (CCBUI **)&this->m_pResultWaterLvup);
  if ( result )
  {
    v6 = 0;
    v7 = 0;
    v4 = (CCBUI *)*p_m_pResultWaterLvup;
    v5 = 2;
    v7 = 251;
    v6 = 278;
    v8 = 484;
    (((CCBUI *)v4))->CCBUI::AddTask((tagUITask *)&v5, (int)this);
    p_m_pResultWaterLvup->ShowWindow(0);
    return 1;
  }
  return result;
}

// 0x00517C10
bool CCBUI::CreateAttackSequen()
{
  UIStatic **p_m_pResultEarthLvup; // esi
  bool result; // al
  CCBItemWindow *v4; // ecx
  int pRect; // [esp+0x8] [ebp-0x10] BYREF
  int v6; // [esp+0xC] [ebp-0xC]
  int v7; // [esp+0x10] [ebp-0x8]
  int v8; // [esp+0x14] [ebp-0x4]

  p_m_pResultEarthLvup = (UIStatic **)&this->m_pResultEarthLvup;
  if ( result )
  {
    v6 = 0;
    v7 = 0;
    v4 = (CCBItemWindow *)*p_m_pResultEarthLvup;
    pRect = 14;
    v7 = 172;
    v6 = 316;
    v8 = 474;
    (((CCBItemWindow *)v4))->CCBItemWindow::Create(&pRect, (int)this);
    p_m_pResultEarthLvup->ShowWindow(0);
    return 1;
  }
  return result;
}

// 0x00517C80
bool CCBUI::CreateBattleFieldAttr()
{
  UIStatic **p_m_pResultDoubleLvup; // esi
  bool result; // al
  CCBParabolaWindow *v4; // ecx
  int v5; // [esp+0x0] [ebp-0x18]
  CCBParabolaWindow *v6; // [esp+0x8] [ebp-0x10] BYREF
  int v7; // [esp+0xC] [ebp-0xC]
  int v8; // [esp+0x10] [ebp-0x8]
  int v9; // [esp+0x14] [ebp-0x4]

  p_m_pResultDoubleLvup = (UIStatic **)&this->m_pResultDoubleLvup;
  (((CCBLineupWindow *)this))->CCBLineupWindow::~CCBLineupWindow((CCBItemWindow **)&this->m_pResultDoubleLvup) /* [ROWTABLE] */;
  if ( result )
  {
    v7 = 0;
    v8 = 0;
    v4 = (CCBParabolaWindow *)*p_m_pResultDoubleLvup;
    v6 = (CCBParabolaWindow *)9;
    v8 = 239;
    v7 = 232;
    v9 = 482;
    p_m_pResultDoubleLvup->ShowWindow(0);
    return 1;
  }
  return result;
}

// 0x00517D60
bool CCBUI::CreateControlWindow()
{
  int v1; // esi
  CCBControlWindow **i; // edi
  CCBSkillWindow *v4; // ecx
  UIWnd *v6; // [esp+0x0] [ebp-0x1C]
  int pRect; // [esp+0xC] [ebp-0x10] BYREF
  int v8; // [esp+0x10] [ebp-0xC]
  int v9; // [esp+0x14] [ebp-0x8]
  int v10; // [esp+0x18] [ebp-0x4]

  v1 = 0;
  v8 = 0;
  v9 = 0;
  pRect = 0;
  v10 = 0;
  for ( i = &this->m_pMain; (((CCBLineupWindow *)i))->CCBLineupWindow::Create(v6); ++i )
  {
    v9 = v1 + 256;
    v4 = (CCBSkillWindow *)*i;
    pRect = v1;
    v8 = 0;
    v10 = 256;
    (((CCBSkillWindow *)v4))->CCBSkillWindow::Create(&pRect, (int)this);
    i->ShowWindow(0);
    v1 += 200;
    if ( v1 >= 800 )
      return 1;
  }
  return 0;
}

// 0x00517DF0

// ---- synthesized vtable stubs (unresolved slots) ----
// [VFTABLE-STUB] original: ((void ( *)(UIStatic *, int, int *, CCBUI *))v4->__vftable->Create)(v4, 531, &v19, this)
static void pal3_vtbl_unk_0(UIStatic *, int, int *, CCBUI *);
// [VFTABLE-STUB] original: ((void ( *)(UIStatic *, int, int *, CCBUI *))v6->__vftable->Create)(v6, 533, &v19, this)
static void pal3_vtbl_unk_1(UIStatic *, int, int *, CCBUI *);
// [VFTABLE-STUB] original: ((void ( *)(UIStatic *, int, int *, CCBUI *))v8->__vftable->Create)(v8, 534, &v19, this)
static void pal3_vtbl_unk_2(UIStatic *, int, int *, CCBUI *);
// [VFTABLE-STUB] original: ((void ( *)(UIStatic *, int, int *, CCBUI *))v10->__vftable->Create)(v10, 535, &v19, this)
static void pal3_vtbl_unk_3(UIStatic *, int, int *, CCBUI *);
// [VFTABLE-STUB] original: ((void ( *)(UIStatic *, int, int *, CCBUI *))v12->__vftable->Create)(v12, 536, &v19, this)
static void pal3_vtbl_unk_4(UIStatic *, int, int *, CCBUI *);
// [VFTABLE-STUB] original: ((void ( *)(UIStatic *, int, int *, CCBUI *))v14->__vftable->Create)(v14, 538, &v19, this)
static void pal3_vtbl_unk_5(UIStatic *, int, int *, CCBUI *);
// [VFTABLE-STUB] original: ((void ( *)(UIStatic *, int, int *, CCBUI *))v16->__vftable->Create)(v16, 539, &v19, this)
static void pal3_vtbl_unk_6(UIStatic *, int, int *, CCBUI *);
// [VFTABLE-STUB] original: ((void ( *)(UIStatic *, int, int *, CCBUI *))v18->__vftable->Create)(v18, 532, &v19, this)
static void pal3_vtbl_unk_7(UIStatic *, int, int *, CCBUI *);

BOOL CCBUI::CreateItemWindow()
{
  UIStatic **v2; // edi
  BOOL result; // eax
  UIStatic *v4; // ecx
  UIStatic **v5; // edi
  UIStatic *v6; // ecx
  UIStatic **v7; // edi
  UIStatic *v8; // ecx
  UIStatic **p_m_pRoleStateSword; // edi
  UIStatic *v10; // ecx
  UIStaticCB **p_m_pTrickName; // edi
  UIStatic *v12; // ecx
  UIStaticCB **p_m_pTrickName2; // edi
  UIStatic *v14; // ecx
  UIStatic **p_m_pDialogBack; // edi
  UIStatic *v16; // ecx
  UIStatic **p_m_pResultLevelup; // edi
  UIStatic *v18; // ecx
  int v19; // [esp+0x80] [ebp-0x10] BYREF
  int v20; // [esp+0x84] [ebp-0xC]
  int v21; // [esp+0x88] [ebp-0x8]
  int v22; // [esp+0x8C] [ebp-0x4]

  v20 = 0;
  v2 = (UIStatic **)&this->m_pRoleStateMP[1];
  v21 = 0;
  v19 = 0;
  v22 = 0;
  /* [MISATTRIBUTED] CCBAIWindow on CCBUI::this -> fix IDB name of callee */ CCBAIWindow::Reset((CCBAIWindow *)this, (int *)&this->m_pRoleStateMP[1]);
  if ( result )
  {
    v4 = (UIStatic *)*v2;
    v19 = 284;
    v21 = 516;
    v20 = 268;
    v22 = 332;
    pal3_vtbl_unk_0(v4, 531, &v19, this) /* [VFTABLE-STUB] */;
    (*v2)->UIStatic::CreateFromTemplate(&unk_5DF42C, 0);
    (((UIScene *)*v2))->UIScene::SetShow(1);
    sub_446010(*v2);
    v2->ShowWindow(0);
    v5 = (UIStatic **)&this->m_pRoleStateMP[2];
    /* [MISATTRIBUTED] CCBAIWindow on CCBUI::this -> fix IDB name of callee */ CCBAIWindow::Reset((CCBAIWindow *)this, (int *)&this->m_pRoleStateMP[2]);
    if ( result )
    {
      v6 = (UIStatic *)*v5;
      v19 = 249;
      v21 = 551;
      v20 = 263;
      v22 = 337;
      pal3_vtbl_unk_1(v6, 533, &v19, this) /* [VFTABLE-STUB] */;
      (*v5)->UIStatic::CreateFromTemplate(&unk_5DF3E4, 0);
      (((UIScene *)*v5))->UIScene::SetShow(1);
      sub_446010(*v5);
      v5->ShowWindow(0);
      v7 = (UIStatic **)&this->m_pRoleStateMP[3];
      /* [MISATTRIBUTED] CCBAIWindow on CCBUI::this -> fix IDB name of callee */ CCBAIWindow::Reset((CCBAIWindow *)this, (int *)&this->m_pRoleStateMP[3]);
      if ( result )
      {
        v8 = (UIStatic *)*v7;
        v19 = 249;
        v21 = 551;
        v20 = 263;
        v22 = 337;
        pal3_vtbl_unk_2(v8, 534, &v19, this) /* [VFTABLE-STUB] */;
        (*v7)->UIStatic::CreateFromTemplate(&unk_5DF3BC, 0);
        (((UIScene *)*v7))->UIScene::SetShow(1);
        sub_446010(*v7);
        v7->ShowWindow(0);
        p_m_pRoleStateSword = (UIStatic **)&this->m_pRoleStateSword;
        /* [MISATTRIBUTED] CCBAIWindow on CCBUI::this -> fix IDB name of callee */ CCBAIWindow::Reset((CCBAIWindow *)this, (int *)&this->m_pRoleStateSword);
        if ( result )
        {
          v10 = (UIStatic *)*p_m_pRoleStateSword;
          v19 = 249;
          v21 = 551;
          v20 = 263;
          v22 = 337;
          pal3_vtbl_unk_3(v10, 535, &v19, this) /* [VFTABLE-STUB] */;
          (*p_m_pRoleStateSword)->UIStatic::CreateFromTemplate(&unk_5DF394, 0);
          (((UIScene *)*p_m_pRoleStateSword))->UIScene::SetShow(1);
          sub_446010(*p_m_pRoleStateSword);
          p_m_pRoleStateSword->ShowWindow(0);
          p_m_pTrickName = (UIStaticCB **)&this->m_pTrickName;
          /* [MISATTRIBUTED] CCBAIWindow on CCBUI::this -> fix IDB name of callee */ CCBAIWindow::Reset((CCBAIWindow *)this, (int *)&this->m_pTrickName);
          if ( result )
          {
            v12 = (UIStatic *)*p_m_pTrickName;
            v19 = 249;
            v21 = 551;
            v20 = 263;
            v22 = 337;
            pal3_vtbl_unk_4(v12, 536, &v19, this) /* [VFTABLE-STUB] */;
            (*p_m_pTrickName)->UIStatic::CreateFromTemplate(&unk_5DF370, 0);
            (((UIScene *)*p_m_pTrickName))->UIScene::SetShow(1);
            sub_446010(*p_m_pTrickName);
            p_m_pTrickName->ShowWindow(0);
            p_m_pTrickName2 = (UIStaticCB **)&this->m_pTrickName2;
            /* [MISATTRIBUTED] CCBAIWindow on CCBUI::this -> fix IDB name of callee */ CCBAIWindow::Reset((CCBAIWindow *)this, (int *)&this->m_pTrickName2);
            if ( result )
            {
              v14 = (UIStatic *)*p_m_pTrickName2;
              v19 = 249;
              v21 = 551;
              v20 = 263;
              v22 = 337;
              pal3_vtbl_unk_5(v14, 538, &v19, this) /* [VFTABLE-STUB] */;
              (*p_m_pTrickName2)->UIStatic::CreateFromTemplate(&unk_5DF348, 0);
              (((UIScene *)*p_m_pTrickName2))->UIScene::SetShow(1);
              sub_446010(*p_m_pTrickName2);
              p_m_pTrickName2->ShowWindow(0);
              p_m_pDialogBack = (UIStatic **)&this->m_pDialogBack;
              /* [MISATTRIBUTED] CCBAIWindow on CCBUI::this -> fix IDB name of callee */ CCBAIWindow::Reset((CCBAIWindow *)this, (int *)&this->m_pDialogBack);
              if ( result )
              {
                v16 = (UIStatic *)*p_m_pDialogBack;
                v19 = 249;
                v21 = 551;
                v20 = 263;
                v22 = 337;
                pal3_vtbl_unk_6(v16, 539, &v19, this) /* [VFTABLE-STUB] */;
                (*p_m_pDialogBack)->UIStatic::CreateFromTemplate(&unk_5DF320, 0);
                (((UIScene *)*p_m_pDialogBack))->UIScene::SetShow(1);
                sub_446010(*p_m_pDialogBack);
                p_m_pDialogBack->ShowWindow(0);
                p_m_pResultLevelup = (UIStatic **)&this->m_pResultLevelup;
                /* [MISATTRIBUTED] CCBAIWindow on CCBUI::this -> fix IDB name of callee */ CCBAIWindow::Reset((CCBAIWindow *)this, (int *)&this->m_pResultLevelup);
                if ( result )
                {
                  v18 = (UIStatic *)*p_m_pResultLevelup;
                  v19 = 221;
                  v21 = 579;
                  v20 = 255;
                  v22 = 345;
                  pal3_vtbl_unk_7(v18, 532, &v19, this) /* [VFTABLE-STUB] */;
                  (*p_m_pResultLevelup)->UIStatic::CreateFromTemplate(&unk_5DF408, 0);
                  (((UIScene *)*p_m_pResultLevelup))->UIScene::SetShow(1);
                  sub_446010(*p_m_pResultLevelup);
                  result = p_m_pResultLevelup->ShowWindow(0);
                  LOBYTE(result) = 1;
                }
              }
            }
          }
        }
      }
    }
  }
  return result;
}

static void pal3_vtbl_unk_0(UIStatic *, int, int *, CCBUI *)
{
    
}
static void pal3_vtbl_unk_1(UIStatic *, int, int *, CCBUI *)
{
    
}
static void pal3_vtbl_unk_2(UIStatic *, int, int *, CCBUI *)
{
    
}
static void pal3_vtbl_unk_3(UIStatic *, int, int *, CCBUI *)
{
    
}
static void pal3_vtbl_unk_4(UIStatic *, int, int *, CCBUI *)
{
    
}
static void pal3_vtbl_unk_5(UIStatic *, int, int *, CCBUI *)
{
    
}
static void pal3_vtbl_unk_6(UIStatic *, int, int *, CCBUI *)
{
    
}
static void pal3_vtbl_unk_7(UIStatic *, int, int *, CCBUI *)
{
    
}


// 0x005181E0

// ---- synthesized vtable stubs (unresolved slots) ----
// [VFTABLE-STUB] original: ((void ( *)(UIStatic *, _DWORD))v2->__vftable->ShowWindow)(v2, 0)
static void pal3_vtbl_unk_0(UIStatic *, _DWORD);
// [VFTABLE-STUB] original: ((void ( *)(UIStatic *, _DWORD))v3->__vftable->ShowWindow)(v3, 0)
static void pal3_vtbl_unk_1(UIStatic *, _DWORD);
// [VFTABLE-STUB] original: ((void ( *)(UIProgressBar *, _DWORD))v4->__vftable->ShowWindow)(v4, 0)
static void pal3_vtbl_unk_2(UIProgressBar *, _DWORD);
// [VFTABLE-STUB] original: ((void ( *)(UIProgressBar *, _DWORD))v5->__vftable->ShowWindow)(v5, 0)
static void pal3_vtbl_unk_3(UIProgressBar *, _DWORD);
// [VFTABLE-STUB] original: ((void ( *)(UIProgressBar *, _DWORD))v6->__vftable->ShowWindow)(v6, 0)
static void pal3_vtbl_unk_4(UIProgressBar *, _DWORD);
// [VFTABLE-STUB] original: ((void ( *)(UIProgressBar *, _DWORD))m_pRoleStateSword->__vftable->ShowWindow)(m_pRoleStateSword, 0)
static void pal3_vtbl_unk_5(UIProgressBar *, _DWORD);
// [VFTABLE-STUB] original: ((void ( *)(UIStaticCB *, _DWORD))m_pTrickName->__vftable->ShowWindow)(m_pTrickName, 0)
static void pal3_vtbl_unk_6(UIStaticCB *, _DWORD);
// [VFTABLE-STUB] original: ((void ( *)(UIStaticCB *, _DWORD))m_pTrickName2->__vftable->ShowWindow)(m_pTrickName2, 0)
static void pal3_vtbl_unk_7(UIStaticCB *, _DWORD);
// [VFTABLE-STUB] original: ((void ( *)(UIStatic *, _DWORD))m_pDialogBack->__vftable->ShowWindow)(m_pDialogBack, 0)
static void pal3_vtbl_unk_8(UIStatic *, _DWORD);
// [VFTABLE-STUB] original: ((void ( *)(UIStatic *, _DWORD))m_pResultLevelup->__vftable->ShowWindow)(m_pResultLevelup, 0)
static void pal3_vtbl_unk_9(UIStatic *, _DWORD);
// [VFTABLE-STUB] original: ((void ( *)(UIStatic *, _DWORD))this->m_pResultThunderLvup->__vftable->ShowWindow)( this->m_pResultThunderLvup, 0)
static void pal3_vtbl_unk_10(UIStatic *, _DWORD);
// [VFTABLE-STUB] original: ((void ( *)(UIStatic *, _DWORD))this->m_pResultWaterLvup->__vftable->ShowWindow)( this->m_pResultWaterLvup, 0)
static void pal3_vtbl_unk_11(UIStatic *, _DWORD);
// [VFTABLE-STUB] original: ((void ( *)(UIStatic *, _DWORD))this->m_pResultFireLvup->__vftable->ShowWindow)(this->m_pResultFireLvup, 0)
static void pal3_vtbl_unk_12(UIStatic *, _DWORD);
// [VFTABLE-STUB] original: ((void ( *)(UIStatic *, _DWORD))this->m_pResultEarthLvup->__vftable->ShowWindow)( this->m_pResultEarthLvup, 0)
static void pal3_vtbl_unk_13(UIStatic *, _DWORD);
// [VFTABLE-STUB] original: ((void ( *)(UIStatic *, _DWORD))this->m_pResultDoubleLvup->__vftable->ShowWindow)( this->m_pResultDoubleLvup, 0)
static void pal3_vtbl_unk_14(UIStatic *, _DWORD);
// [VFTABLE-STUB] original: ((void ( *)(UIStatic *, _DWORD))this->m_pResultGetItem->__vftable->ShowWindow)(this->m_pResultGetItem, 0)
static void pal3_vtbl_unk_15(UIStatic *, _DWORD);

bool CCBUI::CreateParaWindow()
{
  UIStatic *v2; // ecx
  UIStatic *v3; // ecx
  UIProgressBar *v4; // ecx
  UIProgressBar *v5; // ecx
  UIProgressBar *v6; // ecx
  UIProgressBar *m_pRoleStateSword; // ecx
  UIStaticCB *m_pTrickName; // ecx
  UIStaticCB *m_pTrickName2; // ecx
  UIStatic *m_pDialogBack; // ecx
  UIStatic *m_pResultLevelup; // ecx
  UIListBox *v12; // ecx
  int v13; // edi
  CCBControlWindow **p_m_pMain; // ebx
  bool result; // al

  this->m_pAIWindow = (CCBAIWindow *)(*(void **)(this->m_pSkillWindow));
  v2 = (UIStatic *)this->m_pRoleStateImmunity[4];
  if ( v2 )
    pal3_vtbl_unk_0(v2, 0) /* [VFTABLE-STUB] */;
  v3 = (UIStatic *)this->m_pRoleStateImmunity[5];
  if ( v3 )
    pal3_vtbl_unk_1(v3, 0) /* [VFTABLE-STUB] */;
  v4 = (UIProgressBar *)this->m_pRoleStateMP[1];
  if ( v4 )
    pal3_vtbl_unk_2(v4, 0) /* [VFTABLE-STUB] */;
  v5 = (UIProgressBar *)this->m_pRoleStateMP[2];
  if ( v5 )
    pal3_vtbl_unk_3(v5, 0) /* [VFTABLE-STUB] */;
  v6 = (UIProgressBar *)this->m_pRoleStateMP[3];
  if ( v6 )
    pal3_vtbl_unk_4(v6, 0) /* [VFTABLE-STUB] */;
  m_pRoleStateSword = (UIProgressBar *)this->m_pRoleStateSword;
  if ( m_pRoleStateSword )
    pal3_vtbl_unk_5(m_pRoleStateSword, 0) /* [VFTABLE-STUB] */;
  m_pTrickName = (UIStaticCB *)this->m_pTrickName;
  if ( m_pTrickName )
    pal3_vtbl_unk_6(m_pTrickName, 0) /* [VFTABLE-STUB] */;
  m_pTrickName2 = (UIStaticCB *)this->m_pTrickName2;
  if ( m_pTrickName2 )
    pal3_vtbl_unk_7(m_pTrickName2, 0) /* [VFTABLE-STUB] */;
  m_pDialogBack = (UIStatic *)this->m_pDialogBack;
  if ( m_pDialogBack )
    pal3_vtbl_unk_8(m_pDialogBack, 0) /* [VFTABLE-STUB] */;
  m_pResultLevelup = (UIStatic *)this->m_pResultLevelup;
  if ( m_pResultLevelup )
    pal3_vtbl_unk_9(m_pResultLevelup, 0) /* [VFTABLE-STUB] */;
  pal3_vtbl_unk_10(this->m_pResultThunderLvup, 0) /* [VFTABLE-STUB] */;
  pal3_vtbl_unk_11(this->m_pResultWaterLvup, 0) /* [VFTABLE-STUB] */;
  pal3_vtbl_unk_12(this->m_pResultFireLvup, 0) /* [VFTABLE-STUB] */;
  pal3_vtbl_unk_13(this->m_pResultEarthLvup, 0) /* [VFTABLE-STUB] */;
  pal3_vtbl_unk_14(this->m_pResultDoubleLvup, 0) /* [VFTABLE-STUB] */;
  pal3_vtbl_unk_15(this->m_pResultGetItem, 0) /* [VFTABLE-STUB] */;
  ((void ( *)(UIProgressBar *, _DWORD))this->m_pRoleStateMP[0]->__vftable->ShowWindow)(
    this->m_pRoleStateMP[0],
    0);
  this->m_pRoleStateGP[2]->m_pbk = 0;
  ((void ( *)(UIProgressBar *, _DWORD))this->m_pRoleStateGP[2]->__vftable->ShowWindow)(
    this->m_pRoleStateGP[2],
    0);
  this->m_pRoleStateGP[3]->m_pbk = 0;
  ((void ( *)(UIProgressBar *, _DWORD))this->m_pRoleStateGP[3]->__vftable->ShowWindow)(
    this->m_pRoleStateGP[3],
    0);
  this->CCBUI::CreateResultWindow(0);
  v12 = (UIListBox *)this->m_pRoleStateGP[1];
  if ( v12 )
  {
    (((UIListBox *)v12))->UIListBox::GetCurSel();
    (((UIScrollBar *)this->m_pRoleStateGP[1]))->UIScrollBar::SetRange(50.0);
    (((UIProgressBar *)this->m_pRoleStateGP[1]))->UIProgressBar::FindChildByName(0.0);
  }
  v13 = 0;
  p_m_pMain = (CCBControlWindow **)&this->m_pMain;
  do
  {
    *((_DWORD *)&(*p_m_pMain)->m_CurCtrl_2 + 13) = v13;
    p_m_pMain->ShowWindow(0);
    ++v13;
    ++p_m_pMain;
  }
  while ( v13 < 4 );
  memset(&this->m_pLineupWindow, 0, 0x5A0u);
  this->fp.fp = 0;
  this->fp.fp_data[0] = 0;
  *((_DWORD *)&this->fp + 4) = 0;
  *((_DWORD *)&this->fp + 5) = -1;
  result = 1;
  this->fp.fp_data[1] = 0;
  this->fp.fp_data[2] = -1;
  return result;
}

static void pal3_vtbl_unk_0(UIStatic *, _DWORD)
{
    
}
static void pal3_vtbl_unk_1(UIStatic *, _DWORD)
{
    
}
static void pal3_vtbl_unk_2(UIProgressBar *, _DWORD)
{
    
}
static void pal3_vtbl_unk_3(UIProgressBar *, _DWORD)
{
    
}
static void pal3_vtbl_unk_4(UIProgressBar *, _DWORD)
{
    
}
static void pal3_vtbl_unk_5(UIProgressBar *, _DWORD)
{
    
}
static void pal3_vtbl_unk_6(UIStaticCB *, _DWORD)
{
    
}
static void pal3_vtbl_unk_7(UIStaticCB *, _DWORD)
{
    
}
static void pal3_vtbl_unk_8(UIStatic *, _DWORD)
{
    
}
static void pal3_vtbl_unk_9(UIStatic *, _DWORD)
{
    
}
static void pal3_vtbl_unk_10(UIStatic *, _DWORD)
{
    
}
static void pal3_vtbl_unk_11(UIStatic *, _DWORD)
{
    
}
static void pal3_vtbl_unk_12(UIStatic *, _DWORD)
{
    
}
static void pal3_vtbl_unk_13(UIStatic *, _DWORD)
{
    
}
static void pal3_vtbl_unk_14(UIStatic *, _DWORD)
{
    
}
static void pal3_vtbl_unk_15(UIStatic *, _DWORD)
{
    
}


// 0x005183C0

// ---- synthesized vtable stubs (unresolved slots) ----
// [VFTABLE-STUB] original: ((void ( *)(UIStatic *, _DWORD))v2->__vftable->ShowWindow)(v2, 0)
static void pal3_vtbl_unk_0(UIStatic *, _DWORD);
// [VFTABLE-STUB] original: ((void ( *)(UIStatic *, _DWORD))v3->__vftable->ShowWindow)(v3, 0)
static void pal3_vtbl_unk_1(UIStatic *, _DWORD);
// [VFTABLE-STUB] original: ((void ( *)(UIProgressBar *, _DWORD))v4->__vftable->ShowWindow)(v4, 0)
static void pal3_vtbl_unk_2(UIProgressBar *, _DWORD);
// [VFTABLE-STUB] original: ((void ( *)(UIStatic *, _DWORD))m_pResultWindLvup->__vftable->ShowWindow)(m_pResultWindLvup, 0)
static void pal3_vtbl_unk_3(UIStatic *, _DWORD);
// [VFTABLE-STUB] original: ((void ( *)(UIStatic *, _DWORD))m_pResultThunderLvup->__vftable->ShowWindow)(m_pResultThunderLvup, 0)
static void pal3_vtbl_unk_4(UIStatic *, _DWORD);
// [VFTABLE-STUB] original: ((void ( *)(UIStatic *, _DWORD))m_pResultWaterLvup->__vftable->ShowWindow)(m_pResultWaterLvup, 0)
static void pal3_vtbl_unk_5(UIStatic *, _DWORD);
// [VFTABLE-STUB] original: ((void ( *)(UIStatic *, _DWORD))m_pResultFireLvup->__vftable->ShowWindow)(m_pResultFireLvup, 0)
static void pal3_vtbl_unk_6(UIStatic *, _DWORD);
// [VFTABLE-STUB] original: ((void ( *)(UIStatic *, _DWORD))m_pResultEarthLvup->__vftable->ShowWindow)(m_pResultEarthLvup, 0)
static void pal3_vtbl_unk_7(UIStatic *, _DWORD);
// [VFTABLE-STUB] original: ((void ( *)(UIStatic *, _DWORD))m_pResultDoubleLvup->__vftable->ShowWindow)(m_pResultDoubleLvup, 0)
static void pal3_vtbl_unk_8(UIStatic *, _DWORD);
// [VFTABLE-STUB] original: ((void ( *)(UIStatic *, _DWORD))m_pResultGetItem->__vftable->ShowWindow)(m_pResultGetItem, 0)
static void pal3_vtbl_unk_9(UIStatic *, _DWORD);
// [VFTABLE-STUB] original: ((void ( *)(UIProgressBar *, _DWORD))v12->__vftable->ShowWindow)(v12, 0)
static void pal3_vtbl_unk_10(UIProgressBar *, _DWORD);
// [VFTABLE-STUB] original: ((void ( *)(UIProgressBar *, _DWORD))v13->__vftable->ShowWindow)(v13, 0)
static void pal3_vtbl_unk_11(UIProgressBar *, _DWORD);

BOOL CCBUI::CreateMagicWindow()
{
  UIStatic *v2; // ecx
  UIStatic *v3; // ecx
  UIProgressBar *v4; // ecx
  UIStatic *m_pResultWindLvup; // ecx
  UIStatic *m_pResultThunderLvup; // ecx
  UIStatic *m_pResultWaterLvup; // ecx
  UIStatic *m_pResultFireLvup; // ecx
  UIStatic *m_pResultEarthLvup; // ecx
  UIStatic *m_pResultDoubleLvup; // ecx
  UIStatic *m_pResultGetItem; // ecx
  UIProgressBar *v12; // ecx
  UIProgressBar *v13; // ecx
  int v14; // edi
  CCBControlWindow **p_m_pMain; // esi
  BOOL result; // eax

  v2 = (UIStatic *)this->m_pRoleStateImmunity[4];
  if ( v2 )
    pal3_vtbl_unk_0(v2, 0) /* [VFTABLE-STUB] */;
  v3 = (UIStatic *)this->m_pRoleStateImmunity[5];
  if ( v3 )
    pal3_vtbl_unk_1(v3, 0) /* [VFTABLE-STUB] */;
  v4 = (UIProgressBar *)this->m_pRoleStateMP[0];
  if ( v4 )
    pal3_vtbl_unk_2(v4, 0) /* [VFTABLE-STUB] */;
  m_pResultWindLvup = (UIStatic *)this->m_pResultWindLvup;
  if ( m_pResultWindLvup )
    pal3_vtbl_unk_3(m_pResultWindLvup, 0) /* [VFTABLE-STUB] */;
  m_pResultThunderLvup = (UIStatic *)this->m_pResultThunderLvup;
  if ( m_pResultThunderLvup )
    pal3_vtbl_unk_4(m_pResultThunderLvup, 0) /* [VFTABLE-STUB] */;
  m_pResultWaterLvup = (UIStatic *)this->m_pResultWaterLvup;
  if ( m_pResultWaterLvup )
    pal3_vtbl_unk_5(m_pResultWaterLvup, 0) /* [VFTABLE-STUB] */;
  m_pResultFireLvup = (UIStatic *)this->m_pResultFireLvup;
  if ( m_pResultFireLvup )
    pal3_vtbl_unk_6(m_pResultFireLvup, 0) /* [VFTABLE-STUB] */;
  m_pResultEarthLvup = (UIStatic *)this->m_pResultEarthLvup;
  if ( m_pResultEarthLvup )
    pal3_vtbl_unk_7(m_pResultEarthLvup, 0) /* [VFTABLE-STUB] */;
  m_pResultDoubleLvup = (UIStatic *)this->m_pResultDoubleLvup;
  if ( m_pResultDoubleLvup )
    pal3_vtbl_unk_8(m_pResultDoubleLvup, 0) /* [VFTABLE-STUB] */;
  m_pResultGetItem = (UIStatic *)this->m_pResultGetItem;
  if ( m_pResultGetItem )
    pal3_vtbl_unk_9(m_pResultGetItem, 0) /* [VFTABLE-STUB] */;
  v12 = (UIProgressBar *)this->m_pRoleStateGP[2];
  if ( v12 )
    pal3_vtbl_unk_10(v12, 0) /* [VFTABLE-STUB] */;
  v13 = (UIProgressBar *)this->m_pRoleStateGP[3];
  if ( v13 )
    pal3_vtbl_unk_11(v13, 0) /* [VFTABLE-STUB] */;
  this->CCBUI::CreateResultWindow(0);
  v14 = 0;
  p_m_pMain = (CCBControlWindow **)&this->m_pMain;
  do
  {
    result = (BOOL)*p_m_pMain;
    if ( *p_m_pMain )
    {
      *(_DWORD *)(result + 172) = v14;
      result = p_m_pMain->ShowWindow(0);
    }
    ++v14;
    ++p_m_pMain;
  }
  while ( v14 < 4 );
  return result;
}

static void pal3_vtbl_unk_0(UIStatic *, _DWORD)
{
    
}
static void pal3_vtbl_unk_1(UIStatic *, _DWORD)
{
    
}
static void pal3_vtbl_unk_2(UIProgressBar *, _DWORD)
{
    
}
static void pal3_vtbl_unk_3(UIStatic *, _DWORD)
{
    
}
static void pal3_vtbl_unk_4(UIStatic *, _DWORD)
{
    
}
static void pal3_vtbl_unk_5(UIStatic *, _DWORD)
{
    
}
static void pal3_vtbl_unk_6(UIStatic *, _DWORD)
{
    
}
static void pal3_vtbl_unk_7(UIStatic *, _DWORD)
{
    
}
static void pal3_vtbl_unk_8(UIStatic *, _DWORD)
{
    
}
static void pal3_vtbl_unk_9(UIStatic *, _DWORD)
{
    
}
static void pal3_vtbl_unk_10(UIProgressBar *, _DWORD)
{
    
}
static void pal3_vtbl_unk_11(UIProgressBar *, _DWORD)
{
    
}


// 0x005184C0

// ---- synthesized vtable stubs (unresolved slots) ----
// [VFTABLE-STUB] original: ((int ( *)(UIStatic *, int))m_pResultWindLvup->__vftable->ShowWindow)(m_pResultWindLvup, 1)
static int pal3_vtbl_unk_0(UIStatic *, int);
// [VFTABLE-STUB] original: ((int ( *)(UIStatic *, _DWORD))m_pResultWindLvup->__vftable->ShowWindow)(m_pResultWindLvup, 0)
static int pal3_vtbl_unk_1(UIStatic *, _DWORD);

bool CCBUI::CreateSkillWindow(char pData)
{
  UIStatic *m_pResultWindLvup; // ecx

  m_pResultWindLvup = (UIStatic *)this->m_pResultWindLvup;
  if ( pData )
    return pal3_vtbl_unk_0(m_pResultWindLvup, 1) /* [VFTABLE-STUB] */;
  else
    return pal3_vtbl_unk_1(m_pResultWindLvup, 0) /* [VFTABLE-STUB] */;
}

static int pal3_vtbl_unk_0(UIStatic *, int)
{
    return 0;
}
static int pal3_vtbl_unk_1(UIStatic *, _DWORD)
{
    return 0;
}


// 0x005184E0

// ---- synthesized vtable stubs (unresolved slots) ----
// [VFTABLE-STUB] original: ((void ( *)(CCBControlWindow *, int))v45->__vftable->ShowWindow)(v45, 1)
static void pal3_vtbl_unk_0(CCBControlWindow *, int);

int CCBUI::InitRoleDisplay(int a_128)
{
  int v3; // ebx
  CCBControlWindow **p_m_pMain; // esi
  CCBRoleState *left; // ebp
  NPC *v6; // ecx
  CCBRoleState *v7; // ebp
  char *v8; // eax
  CCBRoleState *v9; // ebp
  CCBRoleState *v10; // ebp
  CCBRoleState *v11; // ebp
  CCBRoleState *v12; // ebp
  CCBSkillWindow *m_pSkillWindow; // edx
  double nEXP; // st7
  CCBControlWindow *v15; // eax
  unsigned int v16; // eax
  int RoleExp; // eax
  int v18; // eax
  int v19; // eax
  int v20; // eax
  int v21; // eax
  int v22; // eax
  int *v23; // eax
  CCBControlWindow *v24; // ebp
  int v25; // ecx
  int v26; // eax
  CCBSkillWindow *v27; // ecx
  unsigned int v28; // eax
  int result; // eax
  bool v30; // cc
  int nVal6; // [esp+0x4] [ebp-0x120]
  int nLevel; // [esp+0x8] [ebp-0x11C]
  char *fValue; // [esp+0xC] [ebp-0x118]
  float fValuea; // [esp+0xC] [ebp-0x118]
  float fValueb; // [esp+0xC] [ebp-0x118]
  float fValuec; // [esp+0xC] [ebp-0x118]
  float fValued; // [esp+0xC] [ebp-0x118]
  float fValuee; // [esp+0xC] [ebp-0x118]
  float fValuef; // [esp+0xC] [ebp-0x118]
  int v40; // [esp+0x20] [ebp-0x104]
  char *v41; // [esp+0x24] [ebp-0x100]
  unsigned int dwID; // [esp+0x28] [ebp-FCh]
  int v43; // [esp+0x2C] [ebp-F8h]
  CCBRoleState *v44; // [esp+0x30] [ebp-F4h]
  CCBControlWindow *v45; // [esp+0x34] [ebp-F0h] BYREF
  float v46; // [esp+0x38] [ebp-ECh]
  float v47; // [esp+0x3C] [ebp-E8h]
  float v48; // [esp+0x40] [ebp-E4h]
  int v49; // [esp+0x44] [ebp-E0h]
  int v50; // [esp+0x54] [ebp-D0h]
  int v51; // [esp+0x5C] [ebp-C8h]
  char Buffer[140]; // [esp+0x64] [ebp-C0h] BYREF
  int v53; // [esp+F0h] [ebp-0x34]
  UICaption *pData[8]; // [esp+F4h] [ebp-0x30] BYREF
  char a2[16]; // [esp+0x114] [ebp-0x10] BYREF

  v3 = 0;
  v43 = 0;
  v40 = 108;
  p_m_pMain = (CCBControlWindow **)&this->m_pMain;
  left = (CCBRoleState *)this->m_pSkillWindow->m_rect.left;
  v44 = (CCBRoleState *)left;
  v41 = (char *)&left->m_pObjMsgBuffer[153];
  do
  {
    if ( !*v41 )
      goto LABEL_21;
    dwID = (((CCBRoleState *)this->m_pSkillWindow->m_rect.left))->CCBRoleState::InitUI(v3)->dwID;
    *((_DWORD *)&(*p_m_pMain)->m_CurCtrl_2 + 13) = v3;
    if ( (((CCBRoleState *)left))->CCBRoleState::GetRoleField(v3, 3) )
    {
      v6 = *(NPC **)((char *)((void **)((*p_m_pMain))) + v40);
    }
    else if ( (((CCBRoleState *)left))->CCBRoleState::GetRoleField(v3, 4) )
    {
      v6 = *(NPC **)((char *)((void **)((*p_m_pMain))) + v40);
    }
    else
    {
      if ( (((CCBRoleState *)left))->CCBRoleState::GetRoleField(v3, 2) )
        goto LABEL_12;
      if ( (((CCBRoleState *)left))->CCBRoleState::GetRoleField(v3, 1) )
      {
        v6 = *(NPC **)((char *)((void **)((*p_m_pMain))) + v40);
      }
      else
      {
        if ( !(((CCBRoleState *)left))->CCBRoleState::GetRoleField(v3, 5) )
        {
LABEL_12:
          v6 = *(NPC **)((char *)((void **)((*p_m_pMain))) + v40);
          goto LABEL_13;
        }
        v6 = *(NPC **)((char *)((void **)((*p_m_pMain))) + v40);
      }
    }
LABEL_13:
    (((NPC *)v6))->NPC::UpdateAnim();
    switch ( dwID )
    {
      case 'e':
        v7 = (CCBRoleState *)this->m_pSkillWindow->m_rect.left;
        fValue = (((PalScript *)g_PAL3_Instance.m_nTodo_140))->PalScript::SetAppName(aLevel);
        nLevel = (((CCBRoleState *)v7))->CCBRoleState::InitUI(v3)->nLevel;
        v8 = (((PalScript *)g_PAL3_Instance.m_nTodo_140))->PalScript::SetAppName("Jingtian");
        goto LABEL_19;
      case 'f':
        v12 = (CCBRoleState *)this->m_pSkillWindow->m_rect.left;
        fValue = (((PalScript *)g_PAL3_Instance.m_nTodo_140))->PalScript::SetAppName(aLevel);
        nLevel = (((CCBRoleState *)v12))->CCBRoleState::InitUI(v3)->nLevel;
        v8 = (((PalScript *)g_PAL3_Instance.m_nTodo_140))->PalScript::SetAppName("Changqing");
        goto LABEL_19;
      case 'h':
        v9 = (CCBRoleState *)this->m_pSkillWindow->m_rect.left;
        fValue = (((PalScript *)g_PAL3_Instance.m_nTodo_140))->PalScript::SetAppName(aLevel);
        nLevel = (((CCBRoleState *)v9))->CCBRoleState::InitUI(v3)->nLevel;
        v8 = (((PalScript *)g_PAL3_Instance.m_nTodo_140))->PalScript::SetAppName("Xuejian");
        goto LABEL_19;
      case 'i':
      case 'j':
        v10 = (CCBRoleState *)this->m_pSkillWindow->m_rect.left;
        fValue = (((PalScript *)g_PAL3_Instance.m_nTodo_140))->PalScript::SetAppName(aLevel);
        nLevel = (((CCBRoleState *)v10))->CCBRoleState::InitUI(v3)->nLevel;
        v8 = (((PalScript *)g_PAL3_Instance.m_nTodo_140))->PalScript::SetAppName("Longkui");
        goto LABEL_19;
      case 'k':
        v11 = (CCBRoleState *)this->m_pSkillWindow->m_rect.left;
        fValue = (((PalScript *)g_PAL3_Instance.m_nTodo_140))->PalScript::SetAppName(aLevel);
        nLevel = (((CCBRoleState *)v11))->CCBRoleState::InitUI(v3)->nLevel;
        v8 = (((PalScript *)g_PAL3_Instance.m_nTodo_140))->PalScript::SetAppName("Zixuan");
LABEL_19:
        sprintf(Buffer, "%s %d %s", v8, nLevel, fValue);
        break;
      default:
        break;
    }
    SetEnable((UICaption *)(*p_m_pMain)->m_pButtonFlee);
    SetEnable((UICaption *)(*p_m_pMain)->m_pButtonLineup);
    (*((UIListBox **)&(*p_m_pMain)->m_CurCtrl_2 + 9))->UIListBox::GetCurSel();
    fValuea = (float)(((CCBRoleState *)this->m_pSkillWindow->m_rect.left))->CCBRoleState::InitUI(v3)->nFullHP;
    (*((UIScrollBar **)&(*p_m_pMain)->m_CurCtrl_2 + 9))->UIScrollBar::SetRange(fValuea);
    fValueb = (float)(((CCBRoleState *)this->m_pSkillWindow->m_rect.left))->CCBRoleState::InitUI(v3)->nHP;
    (*((UIProgressBar **)&(*p_m_pMain)->m_CurCtrl_2 + 9))->UIProgressBar::FindChildByName(fValueb);
    (*((UIListBox **)&(*p_m_pMain)->m_CurCtrl_2 + 10))->UIListBox::GetCurSel();
    fValuec = (float)(int)(((CCBRoleState *)this->m_pSkillWindow->m_rect.left))->CCBRoleState::InitUI(v3)->pCCBSystem;
    (*((UIScrollBar **)&(*p_m_pMain)->m_CurCtrl_2 + 10))->UIScrollBar::SetRange(fValuec);
    fValued = (float)(((CCBRoleState *)this->m_pSkillWindow->m_rect.left))->CCBRoleState::InitUI(v3)->nGP;
    (*((UIProgressBar **)&(*p_m_pMain)->m_CurCtrl_2 + 10))->UIProgressBar::FindChildByName(fValued);
    (*((UIListBox **)&(*p_m_pMain)->m_CurCtrl_2 + 11))->UIListBox::GetCurSel();
    fValuee = (float)(((CCBRoleState *)this->m_pSkillWindow->m_rect.left))->CCBRoleState::InitUI(v3)->nFullMP;
    (*((UIScrollBar **)&(*p_m_pMain)->m_CurCtrl_2 + 11))->UIScrollBar::SetRange(fValuee);
    fValuef = (float)(int)(((CCBRoleState *)this->m_pSkillWindow->m_rect.left))->CCBRoleState::InitUI(v3)->nMP;
    (*((UIProgressBar **)&(*p_m_pMain)->m_CurCtrl_2 + 11))->UIProgressBar::FindChildByName(fValuef);
    m_pSkillWindow = (CCBSkillWindow *)this->m_pSkillWindow;
    pData[1] = 0;
    nEXP = (double)(((CCBRoleState *)m_pSkillWindow->m_rect.left))->CCBRoleState::InitUI(v3)->nEXP;
    v15 = (CCBControlWindow *)*p_m_pMain;
    *(float *)&pData[3] = nEXP;
    pData[0] = (UICaption *)v15->m_pButtonAI;
    SetEnable(pData[0]);
    v16 = (((CCBSystem *)this->m_pSkillWindow))->CCBSystem::ProcProtect();
    this->CCBUI::IsResultWindowClosed(0 /* TODO: (int)CCBUI::ShowControlWindow */, 0, 0, 0, v16, 0, 0x40000000, pData);
    RoleExp = (((CCBRoleState *)this->m_pSkillWindow->m_rect.left))->CCBRoleState::GetRoleExp(v3);
    sprintf(Buffer, &dir[20], RoleExp);
    SetEnable((UICaption *)(*p_m_pMain)->m_pButtonAttack);
    v18 = (((CCBRoleState *)this->m_pSkillWindow->m_rect.left))->CCBRoleState::GetRoleExp(v3);
    sprintf(Buffer, &dir[20], v18);
    SetEnable((UICaption *)(*p_m_pMain)->m_pButtonSkill);
    v19 = (((CCBRoleState *)this->m_pSkillWindow->m_rect.left))->CCBRoleState::GetRoleExp(v3);
    sprintf(Buffer, &dir[20], v19);
    SetEnable((UICaption *)(*p_m_pMain)->m_pButtonMagic);
    v20 = (((CCBRoleState *)this->m_pSkillWindow->m_rect.left))->CCBRoleState::GetRoleExp(v3);
    sprintf(Buffer, &dir[20], v20);
    SetEnable((UICaption *)(*p_m_pMain)->m_pButtonItem);
    v21 = (((CCBRoleState *)this->m_pSkillWindow->m_rect.left))->CCBRoleState::GetRoleExp(v3);
    sprintf(Buffer, &dir[20], v21);
    SetEnable((UICaption *)(*p_m_pMain)->m_pButtonDefence);
    v22 = (((CCBRoleState *)this->m_pSkillWindow->m_rect.left))->CCBRoleState::GetRoleExp(v3);
    sprintf(Buffer, &dir[20], v22);
    SetEnable((UICaption *)(*p_m_pMain)->m_pButtonLineup);
    v23 = (int *)sub_445FE0(a2);
    v24 = (CCBControlWindow *)*p_m_pMain;
    v50 = (unsigned long)*v23;
    v25 = (unsigned long)v23[1];
    v51 = (unsigned long)v23[2];
    v26 = (unsigned long)v23[3];
    v49 = 0;
    v46 = (float)v50;
    v45 = (CCBControlWindow *)v24;
    v47 = -(double)(v26 - v25);
    v48 = v46;
    sub_445D20(v24, (__int64)v46, (__int64)v47);
    pal3_vtbl_unk_0(v45, 1) /* [VFTABLE-STUB] */;
    v27 = (CCBSkillWindow *)this->m_pSkillWindow;
    v53 = 0;
    *(float *)&nVal6 = (double)v43 * 0.079999998;
    v28 = (((CCBSystem *)v27))->CCBSystem::ProcProtect();
    this->CCBUI::IsResultWindowClosed(0 /* TODO: (int)CCBUI::ShowBattleFieldAttr */, 0, 0, v53, v28, nVal6, 1161527296, &v45);
    left = (CCBRoleState *)v44;
    ++p_m_pMain;
    ++v43;
LABEL_21:
    result = v40 + 4;
    ++v3;
    v30 = v40 + 4 < 128;
    v40 += 4;
    v41 += 892;
  }
  while ( v30 );
  return result;
}

static void pal3_vtbl_unk_0(CCBControlWindow *, int)
{
    
}


// 0x00518AF0

// ---- synthesized vtable stubs (unresolved slots) ----
// [VFTABLE-STUB] original: ((int ( *)(UIStatic *, int))m_pResultEarthLvup->__vftable->ShowWindow)(m_pResultEarthLvup, 1)
static int pal3_vtbl_unk_0(UIStatic *, int);
// [VFTABLE-STUB] original: ((int ( *)(UIStatic *, _DWORD))m_pResultEarthLvup->__vftable->ShowWindow)(m_pResultEarthLvup, 0)
static int pal3_vtbl_unk_1(UIStatic *, _DWORD);

bool CCBUI::CreateLineupWindow(int nVal, char pData)
{
  UIStatic *m_pResultEarthLvup; // ecx

  this->m_pResultEarthLvup->m_ppicInfo = (_PlugInfo *)nVal;
  m_pResultEarthLvup = (UIStatic *)this->m_pResultEarthLvup;
  if ( pData )
    return pal3_vtbl_unk_0(m_pResultEarthLvup, 1) /* [VFTABLE-STUB] */;
  else
    return pal3_vtbl_unk_1(m_pResultEarthLvup, 0) /* [VFTABLE-STUB] */;
}

static int pal3_vtbl_unk_0(UIStatic *, int)
{
    return 0;
}
static int pal3_vtbl_unk_1(UIStatic *, _DWORD)
{
    return 0;
}


// 0x00518B20
bool CCBUI::CreateProtectWindow()
{
  return *((_BYTE *)&this->m_pMain->m_CurCtrl_2 + 56);
}

// 0x00518B30
bool CCBUI::CreateResultWindow(char pData)
{
  int i; // edi
  bool result; // al
  int byUIIndex; // ebx
  UIStatic **v6; // edi
  int v7; // ebx
  UIStatic **v8; // edi
  int v9; // ebx
  UIStatic **v10; // esi
  int v11; // edi

  if ( pData )
  {
    for ( i = 0; i < 5; ++i )
    {
      result = *(_BYTE *)(this->m_pSkillWindow->m_rect.left + 892 * i + 577);
      if ( result )
      {
        ((void ( *)(UIStatic *, int))this->m_pAttackSequenFace[i + 8]->__vftable->ShowWindow)(
          this->m_pAttackSequenFace[i + 8],
          1);
        ((void ( *)(UIStatic *, int))this->m_pRoleStatePanel[i + 2]->__vftable->ShowWindow)(
          this->m_pRoleStatePanel[i + 2],
          1);
        byUIIndex = (unsigned __int8)(((CCBRoleState *)this->m_pSkillWindow->m_rect.left))->CCBRoleState::InitUI(i)->byUIIndex;
        ((void ( *)(UIStatic *, int))this->m_pRoleStateImmunity[byUIIndex + 6]->__vftable->ShowWindow)(
          this->m_pRoleStateImmunity[byUIIndex + 6],
          1);
        ((void ( *)(UIStatic *, int))this->m_pRoleStateImmunity[byUIIndex + 10]->__vftable->ShowWindow)(
          this->m_pRoleStateImmunity[byUIIndex + 10],
          1);
        ((void ( *)(UIProgressBar *, int))this->m_pRoleStateHP[byUIIndex + 1]->__vftable->ShowWindow)(
          this->m_pRoleStateHP[byUIIndex + 1],
          1);
        result = ((int ( *)(UIStatic *, int))this->m_pAttackSequenFace[byUIIndex + 4]->__vftable->ShowWindow)(
                   this->m_pAttackSequenFace[byUIIndex + 4],
                   1);
        if ( !i )
          result = ((int ( *)(UIProgressBar *, int))this->m_pRoleStateGP[1]->__vftable->ShowWindow)(
                     this->m_pRoleStateGP[1],
                     1);
      }
    }
  }
  else
  {
    ((void ( *)(UIProgressBar *, _DWORD))this->m_pRoleStateGP[1]->__vftable->ShowWindow)(
      this->m_pRoleStateGP[1],
      0);
    v6 = (UIStatic **)&this->m_pRoleStateImmunity[10];
    v7 = 4;
    do
    {
      ((void ( *)(_DWORD, _DWORD))(*(v6 - 4))->__vftable->ShowWindow)(*(v6 - 4), 0);
      v6->ShowWindow(0);
      ((void ( *)(UIStatic *, _DWORD))v6[4]->__vftable->ShowWindow)(v6[4], 0);
      ((void ( *)(_DWORD, _DWORD))(*(v6 - 229))->__vftable->ShowWindow)(*(v6 - 229), 0);
      ++v6;
      --v7;
    }
    while ( v7 );
    v8 = (UIStatic **)&this->m_pRoleStatePanel[2];
    v9 = 5;
    do
    {
      ((void ( *)(_DWORD, _DWORD))(*(v8 - 5))->__vftable->ShowWindow)(*(v8 - 5), 0);
      v8->ShowWindow(0);
      ++v8;
      --v9;
    }
    while ( v9 );
    v10 = (UIStatic **)&this->m_pRoleStateAttackInc[4];
    v11 = 11;
    do
    {
      ((void ( *)(_DWORD, _DWORD))(*(v10 - 11))->__vftable->ShowWindow)(*(v10 - 11), 0);
      v10->ShowWindow(0);
      ((void ( *)(UIStatic *, _DWORD))v10[11]->__vftable->ShowWindow)(v10[11], 0);
      ((void ( *)(UIStatic *, _DWORD))v10[22]->__vftable->ShowWindow)(v10[22], 0);
      ((void ( *)(UIStatic *, _DWORD))v10[55]->__vftable->ShowWindow)(v10[55], 0);
      ((void ( *)(UIStatic *, _DWORD))v10[66]->__vftable->ShowWindow)(v10[66], 0);
      ((void ( *)(UIStatic *, _DWORD))v10[33]->__vftable->ShowWindow)(v10[33], 0);
      ((void ( *)(UIStatic *, _DWORD))v10[44]->__vftable->ShowWindow)(v10[44], 0);
      ((void ( *)(UIStatic *, _DWORD))v10[77]->__vftable->ShowWindow)(v10[77], 0);
      ((void ( *)(UIStatic *, _DWORD))v10[88]->__vftable->ShowWindow)(v10[88], 0);
      ((void ( *)(UIStatic *, _DWORD))v10[99]->__vftable->ShowWindow)(v10[99], 0);
      ((void ( *)(UIStatic *, _DWORD))v10[110]->__vftable->ShowWindow)(v10[110], 0);
      ((void ( *)(UIStatic *, _DWORD))v10[121]->__vftable->ShowWindow)(v10[121], 0);
      ((void ( *)(UIStatic *, _DWORD))v10[132]->__vftable->ShowWindow)(v10[132], 0);
      ((void ( *)(UIStatic *, _DWORD))v10[143]->__vftable->ShowWindow)(v10[143], 0);
      ((void ( *)(UIStatic *, _DWORD))v10[154]->__vftable->ShowWindow)(v10[154], 0);
      ((void ( *)(UIStatic *, _DWORD))v10[165]->__vftable->ShowWindow)(v10[165], 0);
      ((void ( *)(UIStatic *, _DWORD))v10[176]->__vftable->ShowWindow)(v10[176], 0);
      result = ((int ( *)(UIStatic *, _DWORD))v10[187]->__vftable->ShowWindow)(v10[187], 0);
      ++v10;
      --v11;
    }
    while ( v11 );
  }
  return result;
}

// 0x00518D40

// ---- synthesized vtable stubs (unresolved slots) ----
// [VFTABLE-STUB] original: ((int ( *)(UIStatic *, _DWORD))this->m_pResultDoubleLvup->__vftable->ShowWindow)( this->m_pResultDoubleLvup, 0)
static int pal3_vtbl_unk_0(UIStatic *, _DWORD);
// [VFTABLE-STUB] original: (***(void ( ****)(_DWORD, int))((char *)&this->m_pResultDoubleLvup->__vftable + i))( *(vtbl_0056AE2C **)((char *)&this->m_pResultDoubleLvup->__vftable + i), 1)
static void pal3_vtbl_unk_1(_DWORD, int);
// [VFTABLE-STUB] original: (***(void ( ****)(_DWORD, _DWORD))((char *)&this->m_pResultDoubleLvup->__vftable + i))( *(vtbl_0056AE2C **)((char *)&this->m_pResultDoubleLvup->__vftable + i), 0)
static void pal3_vtbl_unk_2(_DWORD, _DWORD);
// [VFTABLE-STUB] original: ((int ( *)(UIStatic *, int))this->m_pResultDoubleLvup->__vftable->ShowWindow)( this->m_pResultDoubleLvup, 1)
static int pal3_vtbl_unk_3(UIStatic *, int);

bool CCBUI::CreateFiveNimbus(char pData)
{
  int v3; // ebx
  int v4; // ebp
  int i; // esi

  if ( !pData )
    return pal3_vtbl_unk_0(this->m_pResultDoubleLvup, 0) /* [VFTABLE-STUB] */;
  v3 = 0;
  v4 = 0;
  for ( i = 96; i < 116; i += 4 )
  {
    if ( *(_BYTE *)(this->m_pSkillWindow->m_rect.left + v4 + 577) )
    {
      pal3_vtbl_unk_1(*(void **)((char *)((void **)(this->m_pResultDoubleLvup)) + i), 1) /* [VFTABLE-STUB] */;
      *(_DWORD *)((char *)this->m_pResultDoubleLvup + i - 24) = *(_DWORD *)&(((CCBRoleState *)this->m_pSkillWindow->m_rect.left))->CCBRoleState::InitUI(v3)->byMagicUseTime[8][3];
      sub_445D20(
        *(_DWORD **)((char *)((void **)(this->m_pResultDoubleLvup)) + i),
        g_nUnkTable_24C[*(_DWORD *)((char *)this->m_pResultDoubleLvup + i - 24)] + 9,
        g_nUnkTable_268[*(_DWORD *)((char *)this->m_pResultDoubleLvup + i - 24)] + 232);
    }
    else
    {
      pal3_vtbl_unk_2(*(void **)((char *)((void **)(this->m_pResultDoubleLvup)) + i), 0) /* [VFTABLE-STUB] */;
    }
    ++v3;
    v4 += 892;
  }
  return pal3_vtbl_unk_3(this->m_pResultDoubleLvup, 1) /* [VFTABLE-STUB] */;
}

static int pal3_vtbl_unk_0(UIStatic *, _DWORD)
{
    return 0;
}
static void pal3_vtbl_unk_1(_DWORD, int)
{
    
}
static void pal3_vtbl_unk_2(_DWORD, _DWORD)
{
    
}
static int pal3_vtbl_unk_3(UIStatic *, int)
{
    return 0;
}


// 0x00518E60
void CCBUI::HideAll()
{
  NPC **v1; // esi
  int v2; // ebx

  v1 = (NPC **)&this->m_pRoleStateAttackInc[4];
  v2 = 4;
  do
  {
    NPC::UpdateAnim(*(v1 - 11));
    NPC::UpdateAnim(*v1);
    (((NPC *)v1[11]))->NPC::UpdateAnim();
    (((NPC *)v1[22]))->NPC::UpdateAnim();
    (((NPC *)v1[33]))->NPC::UpdateAnim();
    (((NPC *)v1[44]))->NPC::UpdateAnim();
    (((NPC *)v1[55]))->NPC::UpdateAnim();
    (((NPC *)v1[66]))->NPC::UpdateAnim();
    (((NPC *)v1[77]))->NPC::UpdateAnim();
    (((NPC *)v1[88]))->NPC::UpdateAnim();
    (((NPC *)v1[99]))->NPC::UpdateAnim();
    (((NPC *)v1[110]))->NPC::UpdateAnim();
    (((NPC *)v1[121]))->NPC::UpdateAnim();
    (((NPC *)v1[132]))->NPC::UpdateAnim();
    (((NPC *)v1[143]))->NPC::UpdateAnim();
    (((NPC *)v1[154]))->NPC::UpdateAnim();
    (((NPC *)v1[165]))->NPC::UpdateAnim();
    (((NPC *)v1[176]))->NPC::UpdateAnim();
    (((NPC *)v1[187]))->NPC::UpdateAnim();
    ++v1;
    --v2;
  }
  while ( v2 );
}

// 0x00518FE0
void CCBUI::ShowBattleFieldAttr(int attr)
{
  CCBLineupWindow **v2; // esi
  CCBSkillWindow *m_pSkillWindow; // ecx
  double v4; // st6
  double v5; // st7
  double v6; // st7

  v2 = (CCBLineupWindow **)(&this->m_pLineupWindow + 18 * *((_DWORD *)&this->fp + 5));
  if ( !BYTE1(this->m_pResultWindow[18 * *((_DWORD *)&this->fp + 5) + 2]) )
  {
    this->m_pResultWindow[18 * *((_DWORD *)&this->fp + 5) + 4] = (CCBResultWindow *)this->m_pSkillWindow->m_pSkillList[0];
    *((_BYTE *)v2 + 17) = 1;
  }
  m_pSkillWindow = (CCBSkillWindow *)this->m_pSkillWindow;
  v4 = *((float *)v2 + 7) + *((float *)v2 + 6);
  if ( *(float *)m_pSkillWindow->m_pSkillList > v4 )
  {
    v5 = *(float *)m_pSkillWindow->m_pSkillList - v4;
    v6 = v5 * (v5 * *((float *)v2 + 8)) * 0.5 + *((float *)v2 + 11);
    if ( v6 > *((float *)v2 + 13) )
    {
      v6 = *((float *)v2 + 13);
      *((_BYTE *)v2 + 18) = 1;
    }
    sub_445D20(v2[9], (__int64)*((float *)v2 + 10), (__int64)v6);
  }
}

// 0x00519080
void CCBUI::ShowControlWindow(int bShow)
{
  CCBLineupWindow **v2; // esi
  double v3; // st6
  float v4; // [esp+0x8] [ebp-0x8]
  float v5; // [esp+0xC] [ebp-0x4]

  v2 = (CCBLineupWindow **)(&this->m_pLineupWindow + 18 * *((_DWORD *)&this->fp + 5));
  if ( !BYTE1(this->m_pResultWindow[18 * *((_DWORD *)&this->fp + 5) + 2]) )
  {
    this->m_pResultWindow[18 * *((_DWORD *)&this->fp + 5) + 4] = (CCBResultWindow *)this->m_pSkillWindow->m_pSkillList[0];
    *((_BYTE *)v2 + 17) = 1;
  }
  v3 = *((float *)v2 + 7) + *((float *)v2 + 6);
  if ( *(float *)this->m_pSkillWindow->m_pSkillList > v3 )
  {
    v5 = (*(float *)this->m_pSkillWindow->m_pSkillList - v3) / *((float *)v2 + 8);
    v4 = (*((float *)v2 + 12) - *((float *)v2 + 10)) * v5 + *((float *)v2 + 10);
    sprintf(byte_17ACB08, &dir[20], (int)v4);
    SetEnable((UICaption *)v2[9]);
    if ( v5 >= 1.0 )
    {
      sprintf(byte_17ACB08, &dir[20], (int)*((float *)v2 + 12));
      SetEnable((UICaption *)v2[9]);
      *((_BYTE *)v2 + 18) = 1;
    }
  }
}

// 0x00519200
void CCBUI::ShowDialogWindow()
{
  int v2; // esi
  _BYTE *v3; // edi

  v2 = 0;
  v3 = (char *)&this->m_pResultWindow[2] + 2;
  do
  {
    if ( *(v3 - 2) == 1 && *v3 == 1 )
      this->CCBUI::ShowAIWindow(v2);
    ++v2;
    v3 += 72;
  }
  while ( v2 < 20 );
}

// 0x00519230
void CCBUI::ShowAIWindow(int nRoleIndex)
{
  LOBYTE(this->m_pResultWindow[18 * nRoleIndex + 2]) = 0;
  --*((_DWORD *)&this->fp + 4);
}

// 0x00519260
bool CCBUI::IsResultWindowClosed(
        
        int nVal,
        int nVal2,
        int nVal3,
        int nVal4,
        int nVal5,
        int nVal6,
        int nVal7,
        const void *pData)
{
  int v10; // eax
  CCBResultWindow **i; // ecx
  UIFrameWnd *v13; // eax

  if ( *((int *)&this->fp + 4) >= 19 )
    return 0;
  v10 = 0;
  for ( i = &this->m_pResultWindow[2]; *(_BYTE *)i; i += 18 )
  {
    if ( ++v10 >= 20 )
      return 0;
  }
  v13 = (CCBUI *)((char *)this + 72 * v10);
  LOBYTE(v13[16].m_pfather) = 1;
  BYTE1(v13[16].m_pfather) = 0;
  BYTE2(v13[16].m_pfather) = 0;
  v13[16].m_childs.m_nSize = nVal6;
  v13[16].m_childs.m_needscriptdel = nVal7;
  v13[16].m_childs.m_pData = (char *)nVal5;
  qmemcpy(&v13[16].m_bcreateok, pData, 0x20u);
  v13 = (UIFrameWnd *)((char *)v13 + 1168);
  (*(void **)(v13)) = (void *)nVal;
  v13->m_fontcolor.Color = nVal2;
  v13->m_wndcolor.Color = nVal3;
  v13->m_id = (void *)nVal4;
  ++*((_DWORD *)&this->fp + 4);
  return 1;
}

// 0x00519310
int * CCBUI::ctor()
{
  this->CCBUI::ClearAttackSequence();
  return (int *)this;
}

// 0x00519380
void CCBUI::Release()
{
  this->CCBUI::ClearAttackSequence();
  (((UIListBox *)this))->UIListBox::~UIListBox() /* [ROWTABLE] */;
}

// 0x005193D0
void CCBUI::ClearAttackSequence()
{
  this->m_pAttackSequenBack = 0;
  this->pPanel = 0;
  this->m_pBattleFieldAttr[0] = 0;
  this->m_pBattleFieldAttr[1] = 0;
  this->m_pBattleFieldAttr[2] = 0;
  this->m_pBattleFieldAttr[3] = 0;
  this->m_pBattleFieldAttr[4] = 0;
  this->m_pBattleFieldAttr[5] = 0;
  this->m_pAttackSequenFace[0] = 0;
  this->m_pAttackSequenFace[1] = 0;
  this->m_pAttackSequenFace[2] = 0;
}

// 0x00519400

// ---- synthesized vtable stubs (unresolved slots) ----
// [VFTABLE-STUB] original: ((void ( *)(UIStatic *, int, int, CCBUI *))this->m_pAttackSequenBack->__vftable->Create)( this->m_pAttackSequenBack, 256, nCount, this)
static void pal3_vtbl_unk_0(UIStatic *, int, int, CCBUI *);
// [VFTABLE-STUB] original: ((void ( *)(UIStatic *, int))this->m_pAttackSequenBack->__vftable->ShowWindow)(this->m_pAttackSequenBack, 1)
static void pal3_vtbl_unk_1(UIStatic *, int);

void CCBUI::CreateImbibeNimbus(int nCount)
{
  void *v3; // eax
  UIStatic *v4; // eax
  char pExceptionObject[1024]; // [esp+0xC] [ebp-0x80C] BYREF
  char ArgList; // [esp+0x40C] [ebp-0x40C] BYREF
  int v7; // [esp+0x814] [ebp-0x4]
  int parent; // [esp+0x820] [ebp+0x8]

  (((CCBItemWindow *)this))->CCBItemWindow::Create(1879048193, (tagRECT *)nCount, parent) /* [ROWTABLE] */;
  v3 = (void *)operator new(0x98u);
  v7 = 0;
  if ( v3 )
    sub_4422E0(v3);
  else
    v4 = 0;
  v7 = -1;
  this->m_pAttackSequenBack = v4;
  if ( !v4 )
  {
    qmemcpy(
      pExceptionObject,
      (((Logger *)&ArgList))->Logger::FormatException((char *)&g_EffMgrData.m_nEffParam_0338 + 16, aDProjectPal3Co_7, 2090),
      sizeof(pExceptionObject));
    _CxxThrowException(pExceptionObject, (_ThrowInfo *)&_TI1_AV_Exception__);
  }
  *(_DWORD *)nCount = 0;
  *(_DWORD *)(nCount + 8) = 256;
  *(_DWORD *)(nCount + 4) = 0;
  *(_DWORD *)(nCount + 12) = 256;
  pal3_vtbl_unk_0(this->m_pAttackSequenBack, 256, nCount, this) /* [VFTABLE-STUB] */;
  (((UIStatic *)this->m_pAttackSequenBack))->UIStatic::CreateFromTemplate(&unk_5DF204, 0);
  pal3_vtbl_unk_1(this->m_pAttackSequenBack, 1) /* [VFTABLE-STUB] */;
  this->CCBUI::SetNimbusToNimbusControl();
}

static void pal3_vtbl_unk_0(UIStatic *, int, int, CCBUI *)
{
    
}
static void pal3_vtbl_unk_1(UIStatic *, int)
{
    
}


// 0x005196C0

// ---- synthesized vtable stubs (unresolved slots) ----
// [VFTABLE-STUB] original: ((void ( *)(UIStatic *, int))this->pPanel->__vftable->ShowWindow)(this->pPanel, 1)
static void pal3_vtbl_unk_0(UIStatic *, int);

void CCBUI::SetNimbusToNimbusControl()
{
  UIStatic **v2; // edi

  v2 = (UIStatic **)&this->m_pAttackSequenFace[2];
  this->CCBUI::WriteNimbusToPlayerMgr();
  v2->ShowWindow(0);
  this->CCBUI::WriteNimbusToPlayerMgr();
  pal3_vtbl_unk_0(this->pPanel, 1) /* [VFTABLE-STUB] */;
  (((PalScript *)this->pPanel))->PalScript::OpenScript("ui\\combat\\control\\attack3.tga", 0);
  this->CCBUI::WriteNimbusToPlayerMgr();
  ((void ( *)(UIStatic *, int))this->m_pBattleFieldAttr[0]->__vftable->ShowWindow)(
    this->m_pBattleFieldAttr[0],
    1);
  (((PalScript *)this->m_pBattleFieldAttr[0]))->PalScript::OpenScript("ui\\combat\\control\\skill3.tga", 0);
  this->CCBUI::WriteNimbusToPlayerMgr();
  ((void ( *)(UIStatic *, int))this->m_pBattleFieldAttr[1]->__vftable->ShowWindow)(
    this->m_pBattleFieldAttr[1],
    1);
  (((PalScript *)this->m_pBattleFieldAttr[1]))->PalScript::OpenScript("ui\\combat\\control\\magic3.tga", 0);
  this->CCBUI::WriteNimbusToPlayerMgr();
  ((void ( *)(UIStatic *, int))this->m_pBattleFieldAttr[2]->__vftable->ShowWindow)(
    this->m_pBattleFieldAttr[2],
    1);
  (((PalScript *)this->m_pBattleFieldAttr[2]))->PalScript::OpenScript("ui\\combat\\control\\item3.tga", 0);
  this->CCBUI::WriteNimbusToPlayerMgr();
  ((void ( *)(UIStatic *, int))this->m_pBattleFieldAttr[4]->__vftable->ShowWindow)(
    this->m_pBattleFieldAttr[4],
    1);
  (((PalScript *)this->m_pBattleFieldAttr[4]))->PalScript::OpenScript("ui\\combat\\control\\lineup3.tga", 0);
  this->CCBUI::WriteNimbusToPlayerMgr();
  ((void ( *)(UIStatic *, int))this->m_pBattleFieldAttr[5]->__vftable->ShowWindow)(
    this->m_pBattleFieldAttr[5],
    1);
  (((PalScript *)this->m_pBattleFieldAttr[5]))->PalScript::OpenScript("ui\\combat\\control\\ai3.tga", 0);
  this->CCBUI::WriteNimbusToPlayerMgr();
  ((void ( *)(UIStatic *, int))this->m_pAttackSequenFace[0]->__vftable->ShowWindow)(
    this->m_pAttackSequenFace[0],
    1);
  (((PalScript *)this->m_pAttackSequenFace[0]))->PalScript::OpenScript("ui\\combat\\control\\flee3.tga", 0);
  this->CCBUI::WriteNimbusToPlayerMgr();
  ((void ( *)(UIStatic *, int))this->m_pAttackSequenFace[1]->__vftable->ShowWindow)(
    this->m_pAttackSequenFace[1],
    1);
  (((PalScript *)this->m_pAttackSequenFace[1]))->PalScript::OpenScript("ui\\combat\\control\\protect3.tga", 0);
  this->CCBUI::WriteNimbusToPlayerMgr();
  ((void ( *)(UIStatic *, int))this->m_pBattleFieldAttr[3]->__vftable->ShowWindow)(
    this->m_pBattleFieldAttr[3],
    1);
  (((PalScript *)this->m_pBattleFieldAttr[3]))->PalScript::OpenScript("ui\\combat\\control\\defence3.tga", 0);
}

static void pal3_vtbl_unk_0(UIStatic *, int)
{
    
}


// 0x00519A10
void CCBUI::WriteNimbusToPlayerMgr()
{
  NameSys *Sys; // eax
  char pExceptionObject[1024]; // [esp+0x8] [ebp-0x80C] BYREF
  char ArgList; // [esp+0x408] [ebp-0x40C] BYREF
  int v5; // [esp+0x810] [ebp-0x4]
  NameSys **v6; // [esp+0x818] [ebp+0x4]
  int v7; // [esp+0x81C] [ebp+0x8]
  int v8; // [esp+0x820] [ebp+0xC]
  int v9; // [esp+0x824] [ebp+0x10]

  v5 = 0;
  if ( operator new(0x158u) )
    Sys = (NameSys *)NameSys::GetSys();
  else
    Sys = 0;
  v5 = -1;
  *v6 = Sys;
  if ( !Sys )
  {
    qmemcpy(
      pExceptionObject,
      (((Logger *)&ArgList))->Logger::FormatException(&path[164], aDProjectPal3Co_7, 2306),
      sizeof(pExceptionObject));
    _CxxThrowException(pExceptionObject, (_ThrowInfo *)&_TI1_AV_Exception__);
  }
  (*(void ( **)(NameSys *, int, int, CCBUI *, int, int, _DWORD))(*(_DWORD *)Sys->m_Flag + 28))(
    Sys,
    v7,
    v8,
    this,
    v9,
    1,
    0);
}

// 0x00519BB0
void CCBUI::Render()
{
  this->m_pBattleFieldAttr[0] = 0;
  this->m_pBattleFieldAttr[1] = 0;
  this->m_pBattleFieldAttr[2] = 0;
  this->m_pAttackSequenBack = 0;
  this->pPanel = 0;
  this->m_pBattleFieldAttr[3] = 0;
  this->m_pBattleFieldAttr[4] = 0;
  this->m_pBattleFieldAttr[5] = 0;
}

// 0x00519BD0

// ---- synthesized vtable stubs (unresolved slots) ----
// [VFTABLE-STUB] original: ((void ( *)(UIStatic *, int, int, CCBUI *))v9->m_pAttackSequenBack->__vftable->Create)( v9->m_pAttackSequenBack, 131, parent, v9)
static void pal3_vtbl_unk_0(UIStatic *, int, int, CCBUI *);
// [VFTABLE-STUB] original: ((void ( *)(UIStatic *, int))v9->m_pAttackSequenBack->__vftable->ShowWindow)(v9->m_pAttackSequenBack, 1)
static void pal3_vtbl_unk_1(UIStatic *, int);
// [VFTABLE-STUB] original: ((void ( *)(UIStatic *, int, int, CCBUI *))v9->pPanel->__vftable->Create)(v9->pPanel, 131, parent, v9)
static void pal3_vtbl_unk_2(UIStatic *, int, int, CCBUI *);
// [VFTABLE-STUB] original: ((void ( *)(UIStatic *, int))v9->pPanel->__vftable->ShowWindow)(v9->pPanel, 1)
static void pal3_vtbl_unk_3(UIStatic *, int);

bool CCBUI::CreateButton(int parent, int id, int rc, int picname, UIButton **a6, int nVal)
{
  CCBItemWindow *v6; // ecx
  _EXCEPTION_REGISTRATION_RECORD *ExceptionList; // eax
  void *v8; // esp
  CCBUI *v9; // ebp
  void *v10; // eax
  UIStatic *v11; // eax
  int *v12; // ebx
  UIListBox **m_pBattleFieldAttr; // esi
  UIListBox *v14; // eax
  UIListBox *updated; // eax
  _DWORD *v16; // eax
  void *v17; // eax
  UIStatic *v18; // eax
  _BYTE pExceptionObject[1040]; // [esp+0x40] [ebp-0x100C] BYREF
  char v21; // [esp+0x450] [ebp-BFCh] BYREF
  char v22[1024]; // [esp+0x850] [ebp-0x7FC] BYREF
  char v23; // [esp+C50h] [ebp-0x3FC] BYREF
  _EXCEPTION_REGISTRATION_RECORD *v24; // [esp+0x1040] [ebp-0xC]
  void *v25; // [esp+0x1044] [ebp-0x8]
  int v26; // [esp+0x1048] [ebp-0x4]

  v26 = -1;
  ExceptionList = NtCurrentTeb()->NtTib.ExceptionList;
  v25 = ((void*)0);
  v24 = (_EXCEPTION_REGISTRATION_RECORD *)ExceptionList;
  v8 = alloca(4120);
  v9 = (CCBUI *)v6;
  (((CCBItemWindow *)v6))->CCBItemWindow::Create(1879048193, (tagRECT *)parent, id);
  v10 = (void *)operator new(0x98u);
  v26 = 0;
  if ( v10 )
    sub_4422E0(v10);
  else
    v11 = 0;
  v26 = -1;
  v9->m_pAttackSequenBack = v11;
  if ( !v11 )
  {
    qmemcpy(
      pExceptionObject,
      (((Logger *)&pExceptionObject[1024]))->Logger::FormatException((char *)&g_EffMgrData.m_nEffParam_0338 + 16, aDProjectPal3Co_7, 2366),
      0x400u);
    _CxxThrowException(pExceptionObject, (_ThrowInfo *)&_TI1_AV_Exception__);
  }
  *(_DWORD *)parent = 0;
  *(_DWORD *)(parent + 8) = 249;
  *(_DWORD *)(parent + 4) = 0;
  *(_DWORD *)(parent + 12) = 206;
  pal3_vtbl_unk_0(v9->m_pAttackSequenBack, 131, parent, v9) /* [VFTABLE-STUB] */;
  (((UIStatic *)v9->m_pAttackSequenBack))->UIStatic::CreateFromTemplate(&unk_5DEF70, 0);
  (((UIScene *)v9->m_pAttackSequenBack))->UIScene::SetShow(0);
  sub_446010(v9->m_pAttackSequenBack);
  (((UIFrameWnd *)v9->m_pAttackSequenBack))->UIFrameWnd::SetPosition(40,   150);
  (((UIFrameWnd *)v9->m_pAttackSequenBack))->UIFrameWnd::SetPosition(0,   0);
  pal3_vtbl_unk_1(v9->m_pAttackSequenBack, 1) /* [VFTABLE-STUB] */;
  v12 = (int *)&g_nSkillItemIDTable[15];
  m_pBattleFieldAttr = (UIListBox **)v9->m_pBattleFieldAttr;
  do
  {
    v14 = (UIListBox *)operator new(0x4B8u);
    if ( v14 )
      updated = (((UIListBox *)v14))->UIListBox::UpdateKeyCtrl();
    else
      updated = 0;
    *m_pBattleFieldAttr = updated;
    if ( !updated )
    {
      qmemcpy(
        &pExceptionObject[16],
        (((Logger *)&v21))->Logger::FormatException((char *)&g_EffMgrData.m_nEffParam_0338 + 16, aDProjectPal3Co_7, 2390),
        0x400u);
      _CxxThrowException(&pExceptionObject[16], (_ThrowInfo *)&_TI1_AV_Exception__);
    }
    *(_DWORD *)parent = 39;
    *(_DWORD *)(parent + 8) = 241;
    *(_DWORD *)(parent + 4) = 78;
    *(_DWORD *)(parent + 12) = 175;
    ((void ( *)(UIListBox *, int, int, CCBUI *, _DWORD, int, _DWORD))(*m_pBattleFieldAttr)->__vftable[1].ShowWindow)(
      *m_pBattleFieldAttr,
      *v12,
      parent,
      v9,
      0,
      1,
      0);
    m_pBattleFieldAttr->ShowWindow(1);
    UIListBox::SetItemOffset(*m_pBattleFieldAttr, 2, -4);
    (*m_pBattleFieldAttr)->UIListBox::SetFirstShow((int)"Name", 150);
    (*m_pBattleFieldAttr)->UIListBox::SetFirstShow((int)unk_5DFDB4, 43);
    UIListBox::SetLockSel(*m_pBattleFieldAttr);
    (*m_pBattleFieldAttr)->UIListBox::GetSel(g_nUnkDataTable[5], 0);
    UIListBox_SetItemData(1);
    v16 = sub_445FE0(pExceptionObject);
    *(_DWORD *)parent = (unsigned long)*v16;
    *(_DWORD *)(parent + 4) = (unsigned long)v16[1];
    *(_DWORD *)(parent + 8) = (unsigned long)v16[2];
    *(_DWORD *)(parent + 12) = (unsigned long)v16[3];
    (*m_pBattleFieldAttr)->UIListBox::GetLockSel((int)&unk_5DFD8C, (int *)parent, 16, 16, 0);
    (((CCBUI *)&(*m_pBattleFieldAttr)->m_scrollbar))->CCBUI::SetSelection(26);
    (((CCBUI *)&(*m_pBattleFieldAttr)->m_scrollbar))->CCBUI::SetCurPlayer(-5);
    (((CCBUI *)&(*m_pBattleFieldAttr)->m_scrollbar))->CCBUI::SetRoleStatePointers(-2);
    ++v12;
    ++m_pBattleFieldAttr;
  }
  while ( (int)v12 < (int)&g_nSkillItemIDTable[18] );
  (((CCBUI *)v9))->CCBUI::ChangeSpecStateLum();
  v17 = (void *)operator new(0x98u);
  if ( v17 )
    sub_4422E0(v17);
  else
    v18 = 0;
  v9->pPanel = v18;
  if ( !v18 )
  {
    qmemcpy(v22, (((Logger *)&v23))->Logger::FormatException(&path[164], aDProjectPal3Co_7, 4346), sizeof(v22));
    _CxxThrowException(v22, (_ThrowInfo *)&_TI1_AV_Exception__);
  }
  *(_DWORD *)parent = 37;
  *(_DWORD *)(parent + 8) = 237;
  *(_DWORD *)(parent + 4) = 170;
  *(_DWORD *)(parent + 12) = 210;
  pal3_vtbl_unk_2(v9->pPanel, 131, parent, v9) /* [VFTABLE-STUB] */;
  pal3_vtbl_unk_3(v9->pPanel, 1) /* [VFTABLE-STUB] */;
  (((CCBUI *)v9))->CCBUI::GravityDown(0);
  return 1;
}

static void pal3_vtbl_unk_0(UIStatic *, int, int, CCBUI *)
{
    
}
static void pal3_vtbl_unk_1(UIStatic *, int)
{
    
}
static void pal3_vtbl_unk_2(UIStatic *, int, int, CCBUI *)
{
    
}
static void pal3_vtbl_unk_3(UIStatic *, int)
{
    
}


// 0x0051A0F0
void CCBUI::ChangeSpecStateLum()
{
  UIStatic **v2; // edi

  v2 = (UIStatic **)&this->m_pBattleFieldAttr[3];
  this->CCBUI::LineMove((POINT *)&this->m_pBattleFieldAttr[3], (POINT *)0xB5);
  v2->ShowWindow(1);
  this->CCBUI::LineMove((POINT *)&this->m_pBattleFieldAttr[4], (POINT *)0xB6);
  ((void ( *)(UIStatic *, int))this->m_pBattleFieldAttr[4]->__vftable->ShowWindow)(
    this->m_pBattleFieldAttr[4],
    1);
  this->CCBUI::LineMove((POINT *)&this->m_pBattleFieldAttr[5], (POINT *)0xB7);
  ((void ( *)(UIStatic *, int))this->m_pBattleFieldAttr[5]->__vftable->ShowWindow)(
    this->m_pBattleFieldAttr[5],
    1);
}

// 0x0051A1D0
BOOL CCBUI::LineMove(POINT *pStart, POINT *pEnd)
{
  UIStatic *v4; // eax
  LONG v5; // eax
  BOOL result; // eax
  char pExceptionObject[1024]; // [esp+0x8] [ebp-0x80C] BYREF
  char ArgList; // [esp+0x408] [ebp-0x40C] BYREF
  int v9; // [esp+0x810] [ebp-0x4]
  int v10; // [esp+0x820] [ebp+0xC]
  int v11; // [esp+0x824] [ebp+0x10]

  v4 = (UIStatic *)operator new(0xF8u);
  v9 = 0;
  if ( v4 )
  {
  }
  else
    v5 = 0;
  v9 = -1;
  pStart->x = v5;
  if ( !v5 )
  {
    qmemcpy(
      pExceptionObject,
      (((Logger *)&ArgList))->Logger::FormatException(&path[164], aDProjectPal3Co_7, 2575),
      sizeof(pExceptionObject));
    _CxxThrowException(pExceptionObject, (_ThrowInfo *)&_TI1_AV_Exception__);
  }
  result = (*(int ( **)(LONG, POINT *, int, CCBUI *, int, _DWORD))(*(_DWORD *)v5 + 28))(
             v5,
             pEnd,
             v10,
             this,
             v11,
             0);
  LOBYTE(result) = 1;
  return result;
}

// 0x0051A2B0
unsigned int CCBUI::GravityDown(unsigned int formal)
{
  int v3; // ebp
  UIStatic **m_pBattleFieldAttr; // edi
  UIStatic *v5; // eax
  UIStatic *v6; // eax
  UIStatic *v7; // eax
  UIStatic *v8; // eax
  unsigned int result; // eax

  v3 = 3;
  m_pBattleFieldAttr = (UIStatic **)this->m_pBattleFieldAttr;
  do
  {
    m_pBattleFieldAttr->ShowWindow(0);
    v5 = (UIStatic *)this->m_pBattleFieldAttr[3];
    ++m_pBattleFieldAttr;
    --v3;
    v5->m_ratioh = 0.0;
    LOBYTE(v5->pDebugTex) = 0;
    v6 = (UIStatic *)this->m_pBattleFieldAttr[4];
    v6->m_ratioh = 0.0;
    LOBYTE(v6->pDebugTex) = 0;
    v7 = (UIStatic *)this->m_pBattleFieldAttr[5];
    v7->m_ratioh = 0.0;
    LOBYTE(v7->pDebugTex) = 0;
  }
  while ( v3 );
  switch ( formal )
  {
    case 0u:
      v8 = (UIStatic *)this->m_pBattleFieldAttr[3];
      goto LABEL_9;
    case 1u:
      v8 = (UIStatic *)this->m_pBattleFieldAttr[4];
      goto LABEL_9;
    case 2u:
      v8 = (UIStatic *)this->m_pBattleFieldAttr[5];
LABEL_9:
      LODWORD(v8->m_ratioh) = 1;
      LOBYTE(v8->pDebugTex) = 1;
      break;
  }
  SetEnable((UICaption *)this->m_pAttackSequenBack);
  SetEnable((UICaption *)this->pPanel);
  result = ((int ( *)(UIStatic *, int))this->m_pBattleFieldAttr[formal]->__vftable->ShowWindow)(
             this->m_pBattleFieldAttr[formal],
             1);
  this->m_pAttackSequenFace[0] = (UIStatic *)formal;
  return result;
}

// 0x0051A340
unsigned int CCBUI::ChangeNumTxt()
{
  sub_51A400(this);
  return (unsigned int)this;
}

// 0x0051A430

// ---- synthesized vtable stubs (unresolved slots) ----
// [VFTABLE-STUB] original: ((void ( *)(UIStatic *, int, tagUITask *, CCBUI *))this->m_pAttackSequenBack->__vftable->Create)( this->m_pAttackSequenBack, 150, pTask, this)
static void pal3_vtbl_unk_0(UIStatic *, int, tagUITask *, CCBUI *);
// [VFTABLE-STUB] original: ((void ( *)(UIStatic *, int))this->m_pAttackSequenBack->__vftable->ShowWindow)(this->m_pAttackSequenBack, 1)
static void pal3_vtbl_unk_1(UIStatic *, int);

BOOL CCBUI::AddTask(tagUITask *pTask, int nParam)
{
  void *v4; // eax
  UIStatic *v5; // eax
  int *v6; // ebp
  UIListBox **p_pPanel; // esi
  UIListBox *v8; // eax
  UIListBox *updated; // eax
  char **v10; // eax
  BOOL result; // eax
  char a2[16]; // [esp+0x2C] [ebp-0x81C] BYREF
  char pExceptionObject[1024]; // [esp+0x3C] [ebp-0x80C] BYREF
  char ArgList[1024]; // [esp+0x43C] [ebp-0x40C] BYREF
  int v15; // [esp+0x844] [ebp-0x4]

  (((CCBItemWindow *)this))->CCBItemWindow::Create(1879048194, (tagRECT *)pTask, nParam) /* [ROWTABLE] */;
  v4 = (void *)operator new(0x98u);
  v15 = 0;
  if ( v4 )
    sub_4422E0(v4);
  else
    v5 = 0;
  v15 = -1;
  this->m_pAttackSequenBack = v5;
  if ( !v5 )
  {
    qmemcpy(
      pExceptionObject,
      (((Logger *)ArgList))->Logger::FormatException((char *)&g_EffMgrData.m_nEffParam_0338 + 16, aDProjectPal3Co_7, 2678),
      sizeof(pExceptionObject));
    _CxxThrowException(pExceptionObject, (_ThrowInfo *)&_TI1_AV_Exception__);
  }
  pTask->fp[0] = 0;
  pTask->fp[2] = (char *)249;
  pTask->fp[1] = 0;
  pTask->fp[3] = (char *)206;
  pal3_vtbl_unk_0(this->m_pAttackSequenBack, 150, pTask, this) /* [VFTABLE-STUB] */;
  (((UIStatic *)this->m_pAttackSequenBack))->UIStatic::CreateFromTemplate(&unk_5DEF44, 0);
  pal3_vtbl_unk_1(this->m_pAttackSequenBack, 1) /* [VFTABLE-STUB] */;
  (((UIScene *)this->m_pAttackSequenBack))->UIScene::SetShow(0);
  sub_446010(this->m_pAttackSequenBack);
  (((UIFrameWnd *)this->m_pAttackSequenBack))->UIFrameWnd::SetPosition(40,   170);
  v6 = (int *)&g_nSkillItemIDTable[18];
  p_pPanel = (UIListBox **)&this->pPanel;
  do
  {
    v8 = (UIListBox *)operator new(0x4B8u);
    v15 = 1;
    if ( v8 )
      updated = (((UIListBox *)v8))->UIListBox::UpdateKeyCtrl();
    else
      updated = 0;
    v15 = -1;
    *p_pPanel = updated;
    if ( !updated )
    {
      qmemcpy(
        pExceptionObject,
        (((Logger *)ArgList))->Logger::FormatException((char *)&g_EffMgrData.m_nEffParam_0338 + 16, aDProjectPal3Co_7, 2700),
        sizeof(pExceptionObject));
      _CxxThrowException(pExceptionObject, (_ThrowInfo *)&_TI1_AV_Exception__);
    }
    pTask->fp[0] = (char *)39;
    pTask->fp[2] = (char *)241;
    pTask->fp[1] = (char *)78;
    pTask->fp[3] = (char *)175;
    ((void ( *)(UIListBox *, int, tagUITask *, CCBUI *, _DWORD, int, _DWORD))(*p_pPanel)->__vftable[1].ShowWindow)(
      *p_pPanel,
      *v6,
      pTask,
      this,
      0,
      1,
      0);
    p_pPanel->ShowWindow(0);
    UIListBox::SetItemOffset(*p_pPanel, 2, -4);
    (*p_pPanel)->UIListBox::SetFirstShow((int)"Name", 96);
    (*p_pPanel)->UIListBox::SetFirstShow((int)&unk_5DFDCC, 37);
    (*p_pPanel)->UIListBox::SetFirstShow((int)&unk_5DFDC0, 50);
    UIListBox::SetLockSel(*p_pPanel);
    (*p_pPanel)->UIListBox::GetSel(g_nUnkDataTable[9], 0);
    UIListBox_SetItemData(1);
    v10 = (char **)sub_445FE0(a2);
    pTask->fp[0] = *v10;
    pTask->fp[1] = v10[1];
    pTask->fp[2] = v10[2];
    pTask->fp[3] = v10[3];
    (*p_pPanel)->UIListBox::GetLockSel((int)&unk_5DFD8C, (int *)pTask, 16, 16, 0);
    (((CCBUI *)&(*p_pPanel)->m_scrollbar))->CCBUI::SetSelection(26);
    (((CCBUI *)&(*p_pPanel)->m_scrollbar))->CCBUI::SetCurPlayer(-5);
    (((CCBUI *)&(*p_pPanel)->m_scrollbar))->CCBUI::SetRoleStatePointers(-2);
    ++v6;
    ++p_pPanel;
  }
  while ( (int)v6 < (int)&g_nSkillItemIDTable[24] );
  result = (BOOL)(((CCBControlWindow *)this))->CCBControlWindow::HandleInput(0) /* [ROWTABLE] */;
  LOBYTE(result) = 1;
  return result;
}

static void pal3_vtbl_unk_0(UIStatic *, int, tagUITask *, CCBUI *)
{
    
}
static void pal3_vtbl_unk_1(UIStatic *, int)
{
    
}


// 0x0051AB00
BOOL CCBUI::CheckMagicKeyPress(int nVal, int nVal2)
{
  if ( this->m_bvisible == 1
    && (g_Input.KeyInfo[16].PressTime == 1 && (g_Input.KeyInfo[16].Data & 0xF) == 1 || g_Input.KeyInfo[17].PressTime == 1) )
  {
    CCBControl::SetParam(*(CCBControl **)(this->m_pfather[17].m_fontcolor.Color + 8), g_nSkillItemIDTable[18], -1);
  }
  return (((SceneObj *)this))->SceneObj::Update(nVal, nVal2) /* [ROWTABLE] */;
}

// 0x00525540
void CCBUI::InitShopUI()
{
  (((UIRoleDialog *)&this[37].m_Task[19].dwID))->UIRoleDialog::~UIRoleDialog();
  (((UIRoleDialog *)&this[37].m_Task[0].dwID))->UIRoleDialog::~UIRoleDialog();
  (((UIFrameWnd *)((char *)this + 6812)))->UIFrameWnd::_UIFrameWnd();
  (((UIFrameWnd *)((char *)this + 6660)))->UIFrameWnd::_UIFrameWnd();
  UITextArea_Destroy();
  (((UIButton *)&this[2].m_pRoleStateBound[1]))->UIButton::~UIButton();
  (((UIFrameWnd *)((char *)this + 6016)))->UIFrameWnd::_UIFrameWnd();
  (((UIFrameWnd *)((char *)this + 5864)))->UIFrameWnd::_UIFrameWnd();
  (((UIFrameWnd *)((char *)this + 5712)))->UIFrameWnd::_UIFrameWnd();
  (((UIFrameWnd *)((char *)this + 5560)))->UIFrameWnd::_UIFrameWnd();
  (((UIFrameWnd *)((char *)this + 5408)))->UIFrameWnd::_UIFrameWnd();
  (((UIFrameWnd *)((char *)this + 5256)))->UIFrameWnd::_UIFrameWnd();
  (((UIFrameWnd *)((char *)this + 5104)))->UIFrameWnd::_UIFrameWnd();
  (((UIFrameWnd *)((char *)this + 4952)))->UIFrameWnd::_UIFrameWnd();
  (((PalScript *)&this[1].m_Task[10].param.fFromY))->PalScript::Reset();
  (((PalScript *)&this[1].m_Task[6].fStartTime))->PalScript::Reset();
  (((PalScript *)&this[1].m_Task[2].fp[1]))->PalScript::Reset();
  (((UICaption *)&this[1].m_pRoleStateImmunity[4]))->UICaption::Destroy2();
  (((UIStatic *)&this[1].m_pRoleStateChaos[8]))->UIStatic::~UIStatic();
  (((UIStatic *)&this[1].m_pRoleStateSpeedDec[1]))->UIStatic::~UIStatic();
  (((UIFrameWnd *)&this->m_Task[10]))->UIFrameWnd::_UIFrameWnd();
  (((UIFrameWnd *)&this->m_Task[7].param.nTimes))->UIFrameWnd::_UIFrameWnd();
  (((UIFrameWnd *)&this->m_Task[5].param.fSpeed))->UIFrameWnd::_UIFrameWnd();
  (((UIListBox *)this))->UIListBox::~UIListBox() /* [ROWTABLE] */;
}

// 0x005257B0

// ---- synthesized vtable stubs (unresolved slots) ----
// [VFTABLE-STUB] original: ((void ( *)(UIStatic *, const char *, _DWORD *, CCBUI *, char *, int))v17->__vftable[1].ShowWindow)( v17, *v16, v71, this, aSubgameApprais_3, v15)
static void pal3_vtbl_unk_0(UIStatic *, const char *, _DWORD *, CCBUI *, char *, int);
// [VFTABLE-STUB] original: ((void ( *)(CCBProtectWindow **, _DWORD))this[2].m_pProtectWindow->__vftable)(&this[2].m_pProtectWindow, 0)
static void pal3_vtbl_unk_1(CCBProtectWindow **, _DWORD);

int * CCBUI::InitSkillUI(int nVal)
{
  int v3; // eax
  int v4; // eax
  float fStartTime; // edx
  UIStatic *v6; // eax
  int v7; // eax
  UIStatic *v8; // edx
  int v9; // edx
  UIStatic *v10; // edx
  UIStatic *v11; // edx
  UIStatic *v12; // edx
  float fSpeed; // edx
  int v14; // edx
  int v15; // ecx
  const char **v16; // ebp
  UIStatic *v17; // edi
  char *fp; // edx
  int v19; // edx
  const char **v20; // ebp
  PalScript *v21; // edi
  int *v22; // ebx
  int v23; // ecx
  int v24; // eax
  int v25; // ecx
  int v26; // edx
  CCBFiveNimbusWindow *v27; // eax
  CUtil *v28; // edx
  int v29; // eax
  int v30; // edx
  char *v31; // edx
  char *v32; // ecx
  char *v33; // edx
  int v34; // ecx
  char **v35; // ebp
  int v36; // ebx
  int *p_fExpectStartTime; // ebp
  int v38; // ebx
  int nTimes; // edx
  int v40; // edx
  CCBUI *v41; // eax
  int v42; // ecx
  char *v43; // eax
  UIStatic *v44; // eax
  int v45; // eax
  float v47; // [esp+0x120] [ebp-E4h]
  int v48; // [esp+0x134] [ebp-D0h] BYREF
  int v49; // [esp+0x138] [ebp-CCh]
  int v50; // [esp+0x13C] [ebp-C8h]
  int v51; // [esp+0x140] [ebp-C4h]
  int v52; // [esp+0x144] [ebp-C0h] BYREF
  int v53; // [esp+0x148] [ebp-BCh]
  int v54; // [esp+0x14C] [ebp-B8h]
  int v55; // [esp+0x150] [ebp-B4h]
  int v56; // [esp+0x154] [ebp-B0h] BYREF
  int v57; // [esp+0x158] [ebp-ACh]
  int v58; // [esp+0x15C] [ebp-A8h]
  int v59; // [esp+0x160] [ebp-A4h]
  int v60; // [esp+0x164] [ebp-A0h] BYREF
  int v61; // [esp+0x168] [ebp-0x9C]
  int v62; // [esp+0x16C] [ebp-0x98]
  int v63; // [esp+0x170] [ebp-0x94]
  int v64; // [esp+0x174] [ebp-0x90] BYREF
  int v65; // [esp+0x178] [ebp-0x8C]
  int v66; // [esp+0x17C] [ebp-0x88]
  int v67; // [esp+0x180] [ebp-0x84]
  _DWORD v68[2]; // [esp+0x184] [ebp-0x80] BYREF
  int v69; // [esp+0x18C] [ebp-0x78]
  int v70; // [esp+0x190] [ebp-0x74]
  _DWORD v71[2]; // [esp+0x194] [ebp-0x70] BYREF
  int v72; // [esp+0x19C] [ebp-0x68]
  int v73; // [esp+0x1A0] [ebp-0x64]
  int v74; // [esp+0x1A4] [ebp-0x60]
  int v75; // [esp+0x1A8] [ebp-0x5C]
  int v76; // [esp+0x1AC] [ebp-0x58]
  int v77; // [esp+0x1B0] [ebp-0x54]
  _DWORD v78[4]; // [esp+0x1B4] [ebp-0x50] BYREF
  _DWORD v79[4]; // [esp+0x1C4] [ebp-0x40] BYREF
  _DWORD v80[4]; // [esp+0x1D4] [ebp-0x30] BYREF
  _DWORD v81[4]; // [esp+0x1E4] [ebp-0x20] BYREF
  _DWORD v82[4]; // [esp+0x1F4] [ebp-0x10] BYREF

  this->pPanel = 0;
  this->m_pAttackSequenBack = 0;
  this->m_pBattleFieldAttr[0] = this->m_pBattleFieldAttr[2];
  this->m_pBattleFieldAttr[1] = (UIStatic *)((char *)this->pPanel + (unsigned int)this->m_pBattleFieldAttr[3]);
  (((UIListBox *)this))->UIListBox::SetSelTexture(-1, (int)this->m_pAttackSequenBack, (int)this->pPanel, (int)this->m_pBattleFieldAttr[0], (int)this->m_pBattleFieldAttr[1]) /* [ROWTABLE] */;
  *(_DWORD *)&this[37].m_Task[0].bValid = nVal;
  v3 = *(_DWORD *)&this[1].m_Task[15].bValid;
  v53 = 32;
  v52 = 168;
  v54 = 636;
  v55 = 136;
  v4 = (*(int ( **)(_BYTE *, char *, int *, CCBUI *))(v3 + 16))(
         &this[1].m_Task[15].bValid,
         &g_PlayerAttBuffer.Remark[250],
         &v52,
         this);
  LOBYTE(v4) = *(_BYTE *)(*(_DWORD *)&this[37].m_Task[0].bValid + 1756);
  (((UIStatic *)&this[1].m_Task[15].bValid))->UIStatic::CreateFromTemplate("SubGame\\Appraise\\Exhibit\\ExhibitRemark.tga", v4);
  fStartTime = this[1].m_Task[17].fStartTime;
  v53 += 6;
  v52 += 24;
  v55 = v53 + 158;
  v54 = v52 + 428;
  (*(void ( **)(float *, char *, int *, CCBUI *))(LODWORD(fStartTime) + 16))(
    &this[1].m_Task[17].fStartTime,
    &g_PlayerAttBuffer.Remark[250],
    &v52,
    this);
  (((UIScene *)&this[1].m_Task[17].fStartTime))->UIScene::SetShow(0);
  sub_446010(&this[1].m_Task[17].fStartTime);
  v6 = (UIStatic *)this[2].m_pRoleStateStable[3];
  v68[1] = 0;
  v68[0] = 0;
  v69 = 14;
  v70 = 600;
  v7 = ((int ( *)(UIStatic **, ARC_PlayerAtt *, _DWORD *, CCBUI *))v6->m_rect.left)(
         &this[2].m_pRoleStateStable[3],
         &g_PlayerAttBuffer,
         v68,
         this);
  LOBYTE(v7) = *(_BYTE *)(*(_DWORD *)&this[37].m_Task[0].bValid + 1756);
  (((UIStatic *)&this[2].m_pRoleStateStable[3]))->UIStatic::CreateFromTemplate("UI\\GameMainUI\\Communal\\smt_Line.tga", v7);
  v8 = (UIStatic *)this[2].m_pRoleStateSleep[8];
  v68[0] = 786;
  v69 = 800;
  ((void ( *)(UIStatic **, ARC_PlayerAtt *, _DWORD *, CCBUI *))v8->m_rect.left)(
    &this[2].m_pRoleStateSleep[8],
    &g_PlayerAttBuffer,
    v68,
    this);
  LOBYTE(v9) = *(_BYTE *)(*(_DWORD *)&this[37].m_Task[0].bValid + 1756);
  (((UIStatic *)&this[2].m_pRoleStateSleep[8]))->UIStatic::CreateFromTemplate("UI\\GameMainUI\\Communal\\smt_Line.tga", v9);
  v10 = (UIStatic *)this[2].m_pRoleStateBound[1];
  v81[1] = 0;
  v81[0] = 16;
  v81[2] = 788;
  v81[3] = 92;
  ((void ( *)(UIStatic **, char *, _DWORD *, CCBUI *))v10->m_rect.left)(
    &this[2].m_pRoleStateBound[1],
    &g_PlayerAttBuffer.Remark[250],
    v81,
    this);
  (((UIScene *)&this[2].m_pRoleStateBound[1]))->UIScene::GetChildCount();
  (((UIScene *)&this[2].m_pRoleStateBound[1]))->UIScene::GetChildAt();
  sub_43FD90((float *)&this[2].m_pRoleStateBound[1], 0);
  (((UIScrollBar *)&this[2].m_pRoleStateBound[1]))->UIScrollBar::SetRange(620.0);
  this[2].m_pResultWaterLvup = (UIStatic *)1;
  this[2].m_pParabolaWindow = (CCBParabolaWindow *)300;
  this[2].m_pMain = (CCBControlWindow *)1092616192;
  this[2].m_pResultEarthLvup = (UIStatic *)255;
  (((UIProgressBar *)&this[2].m_pRoleStateBound[1]))->UIProgressBar::FindChildByName(620.0);
  this[2].m_pRoleStateImmunity[7] = (UIStatic *)1142620160;
  v11 = (UIStatic *)this[2].m_pAttackSequenFace[2];
  v65 = 18;
  v64 = 64;
  v66 = 96;
  v67 = 42;
  ((void ( *)(UIStatic **, char *, int *, CCBUI *))v11->m_rect.left)(
    &this[2].m_pAttackSequenFace[2],
    &g_PlayerAttBuffer.Remark[250],
    &v64,
    this);
  v12 = (UIStatic *)this[2].m_pRoleStateAttackDec[4];
  v65 = v67;
  v67 += 24;
  ((void ( *)(UIStatic **, char *, int *, CCBUI *))v12->m_rect.left)(
    &this[2].m_pRoleStateAttackDec[4],
    &g_PlayerAttBuffer.Remark[250],
    &v64,
    this);
  fSpeed = this->m_Task[5].param.fSpeed;
  v78[1] = 136;
  v78[0] = 90;
  v78[2] = 714;
  v78[3] = 598;
  (*(void ( **)(float *, char *, _DWORD *, CCBUI *))(LODWORD(fSpeed) + 16))(
    &this->m_Task[5].param.fSpeed,
    &g_PlayerAttBuffer.Remark[250],
    v78,
    this);
  LOBYTE(v14) = *(_BYTE *)(*(_DWORD *)&this[37].m_Task[0].bValid + 1756);
  (((UIStatic *)&this->m_Task[5].param.fSpeed))->UIStatic::CreateFromTemplate("SubGame\\Appraise\\Do\\DoingBk.tga", v14);
  v71[1] = 162;
  v71[0] = 120;
  v72 = 160;
  v73 = 208;
  v16 = (const char **)&off_5706AC;
  v17 = (UIStatic *)&this->m_pRoleStateDefenceDec[4];
  do
  {
    LOBYTE(v15) = *(_BYTE *)(*(_DWORD *)&this[37].m_Task[0].bValid + 1756);
    pal3_vtbl_unk_0(v17, *v16, v71, this, "SubGame\\Appraise\\Do\\queue", v15) /* [VFTABLE-STUB] */;
    (((UIStatic *)v17))->UIStatic::SetText();
    ++v16;
    v71[0] = v72;
    v17 = (UIStatic *)((char *)v17 + 248);
    v72 += 40;
  }
  while ( (int)v16 < (int)&off_5706C0 );
  fp = (char *)this[1].fp.fp;
  v79[1] = 170;
  v79[0] = 326;
  v79[2] = 482;
  v79[3] = 202;
  (*((void ( **)(CCBUI_funcptr_t *, char *, _DWORD *, CCBUI *))fp + 4))(
    &this[1].fp,
    &g_PlayerAttBuffer.Remark[283],
    v79,
    this);
  (((UIScene *)&this[1].fp))->UIScene::SetShow(0);
  sub_446010(&this[1].fp);
  v57 = 146;
  v56 = 552;
  v58 = 597;
  v59 = 210;
  v20 = (const char **)&off_5706C0;
  v21 = (PalScript *)&this->m_Task[12].fp[2];
  v22 = (int *)&this[1].m_pRoleStateLuckDec[10];
  do
  {
    LOBYTE(v19) = *(_BYTE *)(*(_DWORD *)&this[37].m_Task[0].bValid + 1756);
    (*(void ( **)(PalScript *, const char *, int *, CCBUI *, char *, _DWORD, int))(v21->m_bLoadSceneScript + 28))(
      v21,
      *v20,
      &v56,
      this,
      "SubGame\\Appraise\\Do\\Magnifier",
      0,
      v19);
    v23 = v57;
    *v22 = v56;
    v24 = v58;
    v22[1] = v23;
    v25 = v59;
    v22[2] = v24;
    v22[3] = v25;
    (((PalScript *)v21))->PalScript::OpenScript("SubGame\\Appraise\\Do\\unMagnifier.tga", *(_BYTE *)(*(_DWORD *)&this[37].m_Task[0].bValid + 1756));
    v19 = v58;
    ++v20;
    v22 += 4;
    v21 = (PalScript *)((char *)v21 + 344);
    v56 = v58 + 2;
    v58 += 47;
  }
  while ( (int)v20 < (int)&off_5706CC );
  v26 = *(_DWORD *)&this[37].m_Task[0].bValid;
  v49 = 548;
  v48 = 213;
  v50 = 307;
  v51 = 568;
  LOBYTE(v26) = *(_BYTE *)(v26 + 1756);
  ((void ( *)(UIStatic **, char *, int *, CCBUI *, char *, int))this[1].m_pRoleStateSpeedDec[1]->m_rect.bottom)(
    &this[1].m_pRoleStateSpeedDec[1],
    &g_PlayerAttBuffer.Remark[272],
    &v48,
    this,
    "SubGame\\Appraise\\Do\\Result",
    v26);
  v27 = (CCBFiveNimbusWindow *)v49;
  this[37].m_pResultWindow[3] = (CCBResultWindow *)v48;
  v28 = (CUtil *)v51;
  this[37].m_pFiveNimbusWindow = v27;
  v29 = v50;
  this[37].m_pCBSystem = (CCBSystem *)v50;
  v48 = v29 + 200;
  this[37].m_pUtil = v28;
  v30 = *(_DWORD *)&this[37].m_Task[0].bValid;
  v50 = v29 + 294;
  LOBYTE(v30) = *(_BYTE *)(v30 + 1756);
  ((void ( *)(UIStatic **, char *, int *, CCBUI *, char *, int))this[1].m_pRoleStateChaos[8]->m_rect.bottom)(
    &this[1].m_pRoleStateChaos[8],
    &g_PlayerAttBuffer.Remark[273],
    &v48,
    this,
    "SubGame\\Appraise\\Do\\Result",
    v30);
  v31 = (char *)v49;
  v80[1] = 573;
  v80[0] = 358;
  v80[2] = 448;
  *((_DWORD *)&this[37].m_pUtil + 1) = v48;
  v32 = (char *)v50;
  v80[3] = 598;
  this[37].m_Task[0].fp[0] = v31;
  v33 = (char *)v51;
  this[37].m_Task[0].fp[1] = v32;
  v34 = *(_DWORD *)&this[37].m_Task[0].bValid;
  this[37].m_Task[0].fp[2] = v33;
  LOBYTE(v33) = *(_BYTE *)(v34 + 1756);
  ((void ( *)(UIStatic **, char *, _DWORD *, CCBUI *, char *, _DWORD, char *))this[1].m_pRoleStateImmunity[4]->m_rect.bottom)(
    &this[1].m_pRoleStateImmunity[4],
    &g_PlayerAttBuffer.Remark[274],
    v80,
    this,
    "UI\\GameMainUI\\MUIDialog\\Normal\\Yes",
    0,
    v33);
  ((void ( *)(UIStatic **, _DWORD))(*(void **)(this[1].m_pRoleStateImmunity[4])))(
    &this[1].m_pRoleStateImmunity[4],
    0);
  (((CCBFiveNimbusWindow *)&this[1].m_Task[2].fp[1]))->CCBFiveNimbusWindow::CreateScriptAndCamera((int)&g_PlayerAttBuffer.Remark[287], (int)this);
  (((CCBFiveNimbusWindow *)&this[1].m_Task[2].fp[1]))->CCBFiveNimbusWindow::SetFloatParam(600.0);
  (((Camera *)&this[1].m_Task[2].fp[1]))->Camera::UpdateCameraLookAt(400, 320);
  v35 = (char **)&this[1].m_Task[3].fp[2];
  v36 = 5;
  do
  {
    *v35 = 0;
    (((UIPushButton *)&this[1].m_Task[2].fp[1]))->UIPushButton::SetAnimOffset(1, 1127481344, v47);
    LODWORD(this[1].m_Task[5].fExpectEndTime) = 58;
    v35 += 8;
    --v36;
    ++this[1].m_Task[3].fp[0];
  }
  while ( v36 );
  (((CCBFiveNimbusWindow *)&this[1].m_Task[6].fStartTime))->CCBFiveNimbusWindow::CreateScriptAndCamera((int)&g_PlayerAttBuffer.Remark[288], (int)this);
  (((CCBFiveNimbusWindow *)&this[1].m_Task[6].fStartTime))->CCBFiveNimbusWindow::SetFloatParam(600.0);
  (((Camera *)&this[1].m_Task[6].fStartTime))->Camera::UpdateCameraLookAt(400, 320);
  p_fExpectStartTime = (int *)&this[1].m_Task[7].fExpectStartTime;
  v38 = 5;
  do
  {
    *p_fExpectStartTime = 0;
    (((UIPushButton *)&this[1].m_Task[6].fStartTime))->UIPushButton::SetAnimOffset(1, 1127481344, v47);
    LODWORD(this[1].m_Task[9].param.fEndY) = 58;
    p_fExpectStartTime += 8;
    --v38;
    ++this[1].m_Task[7].dwID;
  }
  while ( v38 );
  nTimes = this->m_Task[7].param.nTimes;
  *((_DWORD *)&this[1].m_Task[14].param + 8) = -1029701632;
  this[1].m_Task[15].fp[2] = (char *)-1029701632;
  this[1].m_Task[14].param.nTimes = -1017380864;
  this[1].m_Task[15].fp[0] = 0;
  this[1].m_Task[15].fp[1] = (char *)1130102784;
  this[1].m_Task[15].fp[3] = 0;
  v61 = 136;
  v60 = 90;
  v62 = 716;
  v63 = 603;
  (*(void ( **)(int *, char *, int *, CCBUI *))(nTimes + 16))(
    &this->m_Task[7].param.nTimes,
    &g_PlayerAttBuffer.Remark[275],
    &v60,
    this);
  LOBYTE(v40) = *(_BYTE *)(*(_DWORD *)&this[37].m_Task[0].bValid + 1756);
  (((UIStatic *)&this->m_Task[7].param.nTimes))->UIStatic::CreateFromTemplate("SubGame\\Appraise\\Do\\ExhibitZoom.tga", v40);
  (*(void ( **)(int *, _DWORD))this->m_Task[7].param.nTimes)(&this->m_Task[7].param.nTimes, 0);
  (((CCBFiveNimbusWindow *)&this[1].m_Task[10].param.fFromY))->CCBFiveNimbusWindow::CreateScriptAndCamera((int)&g_PlayerAttBuffer.Remark[289], (int)this);
  (((CCBFiveNimbusWindow *)&this[1].m_Task[10].param.fFromY))->CCBFiveNimbusWindow::SetFloatParam(580.0);
  (((Camera *)&this[1].m_Task[10].param.fFromY))->Camera::UpdateCameraLookAt(400, 346);
  v41 = (CCBUI *)((char *)this + 4696);
  v42 = 5;
  do
  {
    (*(void **)(v41)) = (void *)(0);
    v41 = (CCBUI *)((char *)v41 + 32);
    --v42;
    ++LODWORD(this[1].m_Task[11].param.fFromX);
  }
  while ( v42 );
  v43 = (char *)this->m_Task[10].fp[0];
  v61 = 164;
  v60 = 326;
  v62 = 482;
  v63 = 196;
  (*((void ( **)(tagUITask *, char *, int *, CCBUI *))v43 + 4))(
    &this->m_Task[10],
    &g_PlayerAttBuffer.Remark[275],
    &v60,
    this);
  (((UIScene *)&this->m_Task[10]))->UIScene::SetShow(0);
  sub_446010(&this->m_Task[10]);
  (*(void ( **)(tagUITask *, _DWORD))this->m_Task[10].fp[0])(&this->m_Task[10], 0);
  v44 = (UIStatic *)this[2].m_pRoleStateLuckInc[9];
  v82[1] = 158;
  v82[0] = 536;
  v82[2] = 581;
  v82[3] = 208;
  v45 = ((int ( *)(UIStatic **, char *, _DWORD *, CCBUI *))v44->m_rect.left)(
          &this[2].m_pRoleStateLuckInc[9],
          &g_PlayerAttBuffer.Remark[250],
          v82,
          this);
  LOBYTE(v45) = *(_BYTE *)(*(_DWORD *)&this[37].m_Task[0].bValid + 1756);
  (((UIStatic *)&this[2].m_pRoleStateLuckInc[9]))->UIStatic::CreateFromTemplate("SubGame\\Appraise\\Do\\Magnifier0.tga", v45);
  ((void ( *)(UIStatic **, _DWORD))(*(void **)(this[2].m_pRoleStateLuckInc[9])))(
    &this[2].m_pRoleStateLuckInc[9],
    0);
  v74 = 300;
  v77 = 300;
  this[2].m_pRoleStateWall[2] = (UIStatic *)45;
  this[2].m_pRoleStateWall[3] = (UIStatic *)50;
  v75 = 200;
  v76 = 500;
  Create__ovl_1((ARC_PlayerAtt *)&this[37].m_Task[0].dwID);
  (((UIItem *)&this[37].m_Task[0].dwID))->UIItem::SetData(31);
  sub_446010(&this[37].m_Task[0].dwID);
  Create__ovl_1((ARC_PlayerAtt *)&this[37].m_Task[19].dwID);
  (((UIItem *)&this[37].m_Task[19].dwID))->UIItem::SetData(31);
  sub_446010(&this[37].m_Task[19].dwID);
  this[2].m_pSkillWindow = (CCBSkillWindow *)120;
  this[2].m_pAIWindow = (CCBAIWindow *)534;
  this[2].m_pLineupWindow = (CCBLineupWindow *)420;
  this[2].m_pMagicWindow = (CCBMagicWindow *)278;
  (((UINote *)&this[2].m_pProtectWindow))->UINote::Create((int)&g_PlayerAttBuffer.Remark[284], (int)&this[2].m_pMagicWindow, (int)this, "UI\\Flex\\Note");
  pal3_vtbl_unk_1(&this[2].m_pProtectWindow, 0) /* [VFTABLE-STUB] */;
  (*((void ( **)(char **, char *, CCBMagicWindow **, CCBUI *))this[2].m_Task[2].fp[3] + 4))(
    &this[2].m_Task[2].fp[3],
    &g_PlayerAttBuffer.Remark[284],
    &this[2].m_pMagicWindow,
    this);
  (((UIScene *)&this[2].m_Task[2].fp[3]))->UIScene::SetShow(0);
  sub_446010(&this[2].m_Task[2].fp[3]);
  (*(void ( **)(char **, _DWORD))this[2].m_Task[2].fp[3])(&this[2].m_Task[2].fp[3], 0);
  (*(void ( **)(unsigned int *, char *, CCBMagicWindow **, CCBUI *))(this[2].m_Task[4].dwID + 16))(
    &this[2].m_Task[4].dwID,
    &g_PlayerAttBuffer.Remark[285],
    &this[2].m_pMagicWindow,
    this);
  (((UIScene *)&this[2].m_Task[4].dwID))->UIScene::SetShow(0);
  (*(void ( **)(unsigned int *, _DWORD))this[2].m_Task[4].dwID)(&this[2].m_Task[4].dwID, 0);
  return (int *)sub_446010(&this[2].m_Task[4].dwID);
}

static void pal3_vtbl_unk_0(UIStatic *, const char *, _DWORD *, CCBUI *, char *, int)
{
    
}
static void pal3_vtbl_unk_1(CCBProtectWindow **, _DWORD)
{
    
}


// 0x00526740

// ---- synthesized vtable stubs (unresolved slots) ----
// [VFTABLE-STUB] original: ((void ( *)(UIStatic **, _DWORD))v11->__vftable)(&this[2].m_pRoleStateLuckInc[9], 0)
static void pal3_vtbl_unk_0(UIStatic **, _DWORD);

int CCBUI::Update(int deltatime, int haveinput)
{
  UIStatic *TickCount; // eax
  UIStatic *v5; // eax
  unsigned int v6; // ecx
  UIStatic *v7; // eax
  UIStatic *v8; // eax
  int v9; // kr00_4
  int v10; // ecx
  UIStatic *v11; // edx
  float fValue; // [esp+0x4] [ebp-0x28]
  int v14; // [esp+0x8] [ebp-0x24]
  int v15; // [esp+0x8] [ebp-0x24]
  int v16; // [esp+0x8] [ebp-0x24]
  struct tagPOINT Point; // [esp+0x14] [ebp-0x18] BYREF
  int v18; // [esp+0x1C] [ebp-0x10]
  int v19; // [esp+0x20] [ebp-0xC]
  int v20; // [esp+0x24] [ebp-0x8]
  int v21; // [esp+0x28] [ebp-0x4]

  if ( UIParabolaCtrl_GetState(v14) == 2 )
    CCBAttackSequen_AdvanceToNextSlot(v15);
  if ( UIParabolaCtrl_GetState(v15) == 2 )
  {
    if ( BYTE1(this[5].m_Task[8].fp[3]) )
      CCBUI_UpdateCaptions(v16);
    else
      LOBYTE(this[2].m_pRoleStateBound[0]) = 0;
  }
  if ( this[2].m_Task[1].param.nTimes == 2 )
    (*(void ( **)(char **, int))this[2].m_Task[2].fp[3])(&this[2].m_Task[2].fp[3], 1);
  if ( !LOBYTE(this[2].m_pRoleStateBound[0])
    && !BYTE2(this[5].m_Task[7].param.nTimes)
    && !BYTE1(this[5].m_Task[8].fp[3]) )
  {
    if ( !LOBYTE(this[2].m_pRoleStateWall[8]) )
    {
      TickCount = (UIStatic *)GetTickCount();
      this[2].m_pRoleStateWall[6] = TickCount;
      this[2].m_pRoleStateWall[7] = TickCount;
      LOBYTE(this[2].m_pRoleStateWall[8]) = 1;
    }
    v5 = (UIStatic *)GetTickCount();
    v6 = (char *)v5 - (char *)this[2].m_pRoleStateWall[7];
    this[2].m_pRoleStateWall[6] = v5;
    if ( v6 > 0x3E8 )
    {
      this[2].m_pRoleStateWall[7] = v5;
      LOBYTE(this[2].m_pRoleStateWall[8]) = 0;
      v7 = (UIStatic *)((char *)this[2].m_pRoleStateWall[10] - 1);
      this[2].m_pRoleStateWall[10] = v7;
      if ( (int)v7 < 0 )
      {
        v8 = (UIStatic *)this[2].m_pRoleStateWall[9];
        this[2].m_pRoleStateWall[10] = (UIStatic *)59;
        v8 = (UIStatic *)((char *)v8 - 1);
        this[2].m_pRoleStateWall[9] = v8;
        if ( (int)v8 < 0 )
        {
          this[2].m_pRoleStateWall[9] = 0;
          this[2].m_pRoleStateWall[10] = 0;
          LOBYTE(this[2].m_pRoleStateBound[0]) = 1;
          CCBUI_UpdateCaptions(v16);
        }
      }
      if ( LOBYTE(this[2].m_pRoleStateGP[2]) )
        this[2].m_pRoleStateImmunity[7] = (UIStatic *)1065353216;
      Point.x = 10 * ((int)((void **)(this[2].m_pRoleStateWall[10])) + 2);
      fValue = (float)Point.x;
      (((UIProgressBar *)&this[2].m_pRoleStateBound[1]))->UIProgressBar::FindChildByName(fValue);
    }
  }
  CreateDigitPair(
    (int)this[2].m_pRoleStateWall[10],
    &this[2].m_pAttackSequenFace[2],
    &this[2].m_pRoleStateAttackDec[4],
    pszTexBase,
    *(_BYTE *)(*(_DWORD *)&this[37].m_Task[0].bValid + 1756));
  if ( LOBYTE(this[2].m_pRoleStateWall[4]) )
  {
    g_Input.GRPinput::GetCursorPos(&Point);
    v9 = (int)this[2].m_pRoleStateWall[2];
    v20 = Point.x + v9 - v9 / 2;
    v10 = (int)this[2].m_pRoleStateWall[3];
    v18 = Point.x - v9 / 2;
    v19 = Point.y - v10 / 2;
    v21 = Point.y + v10 - v10 / 2;
    sub_445FA0(&this[2].m_pRoleStateLuckInc[9]);
    if ( (g_Input.KeyInfo[1].Data & 0xF) == 1 )
    {
      v11 = (UIStatic *)this[2].m_pRoleStateLuckInc[9];
      LOBYTE(this[2].m_pRoleStateWall[4]) = 0;
      pal3_vtbl_unk_0(&this[2].m_pRoleStateLuckInc[9], 0) /* [VFTABLE-STUB] */;
      sub_445FA0(&this[2].m_pRoleStateLuckInc[9]);
      sub_445E50((int)&this->m_Task[12].fp[86 * (int)this[2].m_pRoleStateWall[5] + 2]);
    }
  }
  (((SceneObj *)this))->SceneObj::Update(deltatime, haveinput) /* [ROWTABLE] */;
  return 1;
}

static void pal3_vtbl_unk_0(UIStatic **, _DWORD)
{
    
}

