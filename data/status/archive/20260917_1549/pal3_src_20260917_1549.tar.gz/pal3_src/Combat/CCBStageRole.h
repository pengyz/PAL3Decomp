#pragma once
// Auto-generated: CCBStageRole
#include "pal3/ida_types.h"

#include "Misc/ACTION_KIND.h"
#include "Misc/Array.h"
#include "Misc/ERoleActState.h"
#include "gbengine/gbGeomNode.h"
#include "gbengine/gbengine_types.h"
#include "gbengine/gbengine_types.h"
#include "Misc/tagRoleTask.h"

class Actor;
class CCBRoleState;
class CCBStage;
class tagCmdData;

class CCBStageRole {
public:
    CCBStage * m_pStage; // +0x0
    CCBRoleState * m_pRoleState; // +0x4
    char m_sLastRole[12]; // +0x8
    Array m_sRoleArray; // +0x14
    char m_sRoleData[228]; // +0x24
    BYTE m_bValid; // +0x108
    BYTE m_bVisible; // +0x109
    BYTE m_bPaused; // +0x10A
    BYTE m_bAbsTime; // +0x10B
    float m_fTimeScale; // +0x10C
    BYTE m_bAlive; // +0x110
    BYTE m_bRun; // +0x111
    BYTE m_bFlash; // +0x112
    BYTE m_bFlashCounter; // +0x113
    float m_fFlashTimeKey; // +0x114
    BYTE m_bShowWeapon; // +0x118
    char _gap_119[3]; // +0x119
    float m_fBlend; // +0x11C
    BYTE m_bBeSelected; // +0x120
    char _gap_121[3]; // +0x121
    int m_nIndex; // +0x124
    UINT m_dwID; // +0x128
    Actor * m_pActor; // +0x12C
    Actor * m_pRawActor; // +0x130
    gbGeomNode * m_pWeaponModel; // +0x134
    gbVec3D m_vecWeapon; // +0x138
    gbVec3D m_rotWeapon; // +0x144
    gbVec3D m_vNoteThrowPos; // +0x150
    gbVec3D m_vThrowVec; // +0x15C
    float m_vecLen; // +0x168
    float m_fTask; // +0x16C
    float m_fStatus; // +0x170
    BYTE m_bShowWeaponModel; // +0x174
    BYTE m_bCatching; // +0x175
    BYTE m_bDelAllTask; // +0x176
    char _gap_177[1]; // +0x177
    int m_iState; // +0x178
    BYTE m_bForceFinishThrowingWeapon; // +0x17C
    char _gap_17D[3]; // +0x17D
    float m_fMaxThrowSpeed; // +0x180
    float m_fThrowSpeed; // +0x184
    float m_fThrowLen; // +0x188
    tagCmdData * m_ThrowCmdData; // +0x18C
    int m_nRotAngle; // +0x190
    int m_nCurActionOff; // +0x194
    int m_nCurActionParam; // +0x198
    int m_nTodo_19C; // +0x19C
    int m_nTransportRun; // +0x1A0
    int m_ActionSlot0; // +0x1A4
    int m_ActionSlot1; // +0x1A8
    int m_ActionSlot2; // +0x1AC
    int m_nUseRecoverItem; // +0x1B0
    int m_nProperAction; // +0x1B4
    gbOBBox * m_OBBox; // +0x1B8
    int m_nOBBox; // +0x1BC
    int m_fActionSpeed0; // +0x1C0
    int m_nTodo_1C4; // +0x1C4
    char _gap_1C8[16]; // +0x1C8
    int m_nTodo_1D8; // +0x1D8
    char _gap_1DC[8]; // +0x1DC
    int m_apSlotData; // +0x1E4
    float m_nTodo_1E8; // +0x1E8
    char _gap_1EC[4]; // +0x1EC
    int m_nCurState; // +0x1F0
    int m_nActionType0; // +0x1F4
    BYTE m_bProperCurAction; // +0x1F8
    BYTE m_bSlotActive0; // +0x1F9
    BYTE m_bSlotBlocked0; // +0x1FA
    char _gap_1FB[9]; // +0x1FB
    BYTE m_bTransMtl; // +0x204
    BYTE m_bSpecTransport; // +0x205
    BYTE m_bGrabed; // +0x206
    BYTE m_bNormalGrab; // +0x207
    UINT m_dwStageTaskID; // +0x208
    BYTE m_bExternalTask; // +0x20C
    char _gap_20D[3]; // +0x20D
    float m_fLeftWeapon; // +0x210
    float m_fRightWeapon; // +0x214
    int m_nTask; // +0x218
    int m_nCurTask; // +0x21C
    char * m_fp; // +0x220
    char _gap_224[12]; // +0x224
    tagRoleTask m_Task[64]; // +0x230
    UINT m_dwCurWeaponIndex; // +0x1A30
    ERoleActState m_eRoleActState; // +0x1A34
    char _gap_1A35[3]; // +0x1A35
    ACTION_KIND m_eCurAction; // +0x1A38
    char _gap_1A39[3]; // +0x1A39
    gbVec3D m_vecSunDir; // +0x1A3C
    gbVec3D m_vecPos; // +0x1A48
    gbVec3D m_vecInitPos; // +0x1A54
    gbVec3D m_vecRunTarget; // +0x1A60
    gbVec3D m_vecRunVelocity; // +0x1A6C
    float m_fFaceDir; // +0x1A78
    float m_fInitFaceDir; // +0x1A7C
    UINT m_dwCurAniFlag; // +0x1A80
    UINT m_dwAniFlagOver; // +0x1A84
    UINT m_dwAniFlagWork; // +0x1A88
    UINT m_dwAniFlagWork1; // +0x1A8C
    UINT m_dwAniFlagWork2; // +0x1A90
    UINT m_dwAniFlagWork3; // +0x1A94
    UINT m_dwAniFlagPause; // +0x1A98
    UINT m_dwAniFlagStore; // +0x1A9C
    UINT m_dwAniFlagFlyup; // +0x1AA0
    UINT m_dwAniFlagFlydown; // +0x1AA4
    UINT m_dwAniFlagThrowED; // +0x1AA8
    UINT m_dwAniFlagCatchED; // +0x1AAC
    UINT m_dwAniFlagSJump; // +0x1AB0
    UINT m_dwAniFlagEJump; // +0x1AB4
    UINT m_dwLastExternalActionCRC; // +0x1AB8
    char _tail_1ABC[4]; // +0x1ABC
    // total size: 0x1AC0 (6848)

    int LoadSaveData(int *p_DWORD); // 0x00521B00
};
