#include "pal3/ida_defs.h"
#include "globals.h"
#include "pal3/pal3_constants.h"
#include "Effect/CEffMeteor.h"
#include "Combat/CCBStage.h"
#include "Effect/CEffMgr.h"
#include "Misc/CEffObj.h"
#include "Effect/CEffect.h"
#include "Effect/CEffgbParticle.h"
#include "Effect/CMeteorChain.h"
#include "Misc/CTaskTpl_tagEffTaskParam_CEffMeteor.h"
#include "GameBase/Logger.h"
#include "GameBase/PAL3.h"
#include "Misc/tagEffMgrData.h"
#include "Misc/tagEffObjType.h"
#include "Misc/tagEffTaskParam.h"
#include "Misc/tagMeteor.h"
#include "free_functions.h"

// Forward declarations for unnamed functions
int sub_4CB3A0(...);
int sub_4CCC60(...);
int sub_4CCD10(...);
int sub_4CD3D0(...);
int sub_4CD500(...);
void __cdecl todo_401800(void);

// Unnamed globals (extern)
void __cdecl nullsub_17(void);
void __cdecl nullsub_18(void);
void __cdecl nullsub_19(void);

// 0x004CB480
CEffMeteor::CEffMeteor()
{
  void *v1; // eax

  v1 = (void *)operator new(0x10D0u);
  if ( v1 )
    sub_4CB3A0(v1);
}

// 0x004CB4C0
CEffMeteor::~CEffMeteor()
{
  CTaskTpl_tagEffTaskParam_CEffMeteor *v2; // edi
  gbGeomQuad *m_pGeomQuad; // eax
  int v4; // ebp
  CMeteorChain *m_pChain; // eax
  gbTexture *m_pTexture; // ecx
  CTaskTpl_tagEffTaskParam_CEffMeteor *v7; // esi
  int v8; // eax
  bool v9; // cc
  int v10; // edi

  v2 = ((CTaskTpl_tagEffTaskParam_CEffMeteor *)this);
  m_pGeomQuad = (gbGeomQuad *)this->m_pGeomQuad;
  v4 = 0;
  if ( m_pGeomQuad )
    operator delete(m_pGeomQuad);
  if ( this->m_pMeteor )
    operator delete(this->m_pMeteor);
  m_pChain = (CMeteorChain *)this->m_pChain;
  if ( m_pChain )
    operator delete(&m_pChain[-1].m_fWidthDecSpeed);
  m_pTexture = (gbTexture *)this->m_pTexture;
  if ( m_pTexture )
    (((gbRefObject *)m_pTexture))->gbRefObject::Release();
  if ( this->m_pTextureArray )
    operator delete(this->m_pTextureArray);
  v7 = this != 0 ? v2 : 0;
  v8 = *((_DWORD *)((void **)(v7)) + 7);
  v9 = v8 <= 0;
  if ( !v8 )
  {
    if ( !*(this != 0 ? ((void **)(v2)) + 8 : (void **)32) )
      return;
    v9 = 1;
  }
  if ( !v9 )
  {
    v10 = 0;
    do
    {
      operator delete(*(void **)(*((_DWORD *)((void **)(v7)) + 3) + v10));
      ++v4;
      *(_DWORD *)(*((_DWORD *)((void **)(v7)) + 3) + v10) = 0;
      v10 += 152;
    }
    while ( v4 < *((_DWORD *)((void **)(v7)) + 7) );
  }
  operator delete(*(((void **)(v7)) + 3));
  *((_DWORD *)((void **)(v7)) + 3) = 0;
  *((_DWORD *)((void **)(v7)) + 7) = 0;
  *((_DWORD *)((void **)(v7)) + 8) = 0;
}

// 0x004CB5E0
int CEffMeteor::Init(float *pType, float fx, float fy, float fz)
{
  void *v5; // edi
  int m_dwStartColor_low; // ecx
  int result; // eax
  int v9; // ecx

  this->m_bIdle = 0;
  this->m_bVisible = 0;
  this->m_vecPos.x = fx + pType[46];
  this->m_vecPos.y = fy + pType[47];
  this->m_vecPos.z = fz + pType[48];
  this->m_vecRot.x = pType[54];
  this->m_vecRot.y = pType[49];
  this->m_vecRot.z = pType[55];
  this->m_vecTarget.x = fx + pType[63];
  this->m_vecTarget.y = fy + pType[64];
  this->m_vecTarget.z = fz + pType[65];
  this->m_vecOffsetPos.z = 0.0;
  this->m_vecOffsetPos.y = 0.0;
  this->m_vecOffsetPos.x = 0.0;
  this->m_dwStartColor = (unsigned int)pType[51];
  if ( (g_bEffSystemFlags & 1) == 0 )
  {
    g_bEffSystemFlags |= 1u;
    (((CEffMgr *)&g_pCEffMgrBackup))->CEffMgr::Reset();
    atexit(todo_401800);
  }
  this->m_fAlpha = (float)HIBYTE(this->m_dwStartColor);
  if ( (g_bEffSystemFlags & 1) == 0 )
  {
    g_bEffSystemFlags |= 1u;
    (((CEffMgr *)&g_pCEffMgrBackup))->CEffMgr::Reset();
    atexit(todo_401800);
  }
  this->m_fRed = (float)(unsigned __int8)BYTE2(this->m_dwStartColor);
  if ( (g_bEffSystemFlags & 1) == 0 )
  {
    g_bEffSystemFlags |= 1u;
    (((CEffMgr *)&g_pCEffMgrBackup))->CEffMgr::Reset();
    atexit(todo_401800);
  }
  this->m_fGreen = (float)(unsigned __int8)BYTE1(this->m_dwStartColor);
  if ( (g_bEffSystemFlags & 1) == 0 )
  {
    g_bEffSystemFlags |= 1u;
    (((CEffMgr *)&g_pCEffMgrBackup))->CEffMgr::Reset();
    atexit(todo_401800);
  }
  this->m_fCurFrame = 0.0;
  m_dwStartColor_low = LOBYTE(this->m_dwStartColor);
  this->m_nLoops = 0;
  this->m_fBlue = (float)m_dwStartColor_low;
  this->m_fXSize = pType[50];
  this->m_fZSize = pType[50];
  NullCallback(v5);
  result = this->m_nMaxChain;
  v9 = 0;
  if ( result > 0 )
  {
    result = 0;
    do
    {
      ++v9;
      *(unsigned int *)((char *)&this->m_pChain->m_dwColor + result) = this->m_dwStartColor;
      *(float *)((char *)&this->m_pChain->m_fMaxWidth + result) = this->m_fMeteorWidth;
      *(float *)((char *)&this->m_pChain->m_fLumDecSpeed + result) = this->m_fLumDecSpeed;
      *(float *)((char *)&this->m_pChain->m_fWidthDecSpeed + result) = this->m_fWidthDecSpeed;
      *(float *)((char *)&this->m_pChain->m_fMaxLum + result) = this->m_fMaxLum;
      result += 56;
    }
    while ( v9 < this->m_nMaxChain );
  }
  return result;
}

// 0x004CB800
char CEffMeteor::Create(tagEffObjType *base)
{
  void *v3; // eax
  int v4; // ebx
  int v5; // edi
  int v6; // edi
  int v7; // edx
  int v8; // eax
  int v9; // ecx
  int v11; // edi
  int m_nMaxChain; // ebx
  gbGeomQuad *v13; // eax
  int v14; // ebx
  int v15; // ebx
  int v16; // ebx
  tagMeteor *v17; // eax
  int v18; // ebx
  _DWORD *p_z; // ecx
  int v20; // ebx
  int v21; // ebx
  int *v22; // eax
  CMeteorChain *v23; // eax
  gbGeomQuad *m_pGeomQuad; // ecx
  int v25; // ecx
  int v26; // edi
  int v27; // ebx
  char ArgList; // [esp+0xC] [ebp-0x810] BYREF
  _BYTE pExceptionObject[1024]; // [esp+0x40C] [ebp-0x410] BYREF
  void *Block; // [esp+0x80C] [ebp-0x10]
  int v32; // [esp+0x818] [ebp-0x4]
  tagEffObjType *basea; // [esp+0x824] [ebp+0x8]

  v3 = (void *)operator new(0x4C0u);
  *((_DWORD *)&this->CTaskTpl_tagEffTaskParam_CEffMeteor::__vftable + 3) = (unsigned long)v3;
  if ( v3 )
  {
    v4 = 0;
    v5 = 0;
    while ( 1 )
    {
      *(_DWORD *)(v5 + *((_DWORD *)&this->CTaskTpl_tagEffTaskParam_CEffMeteor::__vftable + 3)) = (unsigned long)operator new(0x2D0u);
      if ( !*(_DWORD *)(v5 + *((_DWORD *)&this->CTaskTpl_tagEffTaskParam_CEffMeteor::__vftable + 3)) )
        break;
      v5 += 152;
      ++v4;
      if ( v5 >= 1216 )
      {
        v6 = 0;
        *((_DWORD *)&this->CTaskTpl_tagEffTaskParam_CEffMeteor::__vftable + 7) = 8;
        *((_DWORD *)&this->CTaskTpl_tagEffTaskParam_CEffMeteor::__vftable + 8) = 10;
        v7 = 0;
        do
        {
          *(_BYTE *)(v7 + *((_DWORD *)&this->CTaskTpl_tagEffTaskParam_CEffMeteor::__vftable + 3) + 148) = 0;
          v8 = 0;
          if ( *((int *)&this->CTaskTpl_tagEffTaskParam_CEffMeteor::__vftable + 8) > 0 )
          {
            v9 = 0;
            do
            {
              ++v8;
              v9 += 72;
              *(_BYTE *)(*(_DWORD *)(v7 + *((_DWORD *)&this->CTaskTpl_tagEffTaskParam_CEffMeteor::__vftable + 3))
                       + v9
                       - 8) = 0;
            }
            while ( v8 < *((_DWORD *)&this->CTaskTpl_tagEffTaskParam_CEffMeteor::__vftable + 8) );
          }
          ++v6;
          v7 += 152;
        }
        while ( v6 < *((_DWORD *)&this->CTaskTpl_tagEffTaskParam_CEffMeteor::__vftable + 7) );
        goto LABEL_10;
      }
    }
    if ( v4 > 0 && v4 - 1 >= 0 )
    {
      v11 = 152 * (v4 - 1);
      do
      {
        operator delete(*(void **)(v11 + *((_DWORD *)&this->CTaskTpl_tagEffTaskParam_CEffMeteor::__vftable + 3)));
        v11 -= 152;
        --v4;
      }
      while ( v4 );
    }
    operator delete(*(&this->CTaskTpl_tagEffTaskParam_CEffMeteor::__vftable + 3));
  }
LABEL_10:
  if ( (g_bEffSystemFlags & 1) == 0 )
  {
    g_bEffSystemFlags |= 1u;
    (((CEffMgr *)&g_pCEffMgrBackup))->CEffMgr::Reset();
    atexit(todo_401800);
  }
  this->m_nMaxChain = abs32((int)base->fSacleX);
  this->m_fMeteorWidth = base->fSacleY;
  if ( (g_bEffSystemFlags & 1) == 0 )
  {
    g_bEffSystemFlags |= 1u;
    (((CEffMgr *)&g_pCEffMgrBackup))->CEffMgr::Reset();
    atexit(todo_401800);
  }
  this->m_nMaxTrail = (int)base->fSacleZ;
  this->m_fLumDecSpeed = base->fTopRadius;
  this->m_fWidthDecSpeed = base->fBottomRadius;
  this->m_fMaxLum = base->fTextureRepeat;
  this->m_bHaveHead = base->fSacleX > 0.0;
  this->m_fFramePerSec = base->fFramePerSec;
  this->m_vecPos.x = base->fX;
  this->m_vecPos.y = base->fY;
  this->m_vecPos.z = base->fZ;
  this->m_vecRot.x = base->fStartXRot;
  this->m_vecRot.y = base->fStartYRot;
  this->m_vecRot.z = base->fStartZRot;
  this->m_vecTarget.x = base->fTopRadiusIncSpeed;
  this->m_vecTarget.y = base->fBottomRadiusIncSpeed;
  this->m_vecTarget.z = base->fTopRiseSpeed;
  this->m_vecStartSpeed.x = base->fBottomRiseSpeed;
  this->m_vecStartSpeed.y = base->fTopShrink;
  this->m_vecStartSpeed.z = base->fBottomShrink;
  this->m_bAdditiveBlend = base->bAdditiveBlend;
  this->m_bNoZTest = base->bNoZTest;
  this->m_byMaxFrame = base->nFrame;
  this->m_nRequireLoops = (int)&byte_FFFFFF;
  this->m_dwStartColor = base->dwColor;
  sub_4CCC60(base->nFramePerRow, base->nFramePerCol);
  m_nMaxChain = this->m_nMaxChain;
  v13 = (gbGeomQuad *)operator new(68 * m_nMaxChain);
  Block = (void *)v13;
  v32 = 0;
  if ( v13 )
  {
    v14 = m_nMaxChain - 1;
    basea = (tagEffObjType *)v13;
    if ( v14 >= 0 )
    {
      v15 = v14 + 1;
      do
      {
        --v15;
        basea = (tagEffObjType *)((char *)basea + 68);
      }
      while ( v15 );
      v13 = (gbGeomQuad *)Block;
    }
  }
  else
  {
    v13 = 0;
  }
  v16 = this->m_nMaxChain;
  this->m_pGeomQuad = v13;
  v32 = -1;
  v17 = (tagMeteor *)operator new(48 * v16);
  if ( v17 )
  {
    v18 = v16 - 1;
    if ( v18 >= 0 )
    {
      p_z = (_DWORD *)&v17->vecSpeed.z;
      v20 = v18 + 1;
      do
      {
        *(p_z - 5) = 0;
        *(p_z - 4) = 0;
        *(p_z - 3) = 0;
        *(p_z - 2) = 0;
        *(p_z - 1) = 0;
        *p_z = 0;
        p_z[1] = 0;
        p_z[2] = 0;
        p_z[3] = 0;
        p_z[4] = 0;
        p_z[5] = 0;
        p_z[6] = 0;
        p_z += 12;
        --v20;
      }
      while ( v20 );
    }
  }
  else
  {
    v17 = 0;
  }
  v21 = this->m_nMaxChain;
  this->m_pMeteor = v17;
  v22 = (int *)operator new(56 * v21 + 4);
  Block = (void *)v22;
  v32 = 1;
  if ( v22 )
  {
    *v22 = v21;
    v23 = (CMeteorChain *)(v22 + 1);
  }
  else
  {
    v23 = 0;
  }
  m_pGeomQuad = (gbGeomQuad *)this->m_pGeomQuad;
  v32 = -1;
  this->m_pChain = v23;
  if ( !m_pGeomQuad || !v23 )
  {
    qmemcpy(
      pExceptionObject,
      (((Logger *)&ArgList))->Logger::FormatException((char *)&g_EffMgrData.m_nTodo_4FC + 40, (char *)&g_EffMgrData.m_nTodo_4FC + 72, 144),
      sizeof(pExceptionObject));
    _CxxThrowException(pExceptionObject, (_ThrowInfo *)&_TI1_AV_Exception__);
  }
  sub_4CCD10(base->szTexture);
  v26 = 0;
  if ( this->m_nMaxChain > 0 )
  {
    v27 = 0;
    do
    {
      LOBYTE(v25) = this->m_bHaveHead == 0;
      sub_4CD0D0((int)this->m_pEM, this->m_nMaxTrail, v25, (int)this->m_pTextureArray);
      ++v26;
      v27 += 56;
    }
    while ( v26 < this->m_nMaxChain );
  }
  return 1;
}

// 0x004CBC50
int CEffMeteor::slot_6()
{
  int result; // eax
  int v1; // ecx
  int v2; // esi
  int v3; // edi
  int v4; // ebx
  char v5; // al
  bool v6; // zf
  _DWORD *v7; // eax
  gbRenderEffect *v8; // ecx
  int v9; // ebx
  int v10; // edi
  int v11; // ebp
  gbMatrix4 *Top; // eax
  double v13; // st7
  long double v14; // st6
  double v15; // st5
  double v16; // st6
  double v17; // st6
  double v18; // st7
  double v19; // st6
  gbVec3D *v20; // [esp+0x0] [ebp-0x48]
  gbVec3D *v21; // [esp+0x4] [ebp-0x44]
  int v22; // [esp+0x8] [ebp-0x40]
  float v23; // [esp+0x10] [ebp-0x38]
  float v24; // [esp+0x14] [ebp-0x34]
  gbRenderEffect *v25; // [esp+0x18] [ebp-0x30]
  float v26; // [esp+0x1C] [ebp-0x2C]
  gbMatrixStack *v27; // [esp+0x20] [ebp-0x28]
  float v28; // [esp+0x24] [ebp-0x24]
  float v29; // [esp+0x24] [ebp-0x24]
  float v30; // [esp+0x28] [ebp-0x20]
  float v31; // [esp+0x28] [ebp-0x20]
  float v32; // [esp+0x2C] [ebp-0x1C]
  float v33; // [esp+0x2C] [ebp-0x1C]
  float v34; // [esp+0x30] [ebp-0x18]
  float v35; // [esp+0x34] [ebp-0x14]

  v2 = v1;
  if ( (*(_BYTE *)(&g_PAL3.m_nCEffCylinderCount + 27) & 1) == 0 )
  {
    *(&g_PAL3.m_nCEffCylinderCount + 24) = 1065353216;
    *((_BYTE *)&g_PAL3.m_nCEffCylinderCount + 108) |= 1u;
    *(&g_PAL3.m_nCEffCylinderCount + 25) = 0;
    *(&g_PAL3.m_nCEffCylinderCount + 26) = 0;
    result = atexit(nullsub_19);
  }
  if ( (*(_BYTE *)(&g_PAL3.m_nCEffCylinderCount + 27) & 2) == 0 )
  {
    *(&g_PAL3.m_nCEffCylinderCount + 20) = 0;
    *((_BYTE *)&g_PAL3.m_nCEffCylinderCount + 108) |= 2u;
    *(&g_PAL3.m_nCEffCylinderCount + 21) = 1065353216;
    *(&g_PAL3.m_nCEffCylinderCount + 22) = 0;
    result = atexit(nullsub_18);
  }
  if ( (*(_BYTE *)(&g_PAL3.m_nCEffCylinderCount + 27) & 4) == 0 )
  {
    *(&g_PAL3.m_nCEffCylinderCount + 16) = 0;
    *((_BYTE *)&g_PAL3.m_nCEffCylinderCount + 108) |= 4u;
    *(&g_PAL3.m_nCEffCylinderCount + 17) = 0;
    *(&g_PAL3.m_nCEffCylinderCount + 18) = 1065353216;
    result = atexit(nullsub_17);
  }
  LOBYTE(result) = *(_BYTE *)(v2 + 8);
  if ( !(_BYTE)result )
  {
    LOBYTE(result) = *(_BYTE *)(v2 + 68);
    if ( (_BYTE)result )
    {
      result = *(_DWORD *)(v2 + 116);
      v3 = 0;
      if ( result > 0 )
      {
        v4 = 0;
        do
        {
          sub_4CD500(*(_DWORD *)(v2 + 52) + v4);
          result = *(_DWORD *)(v2 + 116);
          ++v3;
          v4 += 56;
        }
        while ( v3 < result );
      }
      LOBYTE(result) = *(_BYTE *)(v2 + 71);
      if ( (_BYTE)result )
      {
        gbVertPoolMgr::GetDynVertBuf(*(gbVertPoolMgr **)(**(_DWORD **)(v2 + 4) + 196), 0x15u);
        v5 = *(_BYTE *)(v2 + 69);
        if ( *(_BYTE *)(v2 + 70) )
        {
          v6 = v5 == 0;
          v7 = *(_DWORD **)(v2 + 4);
          if ( !v6 )
          {
            v25 = (gbRenderEffect *)v7[2];
LABEL_21:
            v9 = 0;
            v27 = *(gbMatrixStack **)(*v7 + 216);
            if ( *(int *)(v2 + 116) > 0 )
            {
              v10 = 0;
              v11 = 0;
              do
              {
                Top = (((gbMatrixStack *)v27))->gbMatrixStack::GetTop();
                (((gbMatrix4 *)Top))->gbMatrix4::Transform(v20, v21, v22);
                v13 = *(float *)(v2 + 108);
                v14 = *(float *)(v2 + 156) * 0.017453292;
                v26 = *(float *)(v2 + 112);
                v24 = cos(v14);
                v23 = sin(v14);
                v34 = -v13 * v24;
                v15 = -v26;
                v28 = v15;
                v30 = v15 * v23;
                *(float *)(*(_DWORD *)(v2 + 48) + v10) = v34 - v30 + 0.0;
                v35 = -v13 * v23;
                v16 = v28 * v24;
                v29 = v16;
                *(float *)(*(_DWORD *)(v2 + 48) + v10 + 4) = v16 + v35 + 0.0;
                *(float *)(*(_DWORD *)(v2 + 48) + v10 + 8) = 0;
                v17 = v24 * v13;
                v32 = v17;
                *(float *)(*(_DWORD *)(v2 + 48) + v10 + 12) = v17 - v30 + 0.0;
                v18 = v13 * v23;
                *(float *)(*(_DWORD *)(v2 + 48) + v10 + 16) = v18 + v29 + 0.0;
                *(float *)(*(_DWORD *)(v2 + 48) + v10 + 20) = 0;
                v31 = v23 * v26;
                *(float *)(*(_DWORD *)(v2 + 48) + v10 + 24) = v32 - v31 + 0.0;
                v19 = v24 * v26;
                v33 = v19;
                *(float *)(*(_DWORD *)(v2 + 48) + v10 + 28) = v19 + v18 + 0.0;
                ++v9;
                v11 += 48;
                *(float *)(*(_DWORD *)(v2 + 48) + v10 + 32) = 0;
                v10 += 68;
                *(float *)(*(_DWORD *)(v2 + 48) + v10 - 32) = v34 - v31 + 0.0;
                *(float *)(*(_DWORD *)(v2 + 48) + v10 - 28) = v33 + v35 + 0.0;
                *(float *)(*(_DWORD *)(v2 + 48) + v10 - 24) = 0;
              }
              while ( v9 < *(_DWORD *)(v2 + 116) );
            }
            (((gbMatrixStack *)v27))->gbMatrixStack::Push();
            (((gbMatrixStack *)v27))->gbMatrixStack::LoadIdentity();
            gbDynVertBuf::RenderGeomQuad(
              *(gbGeomQuad **)(v2 + 48),
              *(_DWORD *)(v2 + 116),
              v25,
              *(gbTextureArray **)(v2 + 64));
            (((gbMatrixStack *)v27))->gbMatrixStack::Pop();
            return result;
          }
          v8 = (gbRenderEffect *)v7[3];
        }
        else
        {
          v6 = v5 == 0;
          v7 = *(_DWORD **)(v2 + 4);
          if ( !v6 )
          {
            v25 = (gbRenderEffect *)v7[4];
            goto LABEL_21;
          }
          v8 = (gbRenderEffect *)v7[5];
        }
        v25 = (gbRenderEffect *)v8;
        goto LABEL_21;
      }
    }
  }
  return result;
}

// 0x004CBFC0

// ---- synthesized vtable stubs (unresolved slots) ----
// [VFTABLE-STUB] original: (*((void ( **)(CTaskTpl_tagEffTaskParam_CEffMeteor *, _DWORD, _DWORD, _DWORD))v4->__vftable + 1))( v4, *(_DWORD *)(*(_DWORD *)v5 + v7), *(_DWORD *)(*(_DWORD *)v5 + v7 + 4), 0)
static void pal3_vtbl_unk_0(CTaskTpl_tagEffTaskParam_CEffMeteor *, _DWORD, _DWORD, _DWORD);

void CEffMeteor::CreateTask(int arg0)
{
  CEffMeteor *v2; // edi
  double v3; // st7
  CTaskTpl_tagEffTaskParam_CEffMeteor *v4; // esi
  int v5; // ebx
  int v6; // edx
  int v7; // edi
  int v8; // ecx
  int v9; // eax
  int v10; // edx
  bool v11; // cc
  int v12; // ebx
  int v13; // esi
  int v14; // esi
  int v15; // edx
  int v16; // eax
  void **v17; // ecx
  int v19; // [esp+0x4] [ebp-0xC]
  int v20; // [esp+0x8] [ebp-0x8]
  int nVal; // [esp+0xC] [ebp-0x4]
v3 = *(float *)&arg0 - *((float *)&this->CTaskTpl_tagEffTaskParam_CEffMeteor::__vftable + 1);
  v4 = ((CTaskTpl_tagEffTaskParam_CEffMeteor *)this);
  *((float *)&this->CTaskTpl_tagEffTaskParam_CEffMeteor::__vftable + 1) = *(float *)&arg0;
  *((float *)&this->CTaskTpl_tagEffTaskParam_CEffMeteor::__vftable + 2) = v3;
  if ( *((float *)&this->CTaskTpl_tagEffTaskParam_CEffMeteor::__vftable + 2) > 0.0 )
  {
    nVal = 0;
    if ( *((int *)&this->CTaskTpl_tagEffTaskParam_CEffMeteor::__vftable + 7) > 0 )
    {
      v20 = 0;
      while ( 1 )
      {
        v5 = v20 + *((_DWORD *)((void **)(v4)) + 3);
        if ( *(_BYTE *)(v5 + 148) )
        {
          if ( *(_DWORD *)(v5 + 12) == 3 )
          {
            v6 = 0;
            v19 = 0;
            if ( *((int *)((void **)(v4)) + 8) > 0 )
              break;
          }
        }
LABEL_29:
        v11 = ++nVal < *((_DWORD *)((void **)(v4)) + 7);
        v20 += 152;
        if ( !v11 )
          goto LABEL_30;
      }
      v7 = 0;
      while ( 1 )
      {
        v8 = v7 + *(_DWORD *)v5;
        if ( !*(_BYTE *)(v8 + 64) || v7 > 0 && *(_DWORD *)(v8 - 64) == 2 )
        {
LABEL_28:
goto LABEL_29;
        }
        switch ( *(_DWORD *)(v8 + 8) )
        {
          case 2:
            if ( v7 > 0 )
            {
              if ( *(float *)(v8 + 20) >= 0.0 )
              {
                if ( *((float *)((void **)(v4)) + 1) - *(float *)(v8 - 56) > *(float *)(v8 + 20) )
                {
                  (((CCBStage *)v4))->CCBStage::GetTaskParam(nVal, v6);
                  *((_DWORD *)((void **)(v4)) + 4) = nVal;
                  *((_DWORD *)((void **)(v4)) + 5) = v19;
                  goto LABEL_24;
                }
              }
              else if ( *(_DWORD *)(v8 - 64) == 4 )
              {
                *(_DWORD *)(*(_DWORD *)(v20 + *((_DWORD *)((void **)(v4)) + 3)) + v7 + 8) = 3;
                *(_DWORD *)(*(_DWORD *)(v20 + *((_DWORD *)((void **)(v4)) + 3)) + v7 + 16) = *((_DWORD *)((void **)(v4))
                                                                                            + 1);
LABEL_21:
                *((_DWORD *)((void **)(v4)) + 5) = v6;
                *((_DWORD *)((void **)(v4)) + 4) = nVal;
LABEL_24:
                pal3_vtbl_unk_0(v4, *(_DWORD *)(*(_DWORD *)v5 + v7), *(_DWORD *)(*(_DWORD *)v5 + v7 + 4), 0) /* [VFTABLE-STUB] */;
              }
            }
            break;
          case 3:
            goto LABEL_21;
          case 4:
            if ( (((CCBStage *)v4))->CCBStage::SetTaskState(nVal) )
            {
              v9 = *(_DWORD *)(v5 + 4);
              *(_DWORD *)(v5 + 12) = 4;
              v10 = 9 * v9;
              LOBYTE(v9) = *(_BYTE *)(v5 + 149);
              *(_DWORD *)(v5 + 20) = *(_DWORD *)(*(_DWORD *)v5 + 8 * v10 - 12);
              if ( (_BYTE)v9 == 1 )
              {
                (((CEffgbParticle *)v4))->CEffgbParticle::Init(nVal);
                goto LABEL_28;
              }
            }
            break;
        }
        v6 = v19 + 1;
        v7 += 72;
        if ( ++v19 >= *((_DWORD *)((void **)(v4)) + 8) )
          goto LABEL_28;
      }
    }
LABEL_30:
    if ( *((int *)&this->CTaskTpl_tagEffTaskParam_CEffMeteor::__vftable + 6) <= 0 )
      this->m_bIdle = 1;
    if ( !this->m_bIdle )
    {
      v12 = 0;
      if ( this->m_nMaxChain > 0 )
      {
        v13 = 0;
        do
        {
          this->m_pChain[v13].m_dwColor = this->m_dwStartColor;
          this->m_pChain[v13].m_fMaxLum = this->m_fMaxLum;
          sub_4CD3D0(arg0);
          ++v12;
          ++v13;
        }
        while ( v12 < this->m_nMaxChain );
      }
      if ( this->m_bHaveHead )
      {
        this->m_fCurFrame = this->m_fFramePerSec * *((float *)&this->CTaskTpl_tagEffTaskParam_CEffMeteor::__vftable + 2)
                        + this->m_fCurFrame;
        if ( (g_bEffSystemFlags & 1) == 0 )
        {
          g_bEffSystemFlags |= 1u;
          (((CEffMgr *)&g_pCEffMgrBackup))->CEffMgr::Reset();
          atexit(todo_401800);
        }
        v14 = 0;
        v15 = (int)abs32((int)this->m_fCurFrame) % (unsigned __int8)this->m_byMaxFrame;
        if ( this->m_nMaxChain > 0 )
        {
          v16 = 0;
          v17 = (void **)(&this->CEffObj::__vftable + 4 * v15);
          do
          {
            ++v14;
            this->m_pGeomQuad[v16++].su = this->m_DefaultUVSet[v15].su;
            LODWORD(this->m_pGeomQuad[v16 - 1].eu) = (unsigned long)v17[54];
            LODWORD(this->m_pGeomQuad[v16 - 1].sv) = (unsigned long)v17[53];
            LODWORD(this->m_pGeomQuad[v16 - 1].ev) = (unsigned long)v17[55];
            this->m_pGeomQuad[v16 - 1].color = this->m_dwStartColor;
          }
          while ( v14 < this->m_nMaxChain );
        }
      }
    }
  }
}

static void pal3_vtbl_unk_0(CTaskTpl_tagEffTaskParam_CEffMeteor *, _DWORD, _DWORD, _DWORD)
{
    
}


// 0x004CC290
void CEffMeteor::CreateTarget(int *pnVal)
{
  CTaskTpl_tagEffTaskParam_CEffMeteor *v2; // ebx
  int v3; // ecx
  int v4; // edx
  int v5; // esi
  _BYTE *i; // eax
  int v7; // ebp
  unsigned int v8; // eax
  int v9; // ecx
  int v10; // eax
  int v11; // edi
  _BYTE *v12; // esi
  int ( **v13)(CEffect *, int); // esi
  unsigned int v14; // eax
  int v15; // ecx
  int v16; // eax
  int v17; // edi
  _BYTE *v18; // esi
  int ( **v19)(CEffect *, int); // esi
  unsigned int v20; // eax

  v2 = ((CTaskTpl_tagEffTaskParam_CEffMeteor *)this);
  v3 = *((_DWORD *)&this->CTaskTpl_tagEffTaskParam_CEffMeteor::__vftable + 7);
  v4 = 0;
  if ( v3 > 0 )
  {
    v5 = *((_DWORD *)((void **)(v2)) + 3);
    for ( i = (_BYTE *)(v5 + 148); *i; i += 152 )
    {
      if ( ++v4 >= v3 )
        return;
    }
    v7 = 152 * v4;
    *(_DWORD *)(v5 + v7 + 12) = 2;
    *(_BYTE *)(*((_DWORD *)((void **)(v2)) + 3) + v7 + 148) = 1;
    *(_BYTE *)(*((_DWORD *)((void **)(v2)) + 3) + v7 + 149) = 1;
    v8 = ++g_PAL3.m_nMeteorChainCount;
    if ( !g_PAL3.m_nMeteorChainCount || v8 >= 0x7FFFFFFF )
    {
      v8 = 1;
      g_PAL3.m_nMeteorChainCount = 1;
    }
    *(_DWORD *)(*((_DWORD *)((void **)(v2)) + 3) + v7 + 16) = v8;
    *(_DWORD *)(*((_DWORD *)((void **)(v2)) + 3) + v7 + 4) = 0;
    *(_DWORD *)(*((_DWORD *)((void **)(v2)) + 3) + v7 + 8) = 0;
    *(_DWORD *)(*((_DWORD *)((void **)(v2)) + 3) + v7 + 20) = 0;
    if ( pnVal )
      qmemcpy((void *)(*((_DWORD *)((void **)(v2)) + 3) + v7 + 24), pnVal, 0x7Cu);
    else
      memset((void *)(*((_DWORD *)((void **)(v2)) + 3) + v7 + 24), 0, 0x7Cu);
    ++*((_DWORD *)((void **)(v2)) + 6);
    if ( v4 != -1 )
    {
      v9 = *((_DWORD *)((void **)(v2)) + 8);
      v10 = 0;
      if ( v9 > 0 )
      {
        v11 = *(_DWORD *)(*((_DWORD *)((void **)(v2)) + 3) + 152 * v4);
        v12 = (_BYTE *)(v11 + 64);
        while ( *v12 )
        {
          ++v10;
          v12 += 72;
          if ( v10 >= v9 )
            goto LABEL_22;
        }
        v13 = (int ( **)(CEffect *, int))(v11 + 72 * v10);
        memset(v13, 0, 0x48u);
        *v13 = CEffect::SetParam;
        *((_BYTE *)v13 + 64) = 1;
        *((_BYTE *)v13 + 65) = 0;
        v13[1] = 0;
        v13[2] = (int ( *)(CEffect *, int))2;
        v14 = ++g_PAL3.m_nMeteorChainCount;
        if ( !g_PAL3.m_nMeteorChainCount || v14 >= 0x7FFFFFFF )
        {
          v14 = 1;
          g_PAL3.m_nMeteorChainCount = 1;
        }
        v13[3] = (int ( *)(CEffect *, int))v14;
        v13[5] = 0;
        v13[4] = 0;
        v13[6] = 0;
        ++*(_DWORD *)(*((_DWORD *)((void **)(v2)) + 3) + v7 + 4);
      }
LABEL_22:
      v15 = *((_DWORD *)((void **)(v2)) + 8);
      v16 = 0;
      if ( v15 > 0 )
      {
        v17 = *(_DWORD *)(*((_DWORD *)((void **)(v2)) + 3) + 152 * v4);
        v18 = (_BYTE *)(v17 + 64);
        while ( *v18 )
        {
          ++v16;
          v18 += 72;
          if ( v16 >= v15 )
            goto LABEL_31;
        }
        v19 = (int ( **)(CEffect *, int))(v17 + 72 * v16);
        memset(v19, 0, 0x48u);
        *v19 = CEffect::SetParam;
        *((_BYTE *)v19 + 64) = 1;
        *((_BYTE *)v19 + 65) = 0;
        v19[1] = 0;
        v19[2] = (int ( *)(CEffect *, int))2;
        v20 = ++g_PAL3.m_nMeteorChainCount;
        if ( !g_PAL3.m_nMeteorChainCount || v20 >= 0x7FFFFFFF )
        {
          v20 = 1;
          g_PAL3.m_nMeteorChainCount = 1;
        }
        v19[3] = (int ( *)(CEffect *, int))v20;
        v19[5] = 0;
        v19[4] = 0;
        v19[6] = 0;
        ++*(_DWORD *)(*((_DWORD *)((void **)(v2)) + 3) + v7 + 4);
      }
LABEL_31:
      (((CMeteorChain *)v2))->CMeteorChain::Update(v4, (int)CEffCylinder_Update, 0, 0, pnVal[18], pnVal[19]);
      *(_DWORD *)(*((_DWORD *)((void **)(v2)) + 3) + v7 + 12) = 3;
      *(_DWORD *)(*(_DWORD *)(*((_DWORD *)((void **)(v2)) + 3) + v7) + 8) = 3;
      *(_DWORD *)(*(_DWORD *)(*((_DWORD *)((void **)(v2)) + 3) + v7) + 16) = *((_DWORD *)((void **)(v2)) + 1);
    }
  }
}

// 0x004CCA90
int CEffMeteor::GetEffectType(int a2)
{
  int result; // eax

  switch ( a2 )
  {
    case 0:
      result = (int)&g_EffMgrData.m_nEffParam_02A4;
      break;
    case 1:
      result = (int)&g_EffMgrData.m_nEffParam9;
      break;
    case 2:
      result = (int)&g_EffMgrData.m_nEffParam8;
      break;
    case 3:
      result = (int)&g_EffMgrData.m_nEffParam7;
      break;
    case 4:
      result = (int)&g_EffMgrData.m_nEffParam6;
      break;
    case 5:
      result = (int)&g_EffMgrData.m_nEffParam_029C;
      break;
    case 6:
      result = (int)&g_EffMgrData.m_nEffParam_0294;
      break;
    case 7:
      result = (int)&g_EffMgrData.m_nEffParam_028C;
      break;
    case 8:
      result = (int)&g_EffMgrData.m_nEffParam2;
      break;
    case 9:
      result = (int)(&g_EffMgrData.m_nEffTypeCode + 8);
      break;
    case 10:
      result = (int)&g_EffMgrData.m_nEffParam_404;
      break;
    case 12:
      result = (int)&g_EffMgrData.m_nEffTypeCode;
      break;
    case 13:
      result = (int)&g_EffMgrData.m_nEffTypeID;
      break;
    case 14:
      result = (int)&g_EffMgrData.m_nEffParam1;
      break;
    case 15:
      result = (int)&g_EffMgrData.m_nEffParam0;
      break;
    case 16:
      result = (int)&g_EffMgrData;
      break;
    case 17:
      result = (int)&g_EffMgrData.m_nEffParam_0268;
      break;
    case 18:
      result = (int)&g_EffMgrData.m_nEffParam_025C;
      break;
    case 19:
      result = (int)&g_EffMgrData.m_nEffParam_0250;
      break;
    case 20:
      result = (int)&g_pszEditorDesc;
      break;
    default:
      result = (int)g_EffCylinderEditorData;
      break;
  }
  return result;
}

// 0x004CCBA0
int CEffMeteor::DispatchByType(int a2)
{
  int result; // eax

  switch ( a2 )
  {
    case 0:
      result = (int)&g_EffMgrData.m_nTodo_5D8;
      break;
    case 1:
      result = (int)&g_EffMgrData.m_nTodo_5CC;
      break;
    case 2:
      result = (int)&g_EffMgrData.m_nTodo_5C0;
      break;
    case 3:
      result = (int)&g_EffMgrData.m_nTodo_5B4;
      break;
    case 4:
      result = (int)&g_EffMgrData.m_nTodo_5A8;
      break;
    case 5:
      result = (int)&g_EffMgrData.m_nTodo_59C;
      break;
    case 6:
      result = (int)&g_EffMgrData.m_nTodo_590;
      break;
    case 7:
      result = (int)&g_EffMgrData.m_nEffParam5;
      break;
    case 8:
      result = (int)&g_EffMgrData.m_nEffParam4;
      break;
    case 9:
      result = (int)&g_EffMgrData.m_nEffParam3;
      break;
    case 10:
      result = (int)&g_EffMgrData.m_nTodo_584;
      break;
    case 11:
      result = (int)&g_EffMgrData.m_nTodo_578;
      break;
    case 12:
      result = (int)&g_EffMgrData.m_nTodo_56C;
      break;
    default:
      result = (int)g_EffCylinderEditorData;
      break;
  }
  return result;
}
