#include "Misc/CTaskTpl_tagEffTaskParam_CEffQuake.h"
#include "Misc/CEffObj.h"
#pragma once
// Auto-generated: CEffQuake
#include "pal3/ida_types.h"

class CEffQuake : public CEffObj, public CTaskTpl_tagEffTaskParam_CEffQuake {
public:
    char _tail_000[4272]; // +0x0
    // total size: 0x10B0 (4272)

    virtual ~CEffQuake() {}

    virtual char AllocSegments(int nVal); // 0x004C0650
    virtual void UpdateInternal(float fVal); // 0x004C29A0
    virtual int * Destroy(); // 0x004D32C0
    virtual int RenderEffectPass(int a2); // 0x004D33B0
    virtual int GetQuakeType(int a2); // 0x004D3660
    int Update(); // 0x004D3300
    CEffQuake * _sdtor(char pData); // 0x004D3860
};
