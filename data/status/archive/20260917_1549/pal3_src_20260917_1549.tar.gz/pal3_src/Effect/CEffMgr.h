#pragma once
// Auto-generated: CEffMgr
#include "pal3/ida_types.h"

#include "gbengine/gbCamera.h"
#include "gbengine/gbGfxManager.h"
#include "gbengine/gbRenderEffect.h"
#include "Misc/tagEffClass.h"

class CCBSystem;

class CEffMgr {
public:
    gbGfxManager * m_pDisplay; // +0x0
    CCBSystem * m_pCBSystem; // +0x4
    gbRenderEffect * m_pAdditiveBlendNoZ; // +0x8
    gbRenderEffect * m_pAlphaBlendNoZ; // +0xC
    gbRenderEffect * m_pAdditiveBlend; // +0x10
    gbRenderEffect * m_pAlphaBlend; // +0x14
    gbCamera * m_pCam; // +0x18
    tagEffClass m_EffClass[32]; // +0x1C
    float m_fEffParam; // +0x9C
    float m_fPosX; // +0xA0
    float m_fPosY; // +0xA4
    float m_fPosZ; // +0xA8
    float m_vecRotAxis; // +0xAC
    float m_nTodo_0B0; // +0xB0
    float m_nTodo_0B4; // +0xB4
    char _gap_0B8[4]; // +0xB8
    int m_nTodo_0BC; // +0xBC
    char _gap_0C0[4]; // +0xC0
    float m_fScaleX; // +0xC4
    float m_fScaleY; // +0xC8
    float m_fScaleZ; // +0xCC
    char m_szEffectPath[48]; // +0xD0
    char m_szLogPath[216]; // +0x100
    int m_nTodo_1D8; // +0x1D8
    char _gap_1DC[264]; // +0x1DC
    int m_nTodo_2E4; // +0x2E4
    char _gap_2E8[124]; // +0x2E8
    char * m_pFileCur; // +0x364
    char _gap_368[152]; // +0x368
    int m_nReset; // +0x400
    int m_nTodo_404; // +0x404
    int m_nTodo_408; // +0x408
    char _gap_40C[1012]; // +0x40C
    int m_pEffectArray; // +0x800
    char _gap_804[280]; // +0x804
    _BYTE m_EffTable[584]; // +0x91C
    int m_nTargetSlot; // +0xB64
    char _gap_B68[10248]; // +0xB68
    UINT roleIdx; // +0x3370
    char _gap_3374[1092]; // +0x3374
    char m_sz5D8C3C[29028]; // +0x37B8
    int m_nEff; // +0xA91C
    float m_fCurTime; // +0xA920
    float m_fDeltaTime; // +0xA924
    float m_fTimer; // +0xA928
    float m_fTimeScale; // +0xA92C
    // total size: 0xA930 (43312)

    void UpdateTimedTrigger(float fVal); // 0x004B7340
    int SetComponent(int nVal); // 0x004B73D0
    int SetEffectClass(int nVal, int nVal2, int nVal3); // 0x004B73F0
    int ProcessEffectPass(int nVal); // 0x004C2F30
    int UpdateParticlePositions(); // 0x004C5350
    int EmitParticles(); // 0x004C7E60
    int UpdateEffect(float fVal, int nVal); // 0x004CCEF0
    char SetEffectsTimeScale(int nVal); // 0x004CDC50
    int CreateEffect(int nVal, int nVal2, int nVal3, int nVal4, int nVal5); // 0x004CDCA0
    int InitEffClass(); // 0x004CDED0
    int FindEffSlot(int nVal); // 0x004CDFD0
    int FindEffByID(int nVal); // 0x004CE000
    CEffMgr(); // 0x004CE100
    ~CEffMgr(); // 0x004CE2A0
    bool Init(int nVal, int nVal2, int nVal3, int nVal4, int nVal5); // 0x004CE340
    void Render(int nVal); // 0x004CE580
    void SetTimeScale(float fScale); // 0x004CE5F0
    static char CreateEff(const char *szEffTypeName, unsigned int dwRunID, float fx, float fy, float fz); // 0x004CE690
    char ReleaseCompletedEffects(); // 0x004CEA80
    static unsigned int RunEffGroup(char *nGroup, float fx, char *fy, float fz, unsigned int dwID); // 0x004CEDA0
    int CreateSParticleEffect(CEffMgr *pEffMgr, int nVal, CEffMgr *pEffMgr2); // 0x004CEFE0
    bool IsAllEffGroupStop(char *pszBuf, int nVal, char *pszBuf2); // 0x004CF100
    int CreateModelEffect(CEffMgr *pEffMgr, int nVal, CEffMgr *pEffMgr2); // 0x004CF220
    int CreateEffectType3(CEffMgr *pEffMgr, int nVal, CEffMgr *pEffMgr2); // 0x004CF460
    int CreateEffectType4(CEffMgr *pEffMgr, int nVal, CEffMgr *pEffMgr2); // 0x004CF6A0
    void CopyObjInGroup(char *nGroup, int nObj, char *nObjType); // 0x004CF7C0
    int CreateEffectType5(CEffMgr *pEffMgr, int nVal, CEffMgr *pEffMgr2); // 0x004CF8E0
    int CreateShockEffect(CEffMgr *pEffMgr, int nVal, CEffMgr *pEffMgr2); // 0x004CFB20
    int UpdateKeyframe(int nVal); // 0x004D22F0
    int * Reset(); // 0x004D58A0
};
