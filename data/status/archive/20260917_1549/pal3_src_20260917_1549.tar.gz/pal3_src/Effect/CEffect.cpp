#include "pal3/ida_defs.h"
#include "globals.h"
#include "pal3/pal3_constants.h"
#include "Effect/CEffect.h"
#include "Combat/CCBCamControl.h"
#include "Combat/CCBRoleState.h"
#include "Combat/CCBStage.h"
#include "Combat/CCBStageCam.h"
#include "Combat/CCBStageRole.h"
#include "Combat/CCBStageScene.h"
#include "Combat/CCBSystem.h"
#include "Combat/CCBUI.h"
#include "Effect/CEffExplosive.h"
#include "Effect/CEffMgr.h"
#include "Effect/CEffQuad.h"
#include "Effect/CEffShock.h"
#include "Effect/CEffectSystem.h"
#include "Effect/CEffgbParticle.h"
#include "Misc/EEffect.h"
#include "GameBase/Logger.h"
#include "GameBase/PAL3.h"
#include "Render/RenderTarget.h"
#include "Render/RenderTarget2.h"
#include "Role/Role.h"
#include "UI/UIWnd.h"
#include "Misc/tagEffMgrData.h"
#include "Misc/tagEffObjType.h"
#include "free_functions.h"

// Forward declarations for unnamed functions
int sub_4D1FD0(...);
int sub_4D3010(...);
int sub_4D48B0(...);
int sub_4D4AB0(...);
void __cdecl todo_401800(void);

// Unnamed globals (extern)
extern char byte_17A7BBC;
extern char byte_17A7E84;
extern int dword_17A7B90;
extern int dword_17A7B94;
extern int dword_17A7B98;
extern int dword_17A7BA0;
extern int dword_17A7BA4;
extern int dword_17A7BA8;
extern int dword_17A7BB0;
extern int dword_17A7BB4;
extern int dword_17A7BB8;
extern int dword_17A7E58;
extern int dword_17A7E5C;
extern int dword_17A7E60;
extern int dword_17A7E68;
extern int dword_17A7E6C;
extern int dword_17A7E70;
extern int dword_17A7E78;
extern int dword_17A7E7C;
extern int dword_17A7E80;
void __cdecl nullsub_89(void);
void __cdecl nullsub_90(void);
void __cdecl nullsub_91(void);
void __cdecl nullsub_92(void);
void __cdecl nullsub_93(void);
void __cdecl nullsub_94(void);

// 0x0048E780
int CEffect::CreateFromTemplate(int f)
{
  char *v4; // edx
  int *v5; // ebx
  int v6; // esi
  RenderTarget *v7; // ebp
  int v8; // eax
  int v9; // eax
  int *p_m_nScaleX; // edi
  RenderTarget *v11; // esi
  bool v12; // zf
  int result; // eax
  int fX; // [esp+0x0] [ebp-0x24]
  float fXa; // [esp+0x0] [ebp-0x24]
  int fXb; // [esp+0x0] [ebp-0x24]
  int fY; // [esp+0x4] [ebp-0x20]
  float fYa; // [esp+0x4] [ebp-0x20]
  int v19; // [esp+0x18] [ebp-0xC]
  int *v20; // [esp+0x1C] [ebp-0x8]
  int fa; // [esp+0x28] [ebp+0x4]

  this->m_QuadBuffer[1579].color = 0;
  this->m_QuadBuffer[1580].vec[0].x = 0.0;
  fa = 16;
  v4 = (char *)this + 16 * f;
  *((_BYTE *)&this->m_QuadBuffer[1579].color + f) = 1;
  v5 = (int *)(v4 + 205644);
  v6 = *((_DWORD *)v4 + 51413) - *((_DWORD *)v4 + 51411);
  v20 = (int *)(&this->m_QuadBuffer[1578].vec[0].z + 4 * f);
  v19 = v6;
  v7 = (RenderTarget *)((char *)&this->m_Partical[1169] + 9344 * f);
  while ( 1 )
  {
    (((RenderTarget *)v7))->RenderTarget::LoadTexture(szFilename);
    (((RenderTarget *)v7))->RenderTarget::SetSize(32);
    fY = rand() % 10 + 66;
    fX = rand() % 10 + 188;
    v8 = rand();
    (((RenderTarget *)v7))->RenderTarget::SetColor(v8 % 10 - 6, fX, fY);
    v9 = rand();
    (((RenderTarget *)v7))->RenderTarget::SetAlpha(v9 % 55 - 56);
    *((_BYTE *)&v7->m_ScreenPlane + 4) = 1;
    (((RenderTarget *)v7))->RenderTarget::SetField084();
    (((RenderTarget *)v7))->RenderTarget::SetState();
    fYa = (float)*v20;
    fXa = (float)(*v5 + rand() % v6);
    (((RenderTarget *)v7))->RenderTarget::UpdateTransform(fXa, fYa);
    (((RenderTarget *)v7))->RenderTarget::Render(*v5, v5[1], v5[2]);
    rand();
    *(float *)&fXb = (float)(rand() % 2 + 1);
    (((RenderTarget *)v7))->RenderTarget::SetOffset(fXb);
    (((RenderTarget *)v7))->RenderTarget::SetScale(0);
    (((RenderTarget *)v7))->RenderTarget::SetVisible(1);
    p_m_nScaleX = (int *)&v7[373].m_nScaleX;
    v11 = (RenderTarget *)v7;
    v7 = (RenderTarget *)((char *)v7 + 584);
    result = fa - 1;
    v12 = fa == 1;
    qmemcpy(p_m_nScaleX, v11, 0x248u);
    --fa;
    if ( v12 )
      break;
    v6 = v19;
  }
  return result;
}

// 0x004BB190
int CEffect::SetRenderParam(int nVal)
{
  int v3; // edi
  float *p_ev; // ebx
  int result; // eax
  int v6; // edi
  RenderTarget *p_color; // ebx

  v3 = 0;
  if ( *(int *)&this->m_Partical[4].byAlpha > 0 )
  {
    p_ev = (float *)&this->m_QuadBuffer[2000].ev;
    do
    {
      (((RenderTarget *)p_ev))->RenderTarget::ApplyScale(*(float *)&nVal);
      ++v3;
      p_ev += 8022;
    }
    while ( v3 < *(_DWORD *)&this->m_Partical[4].byAlpha );
  }
  result = LODWORD(this->m_Partical[4].fSize);
  v6 = 0;
  if ( result > 0 )
  {
    p_color = (RenderTarget *)&this->m_QuadBuffer[731].color;
    do
    {
      (((RenderTarget *)p_color))->RenderTarget::SetRenderState(nVal);
      result = LODWORD(this->m_Partical[4].fSize);
      ++v6;
      p_color = (RenderTarget *)((char *)p_color + 21572);
    }
    while ( v6 < result );
  }
  return result;
}

// 0x004BD7A0
int * CEffect::SetQuadParam(int nVal)
{
  int *result; // eax
  int v3; // ecx

  result = (int *)&this->m_QuadBuffer[2003].vec[2];
  v3 = 4;
  do
  {
    *result = nVal;
    result += 8022;
    --v3;
  }
  while ( v3 );
  return result;
}

// 0x004C6940
CEffect::CEffect()
{
  CEffectSystem *v1; // eax

  v1 = (CEffectSystem *)operator new(0x10C0u);
  if ( v1 )
    (((CEffectSystem *)v1))->CEffectSystem::FillDefaultUVSet();
}

// 0x004C6A70
void CEffect::Reset(float *pfVal, float fVal, float fVal2, float fVal3)
{
  int nQuadIndex_low; // ecx

  this->m_eKind = 0;
  LOBYTE(this->m_Partical[0].fZ) = 0;
  this->m_Partical[2].fSize = fVal + pfVal[46];
  *(float *)&this->m_Partical[2].byAlpha = fVal2 + pfVal[47];
  *(float *)&this->m_Partical[3].pPic = fVal3 + pfVal[48];
  this->m_Partical[2].fX = pfVal[54];
  this->m_Partical[2].fY = pfVal[49];
  this->m_Partical[2].fZ = pfVal[55];
  *(_DWORD *)&this->m_Partical[3].byMaxFrame = 0;
  *(_DWORD *)&this->m_Partical[3].bValid = 0;
  this->m_Partical[3].nQuadIndex = 0;
  this->m_Partical[1].nQuadIndex = (int)pfVal[51];
  if ( (g_bEffSystemFlags & 1) == 0 )
  {
    g_bEffSystemFlags |= 1u;
    (((CEffMgr *)&g_pCEffMgrBackup))->CEffMgr::Reset();
    atexit(todo_401800);
  }
  *(float *)&this->m_Partical[1].bValid = (float)HIBYTE(this->m_Partical[1].nQuadIndex);
  if ( (g_bEffSystemFlags & 1) == 0 )
  {
    g_bEffSystemFlags |= 1u;
    (((CEffMgr *)&g_pCEffMgrBackup))->CEffMgr::Reset();
    atexit(todo_401800);
  }
  *(float *)&this->m_Partical[1].byMaxFrame = (float)(unsigned __int8)BYTE2(this->m_Partical[1].nQuadIndex);
  if ( (g_bEffSystemFlags & 1) == 0 )
  {
    g_bEffSystemFlags |= 1u;
    (((CEffMgr *)&g_pCEffMgrBackup))->CEffMgr::Reset();
    atexit(todo_401800);
  }
  this->m_Partical[1].fFramePerSec = (float)(unsigned __int8)BYTE1(this->m_Partical[1].nQuadIndex);
  if ( (g_bEffSystemFlags & 1) == 0 )
  {
    g_bEffSystemFlags |= 1u;
    (((CEffMgr *)&g_pCEffMgrBackup))->CEffMgr::Reset();
    atexit(todo_401800);
  }
  this->m_Partical[1].pPic = 0;
  nQuadIndex_low = LOBYTE(this->m_Partical[1].nQuadIndex);
  *(_DWORD *)&this->m_Partical[0].byAlpha = 0;
  this->m_Partical[1].fCurFrame = (float)nQuadIndex_low;
  this->m_Partical[1].dwColor = (unsigned int)pfVal[50];
  this->m_Partical[1].fX = pfVal[50];
  /* [MISATTRIBUTED] CEffExplosive on CEffect::this -> fix IDB name of callee */ CEffExplosive::CreateGeom((CEffExplosive *)this);
}

// 0x004C7150
void CEffect::CreateOnePartical(float pPartical)
{
  CEffect *v2; // edi
  double v3; // st7
  CCBStage *p_m_bActive; // esi
  char *v5; // ebx
  int v6; // edx
  int v7; // edi
  int v8; // ecx
  int v9; // eax
  int v10; // edx
  bool v11; // cc
  int v12; // esi
  int v13; // edx
  int fY_low; // ecx
  float *v15; // eax
  float *v16; // ebx
  double v17; // st7
  int v18; // edx
  int v19; // eax
  float *v20; // [esp+0x0] [ebp-0x18]
  float *v21; // [esp+0x4] [ebp-0x14]
  float v22; // [esp+0x8] [ebp-0x10]
  int fZ_low; // [esp+0xC] [ebp-0xC]
  float v25; // [esp+0xC] [ebp-0xC]
  CCBStageScene *v26; // [esp+0x10] [ebp-0x8]
  float v27; // [esp+0x10] [ebp-0x8]
  int v28; // [esp+0x14] [ebp-0x4]
  float v29; // [esp+0x14] [ebp-0x4]
  int pParticala; // [esp+0x20] [ebp+0x8]
  int pParticalb; // [esp+0x20] [ebp+0x8]
v3 = pPartical - *(float *)&this->m_DeltaTime;
  p_m_bActive = (CCBStage *)&this->m_bActive;
  *(float *)&this->m_DeltaTime = pPartical;
  *((float *)&this->m_DeltaTime + 1) = v3;
  if ( *((float *)&this->m_DeltaTime + 1) > 0.0 )
  {
    pParticala = 0;
    if ( *(int *)&this->m_Partical[0].byMaxFrame > 0 )
    {
      v28 = 0;
      while ( 1 )
      {
        v5 = (char *)p_m_bActive->m_pCam + v28;
        if ( v5[148] )
        {
          if ( *((_DWORD *)v5 + 3) == 3 )
          {
            v6 = 0;
            v26 = 0;
            if ( (int)p_m_bActive->m_pRole[2] > 0 )
              break;
          }
        }
LABEL_29:
        v11 = ++pParticala < (int)p_m_bActive->m_pRole[1];
        v28 += 152;
        if ( !v11 )
          goto LABEL_30;
      }
      v7 = 0;
      while ( 1 )
      {
        v8 = v7 + *(_DWORD *)v5;
        if ( !*(_BYTE *)(v8 + 64) || v7 > 0 && *(_DWORD *)(v8 - 64) == 2 )
        {
LABEL_28:
goto LABEL_29;
        }
        switch ( *(_DWORD *)(v8 + 8) )
        {
          case 2:
            if ( v7 > 0 )
            {
              if ( *(float *)(v8 + 20) >= 0.0 )
              {
                if ( *(float *)&p_m_bActive->m_pRoleState - *(float *)(v8 - 56) > *(float *)(v8 + 20) )
                {
                  (((CCBStage *)p_m_bActive))->CCBStage::GetTaskParam(pParticala, v6);
                  p_m_bActive->m_pCamControl = (CCBCamControl *)pParticala;
                  p_m_bActive->m_pScene = v26;
                  goto LABEL_24;
                }
              }
              else if ( *(_DWORD *)(v8 - 64) == 4 )
              {
                *(_DWORD *)(*(_DWORD *)((char *)&p_m_bActive->m_pCam->fov + v28) + v7 + 8) = 3;
                *(_DWORD *)(*(_DWORD *)((char *)&p_m_bActive->m_pCam->fov + v28) + v7 + 16) = (_DWORD)p_m_bActive->m_pRoleState;
LABEL_21:
                p_m_bActive->m_pScene = (CCBStageScene *)v6;
                p_m_bActive->m_pCamControl = (CCBCamControl *)pParticala;
LABEL_24:
                ((void ( *)(CCBStage *, _DWORD, _DWORD, _DWORD))p_m_bActive->m_pCBSystem->m_pUI)(
                  p_m_bActive,
                  *(_DWORD *)(*(_DWORD *)v5 + v7),
                  *(_DWORD *)(*(_DWORD *)v5 + v7 + 4),
                  0);
              }
            }
            break;
          case 3:
            goto LABEL_21;
          case 4:
            if ( (((CCBStage *)p_m_bActive))->CCBStage::SetTaskState(pParticala) )
            {
              v9 = *((_DWORD *)v5 + 1);
              *((_DWORD *)v5 + 3) = 4;
              v10 = 9 * v9;
              LOBYTE(v9) = (unsigned long)v5[149];
              *((_DWORD *)v5 + 5) = *(_DWORD *)(*(_DWORD *)v5 + 8 * v10 - 12);
              if ( (_BYTE)v9 == 1 )
              {
                (((CEffgbParticle *)p_m_bActive))->CEffgbParticle::Init(pParticala);
                goto LABEL_28;
              }
            }
            break;
        }
        v6 = (int)&v26->m_pStage + 1;
        v7 += 72;
        v26 = (CCBStageScene *)((char *)v26 + 1);
        if ( (int)v26 >= (int)p_m_bActive->m_pRole[2] )
          goto LABEL_28;
      }
    }
LABEL_30:
    if ( *(int *)&this->m_Partical[0].bValid <= 0 )
      this->m_eKind = (EEffect)1;
    if ( !*(_BYTE *)&this->m_eKind )
    {
      *(float *)&this->m_Partical[1].pPic = *(float *)&this->m_Partical[2].dwColor * *((float *)&this->m_DeltaTime + 1)
                                        + *(float *)&this->m_Partical[1].pPic;
      if ( (g_bEffSystemFlags & 1) == 0 )
      {
        g_bEffSystemFlags |= 1u;
        (((CEffMgr *)&g_pCEffMgrBackup))->CEffMgr::Reset();
        atexit(todo_401800);
      }
      v12 = 0;
      v13 = (int)abs32((int)*(float *)&this->m_Partical[1].pPic) % HIBYTE(this->m_Partical[0].fZ);
      fY_low = LODWORD(this->m_Partical[1].fY);
      v15 = (float *)((char *)v2 + 16 * v13);
      v16 = (float *)(&this->m_Partical[3].fCurFrame + 4 * v13);
      fZ_low = LODWORD(this->m_Partical[1].fZ);
      v20 = (float *)v15;
      v21 = (float *)v16;
      pParticalb = 0;
      v29 = (v15[50] - *v16) * (1.0 / (double)fY_low);
      v27 = (v15[51] - v15[49]) * (1.0 / (double)fZ_low);
      if ( fZ_low > 0 )
      {
        do
        {
          v17 = *v16;
          v18 = 0;
          v25 = (double)pParticalb * v27 + v15[49];
          if ( fY_low > 0 )
          {
            v19 = 68 * v12;
            do
            {
              ++v12;
              *(float *)(v19 + LODWORD(this->m_Partical[0].fCurFrame) + 48) = v17;
              v17 = v17 + v29;
              v19 += 68;
              ++v18;
              *(float *)(v19 + LODWORD(this->m_Partical[0].fCurFrame) - 12) = v17;
              *(float *)(v19 + LODWORD(this->m_Partical[0].fCurFrame) - 16) = v25;
              v22 = v27 + v25;
              *(float *)(v19 + LODWORD(this->m_Partical[0].fCurFrame) - 8) = v22;
              *(_DWORD *)(v19 + LODWORD(this->m_Partical[0].fCurFrame) - 4) = this->m_Partical[1].nQuadIndex;
              fY_low = LODWORD(this->m_Partical[1].fY);
            }
            while ( v18 < fY_low );
            v16 = (float *)v21;
            v15 = (float *)v20;
          }
          ++pParticalb;
        }
        while ( pParticalb < SLODWORD(this->m_Partical[1].fZ) );
      }
    }
  }
}

// 0x004C7450
void CEffect::FillQuadByPartical(int *nParticalIndex)
{
  _BYTE *p_m_bActive; // ebx
  int v3; // ecx
  int v4; // edx
  int v5; // esi
  _BYTE *i; // eax
  int v7; // ebp
  unsigned int v8; // eax
  int v9; // ecx
  int v10; // eax
  int v11; // edi
  _BYTE *v12; // esi
  int ( **v13)(CEffect *, int); // esi
  unsigned int v14; // eax
  int v15; // ecx
  int v16; // eax
  int v17; // edi
  _BYTE *v18; // esi
  int ( **v19)(CEffect *, int); // esi
  unsigned int v20; // eax

  p_m_bActive = (_BYTE *)&this->m_bActive;
  v3 = *(_DWORD *)&this->m_Partical[0].byMaxFrame;
  v4 = 0;
  if ( v3 > 0 )
  {
    v5 = *((_DWORD *)p_m_bActive + 3);
    for ( i = (_BYTE *)(v5 + 148); *i; i += 152 )
    {
      if ( ++v4 >= v3 )
        return;
    }
    v7 = 152 * v4;
    *(_DWORD *)(v5 + v7 + 12) = 2;
    *(_BYTE *)(*((_DWORD *)p_m_bActive + 3) + v7 + 148) = 1;
    *(_BYTE *)(*((_DWORD *)p_m_bActive + 3) + v7 + 149) = 1;
    v8 = ++g_PAL3.m_nCEffCylinderCount;
    if ( !g_PAL3.m_nCEffCylinderCount || v8 >= 0x7FFFFFFF )
    {
      v8 = 1;
      g_PAL3.m_nCEffCylinderCount = 1;
    }
    *(_DWORD *)(*((_DWORD *)p_m_bActive + 3) + v7 + 16) = v8;
    *(_DWORD *)(*((_DWORD *)p_m_bActive + 3) + v7 + 4) = 0;
    *(_DWORD *)(*((_DWORD *)p_m_bActive + 3) + v7 + 8) = 0;
    *(_DWORD *)(*((_DWORD *)p_m_bActive + 3) + v7 + 20) = 0;
    if ( nParticalIndex )
      qmemcpy((void *)(*((_DWORD *)p_m_bActive + 3) + v7 + 24), nParticalIndex, 0x7Cu);
    else
      memset((void *)(*((_DWORD *)p_m_bActive + 3) + v7 + 24), 0, 0x7Cu);
    ++*((_DWORD *)p_m_bActive + 6);
    if ( v4 != -1 )
    {
      v9 = *((_DWORD *)p_m_bActive + 8);
      v10 = 0;
      if ( v9 > 0 )
      {
        v11 = *(_DWORD *)(*((_DWORD *)p_m_bActive + 3) + 152 * v4);
        v12 = (_BYTE *)(v11 + 64);
        while ( *v12 )
        {
          ++v10;
          v12 += 72;
          if ( v10 >= v9 )
            goto LABEL_22;
        }
        v13 = (int ( **)(CEffect *, int))(v11 + 72 * v10);
        memset(v13, 0, 0x48u);
        *v13 = CEffect::SetParam;
        *((_BYTE *)v13 + 64) = 1;
        *((_BYTE *)v13 + 65) = 0;
        v13[1] = 0;
        v13[2] = (int ( *)(CEffect *, int))2;
        v14 = ++g_PAL3.m_nCEffCylinderCount;
        if ( !g_PAL3.m_nCEffCylinderCount || v14 >= 0x7FFFFFFF )
        {
          v14 = 1;
          g_PAL3.m_nCEffCylinderCount = 1;
        }
        v13[3] = (int ( *)(CEffect *, int))v14;
        v13[5] = 0;
        v13[4] = 0;
        v13[6] = 0;
        ++*(_DWORD *)(*((_DWORD *)p_m_bActive + 3) + v7 + 4);
      }
LABEL_22:
      v15 = *((_DWORD *)p_m_bActive + 8);
      v16 = 0;
      if ( v15 > 0 )
      {
        v17 = *(_DWORD *)(*((_DWORD *)p_m_bActive + 3) + 152 * v4);
        v18 = (_BYTE *)(v17 + 64);
        while ( *v18 )
        {
          ++v16;
          v18 += 72;
          if ( v16 >= v15 )
            goto LABEL_31;
        }
        v19 = (int ( **)(CEffect *, int))(v17 + 72 * v16);
        memset(v19, 0, 0x48u);
        *v19 = CEffect::SetParam;
        *((_BYTE *)v19 + 64) = 1;
        *((_BYTE *)v19 + 65) = 0;
        v19[1] = 0;
        v19[2] = (int ( *)(CEffect *, int))2;
        v20 = ++g_PAL3.m_nCEffCylinderCount;
        if ( !g_PAL3.m_nCEffCylinderCount || v20 >= 0x7FFFFFFF )
        {
          v20 = 1;
          g_PAL3.m_nCEffCylinderCount = 1;
        }
        v19[3] = (int ( *)(CEffect *, int))v20;
        v19[5] = 0;
        v19[4] = 0;
        v19[6] = 0;
        ++*(_DWORD *)(*((_DWORD *)p_m_bActive + 3) + v7 + 4);
      }
LABEL_31:
      (((CEffgbParticle *)p_m_bActive))->CEffgbParticle::~CEffgbParticle(v4, (int)ProcCommonTask__ovl, 0, 0, nParticalIndex[18], nParticalIndex[19]);
      *(_DWORD *)(*((_DWORD *)p_m_bActive + 3) + v7 + 12) = 3;
      *(_DWORD *)(*(_DWORD *)(*((_DWORD *)p_m_bActive + 3) + v7) + 8) = 3;
      *(_DWORD *)(*(_DWORD *)(*((_DWORD *)p_m_bActive + 3) + v7) + 16) = *((_DWORD *)p_m_bActive + 1);
    }
  }
}

// 0x004CA400
int CEffect::SetParam(int nVal)
{
  int v2; // edx
  char v3; // bl
  int v4; // edx

  v2 = *(_DWORD *)(this->m_nPartical + 152 * (int)this->m_Partical[0].pPic);
  v3 = *(_BYTE *)(v2 + 72 * this->m_Partical[0].nQuadIndex + 65);
  v4 = v2 + 72 * this->m_Partical[0].nQuadIndex;
  if ( !v3 )
    *(_BYTE *)(v4 + 65) = 1;
  if ( *(_BYTE *)(v4 + 66) == 1 || *(float *)&this->m_DeltaTime - *(float *)(v4 + 16) >= *(float *)(v4 + 24) )
    *(_DWORD *)(v4 + 8) = 4;
  return 0;
}

// 0x004CE460
int CEffect::Render(int nVal)
{
  int result; // eax
  int v3; // esi
  unsigned int v4; // ebx
  int Effect; // edi
  int *v6; // esi
  int v7; // ebp
  bool v8; // cc
  int *v9; // [esp+0x8] [ebp-0x10]
  int v11; // [esp+0x10] [ebp-0x8]
  int v12; // [esp+0x14] [ebp-0x4]
  int *nVala; // [esp+0x1C] [ebp+0x4]

  if ( (g_bEffSystemFlags & 1) == 0 )
  {
    g_bEffSystemFlags |= 1u;
    (((CEffMgr *)&g_pCEffMgrBackup))->CEffMgr::Reset();
    atexit(todo_401800);
  }
  result = g_nCEffect_1895980;
  if ( g_nCEffect_1895980 == -1 )
    result = 1;
  v3 = result;
  g_nCEffect_1895980 = result + 1;
  v12 = result;
  v11 = 0;
  v4 = 15940 * nVal;
  if ( *(&g_nSaveSlot0 + 3985 * nVal) > 0 )
  {
    v9 = (int *)&g_nSaveSlotBase[v4 / 4];
    nVala = (int *)((char *)&g_nSaveSlot1 + v4);
    do
    {
      Effect = /* [MISATTRIBUTED] CEffMgr on CEffect::this -> fix IDB name of callee */ CEffMgr::CreateEffect((CEffMgr *)this, *nVala, v3, 0, 0, 0);
      if ( Effect != -1 )
      {
        v6 = (int *)v9;
        v7 = 8;
        do
        {
          if ( *((_BYTE *)v6 + 88) )
            (*(void ( **)(_DWORD, int *))(**((_DWORD **)&this->m_Partical[48].fFramePerSec + 5 * Effect) + 36))(
              *((_DWORD *)&this->m_Partical[48].fFramePerSec + 5 * Effect),
              v6);
          v6 += 31;
          --v7;
        }
        while ( v7 );
        v3 = v12;
      }
      v8 = ++v11 < *(int *)((char *)&g_nSaveSlot0 + v4);
      ++nVala;
      v9 += 248;
    }
    while ( v8 );
    return v3;
  }
  return result;
}

// 0x004CFE20
int CEffect::_nearby_4cfe20(int a2, float a3, float a4, float a5)
{
  int result; // eax
  float fCurFrame; // ecx

  this->m_eKind = 0;
  this->m_Partical[1].byMaxFrame = 0;
  *(float *)&this->m_Partical[0].dwColor = a3 + *(float *)(a2 + 184);
  this->m_Partical[0].fX = a4 + *(float *)(a2 + 188);
  this->m_Partical[0].fY = a5 + *(float *)(a2 + 192);
  *(_DWORD *)&this->m_Partical[0].byAlpha = 0;
  this->m_Partical[0].fSize = 0.0;
  this->m_Partical[0].fZ = 0.0;
  this->m_Partical[1].pPic = *(char **)(a2 + 216);
  this->m_Partical[1].nQuadIndex = *(_DWORD *)(a2 + 196);
  *(_DWORD *)&this->m_Partical[1].bValid = *(_DWORD *)(a2 + 220);
  this->m_Partical[1].fFramePerSec = *(float *)(a2 + 200);
  this->m_Partical[1].fCurFrame = *(float *)(a2 + 200);
  result = *(_DWORD *)(a2 + 200);
  this->m_Partical[1].dwColor = result;
  fCurFrame = this->m_Partical[0].fCurFrame;
  if ( fCurFrame != 0.0 )
    return (*(int ( **)(float, _DWORD))(*(_DWORD *)LODWORD(fCurFrame) + 24))(
             _pal3_coerce_f32(LODWORD(fCurFrame)),
             0);
  return result;
}

// 0x004CFFB0
void CEffect::_nearby_4cffb0(float a2)
{
  float *p_m_bActive; // esi
  int v3; // ebx
  int *v4; // ebp
  int v5; // edx
  int v6; // edi
  int v7; // ecx
  int v8; // ecx
  _DWORD *v9; // eax
  int v10; // edx
  _DWORD *v11; // eax
  int v12; // eax
  int v13; // ecx
  int v14; // eax
  int v15; // ecx
  float fCurFrame; // ecx
  int v17; // [esp+0xC] [ebp-0x8]
  CEffect *v18; // [esp+0x10] [ebp-0x4]
  int a2a; // [esp+0x18] [ebp+0x4]

  p_m_bActive = (float *)&this->m_bActive;
*((float *)&this->m_DeltaTime + 1) = a2 - *(float *)&this->m_DeltaTime;
  *(float *)&this->m_DeltaTime = a2;
  if ( *((float *)&this->m_DeltaTime + 1) <= 0.0 )
    return;
  v3 = 0;
  a2a = 0;
  if ( *(int *)&this->m_Partical[0].byMaxFrame <= 0 )
    goto LABEL_35;
  do
  {
    v4 = (int *)(v3 + *((_DWORD *)p_m_bActive + 3));
    if ( *((_BYTE *)v4 + 148) )
    {
      if ( v4[3] == 3 )
      {
        v5 = 0;
        v17 = 0;
        if ( *((int *)p_m_bActive + 8) > 0 )
        {
          v6 = 0;
          do
          {
            v7 = (unsigned long)*v4;
            if ( !*(_BYTE *)(v6 + *v4 + 64) || v6 > 0 && *(_DWORD *)(v6 + v7 - 64) == 2 )
              break;
            switch ( *(_DWORD *)(v6 + v7 + 8) )
            {
              case 2:
                if ( v6 > 0 )
                {
                  if ( *(float *)(v6 + v7 + 20) >= 0.0 )
                  {
                    if ( p_m_bActive[1] - *(float *)(v6 + v7 - 56) > *(float *)(v6 + v7 + 20) )
                    {
LABEL_25:
                      *(_DWORD *)(*(_DWORD *)(v3 + *((_DWORD *)p_m_bActive + 3)) + v6 + 8) = 3;
                      *(float *)(*(_DWORD *)(v3 + *((_DWORD *)p_m_bActive + 3)) + v6 + 16) = (unsigned long)p_m_bActive[1];
                      *((_DWORD *)p_m_bActive + 4) = a2a;
                      *((_DWORD *)p_m_bActive + 5) = v17;
                      goto LABEL_26;
                    }
                  }
                  else if ( *(_DWORD *)(v6 + v7 - 64) == 4 )
                  {
                    goto LABEL_25;
                  }
                }
                break;
              case 3:
                *((_DWORD *)p_m_bActive + 5) = v5;
                *((_DWORD *)p_m_bActive + 4) = a2a;
LABEL_26:
                (*(void ( **)(float *, _DWORD, _DWORD, _DWORD))(*(_DWORD *)p_m_bActive + 4))(
                  p_m_bActive,
                  *(_DWORD *)(*v4 + v6),
                  *(_DWORD *)(*v4 + v6 + 4),
                  0);
                break;
              case 4:
                v8 = 0;
                v9 = (_DWORD *)(v3 + *((_DWORD *)p_m_bActive + 3));
                v10 = (unsigned long)v9[1];
                if ( v10 <= 0 )
                {
LABEL_17:
                  v12 = (unsigned long)v4[1];
                  v4[3] = 4;
                  v13 = 9 * v12;
                  LOBYTE(v12) = *((_BYTE *)v4 + 149);
                  v4[5] = *(_DWORD *)(*v4 + 8 * v13 - 12);
                  if ( (_BYTE)v12 == 1 )
                  {
                    v14 = 0;
                    *(_BYTE *)(v3 + *((_DWORD *)p_m_bActive + 3) + 148) = 0;
                    if ( *((int *)p_m_bActive + 8) > 0 )
                    {
                      v15 = 0;
                      do
                      {
                        ++v14;
                        v15 += 72;
                        *(_BYTE *)(*(_DWORD *)(v3 + *((_DWORD *)p_m_bActive + 3)) + v15 - 8) = 0;
                      }
                      while ( v14 < *((_DWORD *)p_m_bActive + 8) );
                    }
                    *(_DWORD *)(v3 + *((_DWORD *)p_m_bActive + 3) + 4) = 0;
                    --*((_DWORD *)p_m_bActive + 6);
                    goto LABEL_33;
                  }
                }
                else
                {
                  v11 = (_DWORD *)(*v9 + 8);
                  while ( *v11 == 4 )
                  {
                    ++v8;
                    v11 += 18;
                    if ( v8 >= v10 )
                      goto LABEL_17;
                  }
                }
                break;
            }
            v5 = v17 + 1;
            v6 += 72;
            ++v17;
          }
          while ( v17 < *((_DWORD *)p_m_bActive + 8) );
        }
      }
    }
LABEL_33:
    v3 += 152;
    ++a2a;
  }
  while ( a2a < *((_DWORD *)p_m_bActive + 7) );
  this = v18;
LABEL_35:
  if ( *(int *)&this->m_Partical[0].bValid <= 0 )
  {
    this->m_eKind = (EEffect)1;
    this->m_Partical[1].byMaxFrame = 0;
  }
  fCurFrame = this->m_Partical[0].fCurFrame;
  if ( fCurFrame != 0.0 )
    (*(void ( **)(float))(*(_DWORD *)LODWORD(fCurFrame) + 20))(_pal3_coerce_f32(LODWORD(fCurFrame)));
}

// 0x004D0D70
CEffect * CEffect::SetTimeScale()
{
  int v2; // [esp+0x4] [ebp+0x4]

  if ( operator new(0x10B0u) )
    return (CEffect *)CEffModel_Reset(v2);
  else
    return 0;
}

// 0x004D0DB0
void CEffect::UpdateCallback()
{
  _BYTE *p_m_bActive; // edi
  float fY; // eax
  int v4; // ebp
  gbRefObject *v5; // ecx
  _BYTE *v6; // esi
  int v7; // eax
  bool v8; // cc
  int v9; // edi

  p_m_bActive = (_BYTE *)&this->m_bActive;
  fY = this->m_Partical[2].fY;
  v4 = 0;
  if ( fY != 0.0 )
    operator delete((void *)LODWORD(fY));
  if ( LODWORD(this->m_Partical[2].fZ) )
    operator delete((void *)LODWORD(this->m_Partical[2].fZ));
  if ( LODWORD(this->m_Partical[2].fSize) )
    operator delete((void *)LODWORD(this->m_Partical[2].fSize));
  v5 = *(gbRefObject **)&this->m_Partical[88].byMaxFrame;
  if ( v5 )
    (((gbRefObject *)v5))->gbRefObject::Release();
  if ( LODWORD(this->m_Partical[88].fFramePerSec) )
    operator delete((void *)LODWORD(this->m_Partical[88].fFramePerSec));
  v6 = this != 0 ? p_m_bActive : 0;
  v7 = *((_DWORD *)v6 + 7);
  v8 = v7 <= 0;
  if ( !v7 )
  {
    if ( !*(this != 0 ? (_DWORD *)(p_m_bActive + 32) : (_DWORD *)32) )
      return;
    v8 = 1;
  }
  if ( !v8 )
  {
    v9 = 0;
    do
    {
      operator delete(*(void **)(*((_DWORD *)v6 + 3) + v9));
      ++v4;
      *(_DWORD *)(*((_DWORD *)v6 + 3) + v9) = 0;
      v9 += 152;
    }
    while ( v4 < *((_DWORD *)v6 + 7) );
  }
  operator delete(*((void **)v6 + 3));
  *((_DWORD *)v6 + 3) = 0;
  *((_DWORD *)v6 + 7) = 0;
  *((_DWORD *)v6 + 8) = 0;
}

// 0x004D0EC0
int CEffect::ProcInitTask(float *dwParam, float fVal, float fVal2, float fVal3)
{
  int result; // eax
  int v7; // edx
  double v8; // st7

  LOBYTE(this->m_Partical[0].fCurFrame) = 1;
  BYTE1(this->m_Partical[0].fCurFrame) = 1;
  this->m_eKind = 0;
  HIBYTE(this->m_Partical[0].fCurFrame) = *((_BYTE *)dwParam + 214);
  (((CCBStage *)this))->CCBStage::GetActiveTaskCount() /* [ROWTABLE] */;
  this->m_Partical[1].nQuadIndex = 257;
  this->m_Partical[2].fX = dwParam[51];
  if ( (g_bEffSystemFlags & 1) == 0 )
  {
    g_bEffSystemFlags |= 1u;
    (((CEffMgr *)&g_pCEffMgrBackup))->CEffMgr::Reset();
    atexit(todo_401800);
  }
  *(float *)&this->m_Partical[2].byMaxFrame = (float)HIBYTE(*((_DWORD *)dwParam + 51));
  if ( (g_bEffSystemFlags & 1) == 0 )
  {
    g_bEffSystemFlags |= 1u;
    (((CEffMgr *)&g_pCEffMgrBackup))->CEffMgr::Reset();
    atexit(todo_401800);
  }
  this->m_Partical[2].fFramePerSec = (float)(unsigned __int8)BYTE2(*((_DWORD *)dwParam + 51));
  if ( (g_bEffSystemFlags & 1) == 0 )
  {
    g_bEffSystemFlags |= 1u;
    (((CEffMgr *)&g_pCEffMgrBackup))->CEffMgr::Reset();
    atexit(todo_401800);
  }
  this->m_Partical[2].fCurFrame = (float)(unsigned __int8)BYTE1(*((_DWORD *)dwParam + 51));
  if ( (g_bEffSystemFlags & 1) == 0 )
  {
    g_bEffSystemFlags |= 1u;
    (((CEffMgr *)&g_pCEffMgrBackup))->CEffMgr::Reset();
    atexit(todo_401800);
  }
  result = 0;
  v7 = *((unsigned __int8 *)dwParam + 204);
  *(_DWORD *)&this->m_Partical[1].byMaxFrame = 0;
  *(float *)&this->m_Partical[2].dwColor = (float)v7;
  *(float *)&this->m_Partical[1].bValid = dwParam[45];
  this->m_Partical[2].pPic = (char *)dwParam[49];
  this->m_Partical[2].nQuadIndex = (int)dwParam[54];
  *(float *)&this->m_Partical[2].bValid = dwParam[55];
  this->m_Partical[1].fX = dwParam[50];
  this->m_Partical[1].fY = dwParam[50];
  this->m_Partical[1].fFramePerSec = fVal + dwParam[46];
  this->m_Partical[1].fCurFrame = fVal2 + dwParam[47];
  v8 = fVal3 + dwParam[48];
  this->m_Partical[1].fZ = 0.0;
  this->m_Partical[1].fSize = 0.0;
  *(_DWORD *)&this->m_Partical[1].byAlpha = 0;
  this->m_Partical[1].pPic = 0;
  *(float *)&this->m_Partical[1].dwColor = v8;
  return result;
}

// 0x004D1090
char CEffect::Create(tagEffObjType *pEffObjType)
{
  int nMaxQuad; // ebp
  void *v4; // eax
  int v5; // ebp
  int v6; // ebx
  int v7; // ebp
  void *v8; // eax
  float fY; // ecx
  int i; // eax
  void *v11; // eax
  int v12; // ebx
  int v13; // edi
  int v14; // edi
  int v15; // edx
  int v16; // eax
  int v17; // ecx
  int v19; // edi
  size_t v20; // [esp-0x4] [ebp-0x824]
  void *v21; // [esp+0x10] [ebp-0x810]
  char pExceptionObject[1024]; // [esp+0x14] [ebp-0x80C] BYREF
  char ArgList; // [esp+0x414] [ebp-0x40C] BYREF
  int v24; // [esp+0x81C] [ebp-0x4]

  BYTE2(this->m_Partical[0].fCurFrame) = 1;
  BYTE1(this->m_Partical[0].dwColor) = pEffObjType->bNoZTest;
  LOBYTE(this->m_Partical[0].dwColor) = pEffObjType->bAdditiveBlend;
  BYTE2(this->m_Partical[0].dwColor) = pEffObjType->nFrame;
  LODWORD(this->m_Partical[0].fX) = (unsigned long)&byte_FFFFFF;
  sub_4D1FD0(pEffObjType->nFramePerRow, pEffObjType->nFramePerCol);
  LODWORD(this->m_Partical[2].fY) = (unsigned long)operator new(80 * pEffObjType->nMaxQuad);
  nMaxQuad = pEffObjType->nMaxQuad;
  v4 = (void *)operator new(68 * nMaxQuad);
  v21 = (void *)v4;
  v24 = 0;
  if ( v4 )
  {
    v5 = nMaxQuad - 1;
    v6 = (int)v4;
    if ( v5 >= 0 )
    {
      v7 = v5 + 1;
      do
      {
        v6 += 68;
        --v7;
      }
      while ( v7 );
      v4 = (void *)v21;
    }
  }
  else
  {
    v4 = 0;
  }
  LODWORD(this->m_Partical[2].fZ) = (unsigned long)v4;
  v20 = 4 * pEffObjType->nMaxQuad;
  v24 = -1;
  v8 = (void *)operator new(v20);
  fY = this->m_Partical[2].fY;
  LODWORD(this->m_Partical[2].fSize) = (unsigned long)v8;
  if ( fY == 0.0 || !LODWORD(this->m_Partical[2].fZ) || !v8 )
  {
    qmemcpy(
      pExceptionObject,
      (((Logger *)&ArgList))->Logger::FormatException((char *)&pTarget.m_pfnUpdatePost + 8, (char *)&pTarget.m_nTodo_184 + 8, 127),
      sizeof(pExceptionObject));
    _CxxThrowException(pExceptionObject, (_ThrowInfo *)&_TI1_AV_Exception__);
  }
  LODWORD(this->m_Partical[0].fSize) = pEffObjType->nMaxQuad;
  (((CCBStage *)this))->CCBStage::GetActiveTaskCount() /* [ROWTABLE] */;
  for ( i = 0; i < SLODWORD(this->m_Partical[0].fSize); ++i )
    *(_DWORD *)(LODWORD(this->m_Partical[2].fSize) + 4 * i) = i;
  /* [MISATTRIBUTED] CEffQuad on CEffect::this -> fix IDB name of callee */ CEffQuad::ToNextFrame((CEffQuad *)this, (int)pEffObjType->szTexture);
  v11 = (void *)operator new(0x4C0u);
  this->m_nPartical = (int)v11;
  if ( v11 )
  {
    v12 = 0;
    v13 = 0;
    while ( 1 )
    {
      *(_DWORD *)(v13 + this->m_nPartical) = (unsigned long)operator new(0x2D0u);
      if ( !*(_DWORD *)(v13 + this->m_nPartical) )
        break;
      v13 += 152;
      ++v12;
      if ( v13 >= 1216 )
      {
        v14 = 0;
        *(_DWORD *)&this->m_Partical[0].byMaxFrame = 8;
        LODWORD(this->m_Partical[0].fFramePerSec) = 10;
        v15 = 0;
        do
        {
          *(_BYTE *)(v15 + this->m_nPartical + 148) = 0;
          v16 = 0;
          if ( SLODWORD(this->m_Partical[0].fFramePerSec) > 0 )
          {
            v17 = 0;
            do
            {
              ++v16;
              v17 += 72;
              *(_BYTE *)(*(_DWORD *)(v15 + this->m_nPartical) + v17 - 8) = 0;
            }
            while ( v16 < SLODWORD(this->m_Partical[0].fFramePerSec) );
          }
          ++v14;
          v15 += 152;
        }
        while ( v14 < *(_DWORD *)&this->m_Partical[0].byMaxFrame );
        return 1;
      }
    }
    if ( v12 > 0 && v12 - 1 >= 0 )
    {
      v19 = 152 * (v12 - 1);
      do
      {
        operator delete(*(void **)(v19 + this->m_nPartical));
        v19 -= 152;
        --v12;
      }
      while ( v12 );
    }
    operator delete((void *)this->m_nPartical);
  }
  return 1;
}

// 0x004D1300
int CEffect::sub_4D1300()
{
  int v2; // ebx
  char dwColor; // al
  bool v4; // zf
  int result; // eax
  gbRenderEffect *v6; // ecx
  int v7; // ebp
  float *v8; // edi
  gbMatrix4 *Top; // eax
  double v10; // st7
  long double v11; // st6
  double v12; // st5
  double v13; // st6
  double v14; // st6
  double v15; // st7
  double v16; // st6
  gbMatrixStack *v17; // ebp
  int v18; // edi
  float v19; // [esp+0x10] [ebp-0x54]
  float v20; // [esp+0x14] [ebp-0x50]
  float v21; // [esp+0x18] [ebp-0x4C]
  gbVec3D *v22; // [esp+0x1C] [ebp-0x48]
  int v23; // [esp+0x20] [ebp-0x44]
  gbRenderEffect *v24; // [esp+0x2C] [ebp-0x38]
  float v25; // [esp+0x30] [ebp-0x34]
  float v26; // [esp+0x34] [ebp-0x30]
  float v27; // [esp+0x38] [ebp-0x2C]
  int v28; // [esp+0x38] [ebp-0x2C]
  float v29; // [esp+0x3C] [ebp-0x28]
  float v30; // [esp+0x3C] [ebp-0x28]
  float v31; // [esp+0x40] [ebp-0x24]
  float v32; // [esp+0x40] [ebp-0x24]
  float v33; // [esp+0x44] [ebp-0x20]
  float v34; // [esp+0x44] [ebp-0x20]
  float v35; // [esp+0x48] [ebp-0x1C]
  float v36; // [esp+0x4C] [ebp-0x18]
  gbMatrixStack *v37; // [esp+0x50] [ebp-0x14]
  float v38; // [esp+0x58] [ebp-0xC]
  float v39; // [esp+0x5C] [ebp-0x8]
  float v40; // [esp+0x60] [ebp-0x4]

  (((gbVertPoolMgr *)this->m_pES[1]->m_pDisplay->pVertPoolMgr))->gbVertPoolMgr::GetDynVertBuf(0x15u);
  v2 = 0;
  dwColor = this->m_Partical[0].dwColor;
  if ( BYTE1(this->m_Partical[0].dwColor) )
  {
    v4 = dwColor == 0;
    result = (int)this->m_pES[1];
    if ( !v4 )
    {
      v24 = *(gbRenderEffect **)(result + 8);
      goto LABEL_9;
    }
    v6 = *(gbRenderEffect **)(result + 12);
  }
  else
  {
    v4 = dwColor == 0;
    result = (int)this->m_pES[1];
    if ( !v4 )
    {
      v24 = *(gbRenderEffect **)(result + 16);
      goto LABEL_9;
    }
    v6 = *(gbRenderEffect **)(result + 20);
  }
  v24 = (gbRenderEffect *)v6;
LABEL_9:
  if ( SLODWORD(this->m_Partical[0].fZ) > 0 )
  {
    if ( HIBYTE(this->m_Partical[0].fCurFrame) )
    {
      v7 = 0;
      v37 = *(gbMatrixStack **)(*(_DWORD *)result + 216);
      do
      {
        v8 = (float *)(LODWORD(this->m_Partical[2].fY) + 80 * *(_DWORD *)(LODWORD(this->m_Partical[2].fSize) + 4 * v7));
        v38 = v8[9] + v8[4];
        v39 = v8[10] + v8[5];
        v40 = v8[11] + v8[6];
        Top = (((gbMatrixStack *)v37))->gbMatrixStack::GetTop();
        (((gbMatrix4 *)Top))->gbMatrix4::Transform(v22, v23);
        v10 = v8[7];
        v11 = v8[12] * 0.017453292;
        v27 = v8[8];
        v26 = cos(v11);
        v25 = sin(v11);
        v35 = -v10 * v26;
        v12 = -v27;
        v29 = v12;
        v31 = v12 * v25;
        *(float *)(v2 + LODWORD(this->m_Partical[2].fZ)) = v35 - v31 + v38;
        v36 = -v10 * v25;
        v13 = v29 * v26;
        v30 = v13;
        *(float *)(v2 + LODWORD(this->m_Partical[2].fZ) + 4) = v13 + v36 + v39;
        *(float *)(v2 + LODWORD(this->m_Partical[2].fZ) + 8) = v40;
        v14 = v26 * v10;
        v33 = v14;
        *(float *)(v2 + LODWORD(this->m_Partical[2].fZ) + 12) = v14 - v31 + v38;
        v15 = v10 * v25;
        *(float *)(v2 + LODWORD(this->m_Partical[2].fZ) + 16) = v15 + v30 + v39;
        *(float *)(v2 + LODWORD(this->m_Partical[2].fZ) + 20) = v40;
        v32 = v25 * v27;
        ++v7;
        v2 += 68;
        *(float *)(v2 + LODWORD(this->m_Partical[2].fZ) - 44) = v33 - v32 + v38;
        v16 = v26 * v27;
        v34 = v16;
        *(float *)(v2 + LODWORD(this->m_Partical[2].fZ) - 40) = v16 + v15 + v39;
        *(float *)(v2 + LODWORD(this->m_Partical[2].fZ) - 36) = v40;
        *(float *)(v2 + LODWORD(this->m_Partical[2].fZ) - 32) = v35 - v32 + v38;
        *(float *)(v2 + LODWORD(this->m_Partical[2].fZ) - 28) = v34 + v36 + v39;
        *(float *)(v2 + LODWORD(this->m_Partical[2].fZ) - 24) = v40;
      }
      while ( v7 < SLODWORD(this->m_Partical[0].fZ) );
      (((gbMatrixStack *)v37))->gbMatrixStack::Push();
      (((gbMatrixStack *)v37))->gbMatrixStack::LoadIdentity();
      (((gbDynVertBuf *)LODWORD(this->m_Partical[2].fZ)))->gbDynVertBuf::RenderGeomQuad(LODWORD(this->m_Partical[0].fZ), v24, (gbTextureArray *)LODWORD(this->m_Partical[88].fFramePerSec));
      (((gbMatrixStack *)v37))->gbMatrixStack::Pop();
    }
    else
    {
      if ( (byte_17A7BBC & 1) == 0 )
      {
        dword_17A7BB0 = 1065353216;
        byte_17A7BBC |= 1u;
        dword_17A7BB4 = 0;
        dword_17A7BB8 = 0;
        atexit(nullsub_91);
      }
      if ( (byte_17A7BBC & 2) == 0 )
      {
        dword_17A7BA0 = 0;
        byte_17A7BBC |= 2u;
        dword_17A7BA4 = 1065353216;
        dword_17A7BA8 = 0;
        atexit(nullsub_90);
      }
      if ( (byte_17A7BBC & 4) == 0 )
      {
        dword_17A7B90 = 0;
        byte_17A7BBC |= 4u;
        dword_17A7B94 = 0;
        dword_17A7B98 = 1065353216;
        atexit(nullsub_89);
      }
      result = LODWORD(this->m_Partical[0].fZ);
      v28 = 0;
      v17 = (gbMatrixStack *)this->m_pES[1]->m_pDisplay->pMatrixStack[1];
      if ( result > 0 )
      {
        do
        {
          v18 = LODWORD(this->m_Partical[2].fY) + 80 * *(_DWORD *)(LODWORD(this->m_Partical[2].fSize) + 4 * v28);
          (((gbMatrixStack *)v17))->gbMatrixStack::Push();
          v21 = *(float *)(v18 + 44) + *(float *)(v18 + 24);
          v20 = *(float *)(v18 + 40) + *(float *)(v18 + 20);
          v19 = *(float *)(v18 + 36) + *(float *)(v18 + 16);
          (((gbMatrixStack *)v17))->gbMatrixStack::Translate(*v19,   v20,   v21);
          (((gbMatrixStack *)v17))->gbMatrixStack::Rotate(*(float *)(v18 + 52), * (gbVec3D *)&dword_17A7BB0);
          (((gbMatrixStack *)v17))->gbMatrixStack::Rotate(*(float *)(v18 + 48), * (gbVec3D *)&dword_17A7BA0);
          (((gbMatrixStack *)v17))->gbMatrixStack::Rotate(*(float *)(v18 + 56), * (gbVec3D *)&dword_17A7B90);
          *(float *)(v2 + LODWORD(this->m_Partical[2].fZ)) = -*(float *)(v18 + 28);
          *(_DWORD *)(v2 + LODWORD(this->m_Partical[2].fZ) + 12) = *(_DWORD *)(v18 + 28);
          *(_DWORD *)(v2 + LODWORD(this->m_Partical[2].fZ) + 24) = *(_DWORD *)(v18 + 28);
          *(float *)(v2 + LODWORD(this->m_Partical[2].fZ) + 36) = -*(float *)(v18 + 28);
          *(_DWORD *)(v2 + LODWORD(this->m_Partical[2].fZ) + 8) = *(_DWORD *)(v18 + 32);
          *(_DWORD *)(v2 + LODWORD(this->m_Partical[2].fZ) + 20) = *(_DWORD *)(v18 + 32);
          *(float *)(v2 + LODWORD(this->m_Partical[2].fZ) + 32) = -*(float *)(v18 + 32);
          *(float *)(v2 + LODWORD(this->m_Partical[2].fZ) + 44) = -*(float *)(v18 + 32);
          (((gbDynVertBuf *)(LODWORD(this->m_Partical[2].fZ) + v2)))->gbDynVertBuf::RenderGeomQuad(1, v24, (gbTextureArray *)LODWORD(this->m_Partical[88].fFramePerSec));
          (((gbMatrixStack *)v17))->gbMatrixStack::Pop();
          result = v28 + 1;
          v2 += 68;
          ++v28;
        }
        while ( v28 < SLODWORD(this->m_Partical[0].fZ) );
      }
    }
  }
  return result;
}

// 0x004D17D0
int CEffect::sub_4D17D0()
{
  CEffect *v1; // edi
  double v2; // st7
  float *p_m_bActive; // esi
  __int16 v4; // fps
  double v5; // st7
  bool v6; // c0
  char v7; // c2
  bool v8; // c3
  int result; // eax
  int v10; // ebx
  int v11; // eax
  int v12; // eax
  int v13; // eax
  float fY; // edx
  int v15; // ecx
  int v16; // eax
  int v17; // ecx
  int v18; // ebx
  int v19; // edi
  int v20; // edx
  int v21; // eax
  _DWORD *i; // edx
  int v23; // eax
  int v24; // eax
  int v25; // edx
  bool v26; // cc
  _DWORD *v27; // [esp+0x4] [ebp-0x10]
  int nVal; // [esp+0xC] [ebp-0x8]
  int nVala; // [esp+0xC] [ebp-0x8]
  int v31; // [esp+0x10] [ebp-0x4]
  float v32; // [esp+0x1C] [ebp+0x8]
  float v33; // [esp+0x1C] [ebp+0x8]
  int v34; // [esp+0x1C] [ebp+0x8]
HIWORD(result) = HIWORD(v32);
  v2 = v32 - *(float *)&this->m_DeltaTime;
  p_m_bActive = (float *)&this->m_bActive;
  *(float *)&this->m_DeltaTime = v32;
  *((float *)&this->m_DeltaTime + 1) = v2;
  v5 = *((float *)&this->m_DeltaTime + 1);
  v6 = v5 < 0.0;
  v7 = 0;
  v8 = v5 == 0.0;
  LOWORD(result) = v4;
  if ( v5 > 0.0 )
  {
    LOBYTE(result) = this->m_eKind;
    if ( !(_BYTE)result )
    {
      v10 = 0;
      nVal = 0;
      if ( SLODWORD(this->m_Partical[0].fY) > 0 )
      {
        do
        {
          v11 = v10 + LODWORD(this->m_Partical[2].fY);
          if ( *(_BYTE *)(v11 + 4) )
          {
            v33 = *(float *)(v11 + 8) * *((float *)&this->m_DeltaTime + 1) + *(float *)(v11 + 12);
            if ( (g_bEffSystemFlags & 1) == 0 )
            {
              g_bEffSystemFlags |= 1u;
              (((CEffMgr *)&g_pCEffMgrBackup))->CEffMgr::Reset();
              atexit(todo_401800);
            }
            v12 = (int)v33;
            if ( v12 < BYTE2(this->m_Partical[0].dwColor) )
            {
              *(float *)(v10 + LODWORD(this->m_Partical[2].fY) + 12) = v33;
              *(_BYTE *)(v10 + LODWORD(this->m_Partical[2].fY) + 6) = v12;
              goto LABEL_12;
            }
            ++*(_BYTE *)(v10 + LODWORD(this->m_Partical[2].fY) + 7);
            *(_BYTE *)(v10 + LODWORD(this->m_Partical[2].fY) + 6) = 0;
            v13 = v10 + LODWORD(this->m_Partical[2].fY);
            if ( *(unsigned __int8 *)(v13 + 7) < SLODWORD(this->m_Partical[0].fX) )
            {
              *(float *)(v13 + 12) = v33 - (double)BYTE2(this->m_Partical[0].dwColor);
LABEL_12:
              fY = this->m_Partical[2].fY;
              if ( *(_BYTE *)(v10 + LODWORD(fY) + 6) >= BYTE2(this->m_Partical[0].dwColor) )
                *(_BYTE *)(v10 + LODWORD(fY) + 6) = 0;
              v15 = v10 + LODWORD(this->m_Partical[2].fY);
              v16 = 68 * *(_DWORD *)v15;
              *(_DWORD *)(v16 + LODWORD(this->m_Partical[2].fZ) + 48) = *((_DWORD *)&this->m_Partical[2].byAlpha
                                                                      + 4 * *(unsigned __int8 *)(v15 + 6));
              *(_DWORD *)(v16 + LODWORD(this->m_Partical[2].fZ) + 52) = *((_DWORD *)&this->m_Partical[3].pPic
                                                                      + 4
                                                                      * *(unsigned __int8 *)(v10
                                                                                           + LODWORD(this->m_Partical[2].fY)
                                                                                           + 6));
              *(_DWORD *)(v16 + LODWORD(this->m_Partical[2].fZ) + 56) = *(&this->m_Partical[3].nQuadIndex
                                                                      + 4
                                                                      * *(unsigned __int8 *)(v10
                                                                                           + LODWORD(this->m_Partical[2].fY)
                                                                                           + 6));
              *(_DWORD *)(v16 + LODWORD(this->m_Partical[2].fZ) + 60) = *((_DWORD *)&this->m_Partical[3].bValid
                                                                      + 4
                                                                      * *(unsigned __int8 *)(v10
                                                                                           + LODWORD(this->m_Partical[2].fY)
                                                                                           + 6));
              goto LABEL_15;
            }
            *(_BYTE *)(v13 + 7) = 0;
            (((CEffQuad *)v1))->CEffQuad::DestroyAllQuad(nVal);
          }
LABEL_15:
          v10 += 80;
          ++nVal;
        }
        while ( nVal < SLODWORD(this->m_Partical[0].fY) );
      }
      v17 = 0;
      v31 = 0;
      if ( *((int *)p_m_bActive + 7) > 0 )
      {
        nVala = 0;
        while ( 1 )
        {
          v18 = v17 + *((_DWORD *)p_m_bActive + 3);
          if ( *(_BYTE *)(v18 + 148) )
          {
            if ( *(_DWORD *)(v18 + 12) == 3 )
            {
              v34 = 0;
              if ( *((int *)p_m_bActive + 8) > 0 )
                break;
            }
          }
LABEL_51:
          v17 += 152;
          v26 = ++v31 < *((_DWORD *)p_m_bActive + 7);
          nVala = v17;
          if ( !v26 )
            goto LABEL_52;
        }
        v19 = 0;
        while ( 1 )
        {
          v20 = *(_DWORD *)v18;
          if ( !*(_BYTE *)(v19 + *(_DWORD *)v18 + 64) || v19 > 0 && *(_DWORD *)(v19 + v20 - 64) == 2 )
          {
LABEL_50:
goto LABEL_51;
          }
          switch ( *(_DWORD *)(v19 + v20 + 8) )
          {
            case 2:
              if ( v19 > 0 )
              {
                if ( *(float *)(v19 + v20 + 20) >= 0.0 )
                {
                  if ( p_m_bActive[1] - *(float *)(v19 + v20 - 56) > *(float *)(v19 + v20 + 20) )
                  {
                    *(_DWORD *)(*(_DWORD *)(v17 + *((_DWORD *)p_m_bActive + 3)) + v19 + 8) = 3;
                    *(float *)(*(_DWORD *)(v17 + *((_DWORD *)p_m_bActive + 3)) + v19 + 16) = (unsigned long)p_m_bActive[1];
                    *((_DWORD *)p_m_bActive + 4) = v31;
                    *((_DWORD *)p_m_bActive + 5) = v34;
LABEL_42:
                    (*(void ( **)(float *, _DWORD, _DWORD, _DWORD))(*(_DWORD *)p_m_bActive + 4))(
                      p_m_bActive,
                      *(_DWORD *)(*(_DWORD *)v18 + v19),
                      *(_DWORD *)(*(_DWORD *)v18 + v19 + 4),
                      0);
LABEL_43:
                    v17 = nVala;
                  }
                }
                else if ( *(_DWORD *)(v19 + v20 - 64) == 4 )
                {
                  *(_DWORD *)(*(_DWORD *)(v17 + *((_DWORD *)p_m_bActive + 3)) + v19 + 8) = 3;
                  *(float *)(*(_DWORD *)(v17 + *((_DWORD *)p_m_bActive + 3)) + v19 + 16) = (unsigned long)p_m_bActive[1];
                  *((_DWORD *)p_m_bActive + 4) = v31;
                  *((_DWORD *)p_m_bActive + 5) = v34;
                  goto LABEL_42;
                }
              }
              break;
            case 3:
              *((_DWORD *)p_m_bActive + 4) = v31;
              *((_DWORD *)p_m_bActive + 5) = v34;
              (*(void ( **)(float *, _DWORD, _DWORD, _DWORD))(*(_DWORD *)p_m_bActive + 4))(
                p_m_bActive,
                *(_DWORD *)(*(_DWORD *)v18 + v19),
                *(_DWORD *)(*(_DWORD *)v18 + v19 + 4),
                0);
              goto LABEL_43;
            case 4:
              v21 = 0;
              v27 = (_DWORD *)(v17 + *((_DWORD *)p_m_bActive + 3));
              if ( (int)v27[1] <= 0 )
              {
LABEL_33:
                v23 = *(_DWORD *)(v18 + 4);
                *(_DWORD *)(v18 + 12) = 4;
                *(_DWORD *)(v18 + 20) = *(_DWORD *)(*(_DWORD *)v18 + 72 * v23 - 12);
                if ( *(_BYTE *)(v18 + 149) == 1 )
                {
                  v24 = 0;
                  *(_BYTE *)(v17 + *((_DWORD *)p_m_bActive + 3) + 148) = 0;
                  if ( *((int *)p_m_bActive + 8) > 0 )
                  {
                    v25 = 0;
                    do
                    {
                      ++v24;
                      v25 += 72;
                      *(_BYTE *)(*(_DWORD *)(v17 + *((_DWORD *)p_m_bActive + 3)) + v25 - 8) = 0;
                    }
                    while ( v24 < *((_DWORD *)p_m_bActive + 8) );
                  }
                  *(_DWORD *)(v17 + *((_DWORD *)p_m_bActive + 3) + 4) = 0;
                  --*((_DWORD *)p_m_bActive + 6);
                  goto LABEL_50;
                }
              }
              else
              {
                for ( i = (_DWORD *)(*v27 + 8); *i == 4; i += 18 )
                {
                  if ( ++v21 >= v27[1] )
                    goto LABEL_33;
                }
              }
              break;
          }
          v19 += 72;
          if ( ++v34 >= *((_DWORD *)p_m_bActive + 8) )
            goto LABEL_50;
        }
      }
LABEL_52:
      result = *(_DWORD *)&this->m_Partical[0].bValid;
      if ( result <= 0 )
      {
        result = (((CCBStage *)v1))->CCBStage::GetActiveTaskCount();
        this->m_eKind = (EEffect)1;
      }
    }
  }
  return result;
}

// 0x004D2080
int CEffect::CreateTask(int *p)
{
  _DWORD *p_m_bActive; // ebp
  int v3; // edx
  int result; // eax
  int m_nPartical; // esi
  _BYTE *i; // ecx
  int v7; // ebx
  unsigned int v8; // eax
  int v9; // ecx
  int v10; // eax
  int v11; // esi
  _BYTE *v12; // edi
  int ( **v13)(CEffect *, int); // edx
  unsigned int v14; // eax
  int v15; // edx
  int v16; // ecx
  _DWORD *v17; // eax
  int v18; // ecx
  int v19; // eax
  int v20; // esi
  _BYTE *v21; // edi
  int ( **v22)(CEffect *, int); // edx
  unsigned int v23; // eax
  int v24; // edx
  int v25; // ecx
  _DWORD *v26; // eax
  int v27; // [esp+0x10] [ebp-0xC]

  p_m_bActive = (_DWORD *)&this->m_bActive;
  v3 = 0;
  LODWORD(this->m_Partical[0].fX) = (unsigned long)p[20];
  result = *(_DWORD *)&this->m_Partical[0].byMaxFrame;
  if ( result > 0 )
  {
    m_nPartical = this->m_nPartical;
    for ( i = (_BYTE *)(m_nPartical + 148); *i; i += 152 )
    {
      if ( ++v3 >= result )
        return result;
    }
    v27 = v3;
    v7 = 152 * v3;
    *(_DWORD *)(m_nPartical + v7 + 12) = 2;
    *(_BYTE *)(p_m_bActive[3] + v7 + 148) = 1;
    *(_BYTE *)(p_m_bActive[3] + v7 + 149) = 1;
    v8 = ++g_nSceneObjCount;
    if ( !g_nSceneObjCount || v8 >= 0x7FFFFFFF )
    {
      v8 = 1;
      g_nSceneObjCount = 1;
    }
    *(_DWORD *)(p_m_bActive[3] + v7 + 16) = v8;
    *(_DWORD *)(p_m_bActive[3] + v7 + 4) = 0;
    *(_DWORD *)(p_m_bActive[3] + v7 + 8) = 0;
    *(_DWORD *)(p_m_bActive[3] + v7 + 20) = 0;
    if ( p )
    {
      result = (unsigned long)p_m_bActive[3];
      qmemcpy((void *)(result + v7 + 24), p, 0x7Cu);
    }
    else
    {
      result = 0;
      memset((void *)(p_m_bActive[3] + v7 + 24), 0, 0x7Cu);
    }
    ++p_m_bActive[6];
    if ( v3 != -1 )
    {
      v9 = (unsigned long)p_m_bActive[8];
      v10 = 0;
      if ( v9 > 0 )
      {
        v11 = *(_DWORD *)(v7 + p_m_bActive[3]);
        v12 = (_BYTE *)(v11 + 64);
        while ( *v12 )
        {
          ++v10;
          v12 += 72;
          if ( v10 >= v9 )
            goto LABEL_22;
        }
        v13 = (int ( **)(CEffect *, int))(v11 + 72 * v10);
        memset(v13, 0, 0x48u);
        *((_BYTE *)v13 + 65) = 0;
        *v13 = CEffect::SetParam;
        *((_BYTE *)v13 + 64) = 1;
        v13[1] = 0;
        v13[2] = (int ( *)(CEffect *, int))2;
        v14 = ++g_nSceneObjCount;
        if ( !g_nSceneObjCount || v14 >= 0x7FFFFFFF )
        {
          v14 = 1;
          g_nSceneObjCount = 1;
        }
        v13[3] = (int ( *)(CEffect *, int))v14;
        v13[5] = 0;
        v13[4] = 0;
        v13[6] = 0;
        v15 = (unsigned long)p_m_bActive[3];
        v16 = *(_DWORD *)(v7 + v15 + 4);
        v17 = (_DWORD *)(v7 + v15 + 4);
        v3 = v27;
        *v17 = v16 + 1;
      }
LABEL_22:
      v18 = (unsigned long)p_m_bActive[8];
      v19 = 0;
      if ( v18 > 0 )
      {
        v20 = *(_DWORD *)(p_m_bActive[3] + v7);
        v21 = (_BYTE *)(v20 + 64);
        while ( *v21 )
        {
          ++v19;
          v21 += 72;
          if ( v19 >= v18 )
            goto LABEL_31;
        }
        v22 = (int ( **)(CEffect *, int))(v20 + 72 * v19);
        memset(v22, 0, 0x48u);
        *((_BYTE *)v22 + 64) = 1;
        *v22 = CEffect::SetParam;
        *((_BYTE *)v22 + 65) = 0;
        v22[1] = 0;
        v22[2] = (int ( *)(CEffect *, int))2;
        v23 = ++g_nSceneObjCount;
        if ( !g_nSceneObjCount || v23 >= 0x7FFFFFFF )
        {
          v23 = 1;
          g_nSceneObjCount = 1;
        }
        v22[3] = (int ( *)(CEffect *, int))v23;
        v22[5] = 0;
        v22[4] = 0;
        v22[6] = 0;
        v24 = (unsigned long)p_m_bActive[3];
        v25 = *(_DWORD *)(v24 + v7 + 4);
        v26 = (_DWORD *)(v24 + v7 + 4);
        v3 = v27;
        *v26 = v25 + 1;
      }
LABEL_31:
      sub_4D3010(v3, CEffMgr::UpdateKeyframe, 0, 0, p[18], p[19]);
      sub_4D3010(v27, CEffQuad::ProcessDestroyPass, 0, 0, 0, p[19]);
      *(_DWORD *)(p_m_bActive[3] + v7 + 12) = 3;
      *(_DWORD *)(*(_DWORD *)(p_m_bActive[3] + v7) + 8) = 3;
      result = *(_DWORD *)(p_m_bActive[3] + v7);
      *(_DWORD *)(result + 16) = (unsigned long)p_m_bActive[1];
    }
  }
  return result;
}

// 0x004D2ED0
int CEffect::GetEffectSubType(int a2)
{
  int result; // eax

  switch ( a2 )
  {
    case 0:
      result = (int)&g_EffMgrData.m_nEffParam_02A4;
      break;
    case 1:
      result = (int)&g_EffMgrData.m_nEffParam9;
      break;
    case 2:
      result = (int)&g_EffMgrData.m_nEffParam8;
      break;
    case 3:
      result = (int)&g_EffMgrData.m_nEffParam7;
      break;
    case 4:
      result = (int)&g_EffMgrData.m_nEffParam6;
      break;
    case 5:
      result = (int)&g_EffMgrData.m_nEffParam_029C;
      break;
    case 6:
      result = (int)&g_EffMgrData.m_nEffParam_0294;
      break;
    case 7:
      result = (int)&g_EffMgrData.m_nEffParam_028C;
      break;
    case 8:
      result = (int)&g_EffMgrData.m_nEffParam2;
      break;
    case 9:
      result = (int)(&g_EffMgrData.m_nEffTypeCode + 8);
      break;
    case 10:
      result = (int)(&pTarget.m_pfnStageCleanup + 4);
      break;
    case 11:
      result = (int)&g_EffMgrData.m_nEffParam_0274;
      break;
    case 12:
      result = (int)&g_EffMgrData.m_nEffTypeCode;
      break;
    case 13:
      result = (int)&g_EffMgrData.m_nEffTypeID;
      break;
    case 14:
      result = (int)&g_EffMgrData.m_nEffParam1;
      break;
    case 15:
      result = (int)&g_EffMgrData.m_nEffParam0;
      break;
    case 16:
      result = (int)&g_EffMgrData;
      break;
    case 17:
      result = (int)&g_EffMgrData.m_nEffParam_0268;
      break;
    case 18:
      result = (int)&g_EffMgrData.m_nEffParam_025C;
      break;
    case 19:
      result = (int)&g_EffMgrData.m_nEffParam_0250;
      break;
    case 20:
      result = (int)&g_pszEditorDesc;
      break;
    case 21:
      result = (int)&g_EffMgrData.m_nEffParam_244;
      break;
    case 22:
      result = (int)&g_EffMgrData.m_nEffParam_234;
      break;
    case 23:
      result = (int)&g_EffMgrData.m_nEffParam_224;
      break;
    default:
      result = (int)g_EffCylinderEditorData;
      break;
  }
  return result;
}

// 0x004D3950
void CEffect::DestroyCallback()
{
  _BYTE *p_m_bActive; // edi
  char *pPic; // eax
  int v4; // ebp
  float fZ; // ecx
  _BYTE *v6; // esi
  int v7; // eax
  bool v8; // cc
  int v9; // edi

  p_m_bActive = (_BYTE *)&this->m_bActive;
  pPic = (char *)this->m_Partical[86].pPic;
  v4 = 0;
  if ( pPic )
    operator delete(pPic);
  if ( this->m_Partical[86].nQuadIndex )
    operator delete((void *)this->m_Partical[86].nQuadIndex);
  fZ = this->m_Partical[85].fZ;
  if ( fZ != 0.0 )
    (((gbRefObject *)LODWORD(fZ)))->gbRefObject::Release();
  if ( LODWORD(this->m_Partical[85].fSize) )
    operator delete((void *)LODWORD(this->m_Partical[85].fSize));
  v6 = this != 0 ? p_m_bActive : 0;
  v7 = *((_DWORD *)v6 + 7);
  v8 = v7 <= 0;
  if ( !v7 )
  {
    if ( !*(this != 0 ? (_DWORD *)(p_m_bActive + 32) : (_DWORD *)32) )
      return;
    v8 = 1;
  }
  if ( !v8 )
  {
    v9 = 0;
    do
    {
      operator delete(*(void **)(*((_DWORD *)v6 + 3) + v9));
      ++v4;
      *(_DWORD *)(*((_DWORD *)v6 + 3) + v9) = 0;
      v9 += 152;
    }
    while ( v4 < *((_DWORD *)v6 + 7) );
  }
  operator delete(*((void **)v6 + 3));
  *((_DWORD *)v6 + 3) = 0;
  *((_DWORD *)v6 + 7) = 0;
  *((_DWORD *)v6 + 8) = 0;
}

// 0x004D3A50
int CEffect::Init(float *pType, float fx, float fy, float fz)
{
  int result; // eax

  this->m_eKind = 0;
  this->m_Partical[87].nQuadIndex = (int)pType[50];
  this->m_Partical[87].fCurFrame = fx + pType[46];
  *(float *)&this->m_Partical[87].dwColor = fy + pType[47];
  this->m_Partical[87].fX = fz + pType[48];
  *(float *)&this->m_Partical[87].bValid = pType[54];
  *(float *)&this->m_Partical[87].byMaxFrame = pType[49];
  this->m_Partical[87].fFramePerSec = pType[55];
  result = *((_DWORD *)pType + 51);
  LODWORD(this->m_Partical[86].fY) = result;
  return result;
}

// 0x004D3AD0
char CEffect::Create_3ad0(tagEffObjType *pEffObjType)
{
  void *v3; // eax
  int v4; // ebx
  int v5; // edi
  int v6; // edi
  int v7; // edx
  int v8; // eax
  int v9; // ecx
  int v10; // edx
  int v11; // ebx
  char *v12; // eax
  int v13; // ebx
  int v14; // ebp
  int v15; // ebx
  int v16; // edi
  void *v17; // eax
  char *pPic; // ecx
  size_t v20; // [esp-0x4] [ebp-0x820]
  char *v21; // [esp+0xC] [ebp-0x810]
  char pExceptionObject[1024]; // [esp+0x10] [ebp-0x80C] BYREF
  char ArgList; // [esp+0x410] [ebp-0x40C] BYREF
  int v24; // [esp+0x818] [ebp-0x4]

  v3 = (void *)operator new(0x4C0u);
  this->m_nPartical = (int)v3;
  if ( v3 )
  {
    v4 = 0;
    v5 = 0;
    while ( 1 )
    {
      *(_DWORD *)(v5 + this->m_nPartical) = (unsigned long)operator new(0x2D0u);
      if ( !*(_DWORD *)(v5 + this->m_nPartical) )
        break;
      v5 += 152;
      ++v4;
      if ( v5 >= 1216 )
      {
        v6 = 0;
        *(_DWORD *)&this->m_Partical[0].byMaxFrame = 8;
        LODWORD(this->m_Partical[0].fFramePerSec) = 10;
        v7 = 0;
        do
        {
          *(_BYTE *)(v7 + this->m_nPartical + 148) = 0;
          v8 = 0;
          if ( SLODWORD(this->m_Partical[0].fFramePerSec) > 0 )
          {
            v9 = 0;
            do
            {
              ++v8;
              v9 += 72;
              *(_BYTE *)(*(_DWORD *)(v7 + this->m_nPartical) + v9 - 8) = 0;
            }
            while ( v8 < SLODWORD(this->m_Partical[0].fFramePerSec) );
          }
          ++v6;
          v7 += 152;
        }
        while ( v6 < *(_DWORD *)&this->m_Partical[0].byMaxFrame );
        goto LABEL_10;
      }
    }
    if ( v4 > 0 && v4 - 1 >= 0 )
    {
      v16 = 152 * (v4 - 1);
      do
      {
        operator delete(*(void **)(v16 + this->m_nPartical));
        v16 -= 152;
        --v4;
      }
      while ( v4 );
    }
    operator delete((void *)this->m_nPartical);
  }
LABEL_10:
  *(_DWORD *)&this->m_Partical[87].byAlpha = (__int64)pEffObjType->fSacleX;
  this->m_Partical[88].pPic = (char *)(__int64)pEffObjType->fSacleY;
  this->m_Partical[88].nQuadIndex = LODWORD(pEffObjType->fSacleZ);
  *(float *)&this->m_Partical[88].bValid = pEffObjType->fTopRadius;
  v10 = *(_DWORD *)&this->m_Partical[87].byAlpha * (int)this->m_Partical[88].pPic;
  *(float *)&this->m_Partical[88].byMaxFrame = pEffObjType->fBottomRadius;
  this->m_Partical[88].fFramePerSec = pEffObjType->fTextureRepeat;
  *(_DWORD *)&this->m_Partical[85].byAlpha = v10;
  *(float *)&this->m_Partical[86].byMaxFrame = pEffObjType->fFramePerSec;
  this->m_Partical[87].fCurFrame = pEffObjType->fX;
  this->m_Partical[87].dwColor = LODWORD(pEffObjType->fY);
  this->m_Partical[87].fX = pEffObjType->fZ;
  *(float *)&this->m_Partical[87].bValid = pEffObjType->fStartXRot;
  *(float *)&this->m_Partical[87].byMaxFrame = pEffObjType->fStartYRot;
  this->m_Partical[87].fFramePerSec = pEffObjType->fStartZRot;
  this->m_Partical[86].bVisible = pEffObjType->bAdditiveBlend;
  this->m_Partical[86].bAniFrame = pEffObjType->bNoZTest;
  LOBYTE(this->m_Partical[86].fFramePerSec) = pEffObjType->nFrame;
  LODWORD(this->m_Partical[86].fCurFrame) = 0xFFFF;
  LODWORD(this->m_Partical[86].fY) = pEffObjType->dwColor;
  /* [MISATTRIBUTED] CEffShock on CEffect::this -> fix IDB name of callee */ CEffShock::CreateGeom((CEffShock *)this, pEffObjType->nFramePerRow, pEffObjType->nFramePerCol);
  v11 = *(_DWORD *)&this->m_Partical[85].byAlpha;
  v12 = (char *)operator new(68 * v11);
  v21 = (char *)v12;
  v24 = 0;
  if ( v12 )
  {
    v13 = v11 - 1;
    v14 = (int)v12;
    if ( v13 >= 0 )
    {
      v15 = v13 + 1;
      do
      {
        v14 += 68;
        --v15;
      }
      while ( v15 );
      v12 = (char *)v21;
    }
  }
  else
  {
    v12 = 0;
  }
  this->m_Partical[86].pPic = v12;
  v20 = 8 * *(_DWORD *)&this->m_Partical[85].byAlpha;
  v24 = -1;
  v17 = (void *)operator new(v20);
  pPic = (char *)this->m_Partical[86].pPic;
  this->m_Partical[86].nQuadIndex = (int)v17;
  if ( !pPic || !v17 )
  {
    qmemcpy(
      pExceptionObject,
      (((Logger *)&ArgList))->Logger::FormatException((char *)&pTarget.m_pfnStageCleanup + 88, (char *)&pTarget.m_nTargetType + 12, 91),
      sizeof(pExceptionObject));
    _CxxThrowException(pExceptionObject, (_ThrowInfo *)&_TI1_AV_Exception__);
  }
  sub_4D4AB0(pEffObjType->szTexture);
  sub_4D48B0(this);
  return 1;
}

// 0x004D3DC0
int CEffect::sub_4D3DC0()
{
  CCBStage *p_m_bActive; // esi
  __int16 v2; // fps
  double v3; // st7
  bool v4; // c0
  char v5; // c2
  bool v6; // c3
  int result; // eax
  int v8; // ebx
  char *v9; // ebx
  int v10; // edi
  int v11; // edx
  int v12; // eax
  int v13; // edx
  bool v14; // cc
  double fFramePerSec_low; // st7
  int v16; // edi
  int v17; // esi
  float *v18; // eax
  int v19; // edx
  int v20; // eax
  int v21; // [esp+0x0] [ebp-0xC]
  int nVal2; // [esp+0x4] [ebp-0x8]
  CEffect *v23; // [esp+0x8] [ebp-0x4]
  float nVal; // [esp+0x14] [ebp+0x8]
  int nVala; // [esp+0x14] [ebp+0x8]
  float nValb; // [esp+0x14] [ebp+0x8]

  HIWORD(result) = HIWORD(nVal);
  p_m_bActive = (CCBStage *)&this->m_bActive;
*((float *)&this->m_DeltaTime + 1) = nVal - *(float *)&this->m_DeltaTime;
  *(float *)&this->m_DeltaTime = nVal;
  v3 = *((float *)&this->m_DeltaTime + 1);
  v4 = v3 < 0.0;
  v5 = 0;
  v6 = v3 == 0.0;
  LOWORD(result) = v2;
  if ( v3 > 0.0 )
  {
    nVala = 0;
    if ( *(int *)&this->m_Partical[0].byMaxFrame > 0 )
    {
      v8 = 0;
      v21 = 0;
      while ( 1 )
      {
        v9 = (char *)p_m_bActive->m_pCam + v8;
        if ( v9[148] )
        {
          if ( *((_DWORD *)v9 + 3) == 3 )
          {
            nVal2 = 0;
            if ( (int)p_m_bActive->m_pRole[2] > 0 )
              break;
          }
        }
LABEL_29:
        v8 = v21 + 152;
        v14 = ++nVala < (int)p_m_bActive->m_pRole[1];
        v21 += 152;
        if ( !v14 )
          goto LABEL_30;
      }
      v10 = 0;
      while ( 1 )
      {
        v11 = v10 + *(_DWORD *)v9;
        if ( !*(_BYTE *)(v11 + 64) || v10 > 0 && *(_DWORD *)(v11 - 64) == 2 )
          goto LABEL_29;
        switch ( *(_DWORD *)(v11 + 8) )
        {
          case 2:
            if ( v10 > 0 )
            {
              if ( *(float *)(v11 + 20) >= 0.0 )
              {
                if ( *(float *)&p_m_bActive->m_pRoleState - *(float *)(v11 - 56) > *(float *)(v11 + 20) )
                {
                  (((CCBStage *)p_m_bActive))->CCBStage::GetTaskParam(nVala, nVal2);
                  p_m_bActive->m_pCamControl = (CCBCamControl *)nVala;
                  p_m_bActive->m_pScene = (CCBStageScene *)nVal2;
LABEL_24:
                  ((void ( *)(CCBStage *, _DWORD, _DWORD, _DWORD))p_m_bActive->m_pCBSystem->m_pUI)(
                    p_m_bActive,
                    *(_DWORD *)(*(_DWORD *)v9 + v10),
                    *(_DWORD *)(*(_DWORD *)v9 + v10 + 4),
                    0);
LABEL_25:
                  this = v23;
                }
              }
              else if ( *(_DWORD *)(v11 - 64) == 4 )
              {
                *(_DWORD *)(*(_DWORD *)((char *)&p_m_bActive->m_pCam->fov + v21) + v10 + 8) = 3;
                *(_DWORD *)(*(_DWORD *)((char *)&p_m_bActive->m_pCam->fov + v21) + v10 + 16) = (_DWORD)p_m_bActive->m_pRoleState;
                p_m_bActive->m_pCamControl = (CCBCamControl *)nVala;
                p_m_bActive->m_pScene = (CCBStageScene *)nVal2;
                goto LABEL_24;
              }
            }
            break;
          case 3:
            p_m_bActive->m_pCamControl = (CCBCamControl *)nVala;
            p_m_bActive->m_pScene = (CCBStageScene *)nVal2;
            ((void ( *)(CCBStage *, _DWORD, _DWORD, _DWORD))p_m_bActive->m_pCBSystem->m_pUI)(
              p_m_bActive,
              *(_DWORD *)(*(_DWORD *)v9 + v10),
              *(_DWORD *)(*(_DWORD *)v9 + v10 + 4),
              0);
            goto LABEL_25;
          case 4:
            if ( (((CCBStage *)p_m_bActive))->CCBStage::SetTaskState(nVala) )
            {
              v12 = *((_DWORD *)v9 + 1);
              v13 = *(_DWORD *)v9;
              *((_DWORD *)v9 + 3) = 4;
              *((_DWORD *)v9 + 5) = *(_DWORD *)(v13 + 72 * v12 - 12);
              if ( v9[149] == 1 )
              {
                (((CEffgbParticle *)p_m_bActive))->CEffgbParticle::Init(nVala);
                this = v23;
                goto LABEL_29;
              }
            }
            goto LABEL_25;
        }
        v10 += 72;
        if ( ++nVal2 >= (int)p_m_bActive->m_pRole[2] )
          goto LABEL_29;
      }
    }
LABEL_30:
    if ( *(int *)&this->m_Partical[0].bValid <= 0 )
      this->m_eKind = (EEffect)1;
    fFramePerSec_low = (double)LOBYTE(this->m_Partical[86].fFramePerSec);
    nValb = fFramePerSec_low;
    if ( fFramePerSec_low <= 0.0 )
      nValb = 1.0;
    result = *(_DWORD *)&this->m_Partical[85].byAlpha;
    v16 = 0;
    if ( result > 0 )
    {
      v17 = 0;
      do
      {
        v18 = (float *)(this->m_Partical[86].nQuadIndex + 8 * v16 + 4);
        *v18 = *((float *)&this->m_DeltaTime + 1) * *(float *)&this->m_Partical[86].byMaxFrame + *v18;
        if ( nValb * *(float *)(this->m_Partical[86].nQuadIndex + 8 * v16) >= *(float *)(this->m_Partical[86].nQuadIndex
                                                                                       + 8 * v16
                                                                                       + 4) )
        {
          if ( (g_bScriptFlag & 1) == 0 )
          {
            g_bScriptFlag |= 1u;
            (((CEffMgr *)&g_pCEffMgrBackup))->CEffMgr::Reset();
            atexit(todo_401800);
            this = v23;
          }
          v19 = (int)abs32((int)*(float *)(this->m_Partical[86].nQuadIndex + 8 * v16 + 4))
              % LOBYTE(this->m_Partical[86].fFramePerSec);
          v20 = 4 * (v19 + 3);
          v19 *= 16;
          *(_DWORD *)&this->m_Partical[86].pPic[v17 + 48] = (unsigned long)this->m_pES[v20];
          *(float *)&this->m_Partical[86].pPic[v17 + 56] = *(float *)((char *)&this->m_Partical[0].fX + v19);
          *(_DWORD *)&this->m_Partical[86].pPic[v17 + 52] = *(unsigned int *)((char *)&this->m_Partical[0].dwColor
                                                                                + v19);
          *(float *)&this->m_Partical[86].pPic[v17 + 60] = *(float *)((char *)&this->m_Partical[0].fY + v19);
          *(float *)&this->m_Partical[86].pPic[v17 + 64] = this->m_Partical[86].fY;
        }
        else
        {
          *(_DWORD *)&this->m_Partical[86].pPic[v17 + 48] = 0;
          *(_DWORD *)&this->m_Partical[86].pPic[v17 + 56] = 0;
          *(_DWORD *)&this->m_Partical[86].pPic[v17 + 52] = 0;
          *(_DWORD *)&this->m_Partical[86].pPic[v17 + 60] = 0;
          *(_DWORD *)&this->m_Partical[86].pPic[v17 + 64] = 0;
        }
        result = *(_DWORD *)&this->m_Partical[85].byAlpha;
        ++v16;
        v17 += 68;
      }
      while ( v16 < result );
    }
  }
  return result;
}

// 0x004D4110
int CEffect::sub_4D4110()
{
  int result; // eax
  char bVisible; // al
  bool v4; // zf
  CEffectSystem *v5; // eax
  gbRenderEffect *m_pAlphaBlend; // ebp
  gbMatrixStack *v7; // edi
  float v8; // [esp+0x3C] [ebp-0xC]
  float retaddr; // [esp+0x48] [ebp+0x0] BYREF

  if ( (byte_17A7E84 & 1) == 0 )
  {
    dword_17A7E78 = 1065353216;
    byte_17A7E84 |= 1u;
    dword_17A7E7C = 0;
    dword_17A7E80 = 0;
    result = atexit(nullsub_94);
  }
  if ( (byte_17A7E84 & 2) == 0 )
  {
    dword_17A7E68 = 0;
    byte_17A7E84 |= 2u;
    dword_17A7E6C = 1065353216;
    dword_17A7E70 = 0;
    result = atexit(nullsub_93);
  }
  if ( (byte_17A7E84 & 4) == 0 )
  {
    dword_17A7E58 = 0;
    byte_17A7E84 |= 4u;
    dword_17A7E5C = 0;
    dword_17A7E60 = 1065353216;
    result = atexit(nullsub_92);
  }
  LOBYTE(result) = this->m_eKind;
  if ( !(_BYTE)result )
  {
    (((gbVertPoolMgr *)this->m_pES[1]->m_pDisplay->pVertPoolMgr))->gbVertPoolMgr::GetDynVertBuf(0x15u);
    bVisible = this->m_Partical[86].bVisible;
    if ( this->m_Partical[86].bAniFrame )
    {
      v4 = bVisible == 0;
      v5 = (CEffectSystem *)this->m_pES[1];
      if ( v4 )
        m_pAlphaBlend = (gbRenderEffect *)v5->m_pAlphaBlend;
      else
        m_pAlphaBlend = (gbRenderEffect *)v5->m_pAdditiveBlend;
    }
    else
    {
      v4 = bVisible == 0;
      v5 = (CEffectSystem *)this->m_pES[1];
      if ( v4 )
        m_pAlphaBlend = (gbRenderEffect *)LODWORD(v5->m_DefaultUVSet[0].sv);
      else
        m_pAlphaBlend = (gbRenderEffect *)LODWORD(v5->m_DefaultUVSet[0].su);
    }
    v7 = (gbMatrixStack *)v5->m_pDisplay->pMatrixStack[1];
    (((gbMatrixStack *)v7))->gbMatrixStack::Push();
    v8 = this->m_Partical[87].fY + this->m_Partical[87].fCurFrame;
    retaddr = v8;
    (((gbMatrixStack *)v7))->gbMatrixStack::Translate(*(gbVec3D *)&retaddr);
    (((gbMatrixStack *)v7))->gbMatrixStack::Rotate(*(float *)&this->m_Partical[87].bValid, * (gbVec3D *)&dword_17A7E78);
    (((gbMatrixStack *)v7))->gbMatrixStack::Rotate(*(float *)&this->m_Partical[87].byMaxFrame, * (gbVec3D *)&dword_17A7E68);
    (((gbMatrixStack *)v7))->gbMatrixStack::Rotate(this->m_Partical[87].fFramePerSec, * (gbVec3D *)&dword_17A7E58);
    (((gbMatrixStack *)v7))->gbMatrixStack::Scale(*(float *)&this->m_Partical[87].nQuadIndex,   *(float *)&this->m_Partical[87].nQuadIndex,   *(float *)&this->m_Partical[87].nQuadIndex);
    (((gbDynVertBuf *)this->m_Partical[86].pPic))->gbDynVertBuf::RenderGeomQuad(*(_DWORD *)&this->m_Partical[85].byAlpha, m_pAlphaBlend, (gbTextureArray *)LODWORD(this->m_Partical[85].fSize));
    (((gbMatrixStack *)v7))->gbMatrixStack::Pop();
  }
  return result;
}

// 0x004D4340
void CEffect::CreateTarget(int *pnVal)
{
  _BYTE *p_m_bActive; // ebx
  int v3; // ecx
  int v4; // edx
  int v5; // esi
  _BYTE *i; // eax
  int v7; // ebp
  unsigned int v8; // eax
  int v9; // ecx
  int v10; // eax
  int v11; // edi
  _BYTE *v12; // esi
  int ( **v13)(CEffect *, int); // esi
  unsigned int v14; // eax
  int v15; // ecx
  int v16; // eax
  int v17; // edi
  _BYTE *v18; // esi
  int ( **v19)(CEffect *, int); // esi
  unsigned int v20; // eax

  p_m_bActive = (_BYTE *)&this->m_bActive;
  v3 = *(_DWORD *)&this->m_Partical[0].byMaxFrame;
  v4 = 0;
  if ( v3 > 0 )
  {
    v5 = *((_DWORD *)p_m_bActive + 3);
    for ( i = (_BYTE *)(v5 + 148); *i; i += 152 )
    {
      if ( ++v4 >= v3 )
        return;
    }
    v7 = 152 * v4;
    *(_DWORD *)(v5 + v7 + 12) = 2;
    *(_BYTE *)(*((_DWORD *)p_m_bActive + 3) + v7 + 148) = 1;
    *(_BYTE *)(*((_DWORD *)p_m_bActive + 3) + v7 + 149) = 1;
    v8 = ++g_nEffShockCount;
    if ( !g_nEffShockCount || v8 >= 0x7FFFFFFF )
    {
      v8 = 1;
      g_nEffShockCount = 1;
    }
    *(_DWORD *)(*((_DWORD *)p_m_bActive + 3) + v7 + 16) = v8;
    *(_DWORD *)(*((_DWORD *)p_m_bActive + 3) + v7 + 4) = 0;
    *(_DWORD *)(*((_DWORD *)p_m_bActive + 3) + v7 + 8) = 0;
    *(_DWORD *)(*((_DWORD *)p_m_bActive + 3) + v7 + 20) = 0;
    if ( pnVal )
      qmemcpy((void *)(*((_DWORD *)p_m_bActive + 3) + v7 + 24), pnVal, 0x7Cu);
    else
      memset((void *)(*((_DWORD *)p_m_bActive + 3) + v7 + 24), 0, 0x7Cu);
    ++*((_DWORD *)p_m_bActive + 6);
    if ( v4 != -1 )
    {
      v9 = *((_DWORD *)p_m_bActive + 8);
      v10 = 0;
      if ( v9 > 0 )
      {
        v11 = *(_DWORD *)(*((_DWORD *)p_m_bActive + 3) + 152 * v4);
        v12 = (_BYTE *)(v11 + 64);
        while ( *v12 )
        {
          ++v10;
          v12 += 72;
          if ( v10 >= v9 )
            goto LABEL_22;
        }
        v13 = (int ( **)(CEffect *, int))(v11 + 72 * v10);
        memset(v13, 0, 0x48u);
        *v13 = CEffect::SetParam;
        *((_BYTE *)v13 + 64) = 1;
        *((_BYTE *)v13 + 65) = 0;
        v13[1] = 0;
        v13[2] = (int ( *)(CEffect *, int))2;
        v14 = ++g_nEffShockCount;
        if ( !g_nEffShockCount || v14 >= 0x7FFFFFFF )
        {
          v14 = 1;
          g_nEffShockCount = 1;
        }
        v13[3] = (int ( *)(CEffect *, int))v14;
        v13[5] = 0;
        v13[4] = 0;
        v13[6] = 0;
        ++*(_DWORD *)(*((_DWORD *)p_m_bActive + 3) + v7 + 4);
      }
LABEL_22:
      v15 = *((_DWORD *)p_m_bActive + 8);
      v16 = 0;
      if ( v15 > 0 )
      {
        v17 = *(_DWORD *)(*((_DWORD *)p_m_bActive + 3) + 152 * v4);
        v18 = (_BYTE *)(v17 + 64);
        while ( *v18 )
        {
          ++v16;
          v18 += 72;
          if ( v16 >= v15 )
            goto LABEL_31;
        }
        v19 = (int ( **)(CEffect *, int))(v17 + 72 * v16);
        memset(v19, 0, 0x48u);
        *v19 = CEffect::SetParam;
        *((_BYTE *)v19 + 64) = 1;
        *((_BYTE *)v19 + 65) = 0;
        v19[1] = 0;
        v19[2] = (int ( *)(CEffect *, int))2;
        v20 = ++g_nEffShockCount;
        if ( !g_nEffShockCount || v20 >= 0x7FFFFFFF )
        {
          v20 = 1;
          g_nEffShockCount = 1;
        }
        v19[3] = (int ( *)(CEffect *, int))v20;
        v19[5] = 0;
        v19[4] = 0;
        v19[6] = 0;
        ++*(_DWORD *)(*((_DWORD *)p_m_bActive + 3) + v7 + 4);
      }
LABEL_31:
      (((CEffShock *)p_m_bActive))->CEffShock::LoadTexture(v4, 0 /* TODO: (int)CEffShock::UpdateSegment */, 0, 0, pnVal[18], pnVal[19]);
      *(_DWORD *)(*((_DWORD *)p_m_bActive + 3) + v7 + 12) = 3;
      *(_DWORD *)(*(_DWORD *)(*((_DWORD *)p_m_bActive + 3) + v7) + 8) = 3;
      *(_DWORD *)(*(_DWORD *)(*((_DWORD *)p_m_bActive + 3) + v7) + 16) = *((_DWORD *)p_m_bActive + 1);
    }
  }
}

// 0x004D4700
int CEffect::sub_4D4700()
{
  int result; // eax
  int v2; // [esp+0x4] [ebp+0x4]

  switch ( v2 )
  {
    case 0:
      result = (int)&g_EffMgrData.m_nEffParam_02A4;
      break;
    case 1:
      result = (int)&g_EffMgrData.m_nEffParam9;
      break;
    case 2:
      result = (int)&g_EffMgrData.m_nEffParam8;
      break;
    case 3:
      result = (int)&g_EffMgrData.m_nEffParam7;
      break;
    case 4:
      result = (int)&g_EffMgrData.m_nEffParam6;
      break;
    case 5:
      result = (int)&g_EffMgrData.m_nEffParam_029C;
      break;
    case 6:
      result = (int)&g_EffMgrData.m_nEffParam_0294;
      break;
    case 7:
      result = (int)&g_EffMgrData.m_nEffParam_028C;
      break;
    case 8:
      result = (int)&g_EffMgrData.m_nEffParam2;
      break;
    case 9:
      result = (int)(&g_EffMgrData.m_nEffTypeCode + 8);
      break;
    case 10:
      result = (int)(&pTarget.m_pfnStageCleanup + 4);
      break;
    case 11:
      result = (int)&g_EffMgrData.m_nEffParam_0274;
      break;
    case 12:
      result = (int)&g_EffMgrData.m_nEffTypeCode;
      break;
    case 13:
      result = (int)&g_EffMgrData.m_nEffTypeID;
      break;
    case 14:
      result = (int)&g_EffMgrData.m_nEffParam1;
      break;
    case 15:
      result = (int)&g_EffMgrData.m_nEffParam0;
      break;
    case 16:
      result = (int)&g_EffMgrData;
      break;
    case 17:
      result = (int)&g_EffMgrData.m_nEffParam_0268;
      break;
    case 18:
      result = (int)&g_EffMgrData.m_nEffParam_025C;
      break;
    case 19:
      result = (int)&g_EffMgrData.m_nEffParam_0250;
      break;
    case 20:
      result = (int)&g_pszEditorDesc;
      break;
    case 21:
      result = (int)&g_EffMgrData.m_nEffParam_244;
      break;
    case 22:
      result = (int)&g_EffMgrData.m_nEffParam_234;
      break;
    case 23:
      result = (int)&g_EffMgrData.m_nEffParam_224;
      break;
    default:
      result = (int)g_EffCylinderEditorData;
      break;
  }
  return result;
}

// 0x004D4840
int CEffect::sub_4D4840()
{
  int result; // eax
  int v2; // [esp+0x4] [ebp+0x4]

  switch ( v2 )
  {
    case 0:
      result = (int)(&pTarget.m_nTargetType + 27);
      break;
    case 1:
      result = (int)(&pTarget.m_nTargetType + 24);
      break;
    case 2:
      result = (int)(&pTarget.m_nTargetType + 21);
      break;
    case 3:
      result = (int)&g_EffMgrData.m_nTodo_458;
      break;
    case 4:
      result = (int)(&pTarget.m_nTargetType + 18);
      break;
    case 5:
      result = (int)(&pTarget.m_nTargetType + 15);
      break;
    case 6:
      result = (int)(&pTarget.m_nTargetType + 12);
      break;
    default:
      result = (int)g_EffCylinderEditorData;
      break;
  }
  return result;
}

// 0x0053D580
void CEffect::ReleaseResources()
{
  int v2; // ebp
  _BYTE *p_byMaxFrame; // edi
  gbRefObject **v4; // esi
  char *pPic; // ecx

  v2 = 6;
  p_byMaxFrame = (_BYTE *)&this->m_Partical[1].byMaxFrame;
  v4 = (gbRefObject **)&this->m_Partical[1].byMaxFrame;
  do
  {
    if ( *v4 )
      (*v4)->gbRefObject::Release();
    ++v4;
    --v2;
  }
  while ( v2 );
  memset(p_byMaxFrame, 0, 0x18u);
  pPic = (char *)this->m_Partical[2].pPic;
  if ( pPic )
  {
    (((gbRefObject *)pPic))->gbRefObject::Release();
    this->m_Partical[2].pPic = 0;
  }
}
