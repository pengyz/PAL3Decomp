#include "pal3/ida_defs.h"
#include "globals.h"
#include "pal3/pal3_constants.h"
#include "Effect/CEffQuake.h"
#include "Effect/CEffMgr.h"
#include "Effect/CEffShock.h"
#include "Effect/CEffect.h"
#include "Misc/CTaskTpl_tagEffTaskParam_CEffQuake.h"
#include "Render/RenderTarget2.h"
#include "Misc/tagEffMgrData.h"
#include "free_functions.h"

// Forward declarations for unnamed functions
int sub_4D35E0(...);
int sub_4D36C0(...);

// 0x004C0650
char CEffQuake::AllocSegments(int nVal)
{
  void *v3; // eax
  int v4; // ebp
  int v5; // edi
  int v6; // edi
  int v7; // edx
  int v8; // eax
  int v9; // ecx
  int v11; // ebx
  int v12; // edi

  v3 = (void *)operator new(0x4C0u);
  *((_DWORD *)&this->CTaskTpl_tagEffTaskParam_CEffQuake::__vftable + 3) = (unsigned long)v3;
  if ( !v3 )
    return 1;
  v4 = 0;
  v5 = 0;
  while ( 1 )
  {
    *(_DWORD *)(*((_DWORD *)&this->CTaskTpl_tagEffTaskParam_CEffQuake::__vftable + 3) + v5) = (unsigned long)operator new(0x2D0u);
    if ( !*(_DWORD *)(*((_DWORD *)&this->CTaskTpl_tagEffTaskParam_CEffQuake::__vftable + 3) + v5) )
      break;
    v5 += 152;
    ++v4;
    if ( v5 >= 1216 )
    {
      v6 = 0;
      *((_DWORD *)&this->CTaskTpl_tagEffTaskParam_CEffQuake::__vftable + 7) = 8;
      *((_DWORD *)&this->CTaskTpl_tagEffTaskParam_CEffQuake::__vftable + 8) = 10;
      v7 = 0;
      do
      {
        *(_BYTE *)(*((_DWORD *)&this->CTaskTpl_tagEffTaskParam_CEffQuake::__vftable + 3) + v7 + 148) = 0;
        v8 = 0;
        if ( *((int *)&this->CTaskTpl_tagEffTaskParam_CEffQuake::__vftable + 8) > 0 )
        {
          v9 = 0;
          do
          {
            ++v8;
            v9 += 72;
            *(_BYTE *)(v9 + *(_DWORD *)(v7 + *((_DWORD *)&this->CTaskTpl_tagEffTaskParam_CEffQuake::__vftable + 3)) - 8) = 0;
          }
          while ( v8 < *((_DWORD *)&this->CTaskTpl_tagEffTaskParam_CEffQuake::__vftable + 8) );
        }
        ++v6;
        v7 += 152;
      }
      while ( v6 < *((_DWORD *)&this->CTaskTpl_tagEffTaskParam_CEffQuake::__vftable + 7) );
      return 1;
    }
  }
  if ( v4 > 0 && v4 - 1 >= 0 )
  {
    v11 = v4;
    v12 = 152 * (v4 - 1);
    do
    {
      operator delete(*(void **)(*((_DWORD *)&this->CTaskTpl_tagEffTaskParam_CEffQuake::__vftable + 3) + v12));
      v12 -= 152;
      --v11;
    }
    while ( v11 );
  }
  operator delete(*(&this->CTaskTpl_tagEffTaskParam_CEffQuake::__vftable + 3));
  return 1;
}

// 0x004C29A0

// ---- synthesized vtable stubs (unresolved slots) ----
// [VFTABLE-STUB] original: (*((void ( **)(CTaskTpl_tagEffTaskParam_CEffQuake *, _DWORD, _DWORD, _DWORD))v2->__vftable + 1))( v2, *(_DWORD *)(*v4 + v6), *(_DWORD *)(*v4 + v6 + 4), 0)
static void pal3_vtbl_unk_0(CTaskTpl_tagEffTaskParam_CEffQuake *, _DWORD, _DWORD, _DWORD);

void CEffQuake::UpdateInternal(float fVal)
{
  CTaskTpl_tagEffTaskParam_CEffQuake *v2; // esi
  int v3; // ebx
  int *v4; // ebp
  int v5; // edx
  int v6; // edi
  int v7; // ecx
  int v8; // ecx
  _DWORD *v9; // eax
  int v10; // edx
  _DWORD *v11; // eax
  int v12; // eax
  int v13; // ecx
  int v14; // eax
  int v15; // ecx
  int v16; // [esp+0xC] [ebp-0x8]
  CEffQuake *v17; // [esp+0x10] [ebp-0x4]
  int fVala; // [esp+0x18] [ebp+0x4]

  v2 = ((CTaskTpl_tagEffTaskParam_CEffQuake *)this);
*((float *)&this->CTaskTpl_tagEffTaskParam_CEffQuake::__vftable + 2) = fVal
                                                                       - *((float *)&this->CTaskTpl_tagEffTaskParam_CEffQuake::__vftable
                                                                         + 1);
  *((float *)&this->CTaskTpl_tagEffTaskParam_CEffQuake::__vftable + 1) = fVal;
  if ( *((float *)&this->CTaskTpl_tagEffTaskParam_CEffQuake::__vftable + 2) > 0.0 )
  {
    v3 = 0;
    fVala = 0;
    if ( *((int *)&this->CTaskTpl_tagEffTaskParam_CEffQuake::__vftable + 7) > 0 )
    {
      while ( 1 )
      {
        v4 = (int *)(v3 + *((_DWORD *)((void **)(v2)) + 3));
        if ( *((_BYTE *)v4 + 148) )
        {
          if ( v4[3] == 3 )
          {
            v5 = 0;
            v16 = 0;
            if ( *((int *)((void **)(v2)) + 8) > 0 )
              break;
          }
        }
LABEL_33:
        v3 += 152;
        if ( ++fVala >= *((_DWORD *)((void **)(v2)) + 7) )
        {
          this = v17;
          goto LABEL_35;
        }
      }
      v6 = 0;
      while ( 1 )
      {
        v7 = (unsigned long)*v4;
        if ( !*(_BYTE *)(v6 + *v4 + 64) || v6 > 0 && *(_DWORD *)(v6 + v7 - 64) == 2 )
          goto LABEL_33;
        switch ( *(_DWORD *)(v6 + v7 + 8) )
        {
          case 2:
            if ( v6 > 0 )
            {
              if ( *(float *)(v6 + v7 + 20) >= 0.0 )
              {
                if ( *((float *)((void **)(v2)) + 1) - *(float *)(v6 + v7 - 56) > *(float *)(v6 + v7 + 20) )
                {
LABEL_25:
                  *(_DWORD *)(*(_DWORD *)(v3 + *((_DWORD *)((void **)(v2)) + 3)) + v6 + 8) = 3;
                  *(_DWORD *)(*(_DWORD *)(v3 + *((_DWORD *)((void **)(v2)) + 3)) + v6 + 16) = *((_DWORD *)((void **)(v2))
                                                                                             + 1);
                  *((_DWORD *)((void **)(v2)) + 4) = fVala;
                  *((_DWORD *)((void **)(v2)) + 5) = v16;
                  goto LABEL_26;
                }
              }
              else if ( *(_DWORD *)(v6 + v7 - 64) == 4 )
              {
                goto LABEL_25;
              }
            }
            break;
          case 3:
            *((_DWORD *)((void **)(v2)) + 5) = v5;
            *((_DWORD *)((void **)(v2)) + 4) = fVala;
LABEL_26:
            pal3_vtbl_unk_0(v2, *(_DWORD *)(*v4 + v6), *(_DWORD *)(*v4 + v6 + 4), 0) /* [VFTABLE-STUB] */;
            break;
          case 4:
            v8 = 0;
            v9 = (_DWORD *)(v3 + *((_DWORD *)((void **)(v2)) + 3));
            v10 = (unsigned long)v9[1];
            if ( v10 <= 0 )
            {
LABEL_17:
              v12 = (unsigned long)v4[1];
              v4[3] = 4;
              v13 = 9 * v12;
              LOBYTE(v12) = *((_BYTE *)v4 + 149);
              v4[5] = *(_DWORD *)(*v4 + 8 * v13 - 12);
              if ( (_BYTE)v12 == 1 )
              {
                v14 = 0;
                *(_BYTE *)(v3 + *((_DWORD *)((void **)(v2)) + 3) + 148) = 0;
                if ( *((int *)((void **)(v2)) + 8) > 0 )
                {
                  v15 = 0;
                  do
                  {
                    ++v14;
                    v15 += 72;
                    *(_BYTE *)(*(_DWORD *)(v3 + *((_DWORD *)((void **)(v2)) + 3)) + v15 - 8) = 0;
                  }
                  while ( v14 < *((_DWORD *)((void **)(v2)) + 8) );
                }
                *(_DWORD *)(v3 + *((_DWORD *)((void **)(v2)) + 3) + 4) = 0;
                --*((_DWORD *)((void **)(v2)) + 6);
                goto LABEL_33;
              }
            }
            else
            {
              v11 = (_DWORD *)(*v9 + 8);
              while ( *v11 == 4 )
              {
                ++v8;
                v11 += 18;
                if ( v8 >= v10 )
                  goto LABEL_17;
              }
            }
            break;
        }
        v5 = v16 + 1;
        v6 += 72;
        if ( ++v16 >= *((_DWORD *)((void **)(v2)) + 8) )
          goto LABEL_33;
      }
    }
LABEL_35:
    if ( *((int *)&this->CTaskTpl_tagEffTaskParam_CEffQuake::__vftable + 6) <= 0 )
      this->m_bIdle = 1;
  }
}

static void pal3_vtbl_unk_0(CTaskTpl_tagEffTaskParam_CEffQuake *, _DWORD, _DWORD, _DWORD)
{
    
}


// 0x004D32C0
int * CEffQuake::Destroy()
{
  CEffShock *v1; // eax
  int v3; // [esp+0x4] [ebp+0x4]

  v1 = (CEffShock *)operator new(0x30u);
  if ( v1 )
    return (int *)(((CEffShock *)v1))->CEffShock::GetEditorTaskDescription(v3);
  else
    return 0;
}

// 0x004D3300
int CEffQuake::Update()
{
  CTaskTpl_tagEffTaskParam_CEffQuake *v1; // esi
  int result; // eax
  int v3; // ebx
  int v4; // edi

  v1 = this != 0 ? ((CTaskTpl_tagEffTaskParam_CEffQuake *)this) : 0;
  if ( *((_DWORD *)((void **)(v1)) + 7)
    || (result = (int)*(this != 0 ? &this->CTaskTpl_tagEffTaskParam_CEffQuake::__vftable + 8 : (void **)32)) != 0 )
  {
    v3 = 0;
    if ( *(this != 0 ? (int *)(&this->CTaskTpl_tagEffTaskParam_CEffQuake::__vftable + 7) : (int *)28) > 0 )
    {
      v4 = 0;
      do
      {
        operator delete(*(void **)(v4 + *((_DWORD *)((void **)(v1)) + 3)));
        ++v3;
        *(_DWORD *)(v4 + *((_DWORD *)((void **)(v1)) + 3)) = 0;
        v4 += 152;
      }
      while ( v3 < *((_DWORD *)((void **)(v1)) + 7) );
    }
    operator delete(*(((void **)(v1)) + 3));
    result = 0;
    *((_DWORD *)((void **)(v1)) + 3) = 0;
    *((_DWORD *)((void **)(v1)) + 7) = 0;
    *((_DWORD *)((void **)(v1)) + 8) = 0;
  }
  return result;
}

// 0x004D33B0
int CEffQuake::RenderEffectPass(int a2)
{
  int result; // eax
  CTaskTpl_tagEffTaskParam_CEffQuake *v3; // ebx
  int v4; // ecx
  int v5; // edx
  int v6; // esi
  int v7; // ebp
  unsigned int v8; // eax
  int v9; // ecx
  int v10; // eax
  int v11; // edi
  _BYTE *v12; // esi
  int ( **v13)(CEffect *, int); // esi
  unsigned int v14; // eax
  int v15; // ecx
  int v16; // eax
  int v17; // edi
  _BYTE *v18; // esi
  int ( **v19)(CEffect *, int); // esi
  unsigned int v20; // eax

  v3 = ((CTaskTpl_tagEffTaskParam_CEffQuake *)this);
  v4 = *((_DWORD *)&this->CTaskTpl_tagEffTaskParam_CEffQuake::__vftable + 7);
  v5 = 0;
  if ( v4 > 0 )
  {
    v6 = *((_DWORD *)((void **)(v3)) + 3);
    result = v6 + 148;
    while ( *(_BYTE *)result )
    {
      ++v5;
      result += 152;
      if ( v5 >= v4 )
        return result;
    }
    v7 = 152 * v5;
    *(_DWORD *)(v6 + v7 + 12) = 2;
    *(_BYTE *)(*((_DWORD *)((void **)(v3)) + 3) + v7 + 148) = 1;
    *(_BYTE *)(*((_DWORD *)((void **)(v3)) + 3) + v7 + 149) = 1;
    v8 = ++dword_17A7E50;
    if ( !dword_17A7E50 || v8 >= 0x7FFFFFFF )
    {
      v8 = 1;
      dword_17A7E50 = 1;
    }
    *(_DWORD *)(*((_DWORD *)((void **)(v3)) + 3) + v7 + 16) = v8;
    *(_DWORD *)(*((_DWORD *)((void **)(v3)) + 3) + v7 + 4) = 0;
    *(_DWORD *)(*((_DWORD *)((void **)(v3)) + 3) + v7 + 8) = 0;
    result = *((_DWORD *)((void **)(v3)) + 3);
    *(_DWORD *)(result + v7 + 20) = 0;
    if ( a2 )
    {
      qmemcpy((void *)(*((_DWORD *)((void **)(v3)) + 3) + v7 + 24), (const void *)a2, 0x7Cu);
    }
    else
    {
      result = 0;
      memset((void *)(*((_DWORD *)((void **)(v3)) + 3) + v7 + 24), 0, 0x7Cu);
    }
    ++*((_DWORD *)((void **)(v3)) + 6);
    if ( v5 != -1 )
    {
      v9 = *((_DWORD *)((void **)(v3)) + 8);
      v10 = 0;
      if ( v9 > 0 )
      {
        v11 = *(_DWORD *)(*((_DWORD *)((void **)(v3)) + 3) + 152 * v5);
        v12 = (_BYTE *)(v11 + 64);
        while ( *v12 )
        {
          ++v10;
          v12 += 72;
          if ( v10 >= v9 )
            goto LABEL_22;
        }
        v13 = (int ( **)(CEffect *, int))(v11 + 72 * v10);
        memset(v13, 0, 0x48u);
        *v13 = CEffect::SetParam;
        *((_BYTE *)v13 + 64) = 1;
        *((_BYTE *)v13 + 65) = 0;
        v13[1] = 0;
        v13[2] = (int ( *)(CEffect *, int))2;
        v14 = ++dword_17A7E50;
        if ( !dword_17A7E50 || v14 >= 0x7FFFFFFF )
        {
          v14 = 1;
          dword_17A7E50 = 1;
        }
        v13[3] = (int ( *)(CEffect *, int))v14;
        v13[5] = 0;
        v13[4] = 0;
        v13[6] = 0;
        ++*(_DWORD *)(*((_DWORD *)((void **)(v3)) + 3) + v7 + 4);
      }
LABEL_22:
      v15 = *((_DWORD *)((void **)(v3)) + 8);
      v16 = 0;
      if ( v15 > 0 )
      {
        v17 = *(_DWORD *)(*((_DWORD *)((void **)(v3)) + 3) + 152 * v5);
        v18 = (_BYTE *)(v17 + 64);
        while ( *v18 )
        {
          ++v16;
          v18 += 72;
          if ( v16 >= v15 )
            goto LABEL_31;
        }
        v19 = (int ( **)(CEffect *, int))(v17 + 72 * v16);
        memset(v19, 0, 0x48u);
        *v19 = CEffect::SetParam;
        *((_BYTE *)v19 + 64) = 1;
        *((_BYTE *)v19 + 65) = 0;
        v19[1] = 0;
        v19[2] = (int ( *)(CEffect *, int))2;
        v20 = ++dword_17A7E50;
        if ( !dword_17A7E50 || v20 >= 0x7FFFFFFF )
        {
          v20 = 1;
          dword_17A7E50 = 1;
        }
        v19[3] = (int ( *)(CEffect *, int))v20;
        v19[5] = 0;
        v19[4] = 0;
        v19[6] = 0;
        ++*(_DWORD *)(*((_DWORD *)((void **)(v3)) + 3) + v7 + 4);
      }
LABEL_31:
      sub_4D36C0(v5, sub_4D35E0, 0, 0, *(_DWORD *)(a2 + 72), *(_DWORD *)(a2 + 76));
      *(_DWORD *)(*((_DWORD *)((void **)(v3)) + 3) + v7 + 12) = 3;
      *(_DWORD *)(*(_DWORD *)(*((_DWORD *)((void **)(v3)) + 3) + v7) + 8) = 3;
      result = *(_DWORD *)(*((_DWORD *)((void **)(v3)) + 3) + v7);
      *(_DWORD *)(result + 16) = *((_DWORD *)((void **)(v3)) + 1);
    }
  }
  return result;
}

// 0x004D3660
int CEffQuake::GetQuakeType(int a2)
{
  int result; // eax

  switch ( a2 )
  {
    case 0:
      result = (int)(&pTarget.m_pfnStageCleanup + 19);
      break;
    case 1:
      result = (int)(&pTarget.m_pfnStageCleanup + 16);
      break;
    case 2:
      result = (int)(&pTarget.m_pfnStageCleanup + 13);
      break;
    case 9:
      result = (int)(&g_EffMgrData.m_nEffTypeCode + 8);
      break;
    default:
      result = (int)g_EffCylinderEditorData;
      break;
  }
  return result;
}
