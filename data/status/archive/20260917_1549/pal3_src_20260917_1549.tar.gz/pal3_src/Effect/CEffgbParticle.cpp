#include "pal3/ida_defs.h"
#include "globals.h"
#include "pal3/pal3_constants.h"
#include "Effect/CEffgbParticle.h"
#include "Effect/CEffExplosive.h"
#include "Effect/CEffMgr.h"
#include "Misc/CEffObj.h"
#include "Effect/CEffSParticle.h"
#include "Effect/CEffect.h"
#include "Misc/CParticleEffect.h"
#include "Misc/CTaskTpl_tagEffTaskParam_CEffgbParticle.h"
#include "GameBase/Logger.h"
#include "GameBase/PAL3.h"
#include "Misc/ParticleEffect.h"
#include "Render/RenderTarget.h"
#include "Misc/tagEffMgrData.h"
#include "Misc/tagEffObjType.h"
#include "Misc/tagEffTaskParam.h"
#include "free_functions.h"

// Forward declarations for unnamed functions
int sub_4C90C0(...);
int sub_4C9320(...);
void __cdecl todo_401800(void);

// Unnamed globals (extern)
void __cdecl nullsub_80(void);
void __cdecl nullsub_81(void);
void __cdecl nullsub_82(void);

// 0x004C6980
void CEffgbParticle::ReleaseEffect()
{
  CTaskTpl_tagEffTaskParam_CEffgbParticle *v2; // edi
  ParticleEffect *m_pEffect; // eax
  int v4; // ebp
  float m_fX; // ecx
  CTaskTpl_tagEffTaskParam_CEffgbParticle *v6; // esi
  int v7; // eax
  bool v8; // cc
  int v9; // edi

  v2 = ((CTaskTpl_tagEffTaskParam_CEffgbParticle *)this);
  m_pEffect = (ParticleEffect *)this->m_pEffect;
  v4 = 0;
  if ( m_pEffect )
    operator delete(m_pEffect);
  if ( LODWORD(this->m_fSize) )
    operator delete((void *)LODWORD(this->m_fSize));
  m_fX = this->m_fX;
  if ( m_fX != 0.0 )
    (((gbRefObject *)LODWORD(m_fX)))->gbRefObject::Release();
  if ( LODWORD(this->m_fY) )
    operator delete((void *)LODWORD(this->m_fY));
  v6 = this != 0 ? v2 : 0;
  v7 = *((_DWORD *)((void **)(v6)) + 7);
  v8 = v7 <= 0;
  if ( !v7 )
  {
    if ( !*(this != 0 ? ((void **)(v2)) + 8 : (void **)32) )
      return;
    v8 = 1;
  }
  if ( !v8 )
  {
    v9 = 0;
    do
    {
      operator delete(*(void **)(*((_DWORD *)((void **)(v6)) + 3) + v9));
      ++v4;
      *(_DWORD *)(*((_DWORD *)((void **)(v6)) + 3) + v9) = 0;
      v9 += 152;
    }
    while ( v4 < *((_DWORD *)((void **)(v6)) + 7) );
  }
  operator delete(*(((void **)(v6)) + 3));
  *((_DWORD *)((void **)(v6)) + 3) = 0;
  *((_DWORD *)((void **)(v6)) + 7) = 0;
  *((_DWORD *)((void **)(v6)) + 8) = 0;
}

// 0x004C6C10
char CEffgbParticle::Create(tagEffObjType *pType)
{
  void *v3; // eax
  int v4; // ebx
  int v5; // edi
  int v6; // edi
  int v7; // edx
  int v8; // eax
  int v9; // ecx
  int v10; // edx
  int v11; // ebx
  ParticleEffect *v12; // eax
  int v13; // ebx
  int v14; // ebp
  int v15; // ebx
  int v16; // edi
  int v17; // ebx
  char *v18; // eax
  _DWORD *v19; // ecx
  int v20; // edx
  ParticleEffect *m_pEffect; // ecx
  ParticleEffect *v23; // [esp+0x10] [ebp-0x810]
  char pExceptionObject[1024]; // [esp+0x14] [ebp-0x80C] BYREF
  char ArgList; // [esp+0x414] [ebp-0x40C] BYREF
  int v26; // [esp+0x81C] [ebp-0x4]

  v3 = (void *)operator new(0x4C0u);
  *((_DWORD *)&this->CTaskTpl_tagEffTaskParam_CEffgbParticle::__vftable + 3) = (unsigned long)v3;
  if ( v3 )
  {
    v4 = 0;
    v5 = 0;
    while ( 1 )
    {
      *(_DWORD *)(v5 + *((_DWORD *)&this->CTaskTpl_tagEffTaskParam_CEffgbParticle::__vftable + 3)) = (unsigned long)operator new(0x2D0u);
      if ( !*(_DWORD *)(v5 + *((_DWORD *)&this->CTaskTpl_tagEffTaskParam_CEffgbParticle::__vftable + 3)) )
        break;
      v5 += 152;
      ++v4;
      if ( v5 >= 1216 )
      {
        v6 = 0;
        *((_DWORD *)&this->CTaskTpl_tagEffTaskParam_CEffgbParticle::__vftable + 7) = 8;
        *((_DWORD *)&this->CTaskTpl_tagEffTaskParam_CEffgbParticle::__vftable + 8) = 10;
        v7 = 0;
        do
        {
          *(_BYTE *)(v7 + *((_DWORD *)&this->CTaskTpl_tagEffTaskParam_CEffgbParticle::__vftable + 3) + 148) = 0;
          v8 = 0;
          if ( *((int *)&this->CTaskTpl_tagEffTaskParam_CEffgbParticle::__vftable + 8) > 0 )
          {
            v9 = 0;
            do
            {
              ++v8;
              v9 += 72;
              *(_BYTE *)(*(_DWORD *)(v7 + *((_DWORD *)&this->CTaskTpl_tagEffTaskParam_CEffgbParticle::__vftable + 3))
                       + v9
                       - 8) = 0;
            }
            while ( v8 < *((_DWORD *)&this->CTaskTpl_tagEffTaskParam_CEffgbParticle::__vftable + 8) );
          }
          ++v6;
          v7 += 152;
        }
        while ( v6 < *((_DWORD *)&this->CTaskTpl_tagEffTaskParam_CEffgbParticle::__vftable + 7) );
        goto LABEL_10;
      }
    }
    if ( v4 > 0 && v4 - 1 >= 0 )
    {
      v16 = 152 * (v4 - 1);
      do
      {
        operator delete(*(void **)(v16 + *((_DWORD *)&this->CTaskTpl_tagEffTaskParam_CEffgbParticle::__vftable + 3)));
        v16 -= 152;
        --v4;
      }
      while ( v4 );
    }
    operator delete(*(&this->CTaskTpl_tagEffTaskParam_CEffgbParticle::__vftable + 3));
  }
LABEL_10:
  *((_DWORD *)&this[1].CTaskTpl_tagEffTaskParam_CEffgbParticle::__vftable + 4) = (__int64)pType->fSacleX;
  *((_DWORD *)&this[1].CTaskTpl_tagEffTaskParam_CEffgbParticle::__vftable + 5) = (__int64)pType->fSacleZ;
  *((_DWORD *)&this[1].CTaskTpl_tagEffTaskParam_CEffgbParticle::__vftable + 6) = LODWORD(pType->fSacleY);
  *((_DWORD *)&this[1].CTaskTpl_tagEffTaskParam_CEffgbParticle::__vftable + 8) = LODWORD(pType->fTopRadius);
  this[1].m_pEffect = (ParticleEffect *)LODWORD(pType->fBottomRadius);
  this[1].m_fSize = pType->fTopRadiusIncSpeed;
  this[1].m_fX = pType->fBottomRadiusIncSpeed;
  v10 = *((_DWORD *)&this[1].CTaskTpl_tagEffTaskParam_CEffgbParticle::__vftable + 4)
      * *((_DWORD *)&this[1].CTaskTpl_tagEffTaskParam_CEffgbParticle::__vftable + 5);
  this[1].m_fY = pType->fTextureRepeat;
  this[1].m_fZ = pType->fTopRiseSpeed;
  *((_DWORD *)&this[1].CTaskTpl_tagEffTaskParam_CEffgbParticle::__vftable + 7) = v10;
  this[1].m_fPX = pType->fFramePerSec;
  this[2].m_pEM = (CEffMgr *)LODWORD(pType->fX);
  *(float *)&this[2].m_bIdle = pType->fY;
  this[2].CTaskTpl_tagEffTaskParam_CEffgbParticle::__vftable = (void *)LODWORD(pType->fZ);
  this[1].m_fPY = pType->fStartXRot;
  this[1].m_fPZ = pType->fStartYRot;
  this[2].CEffObj::__vftable = (void *)LODWORD(pType->fStartZRot);
  BYTE1(this->m_fZ) = pType->bAdditiveBlend;
  BYTE2(this->m_fZ) = pType->bNoZTest;
  HIBYTE(this->m_fZ) = pType->nFrame;
  LODWORD(this->m_fPX) = (unsigned long)&byte_FFFFFF;
  this[1].CEffObj::__vftable = (void *)pType->dwColor;
  /* [MISATTRIBUTED] CEffExplosive on CEffgbParticle::this -> fix IDB name of callee */ CEffExplosive::InitDefaultUVSet((CEffExplosive *)this, pType->nFramePerRow, pType->nFramePerCol);
  v11 = *((_DWORD *)&this[1].CTaskTpl_tagEffTaskParam_CEffgbParticle::__vftable + 7);
  v12 = (ParticleEffect *)operator new(68 * v11);
  v23 = (ParticleEffect *)v12;
  v26 = 0;
  if ( v12 )
  {
    v13 = v11 - 1;
    v14 = (int)v12;
    if ( v13 >= 0 )
    {
      v15 = v13 + 1;
      do
      {
        v14 += 68;
        --v15;
      }
      while ( v15 );
      v12 = (ParticleEffect *)v23;
    }
  }
  else
  {
    v12 = 0;
  }
  v17 = *((_DWORD *)&this[1].CTaskTpl_tagEffTaskParam_CEffgbParticle::__vftable + 7);
  this->m_pEffect = v12;
  v26 = -1;
  v18 = (char *)operator new(24 * v17);
  if ( v18 )
  {
    if ( v17 - 1 >= 0 )
    {
      v19 = (_DWORD *)v18 + 20;
      v20 = v17;
      do
      {
        *(v19 - 5) = 0;
        *(v19 - 4) = 0;
        *(v19 - 3) = 0;
        *(v19 - 2) = 0;
        *(v19 - 1) = 0;
        *v19 = 0;
        v19 += 6;
        --v20;
      }
      while ( v20 );
    }
  }
  else
  {
    v18 = 0;
  }
  m_pEffect = (ParticleEffect *)this->m_pEffect;
  LODWORD(this->m_fSize) = (unsigned long)v18;
  if ( !m_pEffect || !v18 )
  {
    qmemcpy(
      pExceptionObject,
      (((Logger *)&ArgList))->Logger::FormatException((char *)&g_EffMgrData.m_nEffParam_0338 + 116, (char *)&g_EffMgrData.m_nEffParam_0338 + 152, 121),
      sizeof(pExceptionObject));
    _CxxThrowException(pExceptionObject, (_ThrowInfo *)&_TI1_AV_Exception__);
  }
  /* [MISATTRIBUTED] CEffExplosive on CEffgbParticle::this -> fix IDB name of callee */ CEffExplosive::LoadTexture((CEffExplosive *)this, pType->szTexture);
  return 1;
}

// 0x004C6F20
void CEffgbParticle::Destroy()
{
  char v2; // al
  bool v3; // zf
  CEffMgr *m_pEM; // eax
  gbRenderEffect *m_pAlphaBlendNoZ; // ebp
  gbMatrixStack *v6; // edi
  float v7; // [esp+0x3C] [ebp-0xC]
  float retaddr; // [esp+0x48] [ebp+0x0] BYREF

  if ( (g_PAL3.m_bCEffExplosiveFlag & 1) == 0 )
  {
    *(&g_PAL3.m_nScriptCallbackCount + 392) = 1065353216;
    g_PAL3.m_bCEffExplosiveFlag |= 1u;
    *(&g_PAL3.m_nScriptCallbackCount + 393) = 0;
    *(&g_PAL3.m_nScriptCallbackCount + 394) = 0;
    atexit(nullsub_82);
  }
  if ( (g_PAL3.m_bCEffExplosiveFlag & 2) == 0 )
  {
    *(&g_PAL3.m_nScriptCallbackCount + 388) = 0;
    g_PAL3.m_bCEffExplosiveFlag |= 2u;
    *(&g_PAL3.m_nScriptCallbackCount + 389) = 1065353216;
    *(&g_PAL3.m_nScriptCallbackCount + 390) = 0;
    atexit(nullsub_81);
  }
  if ( (g_PAL3.m_bCEffExplosiveFlag & 4) == 0 )
  {
    *(&g_PAL3.m_nScriptCallbackCount + 384) = 0;
    g_PAL3.m_bCEffExplosiveFlag |= 4u;
    *(&g_PAL3.m_nScriptCallbackCount + 385) = 0;
    *(&g_PAL3.m_nScriptCallbackCount + 386) = 1065353216;
    atexit(nullsub_80);
  }
  if ( !this->m_bIdle && LOBYTE(this->m_fZ) )
  {
    (((gbVertPoolMgr *)this->m_pEM->m_pDisplay->pVertPoolMgr))->gbVertPoolMgr::GetDynVertBuf(0x15u);
    v2 = BYTE1(this->m_fZ);
    if ( BYTE2(this->m_fZ) )
    {
      v3 = v2 == 0;
      m_pEM = this->m_pEM;
      if ( v3 )
        m_pAlphaBlendNoZ = (gbRenderEffect *)m_pEM->m_pAlphaBlendNoZ;
      else
        m_pAlphaBlendNoZ = (gbRenderEffect *)m_pEM->m_pAdditiveBlendNoZ;
    }
    else
    {
      v3 = v2 == 0;
      m_pEM = this->m_pEM;
      if ( v3 )
        m_pAlphaBlendNoZ = (gbRenderEffect *)m_pEM->m_pAlphaBlend;
      else
        m_pAlphaBlendNoZ = (gbRenderEffect *)m_pEM->m_pAdditiveBlend;
    }
    v6 = (gbMatrixStack *)m_pEM->m_pDisplay->pMatrixStack[1];
    (((gbMatrixStack *)v6))->gbMatrixStack::Push();
    v7 = *((float *)&this[2].CTaskTpl_tagEffTaskParam_CEffgbParticle::__vftable + 1) + *(float *)&this[2].m_pEM;
    retaddr = v7;
    (((gbMatrixStack *)v6))->gbMatrixStack::Translate(*(gbVec3D *)&retaddr);
    (((gbMatrixStack *)v6))->gbMatrixStack::Scale(*((float *)&this[1].CTaskTpl_tagEffTaskParam_CEffgbParticle::__vftable + 2),   1.0,   *((float *)&this[1].CTaskTpl_tagEffTaskParam_CEffgbParticle::__vftable + 3));
    (((gbMatrixStack *)v6))->gbMatrixStack::Rotate(this[1].m_fPY, * (gbVec3D *)(&g_PAL3.m_nScriptCallbackCount + 392));
    (((gbMatrixStack *)v6))->gbMatrixStack::Rotate(this[1].m_fPZ, * (gbVec3D *)(&g_PAL3.m_nScriptCallbackCount + 388));
    (((gbMatrixStack *)v6))->gbMatrixStack::Rotate(*(float *)&this[2].CEffObj::__vftable, * (gbVec3D *)&g_PAL3.m_nScriptCallbackCount + 128);
    (((gbDynVertBuf *)this->m_pEffect))->gbDynVertBuf::RenderGeomQuad(*((_DWORD *)&this[1].CTaskTpl_tagEffTaskParam_CEffgbParticle::__vftable + 7), m_pAlphaBlendNoZ, (gbTextureArray *)LODWORD(this->m_fY));
    (((gbMatrixStack *)v6))->gbMatrixStack::Pop();
  }
}

// 0x004C7A70
const char * CEffgbParticle::GetEditorTaskDescription(int nIndex)
{
  const char *result; // eax

  switch ( nIndex )
  {
    case 0:
      result = (const char *)&g_EffMgrData.m_nEffParam_02A4;
      break;
    case 1:
      result = (const char *)&g_EffMgrData.m_nEffParam9;
      break;
    case 2:
      result = (const char *)&g_EffMgrData.m_nEffParam8;
      break;
    case 3:
      result = (const char *)&g_EffMgrData.m_nEffParam7;
      break;
    case 4:
      result = (const char *)&g_EffMgrData.m_nEffParam6;
      break;
    case 5:
      result = (const char *)&g_EffMgrData.m_nEffParam_029C;
      break;
    case 6:
      result = (const char *)&g_EffMgrData.m_nEffParam_0294;
      break;
    case 7:
      result = (const char *)&g_EffMgrData.m_nEffParam_028C;
      break;
    case 8:
      result = (const char *)&g_EffMgrData.m_nEffParam2;
      break;
    case 9:
      result = (const char *)(&g_EffMgrData.m_nEffTypeCode + 8);
      break;
    case 10:
      result = (const char *)&g_EffMgrData.m_nEffParam_404;
      break;
    case 12:
      result = (const char *)&g_EffMgrData.m_nEffTypeCode;
      break;
    case 13:
      result = (const char *)&g_EffMgrData.m_nEffTypeID;
      break;
    case 14:
      result = (const char *)&g_EffMgrData.m_nEffParam1;
      break;
    case 15:
      result = (const char *)&g_EffMgrData.m_nEffParam0;
      break;
    case 16:
      result = (const char *)&g_EffMgrData;
      break;
    case 17:
      result = (const char *)&g_EffMgrData.m_nTodo_3F8;
      break;
    case 20:
      result = (const char *)&g_pszEditorDesc;
      break;
    default:
      result = g_EffCylinderEditorData;
      break;
  }
  return result;
}

// 0x004C7B70
const char * CEffgbParticle::GetEditorObjDescription(int nIndex)
{
  const char *result; // eax

  switch ( nIndex )
  {
    case 0:
      result = (const char *)&g_EffMgrData.m_nTodo_470;
      break;
    case 1:
      result = (const char *)&g_EffMgrData.m_nTodo_464;
      break;
    case 2:
      result = (const char *)&g_EffMgrData.m_nTodo_458;
      break;
    case 3:
      result = (const char *)&g_EffMgrData.m_nTodo_44C;
      break;
    case 4:
      result = (const char *)&g_EffMgrData.m_nTodo_440;
      break;
    case 5:
      result = (const char *)&g_EffMgrData.m_nTodo_434;
      break;
    case 6:
      result = (const char *)&g_EffMgrData.m_nTodo_42C;
      break;
    case 7:
      result = (const char *)&g_EffMgrData.m_nTodo_424;
      break;
    case 8:
      result = (const char *)&g_EffMgrData.m_nTodo_41C;
      break;
    case 9:
      result = (const char *)&g_EffMgrData.m_nTodo_410;
      break;
    default:
      result = g_EffCylinderEditorData;
      break;
  }
  return result;
}

// 0x004C8650
CEffgbParticle::~CEffgbParticle()
{
  int v8; // ecx
  int v9; // esi
  int v10; // edx
  _BYTE *i; // eax
  int *v12; // edx
  unsigned int v13; // eax
  int *v14; // edx

  v8 = *((_DWORD *)&this->CTaskTpl_tagEffTaskParam_CEffgbParticle::__vftable + 5);
  v9 = 0;
  if ( v8 > 0 )
  {
    v10 = *((_DWORD *)this->CTaskTpl_tagEffTaskParam_CEffgbParticle::__vftable + 38 * nVal);
    for ( i = (_BYTE *)(v10 + 64); *i; i += 72 )
    {
      if ( ++v9 >= v8 )
        return;
    }
    v12 = (int *)(v10 + 72 * v9);
    memset(v12, 0, 0x48u);
    *((_BYTE *)v12 + 65) = 0;
    *((_BYTE *)v12 + 64) = 1;
    *v12 = nVal2;
    v12[1] = nVal3;
    v12[2] = 2;
    v13 = ++g_PAL3.m_nCEffCylinderCount;
    if ( !g_PAL3.m_nCEffCylinderCount || v13 >= 0x7FFFFFFF )
    {
      v13 = 1;
      g_PAL3.m_nCEffCylinderCount = 1;
    }
    v12[3] = v13;
    v12[4] = 0;
    v12[5] = nVal4;
    v12[6] = nVal5;
    if ( p_DWORD )
    {
      v14 = (int *)(v12 + 7);
      *v14 = *p_DWORD;
      v14[1] = (unsigned long)p_DWORD[1];
      v14[2] = (unsigned long)p_DWORD[2];
      v14[3] = (unsigned long)p_DWORD[3];
    }
    ++*((_DWORD *)this->CTaskTpl_tagEffTaskParam_CEffgbParticle::__vftable + 38 * nVal + 1);
  }
}

// 0x004C87A0
void * CEffgbParticle::Create(CEffgbParticle *Block, char pType)
{
  int v4; // eax
  int v5; // ebx
  int v6; // edi

  v4 = *((_DWORD *)&this->CTaskTpl_tagEffTaskParam_CEffgbParticle::__vftable + 4);
  if ( v4 || *((_DWORD *)&this->CTaskTpl_tagEffTaskParam_CEffgbParticle::__vftable + 5) )
  {
    v5 = 0;
    if ( v4 > 0 )
    {
      v6 = 0;
      do
      {
        operator delete(*(void **)((char *)this->CTaskTpl_tagEffTaskParam_CEffgbParticle::__vftable + v6));
        ++v5;
        *(_DWORD *)((char *)this->CTaskTpl_tagEffTaskParam_CEffgbParticle::__vftable + v6) = 0;
        v6 += 152;
      }
      while ( v5 < *((_DWORD *)&this->CTaskTpl_tagEffTaskParam_CEffgbParticle::__vftable + 4) );
    }
    operator delete(this->CTaskTpl_tagEffTaskParam_CEffgbParticle::__vftable);
    this->CTaskTpl_tagEffTaskParam_CEffgbParticle::__vftable = 0;
    *((_DWORD *)&this->CTaskTpl_tagEffTaskParam_CEffgbParticle::__vftable + 4) = 0;
    *((_DWORD *)&this->CTaskTpl_tagEffTaskParam_CEffgbParticle::__vftable + 5) = 0;
  }
  if ( ((unsigned __int8)Block & 1) != 0 )
    operator delete(this);
  return this;
}

// 0x004C8830
int CEffgbParticle::Init(int pType)
{
  int v2; // edx
  int v3; // esi
  int result; // eax

  *((_BYTE *)this->CTaskTpl_tagEffTaskParam_CEffgbParticle::__vftable + 152 * pType + 148) = 0;
  v2 = 0;
  if ( *((int *)&this->CTaskTpl_tagEffTaskParam_CEffgbParticle::__vftable + 5) > 0 )
  {
    v3 = 0;
    do
    {
      ++v2;
      v3 += 72;
      *(_BYTE *)(*((_DWORD *)this->CTaskTpl_tagEffTaskParam_CEffgbParticle::__vftable + 38 * pType) + v3 - 8) = 0;
    }
    while ( v2 < *((_DWORD *)&this->CTaskTpl_tagEffTaskParam_CEffgbParticle::__vftable + 5) );
  }
  *((_DWORD *)this->CTaskTpl_tagEffTaskParam_CEffgbParticle::__vftable + 38 * pType + 1) = 0;
  result = *((_DWORD *)&this->CTaskTpl_tagEffTaskParam_CEffgbParticle::__vftable + 3) - 1;
  *((_DWORD *)&this->CTaskTpl_tagEffTaskParam_CEffgbParticle::__vftable + 3) = result;
  return result;
}

// 0x004C88C0
char * CEffgbParticle::Attach(char pData)
{
  char *p_m_fPX; // esi

  p_m_fPX = (char *)&this[-1].m_fPX;
  (((CEffgbParticle *)((char *)this - 12)))->CEffgbParticle::ReleaseEffect();
  if ( (pData & 1) != 0 )
    operator delete(p_m_fPX);
  return p_m_fPX;
}

// 0x004C88D0
int * CEffgbParticle::Render()
{
  int *result; // eax

  result = (int *)this;
  this->m_pEM = 0;
  this->m_bIdle = 0;
  *((_DWORD *)&this->CTaskTpl_tagEffTaskParam_CEffgbParticle::__vftable + 1) = 0;
  *((_DWORD *)&this->CTaskTpl_tagEffTaskParam_CEffgbParticle::__vftable + 2) = 0;
  *((_DWORD *)&this->CTaskTpl_tagEffTaskParam_CEffgbParticle::__vftable + 3) = 0;
  *((_DWORD *)&this->CTaskTpl_tagEffTaskParam_CEffgbParticle::__vftable + 4) = -1;
  *((_DWORD *)&this->CTaskTpl_tagEffTaskParam_CEffgbParticle::__vftable + 5) = -1;
  *((_DWORD *)&this->CTaskTpl_tagEffTaskParam_CEffgbParticle::__vftable + 6) = 0;
  *((_DWORD *)&this->CTaskTpl_tagEffTaskParam_CEffgbParticle::__vftable + 7) = 0;
  *((_DWORD *)&this->CTaskTpl_tagEffTaskParam_CEffgbParticle::__vftable + 8) = 0;
  this->m_pEffect = 0;
  this->m_fSize = 0.0;
  this->m_fZ = 0.0;
  this->m_fY = 0.0;
  this->m_fX = 0.0;
  this->m_fPZ = 0.0;
  this->m_fPY = 0.0;
  this->m_fPX = 0.0;
  return result;
}

// 0x004C8930
CEffgbParticle * CEffgbParticle::SetTimeScale()
{
  CEffgbParticle *v1; // eax

  v1 = (CEffgbParticle *)operator new(0x50u);
  if ( v1 )
    return (CEffgbParticle *)(((CEffgbParticle *)v1))->CEffgbParticle::Render();
  else
    return 0;
}

// 0x004C8970
void CEffgbParticle::Destroy__fastcall()
{
  CTaskTpl_tagEffTaskParam_CEffgbParticle *v2; // edi
  ParticleEffect *m_pEffect; // ecx
  int v4; // ebx
  CTaskTpl_tagEffTaskParam_CEffgbParticle *v5; // esi
  int v6; // eax
  bool v7; // cc
  int v8; // edi

  v2 = ((CTaskTpl_tagEffTaskParam_CEffgbParticle *)this);
  m_pEffect = (ParticleEffect *)this->m_pEffect;
  v4 = 0;
  if ( m_pEffect )
  {
    (**(void ( ***)(ParticleEffect *, int))m_pEffect->name)(m_pEffect, 1);
    this->m_pEffect = 0;
  }
  v5 = this != 0 ? v2 : 0;
  v6 = *((_DWORD *)((void **)(v5)) + 7);
  v7 = v6 <= 0;
  if ( !v6 )
  {
    if ( !*(this != 0 ? ((void **)(v2)) + 8 : (void **)32) )
      return;
    v7 = 1;
  }
  if ( !v7 )
  {
    v8 = 0;
    do
    {
      operator delete(*(void **)(*((_DWORD *)((void **)(v5)) + 3) + v8));
      ++v4;
      *(_DWORD *)(*((_DWORD *)((void **)(v5)) + 3) + v8) = 0;
      v8 += 152;
    }
    while ( v4 < *((_DWORD *)((void **)(v5)) + 7) );
  }
  operator delete(*(((void **)(v5)) + 3));
  *((_DWORD *)((void **)(v5)) + 3) = 0;
  *((_DWORD *)((void **)(v5)) + 7) = 0;
  *((_DWORD *)((void **)(v5)) + 8) = 0;
}

// 0x004C8A40
char CEffgbParticle::CreateTask(tagEffTaskParam *p)
{
  void *v3; // eax
  int v4; // ebp
  int v5; // edi
  int v6; // edi
  int v7; // edx
  int v8; // eax
  int v9; // ecx
  ParticleEffect *v10; // eax
  int v11; // edi
  int v13; // [esp+0x0] [ebp-0x20]

  v3 = (void *)operator new(0x4C0u);
  *((_DWORD *)&this->CTaskTpl_tagEffTaskParam_CEffgbParticle::__vftable + 3) = (unsigned long)v3;
  if ( v3 )
  {
    v4 = 0;
    v5 = 0;
    while ( 1 )
    {
      *(_DWORD *)(*((_DWORD *)&this->CTaskTpl_tagEffTaskParam_CEffgbParticle::__vftable + 3) + v5) = (unsigned long)operator new(0x2D0u);
      if ( !*(_DWORD *)(*((_DWORD *)&this->CTaskTpl_tagEffTaskParam_CEffgbParticle::__vftable + 3) + v5) )
        break;
      v5 += 152;
      ++v4;
      if ( v5 >= 1216 )
      {
        v6 = 0;
        *((_DWORD *)&this->CTaskTpl_tagEffTaskParam_CEffgbParticle::__vftable + 7) = 8;
        *((_DWORD *)&this->CTaskTpl_tagEffTaskParam_CEffgbParticle::__vftable + 8) = 10;
        v7 = 0;
        do
        {
          *(_BYTE *)(*((_DWORD *)&this->CTaskTpl_tagEffTaskParam_CEffgbParticle::__vftable + 3) + v7 + 148) = 0;
          v8 = 0;
          if ( *((int *)&this->CTaskTpl_tagEffTaskParam_CEffgbParticle::__vftable + 8) > 0 )
          {
            v9 = 0;
            do
            {
              ++v8;
              v9 += 72;
              *(_BYTE *)(v9
                       + *(_DWORD *)(v7 + *((_DWORD *)&this->CTaskTpl_tagEffTaskParam_CEffgbParticle::__vftable + 3))
                       - 8) = 0;
            }
            while ( v8 < *((_DWORD *)&this->CTaskTpl_tagEffTaskParam_CEffgbParticle::__vftable + 8) );
          }
          ++v6;
          v7 += 152;
        }
        while ( v6 < *((_DWORD *)&this->CTaskTpl_tagEffTaskParam_CEffgbParticle::__vftable + 7) );
        goto LABEL_10;
      }
    }
    if ( v4 > 0 && v4 - 1 >= 0 )
    {
      v11 = 152 * (v4 - 1);
      do
      {
        operator delete(*(void **)(*((_DWORD *)&this->CTaskTpl_tagEffTaskParam_CEffgbParticle::__vftable + 3) + v11));
        v11 -= 152;
        --v4;
      }
      while ( v4 );
    }
    operator delete(*(&this->CTaskTpl_tagEffTaskParam_CEffgbParticle::__vftable + 3));
  }
LABEL_10:
  if ( operator new(0x5896Cu) )
    v10 = (ParticleEffect *)ParticleEffect_Reset(v13);
  else
    v10 = 0;
  this->m_pEffect = v10;
  return (((RenderTarget *)v10))->RenderTarget::LoadParticleTextures((const char *)&p->fSoundStartTime3);
}

// 0x004C8B80
int CEffgbParticle::slot_2(int nVal, float a3, float a4, float a5)
{
  int result; // eax
  double v8; // st7
  int nVala; // [esp+0x10] [ebp+0x4]

  this->m_bIdle = 0;
  nVala = *(int *)(nVal + 200);
  this->m_fSize = *(float *)&nVala;
  ParticleEffect_SetTimeParam(nVala);
  result = (int)(((CEffect *)this->m_pEffect))->CEffect::SetQuadParam(0);
  this->m_fX = a3 + *(float *)(nVal + 184);
  this->m_fY = a4 + *(float *)(nVal + 188);
  v8 = a5 + *(float *)(nVal + 192);
  this->m_fPX = 0.0;
  this->m_fPY = 0.0;
  this->m_fPZ = 0.0;
  this->m_fZ = v8;
  return result;
}

// 0x004C8BF0

// ---- synthesized vtable stubs (unresolved slots) ----
// [VFTABLE-STUB] original: (*((void ( **)(CTaskTpl_tagEffTaskParam_CEffgbParticle *, _DWORD, _DWORD, _DWORD))v4->__vftable + 1))( v4, *(_DWORD *)(*v7 + v9), *(_DWORD *)(*v7 + v9 + 4), 0)
static void pal3_vtbl_unk_0(CTaskTpl_tagEffTaskParam_CEffgbParticle *, _DWORD, _DWORD, _DWORD);

void CEffgbParticle::ProcCommonTask(float dwParam)
{
  CEffgbParticle *v2; // edi
  double v3; // st7
  CTaskTpl_tagEffTaskParam_CEffgbParticle *v4; // esi
  int v5; // ecx
  int v6; // ebx
  int *v7; // ebp
  int v8; // edx
  int v9; // edi
  int v10; // ecx
  int v11; // ecx
  _DWORD *v12; // eax
  int v13; // edx
  _DWORD *v14; // eax
  int v15; // eax
  int v16; // ecx
  int v17; // eax
  int v18; // ecx
  int v19; // [esp+0xC] [ebp-0x8]
  int dwParama; // [esp+0x18] [ebp+0x4]
v3 = dwParam - *((float *)&this->CTaskTpl_tagEffTaskParam_CEffgbParticle::__vftable + 1);
  v4 = ((CTaskTpl_tagEffTaskParam_CEffgbParticle *)this);
  *((float *)&this->CTaskTpl_tagEffTaskParam_CEffgbParticle::__vftable + 1) = dwParam;
  *((float *)&this->CTaskTpl_tagEffTaskParam_CEffgbParticle::__vftable + 2) = v3;
  v5 = *((int *)&this->CTaskTpl_tagEffTaskParam_CEffgbParticle::__vftable + 2);
  if ( *(float *)&v5 > 0.0 )
  {
    ParticleEffect_SetDeltaTime(v5);
    v6 = 0;
    dwParama = 0;
    if ( *((int *)((void **)(v4)) + 7) > 0 )
    {
      while ( 1 )
      {
        v7 = (int *)(*((_DWORD *)((void **)(v4)) + 3) + v6);
        if ( *((_BYTE *)v7 + 148) )
        {
          if ( v7[3] == 3 )
          {
            v8 = 0;
            v19 = 0;
            if ( *((int *)((void **)(v4)) + 8) > 0 )
              break;
          }
        }
LABEL_33:
        v6 += 152;
        if ( ++dwParama >= *((_DWORD *)((void **)(v4)) + 7) )
        {
goto LABEL_35;
        }
      }
      v9 = 0;
      while ( 1 )
      {
        v10 = (unsigned long)*v7;
        if ( !*(_BYTE *)(v9 + *v7 + 64) || v9 > 0 && *(_DWORD *)(v9 + v10 - 64) == 2 )
          goto LABEL_33;
        switch ( *(_DWORD *)(v9 + v10 + 8) )
        {
          case 2:
            if ( v9 > 0 )
            {
              if ( *(float *)(v9 + v10 + 20) >= 0.0 )
              {
                if ( *((float *)((void **)(v4)) + 1) - *(float *)(v9 + v10 - 56) > *(float *)(v9 + v10 + 20) )
                {
LABEL_25:
                  *(_DWORD *)(*(_DWORD *)(*((_DWORD *)((void **)(v4)) + 3) + v6) + v9 + 8) = 3;
                  *(_DWORD *)(*(_DWORD *)(*((_DWORD *)((void **)(v4)) + 3) + v6) + v9 + 16) = *((_DWORD *)((void **)(v4))
                                                                                             + 1);
                  *((_DWORD *)((void **)(v4)) + 4) = dwParama;
                  *((_DWORD *)((void **)(v4)) + 5) = v19;
                  goto LABEL_26;
                }
              }
              else if ( *(_DWORD *)(v9 + v10 - 64) == 4 )
              {
                goto LABEL_25;
              }
            }
            break;
          case 3:
            *((_DWORD *)((void **)(v4)) + 5) = v8;
            *((_DWORD *)((void **)(v4)) + 4) = dwParama;
LABEL_26:
            pal3_vtbl_unk_0(v4, *(_DWORD *)(*v7 + v9), *(_DWORD *)(*v7 + v9 + 4), 0) /* [VFTABLE-STUB] */;
            break;
          case 4:
            v11 = 0;
            v12 = (_DWORD *)(*((_DWORD *)((void **)(v4)) + 3) + v6);
            v13 = (unsigned long)v12[1];
            if ( v13 <= 0 )
            {
LABEL_17:
              v15 = (unsigned long)v7[1];
              v7[3] = 4;
              v16 = 9 * v15;
              LOBYTE(v15) = *((_BYTE *)v7 + 149);
              v7[5] = *(_DWORD *)(*v7 + 8 * v16 - 12);
              if ( (_BYTE)v15 == 1 )
              {
                v17 = 0;
                *(_BYTE *)(*((_DWORD *)((void **)(v4)) + 3) + v6 + 148) = 0;
                if ( *((int *)((void **)(v4)) + 8) > 0 )
                {
                  v18 = 0;
                  do
                  {
                    ++v17;
                    v18 += 72;
                    *(_BYTE *)(*(_DWORD *)(*((_DWORD *)((void **)(v4)) + 3) + v6) + v18 - 8) = 0;
                  }
                  while ( v17 < *((_DWORD *)((void **)(v4)) + 8) );
                }
                *(_DWORD *)(*((_DWORD *)((void **)(v4)) + 3) + v6 + 4) = 0;
                --*((_DWORD *)((void **)(v4)) + 6);
                goto LABEL_33;
              }
            }
            else
            {
              v14 = (_DWORD *)(*v12 + 8);
              while ( *v14 == 4 )
              {
                ++v11;
                v14 += 18;
                if ( v11 >= v13 )
                  goto LABEL_17;
              }
            }
            break;
        }
        v8 = v19 + 1;
        v9 += 72;
        if ( ++v19 >= *((_DWORD *)((void **)(v4)) + 8) )
          goto LABEL_33;
      }
    }
LABEL_35:
    if ( *((int *)&this->CTaskTpl_tagEffTaskParam_CEffgbParticle::__vftable + 6) <= 0 )
      (((CEffect *)this->m_pEffect))->CEffect::SetQuadParam(0);
  }
}

static void pal3_vtbl_unk_0(CTaskTpl_tagEffTaskParam_CEffgbParticle *, _DWORD, _DWORD, _DWORD)
{
    
}


// 0x004C8E10
void CEffgbParticle::GetEditorTaskDescription()
{
  gbMatrixStack *v2; // edi
  int v3; // eax
  float v4; // [esp+0x0] [ebp-0x14]
  float v5; // [esp+0x4] [ebp-0x10]
  float v6; // [esp+0x8] [ebp-0xC]

  if ( !this->m_bIdle )
  {
    v2 = this->m_pEM->m_pDisplay->pMatrixStack[1];
    (((gbMatrixStack *)v2))->gbMatrixStack::Push();
    v6 = this->m_fPZ + this->m_fZ;
    v5 = this->m_fPY + this->m_fY;
    v4 = this->m_fPX + this->m_fX;
    (((gbMatrixStack *)v2))->gbMatrixStack::Translate(*v4,   v5,   v6);
    v3 = (((RenderTarget *)this->m_pEffect))->RenderTarget::RenderToTexture();
    if ( *((int *)&this->CTaskTpl_tagEffTaskParam_CEffgbParticle::__vftable + 6) <= 0 && v3 <= 0 )
      this->m_bIdle = 1;
    (((gbMatrixStack *)v2))->gbMatrixStack::Pop();
  }
}

// 0x004C8E80
int CEffgbParticle::GetEffect(int a2)
{
  int result; // eax

  result = (int)this->m_pEffect;
  *(_DWORD *)(result + 362768) = a2;
  return result;
}

// 0x004C8E90
int CEffgbParticle::RenderEffectPass(int a2)
{
  int result; // eax
  CTaskTpl_tagEffTaskParam_CEffgbParticle *v3; // ebx
  int v4; // ecx
  int v5; // edx
  int v6; // esi
  int v7; // ebp
  unsigned int v8; // eax
  int v9; // ecx
  int v10; // eax
  int v11; // edi
  _BYTE *v12; // esi
  int ( **v13)(CEffect *, int); // esi
  unsigned int v14; // eax
  int v15; // ecx
  int v16; // eax
  int v17; // edi
  _BYTE *v18; // esi
  int ( **v19)(CEffect *, int); // esi
  unsigned int v20; // eax

  v3 = ((CTaskTpl_tagEffTaskParam_CEffgbParticle *)this);
  v4 = *((_DWORD *)&this->CTaskTpl_tagEffTaskParam_CEffgbParticle::__vftable + 7);
  v5 = 0;
  if ( v4 > 0 )
  {
    v6 = *((_DWORD *)((void **)(v3)) + 3);
    result = v6 + 148;
    while ( *(_BYTE *)result )
    {
      ++v5;
      result += 152;
      if ( v5 >= v4 )
        return result;
    }
    v7 = 152 * v5;
    *(_DWORD *)(v6 + v7 + 12) = 2;
    *(_BYTE *)(*((_DWORD *)((void **)(v3)) + 3) + v7 + 148) = 1;
    *(_BYTE *)(*((_DWORD *)((void **)(v3)) + 3) + v7 + 149) = 1;
    v8 = ++*(&g_PAL3.m_nCEffCylinderCount + 1);
    if ( !*(&g_PAL3.m_nCEffCylinderCount + 1) || v8 >= 0x7FFFFFFF )
    {
      v8 = 1;
      *(&g_PAL3.m_nCEffCylinderCount + 1) = 1;
    }
    *(_DWORD *)(*((_DWORD *)((void **)(v3)) + 3) + v7 + 16) = v8;
    *(_DWORD *)(*((_DWORD *)((void **)(v3)) + 3) + v7 + 4) = 0;
    *(_DWORD *)(*((_DWORD *)((void **)(v3)) + 3) + v7 + 8) = 0;
    result = *((_DWORD *)((void **)(v3)) + 3);
    *(_DWORD *)(result + v7 + 20) = 0;
    if ( a2 )
    {
      qmemcpy((void *)(*((_DWORD *)((void **)(v3)) + 3) + v7 + 24), (const void *)a2, 0x7Cu);
    }
    else
    {
      result = 0;
      memset((void *)(*((_DWORD *)((void **)(v3)) + 3) + v7 + 24), 0, 0x7Cu);
    }
    ++*((_DWORD *)((void **)(v3)) + 6);
    if ( v5 != -1 )
    {
      v9 = *((_DWORD *)((void **)(v3)) + 8);
      v10 = 0;
      if ( v9 > 0 )
      {
        v11 = *(_DWORD *)(*((_DWORD *)((void **)(v3)) + 3) + 152 * v5);
        v12 = (_BYTE *)(v11 + 64);
        while ( *v12 )
        {
          ++v10;
          v12 += 72;
          if ( v10 >= v9 )
            goto LABEL_22;
        }
        v13 = (int ( **)(CEffect *, int))(v11 + 72 * v10);
        memset(v13, 0, 0x48u);
        *v13 = CEffect::SetParam;
        *((_BYTE *)v13 + 64) = 1;
        *((_BYTE *)v13 + 65) = 0;
        v13[1] = 0;
        v13[2] = (int ( *)(CEffect *, int))2;
        v14 = ++*(&g_PAL3.m_nCEffCylinderCount + 1);
        if ( !*(&g_PAL3.m_nCEffCylinderCount + 1) || v14 >= 0x7FFFFFFF )
        {
          v14 = 1;
          *(&g_PAL3.m_nCEffCylinderCount + 1) = 1;
        }
        v13[3] = (int ( *)(CEffect *, int))v14;
        v13[5] = 0;
        v13[4] = 0;
        v13[6] = 0;
        ++*(_DWORD *)(*((_DWORD *)((void **)(v3)) + 3) + v7 + 4);
      }
LABEL_22:
      v15 = *((_DWORD *)((void **)(v3)) + 8);
      v16 = 0;
      if ( v15 > 0 )
      {
        v17 = *(_DWORD *)(*((_DWORD *)((void **)(v3)) + 3) + 152 * v5);
        v18 = (_BYTE *)(v17 + 64);
        while ( *v18 )
        {
          ++v16;
          v18 += 72;
          if ( v16 >= v15 )
            goto LABEL_31;
        }
        v19 = (int ( **)(CEffect *, int))(v17 + 72 * v16);
        memset(v19, 0, 0x48u);
        *v19 = CEffect::SetParam;
        *((_BYTE *)v19 + 64) = 1;
        *((_BYTE *)v19 + 65) = 0;
        v19[1] = 0;
        v19[2] = (int ( *)(CEffect *, int))2;
        v20 = ++*(&g_PAL3.m_nCEffCylinderCount + 1);
        if ( !*(&g_PAL3.m_nCEffCylinderCount + 1) || v20 >= 0x7FFFFFFF )
        {
          v20 = 1;
          *(&g_PAL3.m_nCEffCylinderCount + 1) = 1;
        }
        v19[3] = (int ( *)(CEffect *, int))v20;
        v19[5] = 0;
        v19[4] = 0;
        v19[6] = 0;
        ++*(_DWORD *)(*((_DWORD *)((void **)(v3)) + 3) + v7 + 4);
      }
LABEL_31:
      sub_4C9320(v5, sub_4C90C0, 0, 0, *(_DWORD *)(a2 + 72), *(_DWORD *)(a2 + 76));
      *(_DWORD *)(*((_DWORD *)((void **)(v3)) + 3) + v7 + 12) = 3;
      *(_DWORD *)(*(_DWORD *)(*((_DWORD *)((void **)(v3)) + 3) + v7) + 8) = 3;
      result = *(_DWORD *)(*((_DWORD *)((void **)(v3)) + 3) + v7);
      *(_DWORD *)(result + 16) = *((_DWORD *)((void **)(v3)) + 1);
    }
  }
  return result;
}

// 0x004C9260
int CEffgbParticle::GetParticleType(int a2)
{
  int result; // eax

  switch ( a2 )
  {
    case 0:
      result = (int)&g_EffMgrData.m_nTodo_480;
      break;
    case 1:
      result = (int)&g_EffMgrData.m_nEffParam9;
      break;
    case 2:
      result = (int)&g_EffMgrData.m_nEffParam8;
      break;
    case 3:
      result = (int)&g_EffMgrData.m_nEffParam7;
      break;
    case 4:
      result = (int)&g_EffMgrData.m_nEffParam6;
      break;
    case 9:
      result = (int)(&g_EffMgrData.m_nEffTypeCode + 8);
      break;
    case 12:
      result = (int)&g_EffMgrData.m_nEffTypeCode;
      break;
    case 13:
      result = (int)&g_EffMgrData.m_nEffTypeID;
      break;
    case 14:
      result = (int)&g_EffMgrData.m_nEffParam1;
      break;
    case 15:
      result = (int)&g_EffMgrData.m_nEffParam0;
      break;
    case 20:
      result = (int)&g_pszEditorDesc;
      break;
    default:
      result = (int)g_EffCylinderEditorData;
      break;
  }
  return result;
}

// 0x004C9540
char * CEffgbParticle::DestroyEffect(char pData)
{
  char *p_m_fPX; // esi

  p_m_fPX = (char *)&this[-1].m_fPX;
  (((CEffgbParticle *)((char *)this - 12)))->CEffgbParticle::Destroy__fastcall();
  if ( (pData & 1) != 0 )
    operator delete(p_m_fPX);
  return p_m_fPX;
}

// 0x004CEB60
int CEffgbParticle::CreateInstance(
        
        CEffgbParticle *pSrc,
        int nVal,
        CEffgbParticle *pParam)
{
  int v4; // ebp
  _BYTE *i; // eax
  char *v7; // ebx
  const char *v8; // edi
  CEffgbParticle *v9; // eax
  int *v10; // eax

  v4 = 0;
  for ( i = &this[1].m_bIdle; *i; i += 72 )
  {
    if ( ++v4 >= 32 )
      return -1;
  }
  v7 = (char *)this + 72 * v4;
  strcpy(v7 + 28, (const char *)pSrc);
  v8 = (const char *)pParam;
  if ( !pParam )
    v8 = unk_C10D38;
  strcpy(v7 + 58, v8);
  v7[88] = 1;
  v9 = (CEffgbParticle *)operator new(0x50u);
  if ( v9 )
    v10 = (((CEffgbParticle *)v9))->CEffgbParticle::Render();
  else
    v10 = 0;
  *((_DWORD *)v7 + 24) = (unsigned long)v10;
  if ( (g_bEffSystemFlags & 1) == 0 )
  {
    g_bEffSystemFlags |= 1u;
    (((CEffMgr *)&g_pCEffMgrBackup))->CEffMgr::Reset();
    atexit(todo_401800);
  }
  *((_DWORD *)v7 + 23) = (unsigned long)(((CEffSParticle *)&g_pCEffMgrBackup))->CEffSParticle::GetEditorTaskDescription((int)pSrc);
  return v4;
}

// 0x004CFD40
int CEffgbParticle::_nearby_4cfd40(CEffgbParticle *a1)
{
  CTaskTpl_tagEffTaskParam_CEffgbParticle *v2; // edi
  CTaskTpl_tagEffTaskParam_CEffgbParticle *v3; // esi
  int result; // eax
  int v5; // ebx
  int v6; // edi

  v2 = ((CTaskTpl_tagEffTaskParam_CEffgbParticle *)a1);
  (((CEffgbParticle *)a1))->CEffgbParticle::DestroyEffect();
  v3 = a1 != 0 ? v2 : 0;
  result = *((_DWORD *)((void **)(v3)) + 7);
  if ( result || *(a1 != 0 ? ((void **)(v2)) + 8 : (void **)32) )
  {
    v5 = 0;
    if ( result > 0 )
    {
      v6 = 0;
      do
      {
        operator delete(*(void **)(*((_DWORD *)((void **)(v3)) + 3) + v6));
        ++v5;
        *(_DWORD *)(*((_DWORD *)((void **)(v3)) + 3) + v6) = 0;
        v6 += 152;
      }
      while ( v5 < *((_DWORD *)((void **)(v3)) + 7) );
    }
    operator delete(*(((void **)(v3)) + 3));
    result = 0;
    *((_DWORD *)((void **)(v3)) + 3) = 0;
    *((_DWORD *)((void **)(v3)) + 7) = 0;
    *((_DWORD *)((void **)(v3)) + 8) = 0;
  }
  return result;
}

// 0x004D0A60
void CEffgbParticle::DestroyEffect()
{
  ParticleEffect *m_pEffect; // ecx

  m_pEffect = (ParticleEffect *)this->m_pEffect;
  if ( m_pEffect )
  {
    (**(void ( ***)(ParticleEffect *, int))m_pEffect->name)(m_pEffect, 1);
    this->m_pEffect = 0;
  }
}
