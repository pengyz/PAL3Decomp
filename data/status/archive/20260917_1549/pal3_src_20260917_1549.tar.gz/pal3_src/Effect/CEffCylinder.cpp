#include "pal3/ida_defs.h"
#include "globals.h"
#include "pal3/pal3_constants.h"
#include "Effect/CEffCylinder.h"
#include "Combat/CCBStage.h"
#include "Effect/CEffMgr.h"
#include "Misc/CEffObj.h"
#include "Effect/CEffect.h"
#include "Effect/CEffgbParticle.h"
#include "Misc/CTaskTpl_tagEffTaskParam_CEffCylinder.h"
#include "GameBase/Logger.h"
#include "GameBase/PAL3.h"
#include "Misc/tagEffMgrData.h"
#include "Misc/tagEffObjType.h"
#include "Misc/tagEffTaskParam.h"
#include "free_functions.h"

// Forward declarations for unnamed functions
int sub_4C55F0(...);
int sub_4CAD10(...);
int sub_4CB000(...);
int sub_4CB0C0(...);
void __cdecl todo_401800(void);

// Unnamed globals (extern)
void __cdecl nullsub_76(void);
void __cdecl nullsub_77(void);
void __cdecl nullsub_78(void);

// 0x004AF760
int CEffCylinder::Update(int a2)
{
  int result; // eax

  return result;
}

// 0x004C15D0
void CEffCylinder::UpdateParticles()
{
  int v1; // ebp
  int v2; // esi
  int v3; // edi
  int v4; // eax
  _DWORD *v5; // edx

  v1 = 0;
  if ( *((int *)&this->CTaskTpl_tagEffTaskParam_CEffCylinder::__vftable + 7) > 0 )
  {
    v2 = 0;
    do
    {
      if ( *(_BYTE *)(*((_DWORD *)&this->CTaskTpl_tagEffTaskParam_CEffCylinder::__vftable + 3) + v2 + 148) )
      {
        v3 = 0;
        if ( *((int *)&this->CTaskTpl_tagEffTaskParam_CEffCylinder::__vftable + 8) > 0 )
        {
          v4 = 0;
          do
          {
            v5 = (_DWORD *)(v2 + *((_DWORD *)&this->CTaskTpl_tagEffTaskParam_CEffCylinder::__vftable + 3));
            if ( *(_BYTE *)(*v5 + v4 + 64) )
              *(_BYTE *)(*v5 + v4 + 66) = 1;
            ++v3;
            v4 += 72;
          }
          while ( v3 < *((_DWORD *)&this->CTaskTpl_tagEffTaskParam_CEffCylinder::__vftable + 8) );
        }
        *(_BYTE *)(*((_DWORD *)&this->CTaskTpl_tagEffTaskParam_CEffCylinder::__vftable + 3) + v2 + 149) = 1;
      }
      ++v1;
      v2 += 152;
    }
    while ( v1 < *((_DWORD *)&this->CTaskTpl_tagEffTaskParam_CEffCylinder::__vftable + 7) );
  }
}

// 0x004C3C90
CEffCylinder ** CEffCylinder::Init()
{
  CEffCylinder **result; // eax

  result = (CEffCylinder **)this;
  this->m_pEM = 0;
  this->m_bIdle = 0;
  *((_DWORD *)&this->CTaskTpl_tagEffTaskParam_CEffCylinder::__vftable + 1) = 0;
  *((_DWORD *)&this->CTaskTpl_tagEffTaskParam_CEffCylinder::__vftable + 2) = 0;
  *((_DWORD *)&this->CTaskTpl_tagEffTaskParam_CEffCylinder::__vftable + 3) = 0;
  *((_DWORD *)&this->CTaskTpl_tagEffTaskParam_CEffCylinder::__vftable + 4) = -1;
  *((_DWORD *)&this->CTaskTpl_tagEffTaskParam_CEffCylinder::__vftable + 5) = -1;
  *((_DWORD *)&this->CTaskTpl_tagEffTaskParam_CEffCylinder::__vftable + 6) = 0;
  *((_DWORD *)&this->CTaskTpl_tagEffTaskParam_CEffCylinder::__vftable + 7) = 0;
  *((_DWORD *)&this->CTaskTpl_tagEffTaskParam_CEffCylinder::__vftable + 8) = 0;
  this->m_vecRot.x = 0.0;
  this->m_vecRot.y = 0.0;
  this->m_vecRot.z = 0.0;
  this->m_vecPos.x = 0.0;
  this->m_vecPos.y = 0.0;
  this->m_vecPos.z = 0.0;
  this->m_vecOffsetPos.x = 0.0;
  this->m_vecOffsetPos.y = 0.0;
  this->m_vecOffsetPos.z = 0.0;
  this->m_fRotAngle = 360.0;
  this->m_fWide = 10.0;
  this->m_nDivision = 10;
  this->m_fTopShrink = 0.0;
  this->m_fBottomShrink = 0.0;
  this->m_fTopRadius = 50.0;
  this->m_fBottomRadius = 50.0;
  this->m_fTopRadiusIncSpeed = 0.0;
  this->m_fBottomRadiusIncSpeed = 0.0;
  this->m_fTopRiseSpeed = 0.0;
  this->m_fBottomRiseSpeed = 0.0;
  this->m_vecPos.z = 0.0;
  this->m_vecPos.y = 0.0;
  this->m_vecPos.x = 0.0;
  this->m_vecOffsetPos.z = 0.0;
  this->m_vecOffsetPos.y = 0.0;
  this->m_vecOffsetPos.x = 0.0;
  this->m_vecRot.z = 0.0;
  this->m_vecRot.y = 0.0;
  this->m_vecRot.x = 0.0;
  this->m_pGeomQuad = 0;
  this->m_bAdditiveBlend = 0;
  this->m_bNoZTest = 0;
  this->m_pTexture = 0;
  this->m_pTextureArray = 0;
  return result;
}

// 0x004C3D90
void CEffCylinder::AllocEffect()
{
  CEffCylinder *v1; // eax

  v1 = (CEffCylinder *)operator new(0x10C4u);
  if ( v1 )
    (((CEffCylinder *)v1))->CEffCylinder::Init();
}

// 0x004C3DD0
CEffCylinder::CEffCylinder()
{
  CTaskTpl_tagEffTaskParam_CEffCylinder *v2; // edi
  gbGeomQuad *m_pGeomQuad; // eax
  int v4; // ebx
  gbTexture *m_pTexture; // ecx
  CTaskTpl_tagEffTaskParam_CEffCylinder *v6; // esi
  int v7; // eax
  bool v8; // cc
  int v9; // edi

  v2 = ((CTaskTpl_tagEffTaskParam_CEffCylinder *)this);
  m_pGeomQuad = (gbGeomQuad *)this->m_pGeomQuad;
  v4 = 0;
  if ( m_pGeomQuad )
    operator delete(m_pGeomQuad);
  m_pTexture = (gbTexture *)this->m_pTexture;
  if ( m_pTexture )
    (((gbRefObject *)m_pTexture))->gbRefObject::Release();
  if ( this->m_pTextureArray )
    operator delete(this->m_pTextureArray);
  v6 = this != 0 ? v2 : 0;
  v7 = *((_DWORD *)((void **)(v6)) + 7);
  v8 = v7 <= 0;
  if ( !v7 )
  {
    if ( !*(this != 0 ? ((void **)(v2)) + 8 : (void **)32) )
      return;
    v8 = 1;
  }
  if ( !v8 )
  {
    v9 = 0;
    do
    {
      operator delete(*(void **)(*((_DWORD *)((void **)(v6)) + 3) + v9));
      ++v4;
      *(_DWORD *)(*((_DWORD *)((void **)(v6)) + 3) + v9) = 0;
      v9 += 152;
    }
    while ( v4 < *((_DWORD *)((void **)(v6)) + 7) );
  }
  operator delete(*(((void **)(v6)) + 3));
  *((_DWORD *)((void **)(v6)) + 3) = 0;
  *((_DWORD *)((void **)(v6)) + 7) = 0;
  *((_DWORD *)((void **)(v6)) + 8) = 0;
}

// 0x004C3EB0
CEffCylinder::~CEffCylinder()
{
  ;
}

// 0x004C3EC0
int CEffCylinder::Init(float *pType, float fx, float fy, float fz)
{
  int result; // eax
  int m_dwStartColor_low; // ecx
  float v8; // edx

  this->m_bIdle = 0;
  this->m_bVisible = 0;
  this->m_vecPos.x = fx + pType[46];
  this->m_vecPos.y = fy + pType[47];
  this->m_vecPos.z = fz + pType[48];
  this->m_vecRot.x = pType[54];
  this->m_vecRot.y = pType[49];
  this->m_vecRot.z = pType[55];
  this->m_vecOffsetPos.z = 0.0;
  this->m_vecOffsetPos.y = 0.0;
  this->m_vecOffsetPos.x = 0.0;
  this->m_dwStartColor = (unsigned int)pType[51];
  if ( (g_bEffSystemFlags & 1) == 0 )
  {
    g_bEffSystemFlags |= 1u;
    (((CEffMgr *)&g_pCEffMgrBackup))->CEffMgr::Reset();
    atexit(todo_401800);
  }
  this->m_fAlpha = (float)HIBYTE(this->m_dwStartColor);
  if ( (g_bEffSystemFlags & 1) == 0 )
  {
    g_bEffSystemFlags |= 1u;
    (((CEffMgr *)&g_pCEffMgrBackup))->CEffMgr::Reset();
    atexit(todo_401800);
  }
  this->m_fRed = (float)(unsigned __int8)BYTE2(this->m_dwStartColor);
  if ( (g_bEffSystemFlags & 1) == 0 )
  {
    g_bEffSystemFlags |= 1u;
    (((CEffMgr *)&g_pCEffMgrBackup))->CEffMgr::Reset();
    atexit(todo_401800);
  }
  result = (unsigned __int8)BYTE1(this->m_dwStartColor);
  this->m_fGreen = (float)result;
  LOBYTE(result) = g_bEffSystemFlags;
  if ( (g_bEffSystemFlags & 1) == 0 )
  {
    g_bEffSystemFlags |= 1u;
    (((CEffMgr *)&g_pCEffMgrBackup))->CEffMgr::Reset();
    result = atexit(todo_401800);
  }
  this->m_fCurTextureV = 0.0;
  m_dwStartColor_low = LOBYTE(this->m_dwStartColor);
  this->m_fCurFrame = 0.0;
  this->m_nLoops = 0;
  this->m_fBlue = (float)m_dwStartColor_low;
  v8 = pType[50];
  this->m_fHeight = 1.0;
  this->m_fSize = v8;
  return result;
}

// 0x004C4060
char CEffCylinder::Create(tagEffObjType *pType)
{
  void *v3; // eax
  int v4; // ebx
  int v5; // edi
  int v6; // edi
  int v7; // edx
  int v8; // eax
  int v9; // ecx
  gbGeomQuad *v11; // eax
  int v12; // ebx
  int v13; // edi
  char ArgList; // [esp+0xC] [ebp-0x810] BYREF
  _BYTE pExceptionObject[1024]; // [esp+0x40C] [ebp-0x410] BYREF
  void *Block; // [esp+0x80C] [ebp-0x10]
  int v18; // [esp+0x818] [ebp-0x4]
  int pTypea; // [esp+0x824] [ebp+0x8]

  v3 = (void *)operator new(0x4C0u);
  *((_DWORD *)&this->CTaskTpl_tagEffTaskParam_CEffCylinder::__vftable + 3) = (unsigned long)v3;
  if ( v3 )
  {
    v4 = 0;
    v5 = 0;
    while ( 1 )
    {
      *(_DWORD *)(v5 + *((_DWORD *)&this->CTaskTpl_tagEffTaskParam_CEffCylinder::__vftable + 3)) = (unsigned long)operator new(0x2D0u);
      if ( !*(_DWORD *)(v5 + *((_DWORD *)&this->CTaskTpl_tagEffTaskParam_CEffCylinder::__vftable + 3)) )
        break;
      v5 += 152;
      ++v4;
      if ( v5 >= 1216 )
      {
        v6 = 0;
        *((_DWORD *)&this->CTaskTpl_tagEffTaskParam_CEffCylinder::__vftable + 7) = 8;
        *((_DWORD *)&this->CTaskTpl_tagEffTaskParam_CEffCylinder::__vftable + 8) = 10;
        v7 = 0;
        do
        {
          *(_BYTE *)(v7 + *((_DWORD *)&this->CTaskTpl_tagEffTaskParam_CEffCylinder::__vftable + 3) + 148) = 0;
          v8 = 0;
          if ( *((int *)&this->CTaskTpl_tagEffTaskParam_CEffCylinder::__vftable + 8) > 0 )
          {
            v9 = 0;
            do
            {
              ++v8;
              v9 += 72;
              *(_BYTE *)(*(_DWORD *)(v7 + *((_DWORD *)&this->CTaskTpl_tagEffTaskParam_CEffCylinder::__vftable + 3))
                       + v9
                       - 8) = 0;
            }
            while ( v8 < *((_DWORD *)&this->CTaskTpl_tagEffTaskParam_CEffCylinder::__vftable + 8) );
          }
          ++v6;
          v7 += 152;
        }
        while ( v6 < *((_DWORD *)&this->CTaskTpl_tagEffTaskParam_CEffCylinder::__vftable + 7) );
        goto LABEL_10;
      }
    }
    if ( v4 > 0 && v4 - 1 >= 0 )
    {
      v13 = 152 * (v4 - 1);
      do
      {
        operator delete(*(void **)(v13 + *((_DWORD *)&this->CTaskTpl_tagEffTaskParam_CEffCylinder::__vftable + 3)));
        v13 -= 152;
        --v4;
      }
      while ( v4 );
    }
    operator delete(*(&this->CTaskTpl_tagEffTaskParam_CEffCylinder::__vftable + 3));
  }
LABEL_10:
  this->m_fRotAngle = pType->fSacleX;
  this->m_fWide = pType->fSacleY;
  if ( (g_bEffSystemFlags & 1) == 0 )
  {
    g_bEffSystemFlags |= 1u;
    (((CEffMgr *)&g_pCEffMgrBackup))->CEffMgr::Reset();
    atexit(todo_401800);
  }
  this->m_nDivision = (int)pType->fSacleZ;
  this->m_fTopShrink = pType->fTopShrink;
  this->m_fBottomShrink = pType->fBottomShrink;
  this->m_fTopRadius = pType->fTopRadius;
  this->m_fBottomRadius = pType->fBottomRadius;
  this->m_fTopRadiusIncSpeed = pType->fTopRadiusIncSpeed;
  this->m_fBottomRadiusIncSpeed = pType->fBottomRadiusIncSpeed;
  this->m_fTopRiseSpeed = pType->fTopRiseSpeed;
  this->m_fBottomRiseSpeed = pType->fBottomRiseSpeed;
  this->m_fTextureRepeat = pType->fTextureRepeat;
  this->m_fFramePerSec = pType->fFramePerSec;
  this->m_vecPos.x = pType->fX;
  this->m_vecPos.y = pType->fY;
  this->m_vecPos.z = pType->fZ;
  this->m_vecRot.x = pType->fStartXRot;
  this->m_vecRot.y = pType->fStartYRot;
  this->m_vecRot.z = pType->fStartZRot;
  this->m_bAdditiveBlend = pType->bAdditiveBlend;
  this->m_bNoZTest = pType->bNoZTest;
  this->m_byMaxFrame = pType->nFrame;
  this->m_nRequireLoops = (int)&byte_FFFFFF;
  this->m_dwStartColor = pType->dwColor;
  this->CEffCylinder::InitDefaultUVSet(pType->nFramePerRow, pType->nFramePerCol);
  pTypea = this->m_nDivision;
  v11 = (gbGeomQuad *)operator new(68 * pTypea);
  Block = (void *)v11;
  v18 = 0;
  if ( v11 )
  {
    v12 = (int)v11;
    if ( pTypea - 1 >= 0 )
    {
      do
      {
        v12 += 68;
        --pTypea;
      }
      while ( pTypea );
      v11 = (gbGeomQuad *)Block;
    }
  }
  else
  {
    v11 = 0;
  }
  v18 = -1;
  this->m_pGeomQuad = v11;
  if ( !v11 )
  {
    qmemcpy(
      pExceptionObject,
      (((Logger *)&ArgList))->Logger::FormatException((char *)&g_EffMgrData.m_nEffParam_1CC + 12, (char *)&g_EffMgrData.m_nEffParam_1CC + 48, 127),
      sizeof(pExceptionObject));
    _CxxThrowException(pExceptionObject, (_ThrowInfo *)&_TI1_AV_Exception__);
  }
  this->CEffCylinder::LoadTexture(pType->szTexture);
  /* [MISATTRIBUTED] CEffMgr on CEffCylinder::this -> fix IDB name of callee */ CEffMgr::UpdateParticlePositions((CEffMgr *)this);
  return 1;
}

// 0x004C4370
void CEffCylinder::Destroy()
{
  char m_bAdditiveBlend; // al
  bool v3; // zf
  CEffMgr *m_pEM; // eax
  gbRenderEffect *m_pAlphaBlendNoZ; // ebp
  gbMatrixStack *v6; // edi
  float v7; // [esp+0x3C] [ebp-0xC]
  float retaddr; // [esp+0x48] [ebp+0x0] BYREF

  if ( (g_PAL3.m_bCEffCylFlag & 1) == 0 )
  {
    *(&g_PAL3.m_nCEffExplosiveCount + 10) = 1065353216;
    g_PAL3.m_bCEffCylFlag |= 1u;
    *(&g_PAL3.m_nCEffExplosiveCount + 11) = 0;
    *(&g_PAL3.m_nCEffExplosiveCount + 12) = 0;
    atexit(nullsub_78);
  }
  if ( (g_PAL3.m_bCEffCylFlag & 2) == 0 )
  {
    *(&g_PAL3.m_nCEffExplosiveCount + 6) = 0;
    g_PAL3.m_bCEffCylFlag |= 2u;
    *(&g_PAL3.m_nCEffExplosiveCount + 7) = 1065353216;
    *(&g_PAL3.m_nCEffExplosiveCount + 8) = 0;
    atexit(nullsub_77);
  }
  if ( (g_PAL3.m_bCEffCylFlag & 4) == 0 )
  {
    *(&g_PAL3.m_nCEffExplosiveCount + 2) = 0;
    g_PAL3.m_bCEffCylFlag |= 4u;
    *(&g_PAL3.m_nCEffExplosiveCount + 3) = 0;
    *(&g_PAL3.m_nCEffExplosiveCount + 4) = 1065353216;
    atexit(nullsub_76);
  }
  if ( !this->m_bIdle && this->m_bVisible )
  {
    (((gbVertPoolMgr *)this->m_pEM->m_pDisplay->pVertPoolMgr))->gbVertPoolMgr::GetDynVertBuf(0x15u);
    m_bAdditiveBlend = this->m_bAdditiveBlend;
    if ( this->m_bNoZTest )
    {
      v3 = m_bAdditiveBlend == 0;
      m_pEM = this->m_pEM;
      if ( v3 )
        m_pAlphaBlendNoZ = (gbRenderEffect *)m_pEM->m_pAlphaBlendNoZ;
      else
        m_pAlphaBlendNoZ = (gbRenderEffect *)m_pEM->m_pAdditiveBlendNoZ;
    }
    else
    {
      v3 = m_bAdditiveBlend == 0;
      m_pEM = this->m_pEM;
      if ( v3 )
        m_pAlphaBlendNoZ = (gbRenderEffect *)m_pEM->m_pAlphaBlend;
      else
        m_pAlphaBlendNoZ = (gbRenderEffect *)m_pEM->m_pAdditiveBlend;
    }
    v6 = (gbMatrixStack *)m_pEM->m_pDisplay->pMatrixStack[1];
    (((gbMatrixStack *)v6))->gbMatrixStack::Push();
    v7 = this->m_vecOffsetPos.x + this->m_vecPos.x;
    retaddr = v7;
    (((gbMatrixStack *)v6))->gbMatrixStack::Translate(*(gbVec3D *)&retaddr);
    (((gbMatrixStack *)v6))->gbMatrixStack::Rotate(this->m_vecRot.x, * (gbVec3D *)(&g_PAL3.m_nCEffExplosiveCount + 10));
    (((gbMatrixStack *)v6))->gbMatrixStack::Rotate(this->m_vecRot.y, * (gbVec3D *)&g_PAL3.m_nCEffExplosiveCount + 2);
    (((gbMatrixStack *)v6))->gbMatrixStack::Rotate(this->m_vecRot.z, * (gbVec3D *)(&g_PAL3.m_nCEffExplosiveCount + 2));
    (((gbMatrixStack *)v6))->gbMatrixStack::Scale(this->m_fSize,   this->m_fHeight,   this->m_fSize);
    (((gbDynVertBuf *)this->m_pGeomQuad))->gbDynVertBuf::RenderGeomQuadViaStrip(this->m_nDivision, m_pAlphaBlendNoZ, this->m_pTextureArray, this->m_dwStartColor);
    (((gbMatrixStack *)v6))->gbMatrixStack::Pop();
  }
}

// 0x004C45A0

// ---- synthesized vtable stubs (unresolved slots) ----
// [VFTABLE-STUB] original: (*((void ( **)(CTaskTpl_tagEffTaskParam_CEffCylinder *, _DWORD, _DWORD, _DWORD))v4->__vftable + 1))( v4, *(_DWORD *)(*(_DWORD *)v5 + v7), *(_DWORD *)(*(_DWORD *)v5 + v7 + 4), 0)
static void pal3_vtbl_unk_0(CTaskTpl_tagEffTaskParam_CEffCylinder *, _DWORD, _DWORD, _DWORD);

void CEffCylinder::CreateTask(float p)
{
  CEffCylinder *v2; // edi
  double v3; // st7
  CTaskTpl_tagEffTaskParam_CEffCylinder *v4; // esi
  int v5; // ebx
  int v6; // edx
  int v7; // edi
  int v8; // ecx
  int v9; // eax
  int v10; // edx
  bool v11; // cc
  int v12; // eax
  int v13; // edx
  float *v14; // eax
  double v15; // st7
  int v16; // ecx
  double v17; // st7
  int v18; // eax
  float v20; // [esp+0x4] [ebp-0xC]
  float v21; // [esp+0x4] [ebp-0xC]
  int v22; // [esp+0x8] [ebp-0x8]
  float v23; // [esp+0x8] [ebp-0x8]
  int v24; // [esp+0xC] [ebp-0x4]
  float v25; // [esp+0xC] [ebp-0x4]
  int pa; // [esp+0x18] [ebp+0x8]
  float pb; // [esp+0x18] [ebp+0x8]
v3 = p - *((float *)&this->CTaskTpl_tagEffTaskParam_CEffCylinder::__vftable + 1);
  v4 = ((CTaskTpl_tagEffTaskParam_CEffCylinder *)this);
  *((float *)&this->CTaskTpl_tagEffTaskParam_CEffCylinder::__vftable + 1) = p;
  *((float *)&this->CTaskTpl_tagEffTaskParam_CEffCylinder::__vftable + 2) = v3;
  if ( *((float *)&this->CTaskTpl_tagEffTaskParam_CEffCylinder::__vftable + 2) > 0.0 )
  {
    pa = 0;
    if ( *((int *)&this->CTaskTpl_tagEffTaskParam_CEffCylinder::__vftable + 7) > 0 )
    {
      v24 = 0;
      while ( 1 )
      {
        v5 = v24 + *((_DWORD *)((void **)(v4)) + 3);
        if ( *(_BYTE *)(v5 + 148) )
        {
          if ( *(_DWORD *)(v5 + 12) == 3 )
          {
            v6 = 0;
            v22 = 0;
            if ( *((int *)((void **)(v4)) + 8) > 0 )
              break;
          }
        }
LABEL_29:
        v11 = ++pa < *((_DWORD *)((void **)(v4)) + 7);
        v24 += 152;
        if ( !v11 )
          goto LABEL_30;
      }
      v7 = 0;
      while ( 1 )
      {
        v8 = *(_DWORD *)v5 + v7;
        if ( !*(_BYTE *)(v8 + 64) || v7 > 0 && *(_DWORD *)(v8 - 64) == 2 )
        {
LABEL_28:
goto LABEL_29;
        }
        switch ( *(_DWORD *)(v8 + 8) )
        {
          case 2:
            if ( v7 > 0 )
            {
              if ( *(float *)(v8 + 20) >= 0.0 )
              {
                if ( *((float *)((void **)(v4)) + 1) - *(float *)(v8 - 56) > *(float *)(v8 + 20) )
                {
                  (((CCBStage *)v4))->CCBStage::GetTaskParam(pa, v6);
                  *((_DWORD *)((void **)(v4)) + 4) = pa;
                  *((_DWORD *)((void **)(v4)) + 5) = v22;
                  goto LABEL_24;
                }
              }
              else if ( *(_DWORD *)(v8 - 64) == 4 )
              {
                *(_DWORD *)(*(_DWORD *)(v24 + *((_DWORD *)((void **)(v4)) + 3)) + v7 + 8) = 3;
                *(_DWORD *)(*(_DWORD *)(v24 + *((_DWORD *)((void **)(v4)) + 3)) + v7 + 16) = *((_DWORD *)((void **)(v4))
                                                                                            + 1);
LABEL_21:
                *((_DWORD *)((void **)(v4)) + 5) = v6;
                *((_DWORD *)((void **)(v4)) + 4) = pa;
LABEL_24:
                pal3_vtbl_unk_0(v4, *(_DWORD *)(*(_DWORD *)v5 + v7), *(_DWORD *)(*(_DWORD *)v5 + v7 + 4), 0) /* [VFTABLE-STUB] */;
              }
            }
            break;
          case 3:
            goto LABEL_21;
          case 4:
            if ( (((CCBStage *)v4))->CCBStage::SetTaskState(pa) )
            {
              v9 = *(_DWORD *)(v5 + 4);
              *(_DWORD *)(v5 + 12) = 4;
              v10 = 9 * v9;
              LOBYTE(v9) = *(_BYTE *)(v5 + 149);
              *(_DWORD *)(v5 + 20) = *(_DWORD *)(*(_DWORD *)v5 + 8 * v10 - 12);
              if ( (_BYTE)v9 == 1 )
              {
                (((CEffgbParticle *)v4))->CEffgbParticle::Init(pa);
                goto LABEL_28;
              }
            }
            break;
        }
        v6 = v22 + 1;
        v7 += 72;
        if ( ++v22 >= *((_DWORD *)((void **)(v4)) + 8) )
          goto LABEL_28;
      }
    }
LABEL_30:
    if ( *((int *)&this->CTaskTpl_tagEffTaskParam_CEffCylinder::__vftable + 6) <= 0 )
      this->m_bIdle = 1;
    if ( !this->m_bIdle && (this->m_fFramePerSec != 0.0 && this->m_byMaxFrame != 1 || this->m_fCurTextureV != 0.0) )
    {
      v20 = this->m_fTextureRepeat / (double)this->m_nDivision;
      this->m_fCurFrame = this->m_fFramePerSec * *((float *)&this->CTaskTpl_tagEffTaskParam_CEffCylinder::__vftable + 2)
                      + this->m_fCurFrame;
      if ( (g_bEffSystemFlags & 1) == 0 )
      {
        g_bEffSystemFlags |= 1u;
        (((CEffMgr *)&g_pCEffMgrBackup))->CEffMgr::Reset();
        atexit(todo_401800);
      }
      v12 = (int)abs32((int)this->m_fCurFrame) % (unsigned __int8)this->m_byMaxFrame;
      v13 = v12 + 13;
      v14 = (float *)((char *)v2 + 16 * v12);
      v25 = v14[49];
      v21 = (v14[51] - v25) * v20;
      pb = v14[50] + this->m_fCurTextureV;
      v23 = *((float *)&this->CEffObj::__vftable + 4 * v13) + this->m_fCurTextureV;
      if ( (g_bEffSystemFlags & 1) == 0 )
      {
        g_bEffSystemFlags |= 1u;
        (((CEffMgr *)&g_pCEffMgrBackup))->CEffMgr::Reset();
        atexit(todo_401800);
      }
      v15 = (double)(int)pb;
      if ( v15 > 1.0 )
      {
        pb = pb - v15;
        v23 = v23 - v15;
      }
      v16 = 0;
      if ( this->m_nDivision > 0 )
      {
        v17 = v25;
        v18 = 0;
        do
        {
          ++v16;
          this->m_pGeomQuad[v18].su = v17;
          v17 = v17 + v21;
          this->m_pGeomQuad[v18++].eu = v17;
          this->m_pGeomQuad[v18 - 1].sv = pb;
          this->m_pGeomQuad[v18 - 1].ev = v23;
        }
        while ( v16 < this->m_nDivision );
      }
    }
  }
}

static void pal3_vtbl_unk_0(CTaskTpl_tagEffTaskParam_CEffCylinder *, _DWORD, _DWORD, _DWORD)
{
    
}


// 0x004C48D0
void CEffCylinder::ProcInitTask(int *dwParam)
{
  CTaskTpl_tagEffTaskParam_CEffCylinder *v2; // ebx
  int v3; // ecx
  int v4; // edx
  int v5; // esi
  _BYTE *i; // eax
  int v7; // ebp
  unsigned int v8; // eax
  int v9; // ecx
  int v10; // eax
  int v11; // edi
  _BYTE *v12; // esi
  int ( **v13)(CEffect *, int); // esi
  unsigned int v14; // eax
  int v15; // ecx
  int v16; // eax
  int v17; // edi
  _BYTE *v18; // esi
  int ( **v19)(CEffect *, int); // esi
  unsigned int v20; // eax

  v2 = ((CTaskTpl_tagEffTaskParam_CEffCylinder *)this);
  v3 = *((_DWORD *)&this->CTaskTpl_tagEffTaskParam_CEffCylinder::__vftable + 7);
  v4 = 0;
  if ( v3 > 0 )
  {
    v5 = *((_DWORD *)((void **)(v2)) + 3);
    for ( i = (_BYTE *)(v5 + 148); *i; i += 152 )
    {
      if ( ++v4 >= v3 )
        return;
    }
    v7 = 152 * v4;
    *(_DWORD *)(v5 + v7 + 12) = 2;
    *(_BYTE *)(*((_DWORD *)((void **)(v2)) + 3) + v7 + 148) = 1;
    *(_BYTE *)(*((_DWORD *)((void **)(v2)) + 3) + v7 + 149) = 1;
    v8 = ++g_PAL3.m_nScriptCallbackCount;
    if ( !g_PAL3.m_nScriptCallbackCount || v8 >= 0x7FFFFFFF )
    {
      v8 = 1;
      g_PAL3.m_nScriptCallbackCount = 1;
    }
    *(_DWORD *)(*((_DWORD *)((void **)(v2)) + 3) + v7 + 16) = v8;
    *(_DWORD *)(*((_DWORD *)((void **)(v2)) + 3) + v7 + 4) = 0;
    *(_DWORD *)(*((_DWORD *)((void **)(v2)) + 3) + v7 + 8) = 0;
    *(_DWORD *)(*((_DWORD *)((void **)(v2)) + 3) + v7 + 20) = 0;
    if ( dwParam )
      qmemcpy((void *)(*((_DWORD *)((void **)(v2)) + 3) + v7 + 24), dwParam, 0x7Cu);
    else
      memset((void *)(*((_DWORD *)((void **)(v2)) + 3) + v7 + 24), 0, 0x7Cu);
    ++*((_DWORD *)((void **)(v2)) + 6);
    if ( v4 != -1 )
    {
      v9 = *((_DWORD *)((void **)(v2)) + 8);
      v10 = 0;
      if ( v9 > 0 )
      {
        v11 = *(_DWORD *)(*((_DWORD *)((void **)(v2)) + 3) + 152 * v4);
        v12 = (_BYTE *)(v11 + 64);
        while ( *v12 )
        {
          ++v10;
          v12 += 72;
          if ( v10 >= v9 )
            goto LABEL_22;
        }
        v13 = (int ( **)(CEffect *, int))(v11 + 72 * v10);
        memset(v13, 0, 0x48u);
        *v13 = CEffect::SetParam;
        *((_BYTE *)v13 + 64) = 1;
        *((_BYTE *)v13 + 65) = 0;
        v13[1] = 0;
        v13[2] = (int ( *)(CEffect *, int))2;
        v14 = ++g_PAL3.m_nScriptCallbackCount;
        if ( !g_PAL3.m_nScriptCallbackCount || v14 >= 0x7FFFFFFF )
        {
          v14 = 1;
          g_PAL3.m_nScriptCallbackCount = 1;
        }
        v13[3] = (int ( *)(CEffect *, int))v14;
        v13[5] = 0;
        v13[4] = 0;
        v13[6] = 0;
        ++*(_DWORD *)(*((_DWORD *)((void **)(v2)) + 3) + v7 + 4);
      }
LABEL_22:
      v15 = *((_DWORD *)((void **)(v2)) + 8);
      v16 = 0;
      if ( v15 > 0 )
      {
        v17 = *(_DWORD *)(*((_DWORD *)((void **)(v2)) + 3) + 152 * v4);
        v18 = (_BYTE *)(v17 + 64);
        while ( *v18 )
        {
          ++v16;
          v18 += 72;
          if ( v16 >= v15 )
            goto LABEL_31;
        }
        v19 = (int ( **)(CEffect *, int))(v17 + 72 * v16);
        memset(v19, 0, 0x48u);
        *v19 = CEffect::SetParam;
        *((_BYTE *)v19 + 64) = 1;
        *((_BYTE *)v19 + 65) = 0;
        v19[1] = 0;
        v19[2] = (int ( *)(CEffect *, int))2;
        v20 = ++g_PAL3.m_nScriptCallbackCount;
        if ( !g_PAL3.m_nScriptCallbackCount || v20 >= 0x7FFFFFFF )
        {
          v20 = 1;
          g_PAL3.m_nScriptCallbackCount = 1;
        }
        v19[3] = (int ( *)(CEffect *, int))v20;
        v19[5] = 0;
        v19[4] = 0;
        v19[6] = 0;
        ++*(_DWORD *)(*((_DWORD *)((void **)(v2)) + 3) + v7 + 4);
      }
LABEL_31:
      sub_4C55F0(v4, sub_4C4B00, 0, 0, dwParam[18], dwParam[19]);
      *(_DWORD *)(*((_DWORD *)((void **)(v2)) + 3) + v7 + 12) = 3;
      *(_DWORD *)(*(_DWORD *)(*((_DWORD *)((void **)(v2)) + 3) + v7) + 8) = 3;
      *(_DWORD *)(*(_DWORD *)(*((_DWORD *)((void **)(v2)) + 3) + v7) + 16) = *((_DWORD *)((void **)(v2)) + 1);
    }
  }
}

// 0x004C5010
const char * CEffCylinder::GetEditorTaskDescription(int nIndex)
{
  const char *result; // eax

  switch ( nIndex )
  {
    case 0:
      result = (const char *)&g_EffMgrData.m_nEffParam_02A4;
      break;
    case 1:
      result = (const char *)&g_EffMgrData.m_nEffParam9;
      break;
    case 2:
      result = (const char *)&g_EffMgrData.m_nEffParam8;
      break;
    case 3:
      result = (const char *)&g_EffMgrData.m_nEffParam7;
      break;
    case 4:
      result = (const char *)&g_EffMgrData.m_nEffParam6;
      break;
    case 5:
      result = (const char *)&g_EffMgrData.m_nEffParam_029C;
      break;
    case 6:
      result = (const char *)&g_EffMgrData.m_nEffParam_0294;
      break;
    case 7:
      result = (const char *)&g_EffMgrData.m_nEffParam_028C;
      break;
    case 8:
      result = (const char *)&g_EffMgrData.m_nEffParam2;
      break;
    case 9:
      result = (const char *)(&g_EffMgrData.m_nEffTypeCode + 8);
      break;
    case 10:
      result = (const char *)&g_EffMgrData.m_nEffParam_0280;
      break;
    case 11:
      result = (const char *)&g_EffMgrData.m_nEffParam_0274;
      break;
    case 12:
      result = (const char *)&g_EffMgrData.m_nEffTypeCode;
      break;
    case 13:
      result = (const char *)&g_EffMgrData.m_nEffTypeID;
      break;
    case 14:
      result = (const char *)&g_EffMgrData.m_nEffParam1;
      break;
    case 15:
      result = (const char *)&g_EffMgrData.m_nEffParam0;
      break;
    case 16:
      result = (const char *)&g_EffMgrData;
      break;
    case 17:
      result = (const char *)&g_EffMgrData.m_nEffParam_0268;
      break;
    case 18:
      result = (const char *)&g_EffMgrData.m_nEffParam_025C;
      break;
    case 19:
      result = (const char *)&g_EffMgrData.m_nEffParam_0250;
      break;
    case 20:
      result = (const char *)&g_pszEditorDesc;
      break;
    case 21:
      result = (const char *)&g_EffMgrData.m_nEffParam_244;
      break;
    case 22:
      result = (const char *)&g_EffMgrData.m_nEffParam_234;
      break;
    case 23:
      result = (const char *)&g_EffMgrData.m_nEffParam_224;
      break;
    default:
      result = g_EffCylinderEditorData;
      break;
  }
  return result;
}

// 0x004C5150
const char * CEffCylinder::GetEditorObjDescription(int nIndex)
{
  const char *result; // eax

  switch ( nIndex )
  {
    case 0:
      result = (const char *)&g_EffMgrData.m_nEffParam_0338;
      break;
    case 1:
      result = (const char *)&g_EffMgrData.m_nTodo_32C;
      break;
    case 2:
      result = (const char *)&g_EffMgrData.m_nTodo_320;
      break;
    case 3:
      result = (const char *)&g_EffMgrData.m_nTodo_314;
      break;
    case 4:
      result = (const char *)&g_EffMgrData.m_nTodo_30C;
      break;
    case 5:
      result = (const char *)&g_EffMgrData.m_nTodo_304;
      break;
    case 6:
      result = (const char *)&g_EffMgrData.m_nTodo_2F8;
      break;
    case 7:
      result = (const char *)&g_EffMgrData.m_nTodo_2EC;
      break;
    case 8:
      result = (const char *)&g_EffMgrData.m_nGameState_02E0;
      break;
    case 9:
      result = (const char *)&g_EffMgrData.m_nTodo_2D4;
      break;
    case 10:
      result = (const char *)&g_EffMgrData.m_nEffParam_02C8;
      break;
    case 11:
      result = (const char *)&g_EffMgrData.m_nEffParam_02BC;
      break;
    case 12:
      result = (const char *)&g_EffMgrData.m_nEffParam_02B0;
      break;
    default:
      result = g_EffCylinderEditorData;
      break;
  }
  return result;
}

// 0x004C5210
void CEffCylinder::InitDefaultUVSet(int nFramePerRow, int nFramePerCol)
{
  int v3; // ebx
  float *p_eu; // edi
  int v5; // ecx
  double v6; // st7
  float *v7; // eax
  double v8; // st5
  double v9; // st5
  double v10; // st3
  double v11; // st3
  int v12; // [esp+0x8] [ebp-0x8]
  float v13; // [esp+0x8] [ebp-0x8]
  int v14; // [esp+0xC] [ebp-0x4]

  v3 = 0;
  v12 = 0;
  if ( nFramePerCol > 0 )
  {
    p_eu = (float *)&this->m_DefaultUVSet[0].eu;
    do
    {
      v5 = 0;
      v14 = 0;
      if ( nFramePerRow > 0 )
      {
        v6 = (double)nFramePerRow;
        v7 = (float *)p_eu;
        p_eu += 4 * nFramePerRow;
        v8 = (double)nFramePerCol;
        v13 = (double)v12 / v8;
        v9 = 1.0 - (1.0 / v8 + v13);
        do
        {
          v10 = (double)v14;
          v7 += 4;
          v14 = ++v5;
          v11 = v10 / v6;
          *(v7 - 6) = v11;
          *(v7 - 4) = 1.0 / v6 + v11;
          *(v7 - 5) = v9;
          *(v7 - 3) = 1.0 - v13;
        }
        while ( v5 < nFramePerRow );
      }
      v12 = ++v3;
    }
    while ( v3 < nFramePerCol );
  }
}

// 0x004C52C0
int * CEffCylinder::LoadTexture(char *pFileName)
{
  gbTexture *v3; // eax
  int *result; // eax
  gbTexture *m_pTexture; // ecx
  char pExceptionObject[1024]; // [esp+0x8] [ebp-0x800] BYREF
  char ArgList; // [esp+0x408] [ebp-0x400] BYREF

  v3 = (gbTexture *)(*((int ( **)(gbGfxManager *, char *))this->m_pEM->m_pDisplay->CEffObj::__vftable + 2))(
                      this->m_pEM->m_pDisplay,
                      pFileName);
  this->m_pTexture = v3;
  (((gbTexture *)v3))->gbTexture::LoadTexture(1);
  result = (int *)operator new(0x44u);
  if ( result )
  {
    m_pTexture = (gbTexture *)this->m_pTexture;
    result[16] = 1;
    *result = (int)m_pTexture;
  }
  else
  {
    result = 0;
  }
  this->m_pTextureArray = (gbTextureArray *)result;
  if ( !result )
  {
    qmemcpy(
      pExceptionObject,
      (((Logger *)&ArgList))->Logger::FormatException((char *)&g_EffMgrData.m_nEffParam_0338 + 16, (char *)&g_EffMgrData.m_nEffParam_1CC + 48, 504),
      sizeof(pExceptionObject));
    _CxxThrowException(pExceptionObject, (_ThrowInfo *)&_TI1_AV_Exception__);
  }
  return result;
}

// 0x004CA450
int CEffCylinder::UpdateGeometry(int nVal)
{
  double v3; // st7
  int v4; // esi
  int v5; // ecx
  double v6; // st7
  int v7; // edi
  double m_fGreen; // st7
  double m_fBlue; // st7
  double m_fSize; // st7
  double m_fHeight; // st7
  unsigned __int16 v12; // cx
  int v13; // eax
  double v14; // st7
  gbTexture *m_pTexture; // esi
  gbTextureArray *m_pTextureArray; // edi
  float v18; // [esp+0x0] [ebp-0x84]
  float v19; // [esp+0x14] [ebp-0x70]
  float v20; // [esp+0x18] [ebp-0x6C]
  float v21; // [esp+0x1C] [ebp-0x68]
  float v22; // [esp+0x20] [ebp-0x64]
  float v23; // [esp+0x24] [ebp-0x60]
  int v24; // [esp+0x28] [ebp-0x5C]
  gbVec3D v25; // [esp+0x2C] [ebp-0x58] BYREF
  struct gbVec3D v26; // [esp+0x38] [ebp-0x4C] BYREF
  gbMatrix4 v27; // [esp+0x44] [ebp-0x40] BYREF

  v3 = *((float *)&this->CTaskTpl_tagEffTaskParam_CEffCylinder::__vftable + 1);
  v4 = *((_DWORD *)&this->CTaskTpl_tagEffTaskParam_CEffCylinder::__vftable + 3)
     + 152 * *((_DWORD *)&this->CTaskTpl_tagEffTaskParam_CEffCylinder::__vftable + 4);
  v5 = 9 * *((_DWORD *)&this->CTaskTpl_tagEffTaskParam_CEffCylinder::__vftable + 5);
  v6 = v3 - *(float *)(*(_DWORD *)v4 + 8 * v5 + 16);
  v7 = *(_DWORD *)v4 + 8 * v5;
  v19 = *((float *)&this->CTaskTpl_tagEffTaskParam_CEffCylinder::__vftable + 2);
  v24 = v7;
  if ( v6 > *(float *)(v7 + 24) )
    v19 = v19 - (v6 - *(float *)(v7 + 24));
  if ( !*(_BYTE *)(v7 + 65) )
  {
    LOBYTE(this->m_nLoops) = 1;
    *(_BYTE *)(v7 + 65) = 1;
  }
  this->m_fTextureRepeat = v19 * *(float *)(v4 + 64) + this->m_fTextureRepeat;
  this->m_fFramePerSec = v19 * *(float *)(v4 + 68) + this->m_fFramePerSec;
  this->m_fCurTextureV = v19 * *(float *)(v4 + 72) + this->m_fCurTextureV;
  this->m_vecRot.x = v19 * *(float *)(v4 + 28) + this->m_vecRot.x;
  this->m_vecRot.y = v19 * *(float *)(v4 + 32) + this->m_vecRot.y;
  this->m_vecRot.z = v19 * *(float *)(v4 + 36) + this->m_vecRot.z;
  memset(&v25, 0, sizeof(v25));
  memset(&v26, 0, sizeof(v26));
  (((gbMatrix4 *)&v27))->gbMatrix4::LoadIdentity();
  v25 = *(gbVec3D *)(v4 + 44);
  (((gbVec3D *)&v25))->gbVec3D::Normalize();
  v18 = (*((float *)&this->CTaskTpl_tagEffTaskParam_CEffCylinder::__vftable + 1) - *(float *)(v7 + 16))
      * *(float *)(v4 + 60);
  gbMatrix4::SetAxisAngle(v27,  &v25,  v18);
  v26.z = *(float *)(v4 + 56);
  v26.x = 0.0;
  v26.y = 0.0;
  gbMatrix4::Rotate(&v27,  *v26,   &this->m_vecPos);
  if ( *(float *)(v4 + 80) != 0.0
    || *(float *)(v4 + 84) != 0.0
    || *(float *)(v4 + 92) != 0.0
    || *(float *)(v4 + 88) != 0.0 )
  {
    this->m_fGreen = v19 * *(float *)(v4 + 80) + this->m_fGreen;
    this->m_fBlue = v19 * *(float *)(v4 + 84) + this->m_fBlue;
    this->m_fSize = v19 * *(float *)(v4 + 88) + this->m_fSize;
    this->m_fHeight = v19 * *(float *)(v4 + 92) + this->m_fHeight;
    if ( (g_bEffSystemFlags & 1) == 0 )
    {
      g_bEffSystemFlags |= 1u;
      (((CEffMgr *)&g_pCEffMgrBackup))->CEffMgr::Reset();
      atexit(todo_401800);
    }
    if ( this->m_fGreen <= 255.0 )
    {
      if ( this->m_fGreen >= 0.0 )
        m_fGreen = this->m_fGreen;
      else
        m_fGreen = 0.0;
    }
    else
    {
      m_fGreen = 255.0;
    }
    this->m_fGreen = m_fGreen;
    if ( (g_bEffSystemFlags & 1) == 0 )
    {
      g_bEffSystemFlags |= 1u;
      (((CEffMgr *)&g_pCEffMgrBackup))->CEffMgr::Reset();
      atexit(todo_401800);
    }
    if ( this->m_fBlue <= 255.0 )
    {
      if ( this->m_fBlue >= 0.0 )
        m_fBlue = this->m_fBlue;
      else
        m_fBlue = 0.0;
    }
    else
    {
      m_fBlue = 255.0;
    }
    this->m_fBlue = m_fBlue;
    if ( (g_bEffSystemFlags & 1) == 0 )
    {
      g_bEffSystemFlags |= 1u;
      (((CEffMgr *)&g_pCEffMgrBackup))->CEffMgr::Reset();
      atexit(todo_401800);
    }
    if ( this->m_fSize <= 255.0 )
    {
      if ( this->m_fSize >= 0.0 )
        m_fSize = this->m_fSize;
      else
        m_fSize = 0.0;
    }
    else
    {
      m_fSize = 255.0;
    }
    this->m_fSize = m_fSize;
    if ( (g_bEffSystemFlags & 1) == 0 )
    {
      g_bEffSystemFlags |= 1u;
      (((CEffMgr *)&g_pCEffMgrBackup))->CEffMgr::Reset();
      atexit(todo_401800);
    }
    if ( this->m_fHeight <= 255.0 )
    {
      if ( this->m_fHeight >= 0.0 )
        m_fHeight = this->m_fHeight;
      else
        m_fHeight = 0.0;
    }
    else
    {
      m_fHeight = 255.0;
    }
    this->m_fHeight = m_fHeight;
    if ( (g_bEffSystemFlags & 1) == 0 )
    {
      g_bEffSystemFlags |= 1u;
      (((CEffMgr *)&g_pCEffMgrBackup))->CEffMgr::Reset();
      atexit(todo_401800);
    }
    v20 = this->m_fGreen + 12582912.0;
    if ( (g_bEffSystemFlags & 1) == 0 )
    {
      g_bEffSystemFlags |= 1u;
      (((CEffMgr *)&g_pCEffMgrBackup))->CEffMgr::Reset();
      atexit(todo_401800);
    }
    v21 = this->m_fBlue + 12582912.0;
    if ( (g_bEffSystemFlags & 1) == 0 )
    {
      g_bEffSystemFlags |= 1u;
      (((CEffMgr *)&g_pCEffMgrBackup))->CEffMgr::Reset();
      atexit(todo_401800);
    }
    v22 = this->m_fSize + 12582912.0;
    if ( (g_bEffSystemFlags & 1) == 0 )
    {
      g_bEffSystemFlags |= 1u;
      (((CEffMgr *)&g_pCEffMgrBackup))->CEffMgr::Reset();
      atexit(todo_401800);
    }
    v23 = this->m_fHeight + 12582912.0;
    if ( (g_bEffSystemFlags & 1) == 0 )
    {
      g_bEffSystemFlags |= 1u;
      (((CEffMgr *)&g_pCEffMgrBackup))->CEffMgr::Reset();
      atexit(todo_401800);
    }
    HIBYTE(v12) = LOBYTE(v20);
    LOBYTE(v12) = LOBYTE(v21);
    LODWORD(this->m_fRed) = LOBYTE(v23) | ((LOBYTE(v22) | (v12 << 8)) << 8);
  }
  v13 = (LODWORD(this->m_fTopShrink) + 1) * (this->m_nDivision + 1);
  this->m_fRotAngle = v19 * *(float *)(v4 + 24) + this->m_fRotAngle;
  v14 = v19 * *(float *)(v4 + 108) + this->m_fWide;
  m_pTexture = (gbTexture *)this->m_pTexture;
  m_pTextureArray = (gbTextureArray *)this->m_pTextureArray;
  this->m_fWide = v14;
  qmemcpy(m_pTextureArray, m_pTexture, 4 * ((unsigned int)(12 * v13) >> 2));
  sub_4CB000(this);
  sub_4CB0C0(this);
  sub_4CAD10(this);
  qmemcpy(this->m_pTexture, this->m_pTextureArray, 12 * (LODWORD(this->m_fTopShrink) + 1) * (this->m_nDivision + 1));
  if ( *(_BYTE *)(v24 + 66) == 1
    || *((float *)&this->CTaskTpl_tagEffTaskParam_CEffCylinder::__vftable + 1) - *(float *)(v24 + 16) >= *(float *)(v24 + 24) )
  {
    *(_DWORD *)(v24 + 8) = 4;
  }
  return 0;
}
