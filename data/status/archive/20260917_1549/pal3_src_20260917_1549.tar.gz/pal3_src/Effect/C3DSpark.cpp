#include "pal3/ida_defs.h"
#include "globals.h"
#include "pal3/pal3_constants.h"
#include "Effect/C3DSpark.h"
#include "Effect/CEffMgr.h"
#include "GameBase/Logger.h"
#include "Render/RenderTarget2.h"
#include "Misc/tag17A8Data.h"
#include "Misc/tagEffMgrData.h"
#include "free_functions.h"

// 0x004D6670
C3DSpark::C3DSpark()
{
  int v2; // ebx
  gbGeomQuad *m_GeomQuad; // edi
  gbTexture *v4; // eax
  gbTextureArray *v5; // eax
  gbTexture *m_pRedBig; // ecx
  gbTexture *v7; // eax
  gbTextureArray *v8; // eax
  gbTexture *m_pRed16; // ecx
  gbTexture *v10; // eax
  gbTextureArray *v11; // eax
  gbTexture *m_pGreen16; // ecx
  gbTexture *v13; // eax
  gbTextureArray *v14; // eax
  gbTexture *m_pBlue16; // ecx
  gbTexture *v16; // eax
  gbTextureArray *v17; // eax
  gbTexture *m_pYellow16; // ecx
  float *p_sv; // eax
  int v20; // ecx
  char pExceptionObject[1024]; // [esp+0x30] [ebp-0x800] BYREF
  char ArgList[1024]; // [esp+0x430] [ebp-0x400] BYREF

  v2 = 128;
  m_GeomQuad = this->m_GeomQuad;
  do
  {
    --v2;
  }
  while ( v2 );
  memset(this, 0, sizeof(C3DSpark));
  this->m_pAdditiveBlend = (((gbEffectMgr *)gfxMgr->pEffectMgr))->gbEffectMgr::NewRenderEffect("gfxscript\\AdditiveBlend.gbf", 0);
  this->m_pRedBig = v4;
  (((gbTexture *)v4))->gbTexture::LoadTexture(1);
  v5 = (gbTextureArray *)operator new(0x44u);
  if ( v5 )
  {
    m_pRedBig = (gbTexture *)this->m_pRedBig;
    v5->nTex = 1;
    v5->pTexPt[0] = m_pRedBig;
  }
  else
  {
    v5 = 0;
  }
  this->m_pRedBigArray = v5;
  if ( !v5 )
  {
    qmemcpy(
      pExceptionObject,
      (((Logger *)ArgList))->Logger::FormatException((char *)&g_EffMgrData.m_nEffParam_0338 + 16, (char *)&pTarget.m_nTargetType + 472, 37),
      sizeof(pExceptionObject));
    _CxxThrowException(pExceptionObject, (_ThrowInfo *)&_TI1_AV_Exception__);
  }
  this->m_pRed16 = v7;
  (((gbTexture *)v7))->gbTexture::LoadTexture(1);
  v8 = (gbTextureArray *)operator new(0x44u);
  if ( v8 )
  {
    m_pRed16 = (gbTexture *)this->m_pRed16;
    v8->nTex = 1;
    v8->pTexPt[0] = m_pRed16;
  }
  else
  {
    v8 = 0;
  }
  this->m_pRed16Array = v8;
  if ( !v8 )
  {
    qmemcpy(
      pExceptionObject,
      (((Logger *)ArgList))->Logger::FormatException((char *)&g_EffMgrData.m_nEffParam_0338 + 16, (char *)&pTarget.m_nTargetType + 472, 42),
      sizeof(pExceptionObject));
    _CxxThrowException(pExceptionObject, (_ThrowInfo *)&_TI1_AV_Exception__);
  }
  this->m_pGreen16 = v10;
  (((gbTexture *)v10))->gbTexture::LoadTexture(1);
  v11 = (gbTextureArray *)operator new(0x44u);
  if ( v11 )
  {
    m_pGreen16 = (gbTexture *)this->m_pGreen16;
    v11->nTex = 1;
    v11->pTexPt[0] = m_pGreen16;
  }
  else
  {
    v11 = 0;
  }
  this->m_pGreen16Array = v11;
  if ( !this->m_pRed16Array )
  {
    qmemcpy(
      pExceptionObject,
      (((Logger *)ArgList))->Logger::FormatException((char *)&g_EffMgrData.m_nEffParam_0338 + 16, (char *)&pTarget.m_nTargetType + 472, 47),
      sizeof(pExceptionObject));
    _CxxThrowException(pExceptionObject, (_ThrowInfo *)&_TI1_AV_Exception__);
  }
  this->m_pBlue16 = v13;
  (((gbTexture *)v13))->gbTexture::LoadTexture(1);
  v14 = (gbTextureArray *)operator new(0x44u);
  if ( v14 )
  {
    m_pBlue16 = (gbTexture *)this->m_pBlue16;
    v14->nTex = 1;
    v14->pTexPt[0] = m_pBlue16;
  }
  else
  {
    v14 = 0;
  }
  this->m_pBlue16Array = v14;
  if ( !v14 )
  {
    qmemcpy(
      pExceptionObject,
      (((Logger *)ArgList))->Logger::FormatException((char *)&g_EffMgrData.m_nEffParam_0338 + 16, (char *)&pTarget.m_nTargetType + 472, 52),
      sizeof(pExceptionObject));
    _CxxThrowException(pExceptionObject, (_ThrowInfo *)&_TI1_AV_Exception__);
  }
  this->m_pYellow16 = v16;
  (((gbTexture *)v16))->gbTexture::LoadTexture(1);
  v17 = (gbTextureArray *)operator new(0x44u);
  if ( v17 )
  {
    m_pYellow16 = (gbTexture *)this->m_pYellow16;
    v17->nTex = 1;
    v17->pTexPt[0] = m_pYellow16;
  }
  else
  {
    v17 = 0;
  }
  this->m_pYellow16Array = v17;
  if ( !v17 )
  {
    qmemcpy(
      pExceptionObject,
      (((Logger *)ArgList))->Logger::FormatException((char *)&g_EffMgrData.m_nEffParam_0338 + 16, (char *)&pTarget.m_nTargetType + 472, 57),
      sizeof(pExceptionObject));
    _CxxThrowException(pExceptionObject, (_ThrowInfo *)&_TI1_AV_Exception__);
  }
  p_sv = (float *)&this->m_GeomQuad[0].sv;
  v20 = 128;
  do
  {
    p_sv[3] = NAN;
    *p_sv = 0.0;
    *(p_sv - 1) = 0.0;
    p_sv[2] = 1.0;
    p_sv[1] = 1.0;
    p_sv += 17;
    --v20;
  }
  while ( v20 );
  this;
}

// 0x004D6960
C3DSpark::~C3DSpark()
{
  gbRenderEffect *m_pAdditiveBlend; // ecx
  gbTexture *m_pRedBig; // ecx
  gbTexture *m_pGreen16; // ecx
  gbTexture *m_pBlue16; // ecx
  gbTexture *m_pRed16; // ecx
  gbTexture *m_pYellow16; // ecx

  m_pAdditiveBlend = (gbRenderEffect *)this->m_pAdditiveBlend;
  if ( m_pAdditiveBlend )
  {
    (((gbRefObject *)m_pAdditiveBlend))->gbRefObject::Release();
    this->m_pAdditiveBlend = 0;
  }
  m_pRedBig = (gbTexture *)this->m_pRedBig;
  if ( m_pRedBig )
  {
    (((gbRefObject *)m_pRedBig))->gbRefObject::Release();
    this->m_pRedBig = 0;
  }
  m_pGreen16 = (gbTexture *)this->m_pGreen16;
  if ( m_pGreen16 )
  {
    (((gbRefObject *)m_pGreen16))->gbRefObject::Release();
    this->m_pGreen16 = 0;
  }
  m_pBlue16 = (gbTexture *)this->m_pBlue16;
  if ( m_pBlue16 )
  {
    (((gbRefObject *)m_pBlue16))->gbRefObject::Release();
    this->m_pBlue16 = 0;
  }
  m_pRed16 = (gbTexture *)this->m_pRed16;
  if ( m_pRed16 )
  {
    (((gbRefObject *)m_pRed16))->gbRefObject::Release();
    this->m_pRed16 = 0;
  }
  m_pYellow16 = (gbTexture *)this->m_pYellow16;
  if ( m_pYellow16 )
  {
    (((gbRefObject *)m_pYellow16))->gbRefObject::Release();
    this->m_pYellow16 = 0;
  }
  if ( this->m_pRedBigArray )
  {
    operator delete(this->m_pRedBigArray);
    this->m_pRedBigArray = 0;
  }
  if ( this->m_pGreen16Array )
  {
    operator delete(this->m_pGreen16Array);
    this->m_pGreen16Array = 0;
  }
  if ( this->m_pBlue16Array )
  {
    operator delete(this->m_pBlue16Array);
    this->m_pBlue16Array = 0;
  }
  if ( this->m_pRed16Array )
  {
    operator delete(this->m_pRed16Array);
    this->m_pRed16Array = 0;
  }
  if ( this->m_pYellow16Array )
  {
    operator delete(this->m_pYellow16Array);
    this->m_pYellow16Array = 0;
  }
}

// 0x004D6A60
bool C3DSpark::CreateSingle(const void *pSpark)
{
  int v3; // eax
  _BYTE *i; // ecx

  v3 = 0;
  for ( i = &this->m_Spark[0]._tail_000[53]; *i; i += 56 )
  {
    if ( ++v3 >= 128 )
      return 0;
  }
  qmemcpy(&this->m_Spark[v3], pSpark, sizeof(this->m_Spark[v3]));
  this->m_Spark[v3]._tail_000[53] = 1;
  if ( v3 >= this->m_nCurrentSpark )
    this->m_nCurrentSpark = v3 + 1;
  return 1;
}

// 0x004D6AC0
void C3DSpark::CreateOne(int x, int y, int z)
{
  int v5; // eax
  long double v6; // st7
  float xa; // [esp+0x8] [ebp+0x4]

  g_17A8Data.m_nEffParam2C = 1090519040;
  g_17A8Data.m_nEffParam24 = 1128792064;
  g_17A8Data.m_nEffParamBase0 = x;
  g_17A8Data.m_nEffParamBase4 = y;
  g_17A8Data.m_nEffParamBase8 = z;
  g_17A8Data.m_nEffParam1 = 0;
  g_17A8Data.m_nEffParam1C = -1046478848;
  g_17A8Data.m_nEffTypeID = 0;
  g_17A8Data.m_nEffTypeCode = -1015414784;
  g_17A8Data.m_nEffParam30 = 0;
  xa = (float)(rand() % 10);
  v5 = rand();
  g_17A8Data.m_nEffParam10 = -1054867456;
  v6 = (double)(v5 % 5760 / 16) * 0.017453292;
  g_17A8Data.m_nEffParam0 = sin(v6) * xa;
  g_17A8Data.m_nEffParam14 = cos(v6) * xa;
  this->C3DSpark::CreateSingle(&g_17A8Data);
}

// 0x004D6BA0
_BYTE * C3DSpark::DestroyAll()
{
  _BYTE *result; // eax
  int v2; // edx

  result = (_BYTE *)&this->m_Spark[0]._tail_000[53];
  v2 = 128;
  do
  {
    *result = 0;
    result += 56;
    --v2;
  }
  while ( v2 );
  this->m_nCurrentSpark = 0;
  return result;
}

// 0x004D6BC0
void C3DSpark::Render(gbVec3D *pVec3D)
{
  int v1; // ecx
  gbVec3D *v2; // edi
  gbMatrixStack *v3; // ebx
  int v4; // esi
  int v5; // edi
  gbMatrix4 *Top; // eax
  double v7; // st7
  double v8; // st6
  gbVec3D *v9; // [esp-0x4] [ebp-0x34]
  int v10; // [esp+0x0] [ebp-0x30]
  float v11; // [esp+0x8] [ebp-0x28]
  float v12; // [esp+0xC] [ebp-0x24]
  int v13; // [esp+0x10] [ebp-0x20]
  float v14; // [esp+0x1C] [ebp-0x14]
  float v15; // [esp+0x1C] [ebp-0x14]
  int v16; // [esp+0x20] [ebp-0x10]
  int v17; // [esp+0x24] [ebp-0xC]
  int v18; // [esp+0x28] [ebp-0x8]
  float v19; // [esp+0x2C] [ebp-0x4]

  v3 = gfxMgr->pMatrixStack[1];
  v16 = v1;
  v18 = 0;
  v17 = 0;
  if ( *(int *)(v1 + 7168) > 0 )
  {
    v9 = (gbVec3D *)v2;
    v4 = v1 + 7220;
    v5 = v1 + 4;
    do
    {
      if ( *(_BYTE *)(v5 + 49) )
      {
        v11 = *(float *)(v5 - 4);
        v12 = *(float *)v5;
        v13 = *(_DWORD *)(v5 + 4);
        Top = (((gbMatrixStack *)v3))->gbMatrixStack::GetTop();
        (((gbMatrix4 *)Top))->gbMatrix4::Transform(v9, v10);
        v19 = *(float *)(v5 + 40) * 0.5;
        v7 = v11 - v19;
        *(float *)(v4 - 4) = v7;
        v8 = v12 + v19;
        *(float *)v4 = v8;
        *(_DWORD *)(v4 + 4) = v13;
        v14 = v11 + v19;
        *(float *)(v4 + 8) = v14;
        *(float *)(v4 + 12) = v8;
        *(_DWORD *)(v4 + 16) = v13;
        *(float *)(v4 + 20) = v14;
        v15 = v12 - v19;
        *(float *)(v4 + 24) = v15;
        *(_DWORD *)(v4 + 28) = v13;
        *(float *)(v4 + 32) = v7;
        *(float *)(v4 + 36) = v15;
        *(_DWORD *)(v4 + 40) = v13;
        *(_BYTE *)(v4 + 63) = (int)*(float *)(v5 + 32);
        ++v18;
        v1 = v16;
        v4 += 68;
      }
      v5 += 56;
      ++v17;
    }
    while ( v17 < *(_DWORD *)(v1 + 7168) );
    if ( v18 > 0 )
    {
      (((gbVertPoolMgr *)gfxMgr->pVertPoolMgr))->gbVertPoolMgr::GetDynVertBuf(0x15u);
      (((gbMatrixStack *)v3))->gbMatrixStack::Push();
      (((gbMatrixStack *)v3))->gbMatrixStack::LoadIdentity();
      (((gbDynVertBuf *)(v16 + 7216)))->gbDynVertBuf::RenderGeomQuad(v18, *(gbRenderEffect **)(v16 + 7172), *(gbTextureArray **)(v16 + 7204));
      (((gbMatrixStack *)v3))->gbMatrixStack::Pop();
    }
  }
}
