#include "pal3/ida_defs.h"
#include "globals.h"
#include "pal3/pal3_constants.h"
#include "Effect/C2DSpark.h"
#include "Effect/CEffMgr.h"
#include "GameBase/GRPinput.h"
#include "GameBase/Logger.h"
#include "Render/RenderTarget2.h"
#include "Misc/tagEffMgrData.h"
#include "Misc/tagEffSParticleSys.h"

// 0x004D5AB0
C2DSpark::C2DSpark(int nClientWidth, int nClientHeight)
{
  gbTexture *v4; // eax
  gbTexture **v5; // eax
  gbTexture *pTexture1; // ecx
  gbTexture *v7; // eax
  gbTexture **v8; // eax
  gbTexture *pTexture4; // ecx
  gbTexture *v10; // eax
  gbTexture **v11; // eax
  gbTexture *pTexture3; // ecx
  gbTexture *v13; // eax
  int *v14; // eax
  int m_nTodo_008; // ecx
  gbTexture *v16; // eax
  gbTexture **v17; // eax
  gbTexture *pTexture5; // ecx
  _BYTE v19[1056]; // [esp+0x30] [ebp-0x800] BYREF
  char ArgList; // [esp+0x450] [ebp-0x3E0] BYREF

  this->m_Spark[471].nState = -1;
  this->m_Spark[471].pTexture4 = 0;
  memset(this, 0, 0x5870u);
  *(float *)&this->m_Spark[469].pTexture3 = (float)nClientWidth;
  *(float *)&this->m_Spark[469].pTextureWrap3 = (float)nClientHeight;
  LOBYTE(this->m_Spark[469].nRenderEffect) = 0;
  this->m_Spark[469].pRenderEffect = (int)(((gbEffectMgr *)gfxMgr->pEffectMgr))->gbEffectMgr::NewRenderEffect((const char *)&pTarget.m_nTargetType + 412, 0);
  *(_DWORD *)&v19[12] = 1;
  this->m_Spark[470].pTexture1 = v4;
  (((gbTexture *)v4))->gbTexture::LoadTexture(*(_DWORD *)&v19[12]);
  v5 = (gbTexture **)operator new(0x44u);
  if ( v5 )
  {
    pTexture1 = (gbTexture *)this->m_Spark[470].pTexture1;
    v5[16] = (gbTexture *)1;
    *v5 = pTexture1;
  }
  else
  {
    v5 = 0;
  }
  this->m_Spark[470].pTextureWrap1 = v5;
  if ( !v5 )
  {
    qmemcpy(
      &v19[32],
      (((Logger *)&ArgList))->Logger::FormatException((char *)&g_EffMgrData.m_nEffParam_0338 + 16, (char *)&pTarget.m_nTargetType + 352, 41),
      0x400u);
    _CxxThrowException(&v19[32], (_ThrowInfo *)&_TI1_AV_Exception__);
  }
  *(_DWORD *)&v19[8] = 1;
  this->m_Spark[470].pTexture4 = v7;
  (((gbTexture *)v7))->gbTexture::LoadTexture(*(_DWORD *)&v19[8]);
  v8 = (gbTexture **)operator new(0x44u);
  if ( v8 )
  {
    pTexture4 = (gbTexture *)this->m_Spark[470].pTexture4;
    v8[16] = (gbTexture *)1;
    *v8 = pTexture4;
  }
  else
  {
    v8 = 0;
  }
  this->m_Spark[470].nState = (int)v8;
  if ( !v8 )
  {
    qmemcpy(
      &v19[24],
      (((Logger *)&v19[1048]))->Logger::FormatException((char *)&g_EffMgrData.m_nEffParam_0338 + 16, (char *)&pTarget.m_nTargetType + 352, 46),
      0x400u);
    _CxxThrowException(&v19[24], (_ThrowInfo *)&_TI1_AV_Exception__);
  }
  *(_DWORD *)v19 = 1;
  this->m_Spark[470].pTexture3 = v10;
  (((gbTexture *)v10))->gbTexture::LoadTexture(*(_DWORD *)v19);
  v11 = (gbTexture **)operator new(0x44u);
  if ( v11 )
  {
    pTexture3 = (gbTexture *)this->m_Spark[470].pTexture3;
    v11[16] = (gbTexture *)1;
    *v11 = pTexture3;
  }
  else
  {
    v11 = 0;
  }
  this->m_Spark[470].pTextureWrap3 = v11;
  if ( !this->m_Spark[470].nState )
  {
    qmemcpy(
      &v19[16],
      (((Logger *)&v19[1040]))->Logger::FormatException((char *)&g_EffMgrData.m_nEffParam_0338 + 16, (char *)&pTarget.m_nTargetType + 352, 51),
      0x400u);
    _CxxThrowException(&v19[16], (_ThrowInfo *)&_TI1_AV_Exception__);
  }
  this->m_Spark[470].m_nTodo_008 = (int)v13;
  (((gbTexture *)v13))->gbTexture::LoadTexture(1);
  v14 = (int *)operator new(0x44u);
  if ( v14 )
  {
    m_nTodo_008 = this->m_Spark[470].m_nTodo_008;
    v14[16] = 1;
    *v14 = m_nTodo_008;
  }
  else
  {
    v14 = 0;
  }
  this->m_Spark[470].m_nTodo_00C = (int)v14;
  if ( !v14 )
  {
    qmemcpy(
      &v19[8],
      (((Logger *)&v19[1032]))->Logger::FormatException((char *)&g_EffMgrData.m_nEffParam_0338 + 16, (char *)&pTarget.m_nTargetType + 352, 56),
      0x400u);
    _CxxThrowException(&v19[8], (_ThrowInfo *)&_TI1_AV_Exception__);
  }
  this->m_Spark[470].pTexture5 = v16;
  (((gbTexture *)v16))->gbTexture::LoadTexture(1);
  v17 = (gbTexture **)operator new(0x44u);
  if ( v17 )
  {
    pTexture5 = (gbTexture *)this->m_Spark[470].pTexture5;
    v17[16] = (gbTexture *)1;
    *v17 = pTexture5;
  }
  else
  {
    v17 = 0;
  }
  this->m_Spark[470].pTextureWrap5 = v17;
  if ( !v17 )
  {
    qmemcpy(
      v19,
      (((Logger *)&v19[1024]))->Logger::FormatException((char *)&g_EffMgrData.m_nEffParam_0338 + 16, (char *)&pTarget.m_nTargetType + 352, 61),
      0x400u);
    _CxxThrowException(v19, (_ThrowInfo *)&_TI1_AV_Exception__);
  }
  this->m_Spark[471].nState = -1;
  this->m_Spark[471].pTextureWrap3 = (void *)1065353216;
  this->m_Spark[471].pTexture3 = (gbTexture *)1065353216;
  this->m_Spark[471].m_nTodo_00C = 0;
  this->m_Spark[471].m_nTodo_008 = 0;
  this->m_Spark[471].pTexture4 = (gbTexture *)1056964608;
}

// 0x004D5DC0
C2DSpark::~C2DSpark()
{
  gbRefObject *pRenderEffect; // ecx
  gbTexture *pTexture1; // ecx
  gbTexture *pTexture3; // ecx
  gbRefObject *m_nTodo_008; // ecx
  gbTexture *pTexture4; // ecx
  gbTexture *pTexture5; // ecx

  pRenderEffect = (gbRefObject *)this->m_Spark[469].pRenderEffect;
  if ( pRenderEffect )
  {
    (((gbRefObject *)pRenderEffect))->gbRefObject::Release();
    this->m_Spark[469].pRenderEffect = 0;
  }
  pTexture1 = (gbTexture *)this->m_Spark[470].pTexture1;
  if ( pTexture1 )
  {
    (((gbRefObject *)pTexture1))->gbRefObject::Release();
    this->m_Spark[470].pTexture1 = 0;
  }
  pTexture3 = (gbTexture *)this->m_Spark[470].pTexture3;
  if ( pTexture3 )
  {
    (((gbRefObject *)pTexture3))->gbRefObject::Release();
    this->m_Spark[470].pTexture3 = 0;
  }
  m_nTodo_008 = (gbRefObject *)this->m_Spark[470].m_nTodo_008;
  if ( m_nTodo_008 )
  {
    (((gbRefObject *)m_nTodo_008))->gbRefObject::Release();
    this->m_Spark[470].m_nTodo_008 = 0;
  }
  pTexture4 = (gbTexture *)this->m_Spark[470].pTexture4;
  if ( pTexture4 )
  {
    (((gbRefObject *)pTexture4))->gbRefObject::Release();
    this->m_Spark[470].pTexture4 = 0;
  }
  pTexture5 = (gbTexture *)this->m_Spark[470].pTexture5;
  if ( pTexture5 )
  {
    (((gbRefObject *)pTexture5))->gbRefObject::Release();
    this->m_Spark[470].pTexture5 = 0;
  }
  if ( this->m_Spark[470].pTextureWrap1 )
  {
    operator delete(this->m_Spark[470].pTextureWrap1);
    this->m_Spark[470].pTextureWrap1 = 0;
  }
  if ( this->m_Spark[470].pTextureWrap3 )
  {
    operator delete(this->m_Spark[470].pTextureWrap3);
    this->m_Spark[470].pTextureWrap3 = 0;
  }
  if ( this->m_Spark[470].m_nTodo_00C )
  {
    operator delete((void *)this->m_Spark[470].m_nTodo_00C);
    this->m_Spark[470].m_nTodo_00C = 0;
  }
  if ( this->m_Spark[470].nState )
  {
    operator delete((void *)this->m_Spark[470].nState);
    this->m_Spark[470].nState = 0;
  }
  if ( this->m_Spark[470].pTextureWrap5 )
  {
    operator delete(this->m_Spark[470].pTextureWrap5);
    this->m_Spark[470].pTextureWrap5 = 0;
  }
}

// 0x004D5EC0
bool C2DSpark::CreateSingle(const void *pSpark)
{
  int v3; // eax
  _BYTE *i; // ecx

  v3 = 0;
  for ( i = (char *)&this->m_Spark[0].nRenderEffect + 1; *i; i += 44 )
  {
    if ( ++v3 >= 512 )
      return 0;
  }
  qmemcpy((char *)this + 44 * v3, pSpark, 0x2Cu);
  *((_BYTE *)&this->m_Spark[0].nRenderEffect + 44 * v3 + 1) = 1;
  if ( v3 >= (int)this->m_Spark[469].pTexture4 )
    this->m_Spark[469].pTexture4 = (gbTexture *)(v3 + 1);
  return 1;
}

// 0x004D5F20
void C2DSpark::CreateTrack(char nx, int ny, gbColorQuad color)
{
  int v3; // ecx

  *(_DWORD *)(v3 + 22540) = 0;
  *(_BYTE *)(v3 + 22552) = nx;
}

// 0x004D5F40
void C2DSpark::SetEnableMouseTrack(int bEnable, int nVal)
{
  int v4; // edi
  long double v5; // st7
  float v6; // [esp+0x0] [ebp-0x8]

  g_SParticleSys.m_fSpawn3Bright = 16.0;
  g_SParticleSys.m_fSpawn3Size = 200.0;
  g_SParticleSys.m_nSpawn3Flags = 0;
  g_SParticleSys.m_nSpawn3Count = 1145569280;
  g_SParticleSys.m_nSpawn3Color = -1011941376;
  g_SParticleSys.m_nSpawn3Life = 0;
  g_SParticleSys.m_vSpawn3Pos[0] = (double)bEnable - 8.0;
  v4 = 0;
  g_SParticleSys.m_vSpawn3Pos[1] = (double)nVal - 8.0;
  do
  {
    g_SParticleSys.m_bSpawn3Active = rand() & 3;
    v6 = (float)(rand() % 300);
    v5 = (double)(rand() % 5760 / 16) * 0.017453292;
    g_SParticleSys.m_vSpawn3Rand[0] = sin(v5) * v6;
    g_SParticleSys.m_vSpawn3Rand[1] = cos(v5) * v6;
    if ( !this->C2DSpark::CreateSingle(g_SParticleSys.m_vSpawn3Pos) )
      break;
    ++v4;
  }
  while ( v4 < 60 );
  this->m_Spark[469].nState = 1132068864;
  this->m_Spark[469].pTexture5 = (gbTexture *)bEnable;
  this->m_Spark[469].pTextureWrap5 = (void *)nVal;
}

// 0x004D6050
void C2DSpark::CreateMore(int x, int y, int color, int nVal)
{
  double v5; // st7
  double v7; // st7
  float v8; // [esp+0x0] [ebp-0x4]
  float xa; // [esp+0x8] [ebp+0x4]
  float ya; // [esp+0xC] [ebp+0x8]

  v5 = *(float *)&nVal * 0.5;
  g_SParticleSys.m_nSpawn2Effect = nVal;
  g_SParticleSys.m_nSpawn2Life = 1128792064;
  g_SParticleSys.m_nSpawn2Flags = 0;
  g_SParticleSys.m_nSpawn2Count = -1054867456;
  g_SParticleSys.m_fSpawn2Size = 0.0;
  g_SParticleSys.m_nSpawn2Color = -1035468800;
  v8 = (double)x - v5;
  g_SParticleSys.m_nSpawn2Bright = -1027080192;
  g_SParticleSys.m_nSpawn2Rand = 0;
  g_SParticleSys.m_bSpawn2Active = 2;
  ya = (double)y - v5;
  *(float *)&g_SParticleSys.m_nSpawn2Life = 250.0 - (double)(rand() % 50);
  xa = (float)color;
  g_SParticleSys.m_vSpawn2Pos[0] = (double)(rand() % color) + v8 - xa * 0.5;
  g_SParticleSys.m_vSpawn2Pos[1] = (double)(rand() % (2 * color)) + ya - xa;
  if ( *(float *)&nVal >= 19.0 )
    v7 = (double)-(rand() % 100);
  else
    v7 = (double)-(rand() % 50);
  *(float *)&g_SParticleSys.m_nSpawn2Color = v7;
  this->C2DSpark::CreateSingle(g_SParticleSys.m_vSpawn2Pos);
}

// 0x004D61A0
_BYTE * C2DSpark::CreateStars()
{
  _BYTE *result; // eax
  int v2; // edx

  result = (char *)&this->m_Spark[0].nRenderEffect + 1;
  v2 = 512;
  do
  {
    *result = 0;
    result += 44;
    --v2;
  }
  while ( v2 );
  this->m_Spark[469].pTexture4 = 0;
  return result;
}

// 0x004D61C0
void C2DSpark::DestroyAll()
{
  gbDynVertBuf *DynVertBuf; // ebx
  void *y; // ecx
  gbTexture *x; // eax
  double v5; // st7
  double v6; // st7
  gbRenderEffect *pRenderEffect; // ecx
  gbTexture *pTexture4; // eax
  gbTexture **p_pTexture5; // edi
  int nState; // ecx
  gbRenderEffect *v11; // ecx
  gbTexture *v12; // ecx
  gbTextureArray *v13; // [esp-0x4] [ebp-0x20]
  struct tagPOINT Point; // [esp+0xC] [ebp-0x10] BYREF
  float v15; // [esp+0x14] [ebp-0x8]
  int p_r_shift; // [esp+0x18] [ebp-0x4]

  DynVertBuf = (((gbVertPoolMgr *)gfxMgr->pVertPoolMgr))->gbVertPoolMgr::GetDynVertBuf(0x114u);
  if ( *(float *)&this->m_Spark[469].nState > 2.0 )
  {
    g_Input.GRPinput::GetCursorPos(&Point);
    if ( LOBYTE(this->m_Spark[469].nRenderEffect) )
    {
      GetCursorPos(&Point);
      y = (void *)Point.y;
      x = (gbTexture *)Point.x;
    }
    else
    {
      x = (gbTexture *)this->m_Spark[469].pTexture5;
      y = (void *)this->m_Spark[469].pTextureWrap5;
      Point.x = (LONG)x;
      Point.y = (LONG)y;
    }
    p_r_shift = (int)y - 64;
    *(float *)&this->m_Spark[470].nRenderEffect = (float)(int)&x[-1].pMgr;
    v5 = (double)p_r_shift;
    p_r_shift = (int)&x->InFmt.r_shift;
    *(float *)&this->m_Spark[470].pRenderEffect = v5;
    v6 = (double)p_r_shift;
    p_r_shift = (int)y + 64;
    *(float *)&this->m_Spark[471].pTexture1 = v6;
    *(float *)&this->m_Spark[471].pTextureWrap1 = (float)p_r_shift;
    pRenderEffect = (gbRenderEffect *)this->m_Spark[469].pRenderEffect;
    HIBYTE(this->m_Spark[471].nState) = (__int64)*(float *)&this->m_Spark[469].nState;
    (((gbDynVertBuf *)DynVertBuf))->gbDynVertBuf::RenderUIQuad((gbUIQuad *)&this->m_Spark[470].nRenderEffect, 1, pRenderEffect, (gbTextureArray *)this->m_Spark[470].pTextureWrap1);
  }
  pTexture4 = (gbTexture *)this->m_Spark[469].pTexture4;
  p_r_shift = 0;
  if ( (int)pTexture4 > 0 )
  {
    p_pTexture5 = (gbTexture **)&this->m_Spark[0].pTexture5;
    do
    {
      if ( *((_BYTE *)p_pTexture5 + 9) )
      {
        switch ( *((_BYTE *)p_pTexture5 + 8) )
        {
          case 0:
            nState = this->m_Spark[470].nState;
            goto LABEL_14;
          case 1:
            nState = (int)this->m_Spark[470].pTextureWrap3;
            goto LABEL_14;
          case 2:
            nState = this->m_Spark[470].m_nTodo_00C;
            goto LABEL_14;
          case 3:
            nState = (int)this->m_Spark[470].pTextureWrap5;
LABEL_14:
            this->m_Spark[470].nRenderEffect = (int)*(p_pTexture5 - 8);
            this->m_Spark[470].pRenderEffect = (int)*(p_pTexture5 - 7);
            *(float *)&this->m_Spark[471].pTexture1 = *(float *)p_pTexture5 + *((float *)p_pTexture5 - 8);
            *(float *)&this->m_Spark[471].pTextureWrap1 = *(float *)p_pTexture5 + *((float *)p_pTexture5 - 7);
            v15 = *((float *)p_pTexture5 - 2);
            Point.y = (int)v15;
            v13 = (gbTextureArray *)nState;
            v11 = (gbRenderEffect *)this->m_Spark[469].pRenderEffect;
            HIBYTE(this->m_Spark[471].nState) = Point.y;
            (((gbDynVertBuf *)DynVertBuf))->gbDynVertBuf::RenderUIQuad((gbUIQuad *)&this->m_Spark[470].nRenderEffect, 1, v11, v13);
            break;
          default:
            return;
        }
      }
      v12 = (gbTexture *)this->m_Spark[469].pTexture4;
      p_pTexture5 += 11;
      ++p_r_shift;
    }
    while ( p_r_shift < (int)v12 );
  }
}

// 0x004D6380
void C2DSpark::Render(float fVal)
{
  int v3; // edi
  int v4; // eax
  int v5; // edx
  int *p_m_nTodo_008; // ecx
  gbTexture *v7; // eax
  struct tagPOINT Point; // [esp+0x8] [ebp-0xC] BYREF
  int v9; // [esp+0x10] [ebp-0x4]

  if ( LOBYTE(this->m_Spark[469].nRenderEffect) )
  {
    g_Input.GRPinput::GetCursorPos(&Point);
    if ( Point.x != g_SParticleSys.m_ptLastSpawn[0] || Point.y != g_SParticleSys.m_ptLastSpawn[1] )
    {
      g_SParticleSys.m_fSpawnBright = 16.0;
      g_SParticleSys.m_fSpawnSize = 155.0;
      v3 = 5;
      g_SParticleSys.m_vSpawnPos[0] = (double)Point.x - 8.0;
      g_SParticleSys.m_vSpawnPos[1] = (double)Point.y - 8.0;
      do
      {
        rand();
        g_SParticleSys.m_bSpawnActive = 0;
        v9 = rand() % 100;
        g_SParticleSys.m_vSpawnOffset[0] = ((double)v9 - 50.0) * 2.5;
        v4 = rand();
        g_SParticleSys.m_nSpawnFlags = 0;
        g_SParticleSys.m_nSpawnCount = 1145569280;
        g_SParticleSys.m_nSpawnLife = -1011941376;
        g_SParticleSys.m_nSpawnEffect = 0;
        v9 = v4 % 100;
        g_SParticleSys.m_vSpawnOffset[1] = ((double)(v4 % 100) - 50.0) * 2.5;
        this->C2DSpark::CreateSingle(g_SParticleSys.m_vSpawnPos);
        --v3;
      }
      while ( v3 );
      *(tagPOINT *)g_SParticleSys.m_ptLastSpawn = Point;
      v9 = (unsigned __int8)rand();
      *(float *)&this->m_Spark[469].nState = (float)v9;
    }
  }
  if ( *(float *)&this->m_Spark[469].nState > 2.0 )
    *(float *)&this->m_Spark[469].nState = *(float *)&this->m_Spark[469].nState - fVal * 200.0;
  v5 = 0;
  if ( (int)this->m_Spark[469].pTexture4 > 0 )
  {
    p_m_nTodo_008 = (int *)&this->m_Spark[0].m_nTodo_008;
    do
    {
      if ( *((_BYTE *)p_m_nTodo_008 + 33) )
      {
        *(float *)p_m_nTodo_008 = fVal * *((float *)p_m_nTodo_008 + 2) + *(float *)p_m_nTodo_008;
        *((float *)p_m_nTodo_008 + 1) = fVal * *((float *)p_m_nTodo_008 + 3) + *((float *)p_m_nTodo_008 + 1);
        *((float *)p_m_nTodo_008 - 2) = fVal * *(float *)p_m_nTodo_008 + *((float *)p_m_nTodo_008 - 2);
        *((float *)p_m_nTodo_008 - 1) = fVal * *((float *)p_m_nTodo_008 + 1) + *((float *)p_m_nTodo_008 - 1);
        *((float *)p_m_nTodo_008 + 4) = fVal * *((float *)p_m_nTodo_008 + 5) + *((float *)p_m_nTodo_008 + 4);
        *(float *)&v9 = fVal * *((float *)p_m_nTodo_008 + 7) + *((float *)p_m_nTodo_008 + 6);
        p_m_nTodo_008[6] = v9;
        if ( *((float *)p_m_nTodo_008 - 2) >= (double)*(float *)&this->m_Spark[469].pTexture3
          || (*(float *)&Point.x = -*(float *)&v9, *((float *)p_m_nTodo_008 - 2) <= (double)*(float *)&Point.x)
          || *((float *)p_m_nTodo_008 - 1) >= (double)*(float *)&this->m_Spark[469].pTextureWrap3
          || *((float *)p_m_nTodo_008 - 1) <= (double)*(float *)&Point.x
          || *((float *)p_m_nTodo_008 + 4) <= 1.0
          || *((float *)p_m_nTodo_008 + 4) > 255.0
          || *(float *)&v9 < 0.0099999998 )
        {
          *((_BYTE *)p_m_nTodo_008 + 33) = 0;
          v7 = (gbTexture *)((char *)this->m_Spark[469].pTexture4 - 1);
          if ( (gbTexture *)v5 == v7 )
            this->m_Spark[469].pTexture4 = v7;
        }
      }
      ++v5;
      p_m_nTodo_008 += 11;
    }
    while ( v5 < (int)this->m_Spark[469].pTexture4 );
  }
}
