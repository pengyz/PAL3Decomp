#include "pal3/ida_defs.h"
#include "globals.h"
#include "pal3/pal3_constants.h"
#include "Effect/CEffGrid.h"
#include "Combat/CCBStage.h"
#include "Effect/CEffCylinder.h"
#include "Effect/CEffMgr.h"
#include "Effect/CEffect.h"
#include "Effect/CEffgbParticle.h"
#include "Misc/CTaskTpl_tagEffTaskParam_CEffGrid.h"
#include "GameBase/Logger.h"
#include "GameBase/PAL3.h"
#include "Misc/tagEffMgrData.h"
#include "Misc/tagEffObjType.h"
#include "Misc/tagEffTaskParam.h"
#include "free_functions.h"

// Forward declarations for unnamed functions
int sub_4C9550(...);
int sub_4CAB30(...);
int sub_4CABE0(...);
int sub_4CAC70(...);
int sub_4CB130(...);
void __cdecl todo_401800(void);

// Unnamed globals (extern)
void __cdecl nullsub_83(void);
void __cdecl nullsub_84(void);
void __cdecl nullsub_85(void);

// 0x004C9610
CEffGrid::CEffGrid()
{
  void *v1; // eax

  v1 = (void *)operator new(0x10B8u);
  if ( v1 )
    sub_4C9550(v1);
}

// 0x004C9650
CEffGrid::~CEffGrid()
{
  CTaskTpl_tagEffTaskParam_CEffGrid *v2; // edi
  gbGeomQuad *m_pGeomQuad; // eax
  int v4; // ebp
  gbTexture *m_pTexture; // ecx
  CTaskTpl_tagEffTaskParam_CEffGrid *v6; // esi
  int v7; // eax
  bool v8; // cc
  int v9; // edi

  v2 = ((CTaskTpl_tagEffTaskParam_CEffGrid *)this);
  m_pGeomQuad = (gbGeomQuad *)this->m_pGeomQuad;
  v4 = 0;
  if ( m_pGeomQuad )
    operator delete(m_pGeomQuad);
  if ( this->m_pMesh )
    operator delete(this->m_pMesh);
  if ( this->m_pMesh2 )
    operator delete(this->m_pMesh2);
  m_pTexture = (gbTexture *)this->m_pTexture;
  if ( m_pTexture )
    (((gbRefObject *)m_pTexture))->gbRefObject::Release();
  if ( this->m_pTextureArray )
    operator delete(this->m_pTextureArray);
  v6 = this != 0 ? v2 : 0;
  v7 = *((_DWORD *)((void **)(v6)) + 7);
  v8 = v7 <= 0;
  if ( !v7 )
  {
    if ( !*(this != 0 ? ((void **)(v2)) + 8 : (void **)32) )
      return;
    v8 = 1;
  }
  if ( !v8 )
  {
    v9 = 0;
    do
    {
      operator delete(*(void **)(*((_DWORD *)((void **)(v6)) + 3) + v9));
      ++v4;
      *(_DWORD *)(*((_DWORD *)((void **)(v6)) + 3) + v9) = 0;
      v9 += 152;
    }
    while ( v4 < *((_DWORD *)((void **)(v6)) + 7) );
  }
  operator delete(*(((void **)(v6)) + 3));
  *((_DWORD *)((void **)(v6)) + 3) = 0;
  *((_DWORD *)((void **)(v6)) + 7) = 0;
  *((_DWORD *)((void **)(v6)) + 8) = 0;
}

// 0x004C9750
int CEffGrid::Init(float *pfVal, float fVal, float fVal2, float fVal3)
{
  int m_dwStartColor_low; // ecx
  int result; // eax

  this->m_bIdle = 0;
  this->m_bVisible = 0;
  this->m_vecPos.x = fVal + pfVal[46];
  this->m_vecPos.y = fVal2 + pfVal[47];
  this->m_vecPos.z = fVal3 + pfVal[48];
  this->m_vecRot.x = pfVal[54];
  this->m_vecRot.y = pfVal[49];
  this->m_vecRot.z = pfVal[55];
  this->m_vecOffsetPos.z = 0.0;
  this->m_vecOffsetPos.y = 0.0;
  this->m_vecOffsetPos.x = 0.0;
  this->m_dwStartColor = (unsigned int)pfVal[51];
  if ( (g_bEffSystemFlags & 1) == 0 )
  {
    g_bEffSystemFlags |= 1u;
    (((CEffMgr *)&g_pCEffMgrBackup))->CEffMgr::Reset();
    atexit(todo_401800);
  }
  this->m_fAlpha = (float)HIBYTE(this->m_dwStartColor);
  if ( (g_bEffSystemFlags & 1) == 0 )
  {
    g_bEffSystemFlags |= 1u;
    (((CEffMgr *)&g_pCEffMgrBackup))->CEffMgr::Reset();
    atexit(todo_401800);
  }
  this->m_fRed = (float)(unsigned __int8)BYTE2(this->m_dwStartColor);
  if ( (g_bEffSystemFlags & 1) == 0 )
  {
    g_bEffSystemFlags |= 1u;
    (((CEffMgr *)&g_pCEffMgrBackup))->CEffMgr::Reset();
    atexit(todo_401800);
  }
  this->m_fGreen = (float)(unsigned __int8)BYTE1(this->m_dwStartColor);
  if ( (g_bEffSystemFlags & 1) == 0 )
  {
    g_bEffSystemFlags |= 1u;
    (((CEffMgr *)&g_pCEffMgrBackup))->CEffMgr::Reset();
    atexit(todo_401800);
  }
  this->m_fCurFrame = 0.0;
  m_dwStartColor_low = LOBYTE(this->m_dwStartColor);
  this->m_nLoops = 0;
  this->m_fBlue = (float)m_dwStartColor_low;
  this->m_fXSize = pfVal[50];
  result = *((_DWORD *)pfVal + 50);
  LODWORD(this->m_fZSize) = result;
  return result;
}

// 0x004C98F0
char CEffGrid::Create(tagEffObjType *pType)
{
  _EXCEPTION_REGISTRATION_RECORD *ExceptionList; // eax
  void *v3; // esp
  void *v5; // eax
  int v6; // ebx
  int v7; // edi
  int v8; // edi
  int v9; // edx
  int v10; // eax
  int v11; // ecx
  __int64 fSacleZ; // rax
  float fSacleY; // ecx
  int m_nQuad; // ebx
  gbGeomQuad *v15; // eax
  int v16; // ebx
  int v17; // ebp
  int v18; // ebx
  int v19; // edi
  int v20; // ebp
  gbVec3D *v21; // eax
  int v22; // ebp
  gbVec3D *v23; // ebx
  int v24; // ebp
  int v25; // ebp
  gbVec3D *v26; // eax
  int v27; // ebp
  gbVec3D *v28; // ebx
  int v29; // ebp
  gbVec3D *m_pMesh; // ecx
  gbGeomQuad *v32; // [esp+0x0] [ebp-0x1010]
  gbVec3D *v33; // [esp+0x0] [ebp-0x1010]
  gbVec3D *v34; // [esp+0x0] [ebp-0x1010]
  _BYTE v35[1024]; // [esp+0x4] [ebp-0x100C] BYREF
  char pExceptionObject[1024]; // [esp+0x404] [ebp-C0Ch] BYREF
  char ArgList; // [esp+0x804] [ebp-0x80C] BYREF
  char v38; // [esp+C04h] [ebp-0x40C] BYREF
  _EXCEPTION_REGISTRATION_RECORD *v39; // [esp+0x1004] [ebp-0xC]
  void *v40; // [esp+0x1008] [ebp-0x8]
  int v41; // [esp+0x100C] [ebp-0x4]

  v41 = -1;
  ExceptionList = NtCurrentTeb()->NtTib.ExceptionList;
  v40 = ((void*)0);
  v39 = (_EXCEPTION_REGISTRATION_RECORD *)ExceptionList;
  v3 = alloca(4100);
  v5 = (void *)operator new(0x4C0u);
  *((_DWORD *)&this->CTaskTpl_tagEffTaskParam_CEffGrid::__vftable + 3) = (unsigned long)v5;
  if ( v5 )
  {
    v6 = 0;
    v7 = 0;
    while ( 1 )
    {
      *(_DWORD *)(v7 + *((_DWORD *)&this->CTaskTpl_tagEffTaskParam_CEffGrid::__vftable + 3)) = (unsigned long)operator new(0x2D0u);
      if ( !*(_DWORD *)(v7 + *((_DWORD *)&this->CTaskTpl_tagEffTaskParam_CEffGrid::__vftable + 3)) )
        break;
      v7 += 152;
      ++v6;
      if ( v7 >= 1216 )
      {
        v8 = 0;
        *((_DWORD *)&this->CTaskTpl_tagEffTaskParam_CEffGrid::__vftable + 7) = 8;
        *((_DWORD *)&this->CTaskTpl_tagEffTaskParam_CEffGrid::__vftable + 8) = 10;
        v9 = 0;
        do
        {
          *(_BYTE *)(v9 + *((_DWORD *)&this->CTaskTpl_tagEffTaskParam_CEffGrid::__vftable + 3) + 148) = 0;
          v10 = 0;
          if ( *((int *)&this->CTaskTpl_tagEffTaskParam_CEffGrid::__vftable + 8) > 0 )
          {
            v11 = 0;
            do
            {
              ++v10;
              v11 += 72;
              *(_BYTE *)(*(_DWORD *)(v9 + *((_DWORD *)&this->CTaskTpl_tagEffTaskParam_CEffGrid::__vftable + 3)) + v11 - 8) = 0;
            }
            while ( v10 < *((_DWORD *)&this->CTaskTpl_tagEffTaskParam_CEffGrid::__vftable + 8) );
          }
          ++v8;
          v9 += 152;
        }
        while ( v8 < *((_DWORD *)&this->CTaskTpl_tagEffTaskParam_CEffGrid::__vftable + 7) );
        goto LABEL_10;
      }
    }
    if ( v6 > 0 && v6 - 1 >= 0 )
    {
      v19 = 152 * (v6 - 1);
      do
      {
        operator delete(*(void **)(v19 + *((_DWORD *)&this->CTaskTpl_tagEffTaskParam_CEffGrid::__vftable + 3)));
        v19 -= 152;
        --v6;
      }
      while ( v6 );
    }
    operator delete(*(&this->CTaskTpl_tagEffTaskParam_CEffGrid::__vftable + 3));
  }
LABEL_10:
  this->m_nXDivision = (__int64)pType->fSacleX;
  fSacleZ = (__int64)pType->fSacleZ;
  this->m_nZDivision = fSacleZ;
  fSacleY = pType->fSacleY;
  this->m_nQuad = this->m_nXDivision * fSacleZ;
  this->m_fGridSize = fSacleY;
  this->m_fFramePerSec = pType->fFramePerSec;
  this->m_vecPos.x = pType->fX;
  this->m_vecPos.y = pType->fY;
  this->m_vecPos.z = pType->fZ;
  this->m_vecRot.x = pType->fStartXRot;
  this->m_vecRot.y = pType->fStartYRot;
  this->m_vecRot.z = pType->fStartZRot;
  this->m_bAdditiveBlend = pType->bAdditiveBlend;
  this->m_bNoZTest = pType->bNoZTest;
  this->m_byMaxFrame = pType->nFrame;
  this->m_nRequireLoops = (int)&byte_FFFFFF;
  this->m_dwStartColor = pType->dwColor;
  this->m_fWavePower = pType->fTopRadius;
  this->m_fWaveSpeed = pType->fBottomRadius;
  this->m_fFlapPower = pType->fTextureRepeat;
  this->m_fFlapSpeed = pType->fTopRadiusIncSpeed;
  sub_4CAB30(pType->nFramePerRow, pType->nFramePerCol);
  m_nQuad = this->m_nQuad;
  v15 = (gbGeomQuad *)operator new(68 * m_nQuad);
  v32 = (gbGeomQuad *)v15;
  v41 = 0;
  if ( v15 )
  {
    v16 = m_nQuad - 1;
    v17 = (int)v15;
    if ( v16 >= 0 )
    {
      v18 = v16 + 1;
      do
      {
        v17 += 68;
        --v18;
      }
      while ( v18 );
      v15 = (gbGeomQuad *)v32;
    }
  }
  else
  {
    v15 = 0;
  }
  v41 = -1;
  this->m_pGeomQuad = v15;
  if ( !v15 )
  {
    qmemcpy(
      pExceptionObject,
      (((Logger *)&ArgList))->Logger::FormatException((char *)&g_EffMgrData.m_nTodo_480 + 8, (char *)&g_EffMgrData.m_nTodo_480 + 40, 115),
      sizeof(pExceptionObject));
    _CxxThrowException(pExceptionObject, (_ThrowInfo *)&_TI1_AV_Exception__);
  }
  v20 = (this->m_nXDivision + 1) * (this->m_nZDivision + 1);
  v21 = (gbVec3D *)operator new(12 * v20);
  v33 = (gbVec3D *)v21;
  v41 = 1;
  if ( v21 )
  {
    v22 = v20 - 1;
    v23 = (gbVec3D *)v21;
    if ( v22 >= 0 )
    {
      v24 = v22 + 1;
      do
      {
        --v24;
      }
      while ( v24 );
      v21 = (gbVec3D *)v33;
    }
  }
  else
  {
    v21 = 0;
  }
  v25 = (this->m_nXDivision + 1) * (this->m_nZDivision + 1);
  this->m_pMesh = v21;
  v26 = (gbVec3D *)operator new(12 * v25);
  v34 = (gbVec3D *)v26;
  v41 = 2;
  if ( v26 )
  {
    v27 = v25 - 1;
    v28 = (gbVec3D *)v26;
    if ( v27 >= 0 )
    {
      v29 = v27 + 1;
      do
      {
        --v29;
      }
      while ( v29 );
      v26 = (gbVec3D *)v34;
    }
  }
  else
  {
    v26 = 0;
  }
  m_pMesh = (gbVec3D *)this->m_pMesh;
  v41 = -1;
  this->m_pMesh2 = v26;
  if ( !m_pMesh || !v26 )
  {
    qmemcpy(
      v35,
      (((Logger *)&v38))->Logger::FormatException((char *)&g_EffMgrData.m_nTodo_480 + 8, (char *)&g_EffMgrData.m_nTodo_480 + 40, 124),
      sizeof(v35));
    _CxxThrowException(v35, (_ThrowInfo *)&_TI1_AV_Exception__);
  }
  sub_4CABE0(pType->szTexture);
  sub_4CAC70(this);
  return 1;
}

// 0x004C9CA0
int CEffGrid::slot_6(int a2, int a3)
{
  int result; // eax
  char m_bAdditiveBlend; // al
  bool v6; // zf
  CEffMgr *m_pEM; // eax
  gbRenderEffect *m_pAlphaBlendNoZ; // ebp
  gbMatrixStack *v9; // edi
  float v10; // [esp+0x3C] [ebp-0xC]
  float retaddr; // [esp+0x48] [ebp+0x0] BYREF

  if ( (*(_BYTE *)(&g_PAL3.m_nCEffCylinderCount + 13) & 1) == 0 )
  {
    *(&g_PAL3.m_nCEffCylinderCount + 10) = 1065353216;
    *((_BYTE *)&g_PAL3.m_nCEffCylinderCount + 52) |= 1u;
    *(&g_PAL3.m_nCEffCylinderCount + 11) = 0;
    *(&g_PAL3.m_nCEffCylinderCount + 12) = 0;
    result = atexit(nullsub_85);
  }
  if ( (*(_BYTE *)(&g_PAL3.m_nCEffCylinderCount + 13) & 2) == 0 )
  {
    *(&g_PAL3.m_nCEffCylinderCount + 6) = 0;
    *((_BYTE *)&g_PAL3.m_nCEffCylinderCount + 52) |= 2u;
    *(&g_PAL3.m_nCEffCylinderCount + 7) = 1065353216;
    *(&g_PAL3.m_nCEffCylinderCount + 8) = 0;
    result = atexit(nullsub_84);
  }
  if ( (*(_BYTE *)(&g_PAL3.m_nCEffCylinderCount + 13) & 4) == 0 )
  {
    *(&g_PAL3.m_nCEffCylinderCount + 2) = 0;
    *((_BYTE *)&g_PAL3.m_nCEffCylinderCount + 52) |= 4u;
    *(&g_PAL3.m_nCEffCylinderCount + 3) = 0;
    *(&g_PAL3.m_nCEffCylinderCount + 4) = 1065353216;
    result = atexit(nullsub_83);
  }
  LOBYTE(result) = this->m_bIdle;
  if ( !(_BYTE)result )
  {
    LOBYTE(result) = this->m_bVisible;
    if ( (_BYTE)result )
    {
      (((gbVertPoolMgr *)this->m_pEM->m_pDisplay->pVertPoolMgr))->gbVertPoolMgr::GetDynVertBuf(0x15u);
      m_bAdditiveBlend = this->m_bAdditiveBlend;
      if ( this->m_bNoZTest )
      {
        v6 = m_bAdditiveBlend == 0;
        m_pEM = this->m_pEM;
        if ( v6 )
          m_pAlphaBlendNoZ = (gbRenderEffect *)m_pEM->m_pAlphaBlendNoZ;
        else
          m_pAlphaBlendNoZ = (gbRenderEffect *)m_pEM->m_pAdditiveBlendNoZ;
      }
      else
      {
        v6 = m_bAdditiveBlend == 0;
        m_pEM = this->m_pEM;
        if ( v6 )
          m_pAlphaBlendNoZ = (gbRenderEffect *)m_pEM->m_pAlphaBlend;
        else
          m_pAlphaBlendNoZ = (gbRenderEffect *)m_pEM->m_pAdditiveBlend;
      }
      v9 = (gbMatrixStack *)m_pEM->m_pDisplay->pMatrixStack[1];
      (((gbMatrixStack *)v9))->gbMatrixStack::Push();
      v10 = this->m_vecOffsetPos.x + this->m_vecPos.x;
      retaddr = v10;
      (((gbMatrixStack *)v9))->gbMatrixStack::Translate(*(gbVec3D *)&retaddr);
      (((gbMatrixStack *)v9))->gbMatrixStack::Scale(this->m_fXSize,   1.0,   this->m_fZSize);
      (((gbMatrixStack *)v9))->gbMatrixStack::Rotate(this->m_vecRot.x, * (gbVec3D *)(&g_PAL3.m_nCEffCylinderCount + 10));
      (((gbMatrixStack *)v9))->gbMatrixStack::Rotate(this->m_vecRot.y, * (gbVec3D *)&g_PAL3.m_nCEffCylinderCount + 2);
      (((gbMatrixStack *)v9))->gbMatrixStack::Rotate(this->m_vecRot.z, * (gbVec3D *)(&g_PAL3.m_nCEffCylinderCount + 2));
      (((gbDynVertBuf *)this->m_pGeomQuad))->gbDynVertBuf::RenderGeomQuad(this->m_nQuad, m_pAlphaBlendNoZ, this->m_pTextureArray);
      (((gbMatrixStack *)v9))->gbMatrixStack::Pop();
    }
  }
  return result;
}

// 0x004C9ED0

// ---- synthesized vtable stubs (unresolved slots) ----
// [VFTABLE-STUB] original: (*((void ( **)(CTaskTpl_tagEffTaskParam_CEffGrid *, _DWORD, _DWORD, _DWORD))v4->__vftable + 1))( v4, *(_DWORD *)(*(_DWORD *)v11 + v13), *(_DWORD *)(*(_DWORD *)v11 + v13 + 4), 0)
static void pal3_vtbl_unk_0(CTaskTpl_tagEffTaskParam_CEffGrid *, _DWORD, _DWORD, _DWORD);

int CEffGrid::slot_5(int a2)
{
  CEffGrid *v2; // edi
  double v3; // st7
  CTaskTpl_tagEffTaskParam_CEffGrid *v4; // esi
  __int16 v5; // fps
  double v6; // st7
  bool v7; // c0
  char v8; // c2
  bool v9; // c3
  int result; // eax
  int v11; // ebx
  int v12; // edx
  int v13; // edi
  int v14; // ecx
  int v15; // eax
  int v16; // edx
  bool v17; // cc
  int v18; // esi
  int v19; // edx
  int m_nXDivision; // ecx
  double eu; // st7
  int m_nZDivision; // edx
  double v23; // st7
  int v24; // edx
  int v25; // eax
  int v26; // [esp+0x0] [ebp-0x14]
  float v27; // [esp+0x4] [ebp-0x10]
  float v29; // [esp+0x8] [ebp-0xC]
  int v30; // [esp+0xC] [ebp-0x8]
  float v31; // [esp+0xC] [ebp-0x8]
  int v32; // [esp+0x10] [ebp-0x4]
  float v33; // [esp+0x10] [ebp-0x4]
  int a2a; // [esp+0x1C] [ebp+0x8]
  int a2b; // [esp+0x1C] [ebp+0x8]
HIWORD(result) = HIWORD(a2);
  v3 = *(float *)&a2 - *((float *)&this->CTaskTpl_tagEffTaskParam_CEffGrid::__vftable + 1);
  v4 = ((CTaskTpl_tagEffTaskParam_CEffGrid *)this);
  *((float *)&this->CTaskTpl_tagEffTaskParam_CEffGrid::__vftable + 1) = *(float *)&a2;
  *((float *)&this->CTaskTpl_tagEffTaskParam_CEffGrid::__vftable + 2) = v3;
  v6 = *((float *)&this->CTaskTpl_tagEffTaskParam_CEffGrid::__vftable + 2);
  v7 = v6 < 0.0;
  v8 = 0;
  v9 = v6 == 0.0;
  LOWORD(result) = v5;
  if ( v6 > 0.0 )
  {
    a2a = 0;
    if ( *((int *)&this->CTaskTpl_tagEffTaskParam_CEffGrid::__vftable + 7) > 0 )
    {
      v32 = 0;
      while ( 1 )
      {
        v11 = v32 + *((_DWORD *)((void **)(v4)) + 3);
        if ( *(_BYTE *)(v11 + 148) )
        {
          if ( *(_DWORD *)(v11 + 12) == 3 )
          {
            v12 = 0;
            v30 = 0;
            if ( *((int *)((void **)(v4)) + 8) > 0 )
              break;
          }
        }
LABEL_29:
        v17 = ++a2a < *((_DWORD *)((void **)(v4)) + 7);
        v32 += 152;
        if ( !v17 )
          goto LABEL_30;
      }
      v13 = 0;
      while ( 1 )
      {
        v14 = v13 + *(_DWORD *)v11;
        if ( !*(_BYTE *)(v14 + 64) || v13 > 0 && *(_DWORD *)(v14 - 64) == 2 )
        {
LABEL_28:
goto LABEL_29;
        }
        switch ( *(_DWORD *)(v14 + 8) )
        {
          case 2:
            if ( v13 > 0 )
            {
              if ( *(float *)(v14 + 20) >= 0.0 )
              {
                if ( *((float *)((void **)(v4)) + 1) - *(float *)(v14 - 56) > *(float *)(v14 + 20) )
                {
                  (((CCBStage *)v4))->CCBStage::GetTaskParam(a2a, v12);
                  *((_DWORD *)((void **)(v4)) + 4) = a2a;
                  *((_DWORD *)((void **)(v4)) + 5) = v30;
                  goto LABEL_24;
                }
              }
              else if ( *(_DWORD *)(v14 - 64) == 4 )
              {
                *(_DWORD *)(*(_DWORD *)(v32 + *((_DWORD *)((void **)(v4)) + 3)) + v13 + 8) = 3;
                *(_DWORD *)(*(_DWORD *)(v32 + *((_DWORD *)((void **)(v4)) + 3)) + v13 + 16) = *((_DWORD *)((void **)(v4))
                                                                                             + 1);
LABEL_21:
                *((_DWORD *)((void **)(v4)) + 5) = v12;
                *((_DWORD *)((void **)(v4)) + 4) = a2a;
LABEL_24:
                pal3_vtbl_unk_0(v4, *(_DWORD *)(*(_DWORD *)v11 + v13), *(_DWORD *)(*(_DWORD *)v11 + v13 + 4), 0) /* [VFTABLE-STUB] */;
              }
            }
            break;
          case 3:
            goto LABEL_21;
          case 4:
            if ( (((CCBStage *)v4))->CCBStage::SetTaskState(a2a) )
            {
              v15 = *(_DWORD *)(v11 + 4);
              *(_DWORD *)(v11 + 12) = 4;
              v16 = 9 * v15;
              LOBYTE(v15) = *(_BYTE *)(v11 + 149);
              *(_DWORD *)(v11 + 20) = *(_DWORD *)(*(_DWORD *)v11 + 8 * v16 - 12);
              if ( (_BYTE)v15 == 1 )
              {
                (((CEffgbParticle *)v4))->CEffgbParticle::Init(a2a);
                goto LABEL_28;
              }
            }
            break;
        }
        v12 = v30 + 1;
        v13 += 72;
        if ( ++v30 >= *((_DWORD *)((void **)(v4)) + 8) )
          goto LABEL_28;
      }
    }
LABEL_30:
    result = *((_DWORD *)&this->CTaskTpl_tagEffTaskParam_CEffGrid::__vftable + 6);
    if ( result <= 0 )
      this->m_bIdle = 1;
    LOBYTE(result) = this->m_bIdle;
    if ( !(_BYTE)result )
    {
      this->m_fCurFrame = this->m_fFramePerSec * *((float *)&this->CTaskTpl_tagEffTaskParam_CEffGrid::__vftable + 2)
                      + this->m_fCurFrame;
      if ( (g_bEffSystemFlags & 1) == 0 )
      {
        g_bEffSystemFlags |= 1u;
        (((CEffMgr *)&g_pCEffMgrBackup))->CEffMgr::Reset();
        atexit(todo_401800);
      }
      v18 = 0;
      v19 = (int)abs32((int)this->m_fCurFrame) % (unsigned __int8)this->m_byMaxFrame;
      m_nXDivision = this->m_nXDivision;
      eu = this->m_DefaultUVSet[v19].eu;
      result = (int)v2 + 16 * v19;
      m_nZDivision = this->m_nZDivision;
      v26 = result;
      v33 = (eu - *(float *)(result + 184)) * (1.0 / (double)m_nXDivision);
      a2b = 0;
      v29 = (*(float *)(result + 196) - *(float *)(result + 188)) * (1.0 / (double)m_nZDivision);
      if ( m_nZDivision > 0 )
      {
        do
        {
          v23 = *(float *)(result + 184);
          v24 = 0;
          v31 = (double)a2b * v29 + *(float *)(result + 188);
          if ( m_nXDivision > 0 )
          {
            v25 = v18;
            do
            {
              ++v18;
              this->m_pGeomQuad[v25].su = v23;
              v23 = v23 + v33;
              ++v25;
              ++v24;
              this->m_pGeomQuad[v25 - 1].eu = v23;
              this->m_pGeomQuad[v25 - 1].sv = v31;
              v27 = v29 + v31;
              this->m_pGeomQuad[v25 - 1].ev = v27;
              this->m_pGeomQuad[v25 - 1].color = this->m_dwStartColor;
              m_nXDivision = this->m_nXDivision;
            }
            while ( v24 < m_nXDivision );
            result = v26;
          }
          ++a2b;
        }
        while ( a2b < this->m_nZDivision );
      }
    }
  }
  return result;
}

static void pal3_vtbl_unk_0(CTaskTpl_tagEffTaskParam_CEffGrid *, _DWORD, _DWORD, _DWORD)
{
    
}


// 0x004CA1D0
int CEffGrid::RenderEffectPass(int a2)
{
  int result; // eax
  CTaskTpl_tagEffTaskParam_CEffGrid *v3; // ebx
  int v4; // ecx
  int v5; // edx
  int v6; // esi
  int v7; // ebp
  unsigned int v8; // eax
  int v9; // ecx
  int v10; // eax
  int v11; // edi
  _BYTE *v12; // esi
  int ( **v13)(CEffect *, int); // esi
  unsigned int v14; // eax
  int v15; // ecx
  int v16; // eax
  int v17; // edi
  _BYTE *v18; // esi
  int ( **v19)(CEffect *, int); // esi
  unsigned int v20; // eax

  v3 = ((CTaskTpl_tagEffTaskParam_CEffGrid *)this);
  v4 = *((_DWORD *)&this->CTaskTpl_tagEffTaskParam_CEffGrid::__vftable + 7);
  v5 = 0;
  if ( v4 > 0 )
  {
    v6 = *((_DWORD *)((void **)(v3)) + 3);
    result = v6 + 148;
    while ( *(_BYTE *)result )
    {
      ++v5;
      result += 152;
      if ( v5 >= v4 )
        return result;
    }
    v7 = 152 * v5;
    *(_DWORD *)(v6 + v7 + 12) = 2;
    *(_BYTE *)(*((_DWORD *)((void **)(v3)) + 3) + v7 + 148) = 1;
    *(_BYTE *)(*((_DWORD *)((void **)(v3)) + 3) + v7 + 149) = 1;
    v8 = ++*(&g_PAL3.m_nCEffCylinderCount + 14);
    if ( !*(&g_PAL3.m_nCEffCylinderCount + 14) || v8 >= 0x7FFFFFFF )
    {
      v8 = 1;
      *(&g_PAL3.m_nCEffCylinderCount + 14) = 1;
    }
    *(_DWORD *)(*((_DWORD *)((void **)(v3)) + 3) + v7 + 16) = v8;
    *(_DWORD *)(*((_DWORD *)((void **)(v3)) + 3) + v7 + 4) = 0;
    *(_DWORD *)(*((_DWORD *)((void **)(v3)) + 3) + v7 + 8) = 0;
    result = *((_DWORD *)((void **)(v3)) + 3);
    *(_DWORD *)(result + v7 + 20) = 0;
    if ( a2 )
    {
      qmemcpy((void *)(*((_DWORD *)((void **)(v3)) + 3) + v7 + 24), (const void *)a2, 0x7Cu);
    }
    else
    {
      result = 0;
      memset((void *)(*((_DWORD *)((void **)(v3)) + 3) + v7 + 24), 0, 0x7Cu);
    }
    ++*((_DWORD *)((void **)(v3)) + 6);
    if ( v5 != -1 )
    {
      v9 = *((_DWORD *)((void **)(v3)) + 8);
      v10 = 0;
      if ( v9 > 0 )
      {
        v11 = *(_DWORD *)(*((_DWORD *)((void **)(v3)) + 3) + 152 * v5);
        v12 = (_BYTE *)(v11 + 64);
        while ( *v12 )
        {
          ++v10;
          v12 += 72;
          if ( v10 >= v9 )
            goto LABEL_22;
        }
        v13 = (int ( **)(CEffect *, int))(v11 + 72 * v10);
        memset(v13, 0, 0x48u);
        *v13 = CEffect::SetParam;
        *((_BYTE *)v13 + 64) = 1;
        *((_BYTE *)v13 + 65) = 0;
        v13[1] = 0;
        v13[2] = (int ( *)(CEffect *, int))2;
        v14 = ++*(&g_PAL3.m_nCEffCylinderCount + 14);
        if ( !*(&g_PAL3.m_nCEffCylinderCount + 14) || v14 >= 0x7FFFFFFF )
        {
          v14 = 1;
          *(&g_PAL3.m_nCEffCylinderCount + 14) = 1;
        }
        v13[3] = (int ( *)(CEffect *, int))v14;
        v13[5] = 0;
        v13[4] = 0;
        v13[6] = 0;
        ++*(_DWORD *)(*((_DWORD *)((void **)(v3)) + 3) + v7 + 4);
      }
LABEL_22:
      v15 = *((_DWORD *)((void **)(v3)) + 8);
      v16 = 0;
      if ( v15 > 0 )
      {
        v17 = *(_DWORD *)(*((_DWORD *)((void **)(v3)) + 3) + 152 * v5);
        v18 = (_BYTE *)(v17 + 64);
        while ( *v18 )
        {
          ++v16;
          v18 += 72;
          if ( v16 >= v15 )
            goto LABEL_31;
        }
        v19 = (int ( **)(CEffect *, int))(v17 + 72 * v16);
        memset(v19, 0, 0x48u);
        *v19 = CEffect::SetParam;
        *((_BYTE *)v19 + 64) = 1;
        *((_BYTE *)v19 + 65) = 0;
        v19[1] = 0;
        v19[2] = (int ( *)(CEffect *, int))2;
        v20 = ++*(&g_PAL3.m_nCEffCylinderCount + 14);
        if ( !*(&g_PAL3.m_nCEffCylinderCount + 14) || v20 >= 0x7FFFFFFF )
        {
          v20 = 1;
          *(&g_PAL3.m_nCEffCylinderCount + 14) = 1;
        }
        v19[3] = (int ( *)(CEffect *, int))v20;
        v19[5] = 0;
        v19[4] = 0;
        v19[6] = 0;
        ++*(_DWORD *)(*((_DWORD *)((void **)(v3)) + 3) + v7 + 4);
      }
LABEL_31:
      sub_4CB130(v5, CEffCylinder::UpdateGeometry, 0, 0, *(_DWORD *)(a2 + 72), *(_DWORD *)(a2 + 76));
      *(_DWORD *)(*((_DWORD *)((void **)(v3)) + 3) + v7 + 12) = 3;
      *(_DWORD *)(*(_DWORD *)(*((_DWORD *)((void **)(v3)) + 3) + v7) + 8) = 3;
      result = *(_DWORD *)(*((_DWORD *)((void **)(v3)) + 3) + v7);
      *(_DWORD *)(result + 16) = *((_DWORD *)((void **)(v3)) + 1);
    }
  }
  return result;
}

// 0x004CA9A0
const char * CEffGrid::GetEditorObjDescription(int nIndex)
{
  const char *result; // eax

  switch ( nIndex )
  {
    case 0:
      result = (const char *)&g_EffMgrData.m_nEffParam_02A4;
      break;
    case 1:
      result = (const char *)&g_EffMgrData.m_nEffParam9;
      break;
    case 2:
      result = (const char *)&g_EffMgrData.m_nEffParam8;
      break;
    case 3:
      result = (const char *)&g_EffMgrData.m_nEffParam7;
      break;
    case 4:
      result = (const char *)&g_EffMgrData.m_nEffParam6;
      break;
    case 5:
      result = (const char *)&g_EffMgrData.m_nEffParam_029C;
      break;
    case 6:
      result = (const char *)&g_EffMgrData.m_nEffParam_0294;
      break;
    case 7:
      result = (const char *)&g_EffMgrData.m_nEffParam_028C;
      break;
    case 8:
      result = (const char *)&g_EffMgrData.m_nEffParam2;
      break;
    case 9:
      result = (const char *)(&g_EffMgrData.m_nEffTypeCode + 8);
      break;
    case 10:
      result = (const char *)&g_EffMgrData.m_nEffParam_404;
      break;
    case 12:
      result = (const char *)&g_EffMgrData.m_nEffTypeCode;
      break;
    case 13:
      result = (const char *)&g_EffMgrData.m_nEffTypeID;
      break;
    case 14:
      result = (const char *)&g_EffMgrData.m_nEffParam1;
      break;
    case 15:
      result = (const char *)&g_EffMgrData.m_nEffParam0;
      break;
    case 16:
      result = (const char *)&g_EffMgrData;
      break;
    case 17:
      result = (const char *)&g_EffMgrData.m_nEffParam_0268;
      break;
    case 18:
      result = (const char *)&g_EffMgrData.m_nEffParam_025C;
      break;
    case 19:
      result = (const char *)&g_EffMgrData.m_nEffParam_0250;
      break;
    case 20:
      result = (const char *)&g_pszEditorDesc;
      break;
    default:
      result = g_EffCylinderEditorData;
      break;
  }
  return result;
}

// 0x004CAAB0
int CEffGrid::DispatchByType(int a2)
{
  int result; // eax

  switch ( a2 )
  {
    case 0:
      result = (int)&g_EffMgrData.m_nTodo_4FC;
      break;
    case 1:
      result = (int)&g_EffMgrData.m_nTodo_464;
      break;
    case 2:
      result = (int)&g_EffMgrData.m_nTodo_458;
      break;
    case 3:
      result = (int)&g_EffMgrData.m_nTodo_44C;
      break;
    case 4:
      result = (int)&g_EffMgrData.m_nTodo_4F0;
      break;
    case 5:
      result = (int)&g_EffMgrData.m_nTodo_4E4;
      break;
    case 6:
      result = (int)&g_EffMgrData.m_nTodo_4D8;
      break;
    case 7:
      result = (int)&g_EffMgrData.m_nTodo_4CC;
      break;
    default:
      result = (int)g_EffCylinderEditorData;
      break;
  }
  return result;
}
