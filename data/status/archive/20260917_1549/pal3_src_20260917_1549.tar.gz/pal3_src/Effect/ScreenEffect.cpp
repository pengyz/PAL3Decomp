#include "pal3/ida_defs.h"
#include "globals.h"
#include "pal3/pal3_constants.h"
#include "Effect/ScreenEffect.h"
#include "Render/RenderTarget.h"
#include "Misc/TextureLibDataBase.h"
#include "free_functions.h"

// Forward declarations for unnamed functions

// 0x004B4DC0
void ScreenEffect::Apply()
{
  double m_needscriptdel; // st7
  double vftable; // st6
  TextureLibDataBase *v3; // edi
  char *v4; // ebx
  double v5; // st7
  TextureLibDataBase *v6; // ebp
  __int64 v7; // rax
  int v8; // [esp+0x14] [ebp+0x4]

  if ( LOBYTE(this[5].m_nType) )
  {
    m_needscriptdel = (double)(int)this[1].m_needscriptdel;
    vftable = (double)(int)(*(void **)&(this[1]));
    v3 = (TextureLibDataBase *)(__int64)(*(float *)&this[5].m_hold - m_needscriptdel);
    v4 = (char *)(__int64)(this[5].m_age - vftable);
    v5 = m_needscriptdel + *(float *)&this[5].m_hold;
    v6 = (TextureLibDataBase *)(__int64)(vftable + this[5].m_age);
    v7 = (__int64)v5;
    switch ( v8 )
    {
      case 1:
        /* [MISATTRIBUTED] TextureLibDataBase on ScreenEffect::this -> fix IDB name of callee */ TextureLibDataBase::AutoScrollParticles((TextureLibDataBase *)this, v4, (int)v3, v6, v7);
        break;
      case 2:
        /* [MISATTRIBUTED] TextureLibDataBase on ScreenEffect::this -> fix IDB name of callee */ TextureLibDataBase::AutoScrollParticlesEx((TextureLibDataBase *)this, v4, v3, (int)v6, (__int64)v5);
        break;
      case 3:
        /* [MISATTRIBUTED] TextureLibDataBase on ScreenEffect::this -> fix IDB name of callee */ TextureLibDataBase::UpdateCircularMotion((TextureLibDataBase *)this, v4, (int)v3, v6, v7);
        break;
      case 4:
        /* [MISATTRIBUTED] TextureLibDataBase on ScreenEffect::this -> fix IDB name of callee */ TextureLibDataBase::UpdateOrbitalMotion((TextureLibDataBase *)this, v4, (int)v3, v6, (__int64)v5);
        break;
      case 5:
        sub_4B5570((int)this, (int)v4, (int)v3, v6, v7);
        break;
      case 6:
        /* [MISATTRIBUTED] TextureLibDataBase on ScreenEffect::this -> fix IDB name of callee */ TextureLibDataBase::UpdateLinearMotion((TextureLibDataBase *)this, v4, (int)v3, v6, (__int64)v5);
        break;
      case 7:
        sub_4B5830((float *)this, (int)v4, (int)v3, v6, v7);
        break;
      case 8:
        sub_4B5BB0((float *)this, (int)v4, (int)v3, v6, v7);
        break;
      case 9:
        sub_4B59B0((float *)this, (int)v4, v3, (int)v6, (__int64)v5);
        break;
      case 10:
        /* [MISATTRIBUTED] TextureLibDataBase on ScreenEffect::this -> fix IDB name of callee */ TextureLibDataBase::LoadLibrary((TextureLibDataBase *)this, v4, (int)v3, v6, v7);
        break;
      case 11:
        /* [MISATTRIBUTED] TextureLibDataBase on ScreenEffect::this -> fix IDB name of callee */ TextureLibDataBase::UpdateByMode((TextureLibDataBase *)this, v4, (int)v3, v6, (__int64)v5);
        break;
      case 12:
        /* [MISATTRIBUTED] TextureLibDataBase on ScreenEffect::this -> fix IDB name of callee */ TextureLibDataBase::RenderFrame((TextureLibDataBase *)this, (int)v4, (int)v3, (int)v6, (__int64)v5);
        break;
      case 13:
        /* [MISATTRIBUTED] TextureLibDataBase on ScreenEffect::this -> fix IDB name of callee */ TextureLibDataBase::GetTextureByName((TextureLibDataBase *)this, v4, (int)v3, v6, v7);
        break;
      default:
        return;
    }
  }
}

// 0x004BDFB0
ScreenEffect::ScreenEffect()
{
  char v3; // [esp+0xB] [ebp-0x11]

  (((RenderTarget *)&this->m_needscriptdel))->RenderTarget::ResetHorizontal();
  (((RenderTarget *)&this[1].m_nType))->RenderTarget::ResetVertical();
  (((RenderTarget *)&this[2].m_nType))->RenderTarget::ResetVertical2();
  (((RenderTarget *)&this[3].m_nType))->RenderTarget::ResetBase();
  LOBYTE(this[4].m_nType) = v3;
  this[4].m_life = 0;
  this[4].m_age = 0.0;
  *(_DWORD *)&this[4].m_hold = 0;
  (*(void **)&(this[5])) = (void *)(0);
  this[5].m_needscriptdel = 0;
  this[5].m_nType = 0;
  this[5].m_life = 0;
  this[5].m_age = 0.0;
  *(_DWORD *)&this[5].m_hold = 0;
  (*(void **)&(this[6])) = (void *)(0);
  this[6].m_needscriptdel = 0;
  this;
}

// 0x004BE830
void ScreenEffect::CopyParams(int *pParams)
{
  gbImage2D *v2; // edx
  void **v3; // [esp+0x8] [ebp+0x8]

  (*(void **)(this)) = (void *)(*v3);
  v2 = (gbImage2D *)((char *)*v3 + 4096);
  this->m_life = (int)v3;
  this->m_needscriptdel = v2;
  this->m_nType = (int)pParams;
}
