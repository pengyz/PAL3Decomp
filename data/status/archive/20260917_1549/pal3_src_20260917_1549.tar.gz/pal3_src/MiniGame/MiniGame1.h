#pragma once
// Auto-generated: MiniGame1
#include "pal3/ida_types.h"

class MiniGame1 {
public:
    _BYTE _tail_000[4]; // +0x0
    // total size: 0x4 (4)

    void Render(); // 0x0052B860
    // Scalar-wrapper: ctors for IDA (Cls)int casts (no init code)
    MiniGame1() {}
    MiniGame1(int v) { *(int*)this = v; }

};
