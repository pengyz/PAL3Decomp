#pragma once
// Auto-generated: _strflt
#include "pal3/ida_types.h"

class _strflt {
public:
    int sign; // +0x0
    int decpt; // +0x4
    int flag; // +0x8
    char * mantissa; // +0xC
    // total size: 0x10 (16)

};
