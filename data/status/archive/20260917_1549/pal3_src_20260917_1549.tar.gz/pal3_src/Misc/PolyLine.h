#pragma once
// Auto-generated: PolyLine
#include "pal3/ida_types.h"

#include "gbengine/gbengine_types.h"

class PolyLine {
public:
    int numpt; // +0x0
    gbVec3D pt[16]; // +0x4
    // total size: 0xC4 (196)

};
