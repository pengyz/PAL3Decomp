#pragma once
// Auto-generated: _Tex_uv
#include "pal3/ida_types.h"

class _Tex_uv {
public:
    float u; // +0x0
    float v; // +0x4
    // total size: 0x8 (8)

};
