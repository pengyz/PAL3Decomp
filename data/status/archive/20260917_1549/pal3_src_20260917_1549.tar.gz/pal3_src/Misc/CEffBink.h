#include "Misc/CTaskTpl_tagEffTaskParam_CEffBink.h"
#include "Misc/CEffObj.h"
#pragma once
// Auto-generated: CEffBink
#include "pal3/ida_types.h"

class CEffBink : public CEffObj, public CTaskTpl_tagEffTaskParam_CEffBink {
public:
    char _gap_000[48]; // +0x0
    char m_szBinkNamePrefix[128]; // +0x30
    char m_szBinkName[128]; // +0xB0
    // total size: 0x130 (304)

};
