#pragma once
// Auto-generated: UIStaticFlex_State
#include "pal3/ida_types.h"

class UIStaticFlex_State {
public:
    _BYTE _tail_000[4]; // +0x0
    // total size: 0x4 (4)

    // Scalar-wrapper: ctors for IDA (Cls)int casts (no init code)
    UIStaticFlex_State() {}
    UIStaticFlex_State(int v) { *(int*)this = v; }

};
