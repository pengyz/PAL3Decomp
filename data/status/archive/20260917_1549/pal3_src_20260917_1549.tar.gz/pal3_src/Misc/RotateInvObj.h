#include "Misc/PalScriptWaitObj.h"
#pragma once
// Auto-generated: RotateInvObj
#include "pal3/ida_types.h"

#include "gbengine/gbengine_types.h"

class RotateInvObj : public PalScriptWaitObj {
public:
    char _gap_000[8]; // +0x0
    float m_passedtime; // +0x8
    BYTE end; // +0xC
    char _gap_00D[3]; // +0xD
    gbVec3D m_rotate; // +0x10
    // total size: 0x1C (28)

};
