#include "Misc/UIFrameWnd.h"
#pragma once
// Auto-generated: JusticeBookUI
#include "pal3/ida_types.h"

#include "Misc/JB_TYPE.h"
#include "Misc/UI3DCtrl.h"
#include "Misc/UIButton.h"
#include "Misc/UIPushButton.h"
#include "Misc/UIStatic.h"

class UIWnd;

class JusticeBookUI : public UIFrameWnd {
public:
    char _gap_000[72]; // +0x0
    tagRECT rc; // +0x48
    int bkWndX; // +0x58
    int bkWndY; // +0x5C
    int i; // +0x60
    int j; // +0x64
    char buf[256]; // +0x68
    BYTE m_IsMsg; // +0x168
    BYTE m_IsActive; // +0x169
    BYTE m_IsExit; // +0x16A
    BYTE m_IsOpen; // +0x16B
    UIStatic m_BK; // +0x16C
    char _gap_204[8]; // +0x204
    UIButton m_Exit; // +0x20C
    UIStatic m_OutFrameT; // +0x364
    char _gap_3FC[8]; // +0x3FC
    UIStatic m_OutFrameR; // +0x404
    char _gap_49C[8]; // +0x49C
    UIStatic m_OutFrameL; // +0x4A4
    char _gap_53C[8]; // +0x53C
    UIStatic m_OutFrameB; // +0x544
    char _gap_5DC[8]; // +0x5DC
    UI3DCtrl m_JusticeBook; // +0x5E4
    UI3DCtrl m_Monster; // +0x718
    UIStatic m_Name; // +0x84C
    char _gap_8E4[8]; // +0x8E4
    UIStatic m_H; // +0x8EC
    char _gap_984[8]; // +0x984
    UIStatic m_S; // +0x98C
    char _gap_A24[8]; // +0xA24
    UIStatic m_Wuling[5]; // +0xA2C
    char _gap_D24[40]; // +0xD24
    UIStatic m_Att[5]; // +0xD4C
    char _gap_1044[40]; // +0x1044
    UIStatic m_Sorcery[4]; // +0x106C
    char _gap_12CC[32]; // +0x12CC
    tagRECT m_SorceryRc[4]; // +0x12EC
    UIStatic m_Remark; // +0x132C
    char _gap_13C4[8]; // +0x13C4
    UIStatic m_Number; // +0x13CC
    char _gap_1464[8]; // +0x1464
    UIButton m_PgUp; // +0x146C
    UIButton m_PgDw; // +0x15C4
    UIPushButton m_tpGods; // +0x171C
    UIPushButton m_tpImmortal; // +0x1818
    UIPushButton m_tpGhost; // +0x1914
    UIPushButton m_tpDemon; // +0x1A10
    UIPushButton m_tpHuman; // +0x1B0C
    UIPushButton m_tpMagic; // +0x1C08
    UIPushButton m_tpGods_unopen; // +0x1D04
    UIPushButton m_tpImmortal_unopen; // +0x1E00
    UIPushButton m_tpGhost_unopen; // +0x1EFC
    UIPushButton m_tpDemon_unopen; // +0x1FF8
    UIPushButton m_tpHuman_unopen; // +0x20F4
    UIPushButton m_tpMagic_unopen; // +0x21F0
    DWORD * m_allMonsters; // +0x22EC
    int m_MonstersNum; // +0x22F0
    int m_tpNum[6]; // +0x22F4
    DWORD m_tpID[100][6]; // +0x230C
    JB_TYPE m_bookMark; // +0x2C6C
    char _gap_2C6D[3]; // +0x2C6D
    JB_TYPE m_curMark; // +0x2C70
    char _gap_2C71[3]; // +0x2C71
    int m_Page; // +0x2C74
    char _tail_2C78[44808]; // +0x2C78
    // total size: 0xDB80 (56192)

    virtual ~JusticeBookUI() {}

    static int JusticeBookUI_Render(int nVal); // 0x00528ED0
    virtual int ProcessInput(int nVal, int nVal2); // 0x00528F50
    void * _scalar_dtor(UIWnd *Block, char pData); // 0x005284C0
    virtual int OnMessage(int nVal, char *pszBuf, int nVal2); // 0x00529120
    char UpdateFadeAnim(float fDelta); // 0x0044DA30
    int ctor(); // 0x005282E0
    JusticeBookUI(); // 0x005284E0
};
