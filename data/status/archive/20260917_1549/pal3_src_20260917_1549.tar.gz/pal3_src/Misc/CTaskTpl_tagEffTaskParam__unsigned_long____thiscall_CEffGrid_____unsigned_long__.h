#include "Misc/tagEffTaskParam.h"
#include "Misc/CTaskTpl.h"
#pragma once
// Auto-generated: CTaskTpl<tagEffTaskParam, unsigned long (__thiscall CEffGrid::*)(unsigned long)>
#include "pal3/ida_types.h"

class CEffGrid;
typedef unsigned long (CEffGrid::*_CEffGrid_cb)(unsigned long);
template<>
class CTaskTpl<tagEffTaskParam, _CEffGrid_cb> {
public:
    char _tail_000[36]; // +0x0
    // total size: 0x24 (36)

};
