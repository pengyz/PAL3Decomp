#pragma once
// Auto-generated: tagLoggerCallback
#include "pal3/ida_types.h"

class tagLoggerCallback {
public:
    char szName[32]; // +0x0
    char szDesc[100]; // +0x20
    int * pfn; // +0x84
    // total size: 0x88 (136)

    int& operator[](int i) { return ((int*)pfn)[i]; }
};
