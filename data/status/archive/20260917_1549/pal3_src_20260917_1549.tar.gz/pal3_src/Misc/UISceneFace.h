#include "UI/UIWnd.h"
#pragma once
// Auto-generated: UISceneFace
#include "pal3/ida_types.h"

#include "Misc/UIProgressBar.h"
#include "Misc/UIStatic.h"

class UISceneFace : public UIWnd {
public:
    char _gap_000[68]; // +0x0
    UIProgressBar m_hp; // +0x44
    UIProgressBar m_mp; // +0x138
    UIStatic m_face[3]; // +0x22C
    UIStatic m_bk; // +0x3F4
    float m_clicktime; // +0x48C
    int m_onclick; // +0x490
    UIStatic m_state[4]; // +0x494
    // total size: 0x6F4 (1780)

    int SetFaceVisible(int nVal, unsigned int dwVal); // 0x0052D010
    int ResetAllSlots(); // 0x0052D0D0
    int UpdateFacePosition(); // 0x0052D0F0
};
