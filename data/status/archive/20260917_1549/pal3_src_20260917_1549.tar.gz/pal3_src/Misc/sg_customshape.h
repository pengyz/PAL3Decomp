#pragma once
// Auto-generated: sg_customshape
#include "pal3/ida_types.h"

#include <d3dx9.h>
class sg_customshape {
public:
    D3DXVECTOR3 * intervec; // +0x0
    float * disarray; // +0x4
    int m_iVecnum; // +0x8
    D3DXMATRIX curmat; // +0xC
    char _tail_010[60]; // +0x10
    // total size: 0x4C (76)

};
