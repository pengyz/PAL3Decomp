#pragma once
// Auto-generated: elerandvec_emitter_graph
#include "pal3/ida_types.h"

class elerandvec_emitter_graph {
public:
    char _tail_000[5300]; // +0x0
    // total size: 0x14B4 (5300)

};
