#pragma once
// Auto-generated: StringTable
#include "pal3/ida_types.h"

class StringTable {
public:
    char m_data[16]; // +0x0
    // total size: 0x10 (16)

};
