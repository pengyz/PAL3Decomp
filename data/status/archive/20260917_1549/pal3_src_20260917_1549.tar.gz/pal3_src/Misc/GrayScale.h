#pragma once
// Auto-generated: GrayScale
#include "pal3/ida_types.h"

#include "gbengine/gbTexture.h"

class GrayScale {
public:
    BYTE m_bEnable; // +0x0
    char _gap_001[3]; // +0x1
    gbTexture * m_pTex; // +0x4
    // total size: 0x8 (8)

};
