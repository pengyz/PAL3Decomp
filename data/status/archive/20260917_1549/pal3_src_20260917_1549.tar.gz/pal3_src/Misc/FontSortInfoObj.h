#pragma once
// Auto-generated: FontSortInfoObj
#include "pal3/ida_types.h"

class FontSortInfoObj {
public:
    int index; // +0x0
    float z; // +0x4
    // total size: 0x8 (8)

};
