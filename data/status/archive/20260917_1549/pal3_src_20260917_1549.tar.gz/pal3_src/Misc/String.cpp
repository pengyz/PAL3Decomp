#include "pal3/ida_defs.h"
#include "globals.h"
#include "pal3/pal3_constants.h"
#include "Misc/String.h"
#include "Misc/ScriptSystemData.h"

// 0x004326A0
void String::Assign(char *src, int len)
{
  String v5; // eax
  String v6; // eax
  String v7; // eax
  char *srca; // [esp+0x10] [ebp+0x4]
  String lena; // [esp+0x14] [ebp+0x8]

  if ( len > 0 )
    this[3] = (String)len;
  v5 = *this;
  if ( src )
  {
    if ( v5 )
    {
      if ( (int)src > *(_DWORD *)&this[2] )
      {
        lena = (String)src;
        if ( (int)src <= *(_DWORD *)&this[3] + *(_DWORD *)&this[1] )
          lena = (g_ScriptSystemData.m_String)(*(_DWORD *)&this[3] + *(_DWORD *)&this[1]);
        srca = (char *)malloc(4 * *(_DWORD *)&lena);
        qmemcpy(srca, *(const void **)this, 4 * *(_DWORD *)&this[1]);
        free(*(void **)this);
        this[1] = (String)src;
        *this = (String)srca;
        this[2] = lena;
      }
      else
      {
        this[1] = (String)src;
      }
    }
    else
    {
      v6 = this[3];
      this[1] = (String)src;
      v7 = (g_ScriptSystemData.m_String)&src[*(_DWORD *)&v6];
      this[2] = v7;
      *this = (String)malloc(4 * *(_DWORD *)&v7);
    }
  }
  else
  {
    if ( v5 )
    {
      free(*(void **)this);
      *this = 0;
    }
    this[2] = 0;
    this[1] = 0;
  }
}
