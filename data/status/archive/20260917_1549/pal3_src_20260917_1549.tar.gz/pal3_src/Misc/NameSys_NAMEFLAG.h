#pragma once
// Auto-generated: NameSys_NAMEFLAG
#include "pal3/ida_types.h"

class NameSys_NAMEFLAG {
public:
    _BYTE _tail_000[4]; // +0x0
    // total size: 0x4 (4)

    // Scalar-wrapper: ctors for IDA (Cls)int casts (no init code)
    NameSys_NAMEFLAG() {}
    NameSys_NAMEFLAG(int v) { *(int*)this = v; }

};
