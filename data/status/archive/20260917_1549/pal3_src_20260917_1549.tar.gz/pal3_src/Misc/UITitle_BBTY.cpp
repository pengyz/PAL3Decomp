#include "pal3/ida_defs.h"
#include "globals.h"
#include "pal3/pal3_constants.h"
#include "Misc/UITitle_BBTY.h"
#include "Misc/CCBEditor.h"
#include "Data/CGameData.h"
#include "Render/CScreenMode.h"
#include "Combat/CUtil.h"
#include "GameBase/GRPinput.h"
#include "Role/NPC.h"
#include "GameBase/PAL3.h"
#include "Misc/PtrArray.h"
#include "Role/Role.h"
#include "Role/RoleSystem.h"
#include "Scene/SceneMgr.h"
#include "Scene/SceneObj.h"
#include "Misc/UIButton.h"
#include "Misc/UIFrameWnd.h"
#include "Misc/UIProgressBar.h"
#include "Misc/UIScrollBar.h"
#include "UI/UIWnd.h"
#include "Misc/_PlugInfo.h"
#include "free_functions.h"

// Forward declarations for unnamed functions

// 0x00445CD0
void UITitle_BBTY::Render()
{
  int i; // esi
  _DWORD *v3; // ecx

  if ( this->m_bvisible )
  {
    for ( i = 0; i < this->m_childs.capacity; ++i )
    {
      v3 = *(_DWORD **)&this->m_childs.m_pData[4 * i];
      if ( v3[14] )
        (*(void ( **)(_DWORD *))(*v3 + 4))(v3);
    }
  }
}

// 0x00451CC0
UITitle_BBTY::UITitle_BBTY()
{
  sub_445AA0();
  ctor_17((UIButton *)&this->m_pbktex);
  ctor_17((UIButton *)&this->buf[208]);
  sub_4422E0(&this->m_btn[0].m_benable_snd + 12);
  this->m_btn[1].m_texarray.m_ptex[4] = 0;
  (int)this;
}

// 0x00451DA0
void UITitle_BBTY::ctor()
{
  (((UIFrameWnd *)(&this->m_btn[0].m_benable_snd + 12)))->UIFrameWnd::_UIFrameWnd();
  (((UIButton *)&this->buf[208]))->UIButton::~UIButton();
  (((UIButton *)&this->m_pbktex))->UIButton::~UIButton();
  this->UIWnd::~UIWnd();
}

// 0x004520A0
double UITitle_BBTY::UpdateFrame(double result, int arg0, int arg0a)
{
  double v4; // st7
  CScreenMode *SoundList; // eax
  int v7; // edi
  int v8; // ebp
  NPC *v9; // esi
  void ( **vftable)(NPC *, int); // edx
  unsigned int v11; // ebp
  unsigned int v12; // eax
  PtrArray *p_m_childs; // esi
  LONG *p_bottom; // edi
  _PlugInfo **p_m_disablepicInfo; // ebp
  CScreenMode *v16; // ecx
  CScreenMode *v17; // eax
  float fValue; // [esp+0x0] [ebp-0x44]
  float fValuea; // [esp+0x0] [ebp-0x44]
  float fValueb; // [esp+0x0] [ebp-0x44]
  float fValuec; // [esp+0x0] [ebp-0x44]
  gbColorQuad v22; // [esp+0x14] [ebp-0x30] BYREF
  POINT pt; // [esp+0x1C] [ebp-0x28] BYREF
  RECT rc; // [esp+0x24] [ebp-0x20] BYREF
  _BYTE a2[16]; // [esp+0x34] [ebp-0x10] BYREF

  if ( this->m_bvisible && this->m_benable )
  {
    if ( this->m_btn[1].m_texarray.m_ptex[4] )
    {
      v4 = *(float *)&result + *(float *)&this->m_btn[1].m_texarray.m_ptex[3];
      *(float *)&this->m_btn[1].m_texarray.m_ptex[3] = v4;
      if ( v4 <= 0.80000001 )
        return v4;
      this->m_btn[1].m_texarray.m_ptex[3] = 0;
      this->m_btn[1].m_texarray.m_ptex[4] = 0;
      SoundList = (CScreenMode *)(((CScreenMode *)this))->CScreenMode::GetSoundList() /* [ROWTABLE] */;
      if ( !(((CScreenMode *)SoundList))->CScreenMode::IsAudioReady()
        || *(_DWORD *)(((RoleSystem *)&stru_C10DF0)->m_teamSlotOverlay.m_teamSlots[154] + 1264) == 4
        || g_nCameraUpdateCount <= 0
        || LOBYTE(g_CCBEditorInst.m_dwTrickID[358]) )
      {
        if ( g_CCBEditorInst.m_dwTrickID[361] != 12 )
          return v4;
      }
      else
      {
        (((RoleSystem *)((RoleSystem *)&stru_C10DF0)->m_teamSlotOverlay.m_teamSlots[154]))->RoleSystem::Notify();
      }
      (((CGameData *)&g_gamefrm))->CGameData::Load((CUtil *)5);
    }
    else
    {
      v7 = 352 * (_DWORD)g_SceneMgr.m_nCurrentRoleSlot;
      fValue = (float)*((int *)&g_RoleSlotBuf.m_partyActor.m_nAnimFrame + 352 * (_DWORD)g_SceneMgr.m_nCurrentRoleSlot);
      (((UIScrollBar *)&this->buf[208]))->UIScrollBar::SetRange(fValue);
      fValuea = (float)(int)g_RoleSlotBuf.m_partyActor.m_dwMatMsg[v7 + 2];
      (((UIProgressBar *)&this->buf[208]))->UIProgressBar::FindChildByName(fValuea);
      fValueb = (float)*(int *)((char *)&g_RoleSlotBuf.m_partyActor.m_nAnimFrame + v7 * 4 + 8);
      (((UIScrollBar *)&this->m_pbktex))->UIScrollBar::SetRange(fValueb);
      v4 = (double)(int)g_RoleSlotBuf.m_partyActor.m_dwMatMsg[v7 + 4];
      fValuec = v4;
      (((UIProgressBar *)&this->m_pbktex))->UIProgressBar::FindChildByName(fValuec);
      v8 = 27;
      v9 = (NPC *)&this->m_btn[1].m_texarray.m_ptex[5];
      do
      {
        vftable = (void ( **)(NPC *, int))(*(void **)(v9));
        if ( *((_BYTE *)&g_RoleSlotBuf.m_partyActor.m_Actor + v8 + 4) )
        {
          (*vftable)(v9, 1);
          v4 = (1.0 - *(float *)&g_SceneMgr.m_fFadeTimer / 60.0) * 255.0;
          if ( v4 < 80.0 )
            v4 = 80.0;
          (((NPC *)v9))->NPC::UpdateAnim();
        }
        else
        {
          (*vftable)(v9, 0);
        }
        ++v8;
        v9 = (NPC *)((char *)v9 + 152);
      }
      while ( v8 <= 30 );
      switch ( g_nCurrentEventId )
      {
        case 0u:
          v11 = -11356565;
          break;
        case 1u:
          v11 = -6002966;
          break;
        case 2u:
          v11 = -13002067;
          break;
        case 3u:
          v11 = -2198223;
          break;
        case 4u:
          v11 = -2707878;
          break;
        default:
          v11 = -1;
          break;
      }
      v12 = g_RoleSlotBuf.m_partyActor.m_dwMatMsg[v7 + 2];
      v22.Color = v11;
      if ( (int)(100 * v12) / *(_DWORD *)((char *)&g_RoleSlotBuf.m_partyActor.m_nAnimFrame + v7 * 4) < 25 )
      {
        BYTE2(v22.Color) >>= 2;
        BYTE1(v22.Color) = BYTE1(v22.Color) / 5;
        LOBYTE(v22.Color) = LOBYTE(v22.Color) / 5;
      }
      p_m_childs = (PtrArray *)&this->m_remark.m_childs;
      (((NPC *)&this->m_remark.m_childs))->NPC::UpdateAnim();
      p_bottom = (LONG *)&this->m_btn[0].m_rect.bottom;
      (((NPC *)&this->m_btn[0].m_rect.bottom))->NPC::UpdateAnim();
      p_m_disablepicInfo = (_PlugInfo **)&this->m_btn[0].m_disablepicInfo;
      (((NPC *)&this->m_btn[0].m_disablepicInfo))->NPC::UpdateAnim();
      g_Input.GRPinput::GetCursorPos(&pt);
      rc = *(RECT *)sub_445FE0(a2);
      if ( PtInRect(&rc, pt) && (v17 = (CScreenMode *)(((CScreenMode *)v16))->CScreenMode::GetSoundList(), (((CScreenMode *)v17))->CScreenMode::IsAudioReady()) )
      {
        (*(void ( **)(PtrArray *, _DWORD))p_m_childs->m_pData)(&this->m_remark.m_childs, 0);
        (*(void ( **)(LONG *, int))*p_bottom)(&this->m_btn[0].m_rect.bottom, 1);
        ((void ( *)(_PlugInfo **, _DWORD))(*p_m_disablepicInfo)->filepos)(&this->m_btn[0].m_disablepicInfo, 0);
      }
      else
      {
        (*(void ( **)(PtrArray *, int))p_m_childs->m_pData)(&this->m_remark.m_childs, 1);
        (*(void ( **)(LONG *, _DWORD))*p_bottom)(&this->m_btn[0].m_rect.bottom, 0);
        ((void ( *)(_PlugInfo **, _DWORD))(*p_m_disablepicInfo)->filepos)(&this->m_btn[0].m_disablepicInfo, 0);
      }
      (((SceneObj *)this))->SceneObj::Update(SLODWORD(result), SHIDWORD(result)) /* [ROWTABLE] */;
    }
  }
  return v4;
}

// 0x00452420
int UITitle_BBTY::OnMessage(int nVal, int nVal2, int nVal3)
{
  CScreenMode *Instance; // eax
  PAL3 *v6; // ecx
  const void *v8; // [esp-0x8] [ebp-0xC]

  if ( nVal == 1009 && (nVal2 == 2 || nVal2 == 3) )
  {
    this->m_btn[1].m_texarray.m_ptex[3] = 0;
    this->m_btn[1].m_texarray.m_ptex[4] = (gbTexture *)1;
    v8 = (const void *)off_5A6A3C;
    Instance = (CScreenMode *)CScreenMode::GetInstance();
    (((CScreenMode *)Instance))->CScreenMode::AudioSetPosition(v8, 1);
    (*(void ( **)(PtrArray *, _DWORD))this->m_remark.m_childs.m_pData)(&this->m_remark.m_childs, 0);
    (*(void ( **)(LONG *, _DWORD))this->m_btn[0].m_rect.bottom)(&this->m_btn[0].m_rect.bottom, 0);
    ((void ( *)(_PlugInfo **, int))this->m_btn[0].m_disablepicInfo->filepos)(
      &this->m_btn[0].m_disablepicInfo,
      1);
    (((PAL3 *)v6))->PAL3::DefaultKeyMap(0, 64);
  }
  return 1;
}
