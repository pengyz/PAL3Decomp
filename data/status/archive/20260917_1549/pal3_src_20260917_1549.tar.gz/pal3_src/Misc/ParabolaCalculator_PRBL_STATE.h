#pragma once
// Auto-generated: ParabolaCalculator_PRBL_STATE
#include "pal3/ida_types.h"

class ParabolaCalculator_PRBL_STATE {
public:
    _BYTE _tail_000[4]; // +0x0
    // total size: 0x4 (4)

    // Scalar-wrapper: ctors for IDA (Cls)int casts (no init code)
    ParabolaCalculator_PRBL_STATE() {}
    ParabolaCalculator_PRBL_STATE(int v) { *(int*)this = v; }

};
