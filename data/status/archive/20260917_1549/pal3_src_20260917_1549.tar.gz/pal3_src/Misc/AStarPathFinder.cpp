#include "pal3/ida_defs.h"
#include "globals.h"
#include "pal3/pal3_constants.h"
#include "Misc/AStarPathFinder.h"

// 0x00401000
AStarPathFinder::AStarPathFinder()
{
  this->Stack = (AStarPathFinder::STACK *)calloc(1u, 8u);
  this->OPEN = 0;
  this->CLOSED = 0;
  this->PATH = 0;
}

// 0x00401030
AStarPathFinder::~AStarPathFinder()
{
  this->AStarPathFinder::ReleaseAll();
  if ( (1 & 1) != 0 )
    operator delete(this);
  this;
}

// 0x00401050
void AStarPathFinder::ReleaseAll()
{
  this->AStarPathFinder::Reset();
  free(this->Stack);
}

// 0x004014E0
int AStarPathFinder::IsInBounds(int nX, int nY)
{
  return 0;
}

// 0x004014F0
unsigned __int8 AStarPathFinder::GetHeuristicIdx(int nX, int nY)
{
  return 0;
}

// 0x00401500
int AStarPathFinder::FindInOpen(int nTileIdx)
{
  AStarPathFinder::NODE *OPEN; // ecx
  AStarPathFinder::NODE *i; // eax

  OPEN = this->OPEN;
  for ( i = OPEN->next; i; i = i->next )
  {
    if ( i->key == nTileIdx )
      break;
    OPEN = i;
  }
  return (int)OPEN->next;
}

// 0x00401530
int AStarPathFinder::FindInClosed(int nTileIdx)
{
  AStarPathFinder::NODE *CLOSED; // ecx
  AStarPathFinder::NODE *i; // eax

  CLOSED = this->CLOSED;
  for ( i = CLOSED->next; i; i = i->next )
  {
    if ( i->key == nTileIdx )
      break;
    CLOSED = i;
  }
  return (int)CLOSED->next;
}

// 0x00401750
int AStarPathFinder::ResortNode()
{
  int result; // eax
  int v3; // [esp+0x8] [ebp+0x4]

  result = (int)calloc(1u, 8u);
  *(_DWORD *)result = v3;
  *(_DWORD *)(result + 4) = (_DWORD)this->Stack->top;
  this->Stack->top = (AStarPathFinder::NODE *)result;
  return result;
}

// 0x00401780
AStarPathFinder::NODE * AStarPathFinder::PopStack()
{
  AStarPathFinder::STACK *Stack; // ecx
  AStarPathFinder::NODE *v2; // esi
  AStarPathFinder::NODE **top; // [esp-0x4] [ebp-0x8]

  Stack = this->Stack;
  top = (AStarPathFinder::NODE **)Stack->top;
  v2 = *top;
  Stack->top = top[1];
  free(top);
  return v2;
}

// 0x004017A0
int AStarPathFinder::Reset()
{
  int result; // eax

  this->AStarPathFinder::Release(this->OPEN);
  this->AStarPathFinder::Release(this->CLOSED);
  result = 0;
  this->OPEN = 0;
  this->CLOSED = 0;
  this->PATH = 0;
  return result;
}
