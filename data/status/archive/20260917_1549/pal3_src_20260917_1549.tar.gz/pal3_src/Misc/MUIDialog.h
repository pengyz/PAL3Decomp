#include "Misc/UIFrameWnd.h"
#include "Misc/MUIDialogMgr.h"
#include "UI/UIDialog.h"
#pragma once
// Auto-generated: MUIDialog
#include "pal3/ida_types.h"

#include "Misc/UIStatic.h"

class MUIDialog : public UIDialog, public MUIDialogMgr, public UIFrameWnd {
public:
    char _gap_000[304]; // +0x0
    UIStatic m_static; // +0x130
    char _gap_1C8[8]; // +0x1C8
    UIStatic m_text; // +0x1D0
    char _gap_268[8]; // +0x268
    int m_btnW; // +0x270
    int m_btnH; // +0x274
    union { // +0x278
        tagRECT rc; // +0x278
        void * pCallback; // +0x278
    } m_btRc;
    char _gap_288[328]; // +0x288
    void * pCallbackVtable2; // +0x3D0
    char _tail_3D4[308]; // +0x3D4
    // total size: 0x508 (1288)

    int GetPlayerAttField(int nVal, int nVal2); // 0x0049CEC0
    char InvokeCallback(); // 0x004A1620
    void SetSlotCaption(int nVal); // 0x00527130
};
