#include "Misc/UIFrameWnd.h"
#pragma once
// Auto-generated: Comp_DonateUI
#include "pal3/ida_types.h"

#include "Misc/Comp_Donate_Detail.h"
#include "Misc/LineupComp.h"
#include "Misc/MUIDialog.h"
#include "Misc/UIButton.h"
#include "Misc/UIRoleDialog.h"
#include "Misc/UIRoleSelect.h"
#include "Misc/UIStatic.h"

class Comp_DonateUI : public UIFrameWnd {
public:


    enum CDState {
        CD_NONE = 0,
        CD_HASKEY = 1,
        CD_DONATED = 2,
        CD_NOSOURCE = 3,
        CD_NOINTIMACY = 4,
        CD_CANCOMPOSE = 5,
        CD_COMPOSED = 6,
        CD_NUM = 7,
    };
    char _gap_000[72]; // +0x0
    int m_RoleId; // +0x48
    Comp_Donate_Detail m_CompDonate[10]; // +0x4C
    int m_keynum; // +0x164
    int m_curitem; // +0x168
    CDState m_state[10]; // +0x16C
    char m_lang[256][16][5]; // +0x194
    UIStatic m_OutFrameT; // +0x5194
    char _gap_522C[8]; // +0x522C
    UIStatic m_OutFrameR; // +0x5234
    char _gap_52CC[8]; // +0x52CC
    UIStatic m_OutFrameL; // +0x52D4
    char _gap_536C[8]; // +0x536C
    UIStatic m_OutFrameB; // +0x5374
    char _gap_540C[8]; // +0x540C
    UIStatic m_TopFrame; // +0x5414
    char _gap_54AC[8]; // +0x54AC
    UIButton m_ExitBtn; // +0x54B4
    UIButton m_Btn[10]; // +0x560C
    UIStatic m_BtnStatic[10]; // +0x637C
    char _gap_696C[80]; // +0x696C
    int m_mouseon; // +0x69BC
    UIRoleDialog m_RoleDlg; // +0x69C0
    UIRoleSelect m_SelectDlg; // +0x6C90
    char _gap_7260[80]; // +0x7260
    BYTE m_IfSel; // +0x72B0
    BYTE m_IfGetSel; // +0x72B1
    char _gap_72B2[2]; // +0x72B2
    tagRECT m_RoleDlgRc; // +0x72B4
    int m_AddIntimacyDonate[5]; // +0x72C4
    int m_AddIntimacyComp[5]; // +0x72D8
    char m_RoleLang[512][4][5]; // +0x72EC
    int m_SelBtn; // +0x9AEC
    MUIDialog m_Msg; // +0x9AF0
    char _gap_9FF8[96]; // +0x9FF8
    MUIDialog m_ActiveDlg; // +0xA058
    char _gap_A560[96]; // +0xA560
    MUIDialog m_ExitDlg; // +0xA5C0
    char _gap_AAC8[96]; // +0xAAC8
    BYTE m_IsActive; // +0xAB28
    BYTE m_IsOver; // +0xAB29
    char _gap_AB2A[2]; // +0xAB2A
    LineupComp m_LineupComp; // +0xAB2C
    UIStatic m_BK; // +0xB308
    char _tail_B3A0[208]; // +0xB3A0
    // total size: 0xB470 (46192)

    BOOL ProcessInput(int a1); // 0x004A6030
};
