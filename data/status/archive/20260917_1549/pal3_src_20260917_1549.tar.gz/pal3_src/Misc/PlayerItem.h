#pragma once
// Auto-generated: PlayerItem
#include "pal3/ida_types.h"

class FightItem;

class PlayerItem {
public:
    DWORD id; // +0x0
    int num; // +0x4
    FightItem * item; // +0x8
    // total size: 0xC (12)

};
