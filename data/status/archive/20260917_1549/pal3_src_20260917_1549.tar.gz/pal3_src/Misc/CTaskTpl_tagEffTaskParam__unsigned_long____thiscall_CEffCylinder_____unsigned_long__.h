#include "Misc/tagEffTaskParam.h"
#include "Misc/CTaskTpl.h"
#pragma once
// Auto-generated: CTaskTpl<tagEffTaskParam, unsigned long (__thiscall CEffCylinder::*)(unsigned long)>
#include "pal3/ida_types.h"

class CEffCylinder;
typedef unsigned long (CEffCylinder::*_CEffCylinder_cb)(unsigned long);
template<>
class CTaskTpl<tagEffTaskParam, _CEffCylinder_cb> {
public:
    char _tail_000[36]; // +0x0
    // total size: 0x24 (36)

};
