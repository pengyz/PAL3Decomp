#pragma once
// Auto-generated: DPINFO
#include "pal3/ida_types.h"

#include "Misc/DPINFO___unnamed.h"

class DPINFO {
public:
    long active; // +0x0
    DWORD provider; // +0x4
    DPINFO___unnamed TYPE; // +0x8
    // total size: 0x68 (104)

};
