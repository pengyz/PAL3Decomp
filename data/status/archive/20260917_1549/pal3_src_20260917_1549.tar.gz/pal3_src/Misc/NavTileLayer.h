#pragma once
// Auto-generated: NavTileLayer
#include "pal3/ida_types.h"

#include "gbengine/gbengine_types.h"

class NavTile;

class NavTileLayer {
public:
    tagRECT portal[8]; // +0x0
    gbVec3D min; // +0x80
    gbVec3D max; // +0x8C
    int width; // +0x98
    int height; // +0x9C
    NavTile * tile; // +0xA0
    // total size: 0xA4 (164)

};
