#include "pal3/ida_defs.h"
#include "globals.h"
#include "pal3/pal3_constants.h"
#include "Misc/PalScriptIdleObj.h"
#include "GameBase/GRPinput.h"
#include "Misc/UISceneFrm.h"

// 0x00453C00
int PalScriptIdleObj::UpdateWait(const void *pData, unsigned int dwVal)
{
  gbImage2D *m_needscriptdel; // ecx
  char Color_high; // al
  int result; // eax
  unsigned int m_passedtime_low; // eax
  gbImage2D *v8; // ecx

  if ( dwVal > 0xFFFFFFFD )
    std::_Xlen();
  m_needscriptdel = this->m_needscriptdel;
  if ( m_needscriptdel )
  {
    Color_high = HIBYTE(m_needscriptdel[-1].ColorKey.Color);
    if ( Color_high )
    {
      if ( Color_high != -1 )
      {
        if ( !dwVal )
        {
          HIBYTE(m_needscriptdel[-1].ColorKey.Color) = Color_high - 1;
          this->m_needscriptdel = 0;
          this->m_nTodo_008 = 0;
          this->m_passedtime = 0.0;
          return (int)this;
        }
        goto LABEL_13;
      }
    }
  }
  if ( !dwVal )
  {
    (((std *)1))->std::string::_Tidy();
    return (int)this;
  }
  m_passedtime_low = LODWORD(this->m_passedtime);
  if ( m_passedtime_low > 0x1F || m_passedtime_low < dwVal )
  {
    (((std *)1))->std::string::_Tidy();
LABEL_13:
    /* [MISATTRIBUTED] GRPinput on PalScriptIdleObj::this -> fix IDB name of callee */ GRPinput::PollInputState((GRPinput *)this, dwVal);
  }
  qmemcpy(this->m_needscriptdel, pData, dwVal);
  result = (int)this;
  v8 = this->m_needscriptdel;
  this->m_nTodo_008 = dwVal;
  *((_BYTE *)&v8->ImgInfo.isdiskinfo + dwVal) = 0;
  return result;
}

// 0x00535600
UISceneFrm * PalScriptIdleObj::ResetTimers()
{
  int v2; // ecx
  float *p_m_passedtime; // eax

  v2 = 6;
  p_m_passedtime = (float *)&this->m_passedtime;
  do
  {
    *(_BYTE *)p_m_passedtime = 0;
    *((_BYTE *)p_m_passedtime + 256) = 0;
    p_m_passedtime += 128;
    --v2;
  }
  while ( v2 );
  (((UISceneFrm *)this))->UISceneFrm::InitTemplateStrings() /* [ROWTABLE] */;
  return (UISceneFrm *)this;
}
