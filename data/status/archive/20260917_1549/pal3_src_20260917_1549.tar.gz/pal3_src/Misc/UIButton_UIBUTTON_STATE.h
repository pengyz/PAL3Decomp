#pragma once
// Auto-generated: UIButton_UIBUTTON_STATE
#include "pal3/ida_types.h"

class UIButton_UIBUTTON_STATE {
public:
    _BYTE _tail_000[4]; // +0x0
    // total size: 0x4 (4)

    // Scalar-wrapper: ctors for IDA (Cls)int casts (no init code)
    UIButton_UIBUTTON_STATE() {}
    UIButton_UIBUTTON_STATE(int v) { *(int*)this = v; }

};
