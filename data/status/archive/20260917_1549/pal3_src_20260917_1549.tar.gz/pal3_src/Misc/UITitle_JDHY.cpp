#include "pal3/ida_defs.h"
#include "globals.h"
#include "pal3/pal3_constants.h"
#include "Misc/UITitle_JDHY.h"
#include "Role/Actor.h"
#include "Misc/ArcPastScene.h"
#include "Combat/CCBControlWindow.h"
#include "Combat/CCBMagicWindow.h"
#include "Data/CGameData.h"
#include "Render/CScreenMode.h"
#include "Misc/ChoseCompose.h"
#include "Misc/MainEquipUI.h"
#include "GameBase/PAL3.h"
#include "Script/PalScript.h"
#include "Misc/Parent_Data.h"
#include "Misc/PtrArray.h"
#include "Render/RenderTarget.h"
#include "Role/Role.h"
#include "Role/RoleSystem.h"
#include "Scene/SceneObj.h"
#include "Effect/ScreenEffect.h"
#include "UI/StateUI.h"
#include "Misc/UICaption.h"
#include "UI/UICursor.h"
#include "Misc/UIFrameWnd.h"
#include "Misc/UIRoleSelect.h"
#include "UI/UIScene.h"
#include "Misc/UISceneMap.h"
#include "Misc/UIStatic.h"
#include "UI/UIWnd.h"
#include "Misc/_PlugInfo.h"
#include "free_functions.h"

// Forward declarations for unnamed functions

// 0x0045E9F0
void UITitle_JDHY::LayoutCalcRects()
{
  void *m_id; // eax
  void **v3; // eax
  void **v4; // edx
  void **v5; // eax
  void **v6; // edx
  void **v7; // eax
  void **v8; // ecx
  void **v9; // eax
  void **v10; // edx
  void **v11; // eax
  void **v12; // edx
  void **v13; // eax
  void **v14; // edx
  void **v15; // eax
  void **v16; // edx
  void **v17; // eax
  void **v18; // edx
  void **v19; // eax
  void **v20; // edx
  void **v21; // eax
  void **v22; // edx
  void **v23; // eax
  void **v24; // edx
  void **v25; // eax
  void **v26; // edx
  void **v27; // eax
  void **v28; // edx
  void **v29; // eax
  void **v30; // edx
  void **v31; // eax
  void **v32; // edx
  void **v33; // eax
  void **v34; // edx
  void **v35; // eax
  void **v36; // edx
  void **v37; // eax
  void **v38; // edx
  void **v39; // eax
  void **v40; // edx
  void **v41; // eax
  void **v42; // edx
  void **v43; // eax
  void **v44; // edx
  void **v45; // eax
  void **v46; // edx
  void **v47; // eax
  void **v48; // edx
  void **v49; // eax
  void **v50; // edx
  int v51; // edx
  int v52; // ecx
  int v53; // edx
  int v54; // ecx
  int v55; // edx
  int v56; // ecx
  int v57; // edx
  int v58; // ecx
  int v59; // edx
  int v60; // ecx
  int v61; // edx
  int v62; // ecx
  int v63; // edx
  int v64; // ecx
  int v65; // edx
  int v66; // ecx
  LONG v67; // eax
  int v68; // edx
  int v69; // ecx
  int v70; // edx
  int v71; // ecx
  int v72; // edx
  int v73; // ecx
  int v74; // edx
  int v75; // ecx
  int v76; // edx
  int v77; // ecx
  int v78; // edx
  int v79; // ecx
  int v80; // edx
  int v81; // ecx
  int v82; // edx
  int v83; // ecx
  LONG v84; // eax
  int v85; // eax

  this->m_OutFrameT.m_id = 0;
  do
  {
    m_id = this->m_OutFrameT.m_id;
    if ( *((_BYTE *)&this->m_NoteItem[6].m_NotePic.m_FVF + (_DWORD)m_id) )
    {
      sub_445FA0(&this->m_NoteItem[23].m_ItemRc.bottom + 270 * (_DWORD)m_id);
      sub_445FA0(&this->m_NoteItem[23].m_NoteItemBk.m_texarrayInfo[270 * (int)this->m_OutFrameT.m_id + 3]);
      sub_445FA0(&this->m_NoteItem[23].m_NoteID.m_id + 270 * (int)this->m_OutFrameT.m_id);
      sub_445FA0(&this->m_NoteItem[23].m_NoteState.m_childs.capacity + 270 * (int)this->m_OutFrameT.m_id);
      sub_445FA0(&this->m_NoteItem[23].m_HeadShot_NO_SEL[0].pDebugTex + 270 * (int)this->m_OutFrameT.m_id);
      sub_445FA0(&this->m_NoteItem[23].m_HeadShot_NO_SEL[1].m_text[1080 * (int)this->m_OutFrameT.m_id]);
      sub_445FA0(&this->m_NoteItem[24].m_HeadShot[6 * (int)this->m_OutFrameT.m_id + 2].m_ppicInfo);
      sub_445FA0(&this->m_NoteItem[24].m_NoteTime.m_pbkInfo + 228 * (int)this->m_OutFrameT.m_id);
      sub_445FA0(&this->m_NoteItem[24].m_NoteMoney.m_pbkInfo + 228 * (int)this->m_OutFrameT.m_id);
      sub_445FA0(&this->m_NoteItem[24].m_HeadShot[6 * (int)this->m_OutFrameT.m_id + 3].m_ppicInfo);
      sub_445FA0(&this->m_NoteItem[24].m_HeadShot[6 * (int)this->m_OutFrameT.m_id + 4].m_ppicInfo);
      sub_445FA0(&this->m_NoteItem[24].m_NoteLv[6 * (int)this->m_OutFrameT.m_id].m_pbkInfo);
      *((_DWORD *)&this->m_NoteItem[17].m_HeadShot_NO_SEL[0].pDebugTex + 192 * (int)this->m_OutFrameT.m_id) = *((_DWORD *)((void **)(this)) + 4 * ((int)this->m_OutFrameT.m_id + 1641)) + 12;
      *(&this->m_NoteItem[17].m_HeadShot_NO_SEL[0].m_bfocus + 192 * (int)this->m_OutFrameT.m_id) = *(&this->m_NoteItem[6].m_NotePic.m_childs.m_needscriptdel + 4 * (int)this->m_OutFrameT.m_id)
                                                                                                 - 30;
      *(&this->m_NoteItem[17].m_HeadShot_NO_SEL[0].m_align + 192 * (int)this->m_OutFrameT.m_id) = *(&this->m_NoteItem[17].m_HeadShot_NO_SEL[0].m_bfocus
                                                                                                  + 192 * (int)this->m_OutFrameT.m_id)
                                                                                                + 26;
      *((_DWORD *)&this->m_NoteItem[17].m_HeadShot_NO_SEL[0].m_ratiow + 192 * (int)this->m_OutFrameT.m_id) = *((_DWORD *)&this->m_NoteItem[17].m_HeadShot_NO_SEL[0].pDebugTex + 192 * (int)this->m_OutFrameT.m_id) + 38;
      sub_445FA0(&this->m_NoteItem[6].m_NotePicName + 48 * (int)this->m_OutFrameT.m_id);
      v3 = ((void **)(this)) + 192 * (int)this->m_OutFrameT.m_id;
      v4 = (void **)(v3 + 15709);
      v3 += 15713;
      *v3 = *v4;
      v3[1] = v4[1];
      v3[2] = v4[2];
      v3[3] = v4[3];
      sub_445FA0((char *)&this->m_NoteItem[7] + 7296 * (int)this->m_OutFrameT.m_id);
      *(_DWORD *)&this->m_NoteItem[17].m_HeadShot_NO_SEL[0].m_text[768 * (int)this->m_OutFrameT.m_id + 4] = *((_DWORD *)&this->m_NoteItem[17].m_HeadShot_NO_SEL[0].pDebugTex + 192 * (int)this->m_OutFrameT.m_id);
      *(_DWORD *)&this->m_NoteItem[17].m_HeadShot_NO_SEL[0].m_text[768 * (int)this->m_OutFrameT.m_id] = *(&this->m_NoteItem[17].m_HeadShot_NO_SEL[0].m_align + 192 * (int)this->m_OutFrameT.m_id) + 2;
      *(_DWORD *)&this->m_NoteItem[17].m_HeadShot_NO_SEL[0].m_text[768 * (int)this->m_OutFrameT.m_id + 8] = *(_DWORD *)&this->m_NoteItem[17].m_HeadShot_NO_SEL[0].m_text[768 * (int)this->m_OutFrameT.m_id] + 26;
      *(_DWORD *)&this->m_NoteItem[17].m_HeadShot_NO_SEL[0].m_text[768 * (int)this->m_OutFrameT.m_id + 12] = *((_DWORD *)&this->m_NoteItem[17].m_HeadShot_NO_SEL[0].m_ratiow + 192 * (int)this->m_OutFrameT.m_id);
      sub_445FA0(&this->m_NoteItem[7].m_NoteItemBk.m_texarray.m_ptex[1824 * (int)this->m_OutFrameT.m_id + 10]);
      v5 = ((void **)(this)) + 192 * (int)this->m_OutFrameT.m_id;
      v6 = (void **)(v5 + 15717);
      v5 += 15721;
      *v5 = *v6;
      v5[1] = v6[1];
      v5[2] = v6[2];
      v5[3] = v6[3];
      sub_445FA0(&this->m_NoteItem[7].m_NoteItemBk.m_caption[7296 * (int)this->m_OutFrameT.m_id + 96]);
      *(&this->m_NoteItem[17].m_HeadShot_NO_SEL[1].m_childs.m_nSize + 192 * (int)this->m_OutFrameT.m_id) = *((_DWORD *)((void **)(this)) + 4 * ((int)this->m_OutFrameT.m_id + 1641)) + 12;
      *(&this->m_NoteItem[17].m_HeadShot_NO_SEL[1].m_childs.capacity + 192 * (int)this->m_OutFrameT.m_id) = *(&this->m_NoteItem[6].m_NotePic.m_childs.m_needscriptdel + 4 * (int)this->m_OutFrameT.m_id) - 30;
      *(&this->m_NoteItem[17].m_HeadShot_NO_SEL[1].m_childs.m_needscriptdel + 192 * (int)this->m_OutFrameT.m_id) = *(&this->m_NoteItem[17].m_HeadShot_NO_SEL[1].m_childs.capacity + 192 * (int)this->m_OutFrameT.m_id) + 26;
      *((_DWORD *)((UIWnd *)&this->m_NoteItem[17].m_HeadShot_NO_SEL[1]) + 192 * (int)this->m_OutFrameT.m_id + 13) = *(&this->m_NoteItem[17].m_HeadShot_NO_SEL[1].m_childs.m_nSize + 192 * (int)this->m_OutFrameT.m_id) + 38;
      sub_445FA0(this->m_NoteItem[7].m_HeadShot_NO_SEL[48 * (int)this->m_OutFrameT.m_id + 2].m_text);
      v7 = ((void **)(this)) + 192 * (int)this->m_OutFrameT.m_id;
      v8 = (void **)(v7 + 15741);
      v7 += 15745;
      *v7 = *v8;
      v7[1] = v8[1];
      v7[2] = v8[2];
      v7[3] = v8[3];
      sub_445FA0(this->m_NoteItem[7].m_HeadShot_NO_SEL[48 * (int)this->m_OutFrameT.m_id + 3].m_text);
      *((_DWORD *)&this->m_NoteItem[17].m_HeadShot_NO_SEL[1].m_ratiow + 192 * (int)this->m_OutFrameT.m_id) = *(&this->m_NoteItem[17].m_HeadShot_NO_SEL[1].m_childs.m_nSize + 192 * (int)this->m_OutFrameT.m_id);
      *(&this->m_NoteItem[17].m_HeadShot_NO_SEL[1].m_align + 192 * (int)this->m_OutFrameT.m_id) = *(&this->m_NoteItem[17].m_HeadShot_NO_SEL[1].m_childs.m_needscriptdel
                                                                                                  + 192 * (int)this->m_OutFrameT.m_id)
                                                                                                + 2;
      *((_DWORD *)&this->m_NoteItem[17].m_HeadShot_NO_SEL[1].m_ratioh + 192 * (int)this->m_OutFrameT.m_id) = *(&this->m_NoteItem[17].m_HeadShot_NO_SEL[1].m_align + 192 * (int)this->m_OutFrameT.m_id) + 26;
      (&this->m_NoteItem[17].m_HeadShot_NO_SEL[1].m_textx)[192 * (int)this->m_OutFrameT.m_id] = (gbRefObject *)*((_DWORD *)((UIWnd *)&this->m_NoteItem[17].m_HeadShot_NO_SEL[1]) + 192 * (int)this->m_OutFrameT.m_id + 13);
      sub_445FA0(this->m_NoteItem[7].m_HeadShot_NO_SEL[48 * (int)this->m_OutFrameT.m_id + 4].m_text);
      v9 = ((void **)(this)) + 192 * (int)this->m_OutFrameT.m_id;
      v10 = (void **)(v9 + 15749);
      v9 += 15753;
      *v9 = *v10;
      v9[1] = v10[1];
      v9[2] = v10[2];
      v9[3] = v10[3];
      sub_445FA0(this->m_NoteItem[7].m_HeadShot[48 * (int)this->m_OutFrameT.m_id].m_text);
      *(&this->m_NoteItem[17].m_HeadShot_NO_SEL[2].m_rect.top + 192 * (int)this->m_OutFrameT.m_id) = *((_DWORD *)((void **)(this)) + 4 * ((int)this->m_OutFrameT.m_id + 1641)) + 12;
      *(&this->m_NoteItem[17].m_HeadShot_NO_SEL[2].m_rect.left + 192 * (int)this->m_OutFrameT.m_id) = *(&this->m_NoteItem[6].m_NotePic.m_childs.m_needscriptdel + 4 * (int)this->m_OutFrameT.m_id) - 30;
      *(&this->m_NoteItem[17].m_HeadShot_NO_SEL[2].m_rect.right + 192 * (int)this->m_OutFrameT.m_id) = *(&this->m_NoteItem[17].m_HeadShot_NO_SEL[2].m_rect.left + 192 * (int)this->m_OutFrameT.m_id) + 26;
      *(&this->m_NoteItem[17].m_HeadShot_NO_SEL[2].m_rect.bottom + 192 * (int)this->m_OutFrameT.m_id) = *(&this->m_NoteItem[17].m_HeadShot_NO_SEL[2].m_rect.top + 192 * (int)this->m_OutFrameT.m_id) + 38;
      sub_445FA0(&(&this->m_NoteItem[7].m_NoteTime.m_texty)[1824 * (int)this->m_OutFrameT.m_id]);
      v11 = ((void **)(this)) + 192 * (int)this->m_OutFrameT.m_id;
      v12 = (void **)(v11 + 15773);
      v11 += 15777;
      *v11 = *v12;
      v11[1] = v12[1];
      v11[2] = v12[2];
      v11[3] = v12[3];
      sub_445FA0(&(&this->m_NoteItem[7].m_NoteMoney.m_texty)[1824 * (int)this->m_OutFrameT.m_id]);
      *(&this->m_NoteItem[17].m_HeadShot_NO_SEL[2].m_bcreateok + 192 * (int)this->m_OutFrameT.m_id) = *(&this->m_NoteItem[17].m_HeadShot_NO_SEL[2].m_rect.top + 192 * (int)this->m_OutFrameT.m_id);
      *(&this->m_NoteItem[17].m_HeadShot_NO_SEL[2].m_childs.m_needscriptdel + 192 * (int)this->m_OutFrameT.m_id) = *(&this->m_NoteItem[17].m_HeadShot_NO_SEL[2].m_rect.right + 192 * (int)this->m_OutFrameT.m_id) + 2;
      *(&this->m_NoteItem[17].m_HeadShot_NO_SEL[2].m_bvisible + 192 * (int)this->m_OutFrameT.m_id) = *(&this->m_NoteItem[17].m_HeadShot_NO_SEL[2].m_childs.m_needscriptdel + 192 * (int)this->m_OutFrameT.m_id) + 26;
      *(&this->m_NoteItem[17].m_HeadShot_NO_SEL[2].m_benable + 192 * (int)this->m_OutFrameT.m_id) = *(&this->m_NoteItem[17].m_HeadShot_NO_SEL[2].m_rect.bottom + 192 * (int)this->m_OutFrameT.m_id);
      sub_445FA0(&this->m_NoteItem[7].m_NoteLv[48 * (int)this->m_OutFrameT.m_id].m_texty);
      v13 = ((void **)(this)) + 192 * (int)this->m_OutFrameT.m_id;
      v14 = (void **)(v13 + 15781);
      v13 += 15785;
      *v13 = *v14;
      v13[1] = v14[1];
      v13[2] = v14[2];
      v13[3] = v14[3];
      sub_445FA0(&this->m_NoteItem[7].m_NoteLv[48 * (int)this->m_OutFrameT.m_id + 1].m_texty);
      *(&this->m_NoteItem[17].m_HeadShot_NO_SEL[2].m_nTextW + 192 * (int)this->m_OutFrameT.m_id) = *((_DWORD *)((void **)(this)) + 4 * ((int)this->m_OutFrameT.m_id + 1641))
                                                                                                 + 12;
      *(&this->m_NoteItem[17].m_HeadShot_NO_SEL[2].m_FVF + 192 * (int)this->m_OutFrameT.m_id) = *(&this->m_NoteItem[6].m_NotePic.m_bvisible
                                                                                                + 4
                                                                                                * (int)this->m_OutFrameT.m_id)
                                                                                              + 4;
      *((_DWORD *)((void **)&(this->m_NoteItem[17].m_HeadShot_NO_SEL[3])) + 192 * (int)this->m_OutFrameT.m_id) = *(&this->m_NoteItem[17].m_HeadShot_NO_SEL[2].m_FVF + 192 * (int)this->m_OutFrameT.m_id) + 26;
      *(&this->m_NoteItem[17].m_HeadShot_NO_SEL[3].m_fontcolor.Color + 192 * (int)this->m_OutFrameT.m_id) = *(&this->m_NoteItem[17].m_HeadShot_NO_SEL[2].m_nTextW + 192 * (int)this->m_OutFrameT.m_id) + 38;
      sub_445FA0(&(&this->m_NoteItem[7].m_NotePicName.m_texty)[1824 * (int)this->m_OutFrameT.m_id]);
      v15 = ((void **)(this)) + 192 * (int)this->m_OutFrameT.m_id;
      v16 = (void **)(v15 + 15805);
      v15 += 15809;
      *v15 = *v16;
      v15[1] = v16[1];
      v15[2] = v16[2];
      v15[3] = v16[3];
      sub_445FA0(&this->m_NoteItem[8].m_NoteItemBk.m_ratiow + 1824 * (int)this->m_OutFrameT.m_id);
      *(&this->m_NoteItem[17].m_HeadShot_NO_SEL[3].m_rect.bottom + 192 * (int)this->m_OutFrameT.m_id) = *(&this->m_NoteItem[17].m_HeadShot_NO_SEL[2].m_nTextW + 192 * (int)this->m_OutFrameT.m_id);
      *(&this->m_NoteItem[17].m_HeadShot_NO_SEL[3].m_rect.right + 192 * (int)this->m_OutFrameT.m_id) = *((_DWORD *)((void **)&(this->m_NoteItem[17].m_HeadShot_NO_SEL[3])) + 192 * (int)this->m_OutFrameT.m_id) + 2;
      *((_DWORD *)&this->m_NoteItem[17].m_HeadShot_NO_SEL[3].m_pfather + 192 * (int)this->m_OutFrameT.m_id) = *(&this->m_NoteItem[17].m_HeadShot_NO_SEL[3].m_rect.right + 192 * (int)this->m_OutFrameT.m_id) + 26;
      *((_DWORD *)&this->m_NoteItem[17].m_HeadShot_NO_SEL[3].m_childs.m_pData + 192 * (int)this->m_OutFrameT.m_id) = *(&this->m_NoteItem[17].m_HeadShot_NO_SEL[3].m_fontcolor.Color + 192 * (int)this->m_OutFrameT.m_id);
      sub_445FA0(&this->m_NoteItem[8].m_NoteItemBk.m_caption[7296 * (int)this->m_OutFrameT.m_id + 32]);
      v17 = ((void **)(this)) + 192 * (int)this->m_OutFrameT.m_id;
      v18 = (void **)(v17 + 15813);
      v17 += 15817;
      *v17 = *v18;
      v17[1] = v18[1];
      v17[2] = v18[2];
      v17[3] = v18[3];
      sub_445FA0(&this->m_NoteItem[8].m_NoteID.m_pfather + 1824 * (int)this->m_OutFrameT.m_id);
      *((_DWORD *)&this->m_NoteItem[17].m_HeadShot_NO_SEL[3].m_ppicInfo + 192 * (int)this->m_OutFrameT.m_id) = *((_DWORD *)((void **)(this)) + 4 * ((int)this->m_OutFrameT.m_id + 1641)) + 12;
      *((_DWORD *)&this->m_NoteItem[17].m_HeadShot_NO_SEL[3].m_ppic + 192 * (int)this->m_OutFrameT.m_id) = *(&this->m_NoteItem[6].m_NotePic.m_bvisible + 4 * (int)this->m_OutFrameT.m_id) + 4;
      *((_DWORD *)&this->m_NoteItem[17].m_HeadShot_NO_SEL[3].m_disablepic + 192 * (int)this->m_OutFrameT.m_id) = *((_DWORD *)&this->m_NoteItem[17].m_HeadShot_NO_SEL[3].m_ppic + 192 * (int)this->m_OutFrameT.m_id) + 26;
      *((_DWORD *)&this->m_NoteItem[17].m_HeadShot_NO_SEL[3].m_disablepicInfo + 192 * (int)this->m_OutFrameT.m_id) = *((_DWORD *)&this->m_NoteItem[17].m_HeadShot_NO_SEL[3].m_ppicInfo + 192 * (int)this->m_OutFrameT.m_id) + 38;
      sub_445FA0(&this->m_NoteItem[8].m_HeadShot_NO_SEL[48 * (int)this->m_OutFrameT.m_id + 3].m_pfather);
      v19 = ((void **)(this)) + 192 * (int)this->m_OutFrameT.m_id;
      v20 = (void **)(v19 + 15837);
      v19 += 15841;
      *v19 = *v20;
      v19[1] = v20[1];
      v19[2] = v20[2];
      v19[3] = v20[3];
      sub_445FA0(&this->m_NoteItem[8].m_HeadShot_NO_SEL[48 * (int)this->m_OutFrameT.m_id + 4].m_pfather);
      *(&this->m_NoteItem[17].m_HeadShot_NO_SEL[4].m_fontcolor.Color + 192 * (int)this->m_OutFrameT.m_id) = *((_DWORD *)&this->m_NoteItem[17].m_HeadShot_NO_SEL[3].m_ppicInfo + 192 * (int)this->m_OutFrameT.m_id);
      *((_DWORD *)((void **)&(this->m_NoteItem[17].m_HeadShot_NO_SEL[4])) + 192 * (int)this->m_OutFrameT.m_id) = *((_DWORD *)&this->m_NoteItem[17].m_HeadShot_NO_SEL[3].m_disablepic + 192 * (int)this->m_OutFrameT.m_id) + 2;
      *(&this->m_NoteItem[17].m_HeadShot_NO_SEL[4].m_wndcolor.Color + 192 * (int)this->m_OutFrameT.m_id) = *((_DWORD *)((void **)&(this->m_NoteItem[17].m_HeadShot_NO_SEL[4])) + 192 * (int)this->m_OutFrameT.m_id) + 26;
      *((_DWORD *)&this->m_NoteItem[17].m_HeadShot_NO_SEL[4].m_id + 192 * (int)this->m_OutFrameT.m_id) = *((_DWORD *)&this->m_NoteItem[17].m_HeadShot_NO_SEL[3].m_disablepicInfo + 192 * (int)this->m_OutFrameT.m_id);
      sub_445FA0(&this->m_NoteItem[8].m_HeadShot[48 * (int)this->m_OutFrameT.m_id].m_pfather);
      v21 = ((void **)(this)) + 192 * (int)this->m_OutFrameT.m_id;
      v22 = (void **)(v21 + 15845);
      v21 += 15849;
      *v21 = *v22;
      v21[1] = v22[1];
      v21[2] = v22[2];
      v21[3] = v22[3];
      sub_445FA0(&this->m_NoteItem[8].m_HeadShot[48 * (int)this->m_OutFrameT.m_id + 1].m_pfather);
      *(_DWORD *)&this->m_NoteItem[17].m_HeadShot_NO_SEL[4].m_text[768 * (int)this->m_OutFrameT.m_id + 4] = *((_DWORD *)((void **)(this)) + 4 * ((int)this->m_OutFrameT.m_id + 1641)) + 12;
      *(_DWORD *)&this->m_NoteItem[17].m_HeadShot_NO_SEL[4].m_text[768 * (int)this->m_OutFrameT.m_id] = *(&this->m_NoteItem[6].m_NotePic.m_bvisible + 4 * (int)this->m_OutFrameT.m_id) + 4;
      *(_DWORD *)&this->m_NoteItem[17].m_HeadShot_NO_SEL[4].m_text[768 * (int)this->m_OutFrameT.m_id + 8] = *(_DWORD *)&this->m_NoteItem[17].m_HeadShot_NO_SEL[4].m_text[768 * (int)this->m_OutFrameT.m_id] + 26;
      *(_DWORD *)&this->m_NoteItem[17].m_HeadShot_NO_SEL[4].m_text[768 * (int)this->m_OutFrameT.m_id + 12] = *(_DWORD *)&this->m_NoteItem[17].m_HeadShot_NO_SEL[4].m_text[768 * (int)this->m_OutFrameT.m_id + 4] + 38;
      sub_445FA0(&this->m_NoteItem[8].m_NoteMoney.m_rect.right + 1824 * (int)this->m_OutFrameT.m_id);
      v23 = ((void **)(this)) + 192 * (int)this->m_OutFrameT.m_id;
      v24 = (void **)(v23 + 15869);
      v23 += 15873;
      *v23 = *v24;
      v23[1] = v24[1];
      v23[2] = v24[2];
      v23[3] = v24[3];
      sub_445FA0(&this->m_NoteItem[8].m_NoteLv[48 * (int)this->m_OutFrameT.m_id].m_rect.right);
      *((_DWORD *)&this->m_NoteItem[17].m_HeadShot_NO_SEL[4].m_disablepicInfo + 192 * (int)this->m_OutFrameT.m_id) = *(_DWORD *)&this->m_NoteItem[17].m_HeadShot_NO_SEL[4].m_text[768 * (int)this->m_OutFrameT.m_id + 4];
      *((_DWORD *)&this->m_NoteItem[17].m_HeadShot_NO_SEL[4].m_disablepic + 192 * (int)this->m_OutFrameT.m_id) = *(_DWORD *)&this->m_NoteItem[17].m_HeadShot_NO_SEL[4].m_text[768 * (int)this->m_OutFrameT.m_id + 8] + 2;
      *((_DWORD *)&this->m_NoteItem[17].m_HeadShot_NO_SEL[4].m_pbk2 + 192 * (int)this->m_OutFrameT.m_id) = *((_DWORD *)&this->m_NoteItem[17].m_HeadShot_NO_SEL[4].m_disablepic + 192 * (int)this->m_OutFrameT.m_id) + 26;
      *((_DWORD *)&this->m_NoteItem[17].m_HeadShot_NO_SEL[4].m_mouseoff + 192 * (int)this->m_OutFrameT.m_id) = *(_DWORD *)&this->m_NoteItem[17].m_HeadShot_NO_SEL[4].m_text[768 * (int)this->m_OutFrameT.m_id + 12];
      sub_445FA0(&this->m_NoteItem[8].m_NoteLv[48 * (int)this->m_OutFrameT.m_id + 1].m_rect.right);
      v25 = ((void **)(this)) + 192 * (int)this->m_OutFrameT.m_id;
      v26 = (void **)(v25 + 15877);
      v25 += 15881;
      *v25 = *v26;
      v25[1] = v26[1];
      v25[2] = v26[2];
      v25[3] = v26[3];
      sub_445FA0(&this->m_NoteItem[8].m_NoteLv[48 * (int)this->m_OutFrameT.m_id + 2].m_rect.right);
      *((_DWORD *)&this->m_NoteItem[17].m_HeadShot_NO_SEL[0].m_disablepicInfo + 192 * (int)this->m_OutFrameT.m_id) = *(&this->m_NoteItem[6].m_NotePic.m_benable + 4 * (int)this->m_OutFrameT.m_id) - 38;
      *((_DWORD *)&this->m_NoteItem[17].m_HeadShot_NO_SEL[0].m_disablepic + 192 * (int)this->m_OutFrameT.m_id) = *(&this->m_NoteItem[6].m_NotePic.m_childs.m_needscriptdel + 4 * (int)this->m_OutFrameT.m_id) - 30;
      *((_DWORD *)&this->m_NoteItem[17].m_HeadShot_NO_SEL[0].m_pbk2 + 192 * (int)this->m_OutFrameT.m_id) = *((_DWORD *)&this->m_NoteItem[17].m_HeadShot_NO_SEL[0].m_disablepic + 192 * (int)this->m_OutFrameT.m_id) + 26;
      *((_DWORD *)&this->m_NoteItem[17].m_HeadShot_NO_SEL[0].m_mouseoff + 192 * (int)this->m_OutFrameT.m_id) = *((_DWORD *)&this->m_NoteItem[17].m_HeadShot_NO_SEL[0].m_disablepicInfo + 192 * (int)this->m_OutFrameT.m_id) + 38;
      sub_445FA0(&this->m_NoteItem[7].m_NoteID.m_text[7296 * (int)this->m_OutFrameT.m_id]);
      v27 = ((void **)(this)) + 192 * (int)this->m_OutFrameT.m_id;
      v28 = (void **)(v27 + 15725);
      v27 += 15729;
      *v27 = *v28;
      v27[1] = v28[1];
      v27[2] = v28[2];
      v27[3] = v28[3];
      sub_445FA0(&this->m_NoteItem[7].m_NoteState.m_text[7296 * (int)this->m_OutFrameT.m_id]);
      *((_DWORD *)&this->m_NoteItem[17].m_HeadShot_NO_SEL[1].m_id + 192 * (int)this->m_OutFrameT.m_id) = *((_DWORD *)&this->m_NoteItem[17].m_HeadShot_NO_SEL[0].m_disablepicInfo + 192 * (int)this->m_OutFrameT.m_id);
      *(&this->m_NoteItem[17].m_HeadShot_NO_SEL[1].m_wndcolor.Color + 192 * (int)this->m_OutFrameT.m_id) = *((_DWORD *)&this->m_NoteItem[17].m_HeadShot_NO_SEL[0].m_pbk2 + 192 * (int)this->m_OutFrameT.m_id) + 2;
      *(&this->m_NoteItem[17].m_HeadShot_NO_SEL[1].m_rect.left + 192 * (int)this->m_OutFrameT.m_id) = *(&this->m_NoteItem[17].m_HeadShot_NO_SEL[1].m_wndcolor.Color + 192 * (int)this->m_OutFrameT.m_id) + 26;
      *(&this->m_NoteItem[17].m_HeadShot_NO_SEL[1].m_rect.top + 192 * (int)this->m_OutFrameT.m_id) = *((_DWORD *)&this->m_NoteItem[17].m_HeadShot_NO_SEL[0].m_mouseoff + 192 * (int)this->m_OutFrameT.m_id);
      sub_445FA0(this->m_NoteItem[7].m_HeadShot_NO_SEL[48 * (int)this->m_OutFrameT.m_id].m_text);
      v29 = ((void **)(this)) + 192 * (int)this->m_OutFrameT.m_id;
      v30 = (void **)(v29 + 15733);
      v29 += 15737;
      *v29 = *v30;
      v29[1] = v30[1];
      v29[2] = v30[2];
      v29[3] = v30[3];
      sub_445FA0(this->m_NoteItem[7].m_HeadShot_NO_SEL[48 * (int)this->m_OutFrameT.m_id + 1].m_text);
      *(_DWORD *)&this->m_NoteItem[17].m_HeadShot_NO_SEL[1].m_text[768 * (int)this->m_OutFrameT.m_id + 12] = *(&this->m_NoteItem[6].m_NotePic.m_benable + 4 * (int)this->m_OutFrameT.m_id) - 38;
      *(_DWORD *)&this->m_NoteItem[17].m_HeadShot_NO_SEL[1].m_text[768 * (int)this->m_OutFrameT.m_id + 8] = *(&this->m_NoteItem[6].m_NotePic.m_childs.m_needscriptdel + 4 * (int)this->m_OutFrameT.m_id) - 30;
      *(_DWORD *)&this->m_NoteItem[17].m_HeadShot_NO_SEL[1].m_text[768 * (int)this->m_OutFrameT.m_id + 16] = *(_DWORD *)&this->m_NoteItem[17].m_HeadShot_NO_SEL[1].m_text[768 * (int)this->m_OutFrameT.m_id + 8] + 26;
      *((_DWORD *)&this->m_NoteItem[17].m_HeadShot_NO_SEL[1].m_pbkInfo + 192 * (int)this->m_OutFrameT.m_id) = *(_DWORD *)&this->m_NoteItem[17].m_HeadShot_NO_SEL[1].m_text[768 * (int)this->m_OutFrameT.m_id + 12] + 38;
      sub_445FA0(this->m_NoteItem[7].m_HeadShot[48 * (int)this->m_OutFrameT.m_id + 1].m_text);
      v31 = ((void **)(this)) + 192 * (int)this->m_OutFrameT.m_id;
      v32 = (void **)(v31 + 15757);
      v31 += 15761;
      *v31 = *v32;
      v31[1] = v32[1];
      v31[2] = v32[2];
      v31[3] = v32[3];
      sub_445FA0(this->m_NoteItem[7].m_HeadShot[48 * (int)this->m_OutFrameT.m_id + 2].m_text);
      *((_DWORD *)&this->m_NoteItem[17].m_HeadShot_NO_SEL[1].m_mouseoff + 192 * (int)this->m_OutFrameT.m_id) = *(_DWORD *)&this->m_NoteItem[17].m_HeadShot_NO_SEL[1].m_text[768 * (int)this->m_OutFrameT.m_id + 12];
      *((_DWORD *)&this->m_NoteItem[17].m_HeadShot_NO_SEL[1].m_pbk2 + 192 * (int)this->m_OutFrameT.m_id) = *(_DWORD *)&this->m_NoteItem[17].m_HeadShot_NO_SEL[1].m_text[768 * (int)this->m_OutFrameT.m_id + 16] + 2;
      *(&this->m_NoteItem[17].m_HeadShot_NO_SEL[1].m_FVF + 192 * (int)this->m_OutFrameT.m_id) = *((_DWORD *)&this->m_NoteItem[17].m_HeadShot_NO_SEL[1].m_pbk2
                                                                                                + 192
                                                                                                * (int)this->m_OutFrameT.m_id)
                                                                                              + 26;
      *(&this->m_NoteItem[17].m_HeadShot_NO_SEL[1].m_nTextW + 192 * (int)this->m_OutFrameT.m_id) = *((_DWORD *)&this->m_NoteItem[17].m_HeadShot_NO_SEL[1].m_pbkInfo + 192 * (int)this->m_OutFrameT.m_id);
      sub_445FA0(this->m_NoteItem[7].m_HeadShot[48 * (int)this->m_OutFrameT.m_id + 3].m_text);
      v33 = ((void **)(this)) + 192 * (int)this->m_OutFrameT.m_id;
      v34 = (void **)(v33 + 15765);
      v33 += 15769;
      *v33 = *v34;
      v33[1] = v34[1];
      v33[2] = v34[2];
      v33[3] = v34[3];
      sub_445FA0(this->m_NoteItem[7].m_HeadShot[48 * (int)this->m_OutFrameT.m_id + 4].m_text);
      (&this->m_NoteItem[17].m_HeadShot_NO_SEL[2].m_textx)[192 * (int)this->m_OutFrameT.m_id] = (gbRefObject *)(*(&this->m_NoteItem[6].m_NotePic.m_benable + 4 * (int)this->m_OutFrameT.m_id) - 38);
      *((_DWORD *)&this->m_NoteItem[17].m_HeadShot_NO_SEL[2].m_ratioh + 192 * (int)this->m_OutFrameT.m_id) = *(&this->m_NoteItem[6].m_NotePic.m_childs.m_needscriptdel + 4 * (int)this->m_OutFrameT.m_id) - 30;
      (&this->m_NoteItem[17].m_HeadShot_NO_SEL[2].m_texty)[192 * (int)this->m_OutFrameT.m_id] = (gbRefObject *)(*((_DWORD *)&this->m_NoteItem[17].m_HeadShot_NO_SEL[2].m_ratioh + 192 * (int)this->m_OutFrameT.m_id) + 26);
      (&this->m_NoteItem[17].m_HeadShot_NO_SEL[2].m_fonttype)[192 * (int)this->m_OutFrameT.m_id] = (Parent_Data *)((char *)&(&this->m_NoteItem[17].m_HeadShot_NO_SEL[2].m_textx)[192 * (int)this->m_OutFrameT.m_id][4].RefCount + 2);
      sub_445FA0(&this->m_NoteItem[7].m_NoteLv[48 * (int)this->m_OutFrameT.m_id + 2].m_texty);
      v35 = ((void **)(this)) + 192 * (int)this->m_OutFrameT.m_id;
      v36 = (void **)(v35 + 15789);
      v35 += 15793;
      *v35 = *v36;
      v35[1] = v36[1];
      v35[2] = v36[2];
      v35[3] = v36[3];
      sub_445FA0(&this->m_NoteItem[7].m_NoteLv[48 * (int)this->m_OutFrameT.m_id + 3].m_texty);
      *((_DWORD *)&this->m_NoteItem[17].m_HeadShot_NO_SEL[2].m_pbkInfo + 192 * (int)this->m_OutFrameT.m_id) = (&this->m_NoteItem[17].m_HeadShot_NO_SEL[2].m_textx)[192 * (int)this->m_OutFrameT.m_id];
      *(_DWORD *)&this->m_NoteItem[17].m_HeadShot_NO_SEL[2].m_text[768 * (int)this->m_OutFrameT.m_id + 16] = (unsigned long)((char *)((void **)((&this->m_NoteItem[17].m_HeadShot_NO_SEL[2].m_texty)[192 * (int)this->m_OutFrameT.m_id])) + 2);
      *((_DWORD *)&this->m_NoteItem[17].m_HeadShot_NO_SEL[2].m_ppic + 192 * (int)this->m_OutFrameT.m_id) = *(_DWORD *)&this->m_NoteItem[17].m_HeadShot_NO_SEL[2].m_text[768 * (int)this->m_OutFrameT.m_id + 16] + 26;
      *((_DWORD *)&this->m_NoteItem[17].m_HeadShot_NO_SEL[2].m_ppicInfo + 192 * (int)this->m_OutFrameT.m_id) = (&this->m_NoteItem[17].m_HeadShot_NO_SEL[2].m_fonttype)[192 * (int)this->m_OutFrameT.m_id];
      sub_445FA0(&this->m_NoteItem[7].m_NoteLv[48 * (int)this->m_OutFrameT.m_id + 4].m_texty);
      v37 = ((void **)(this)) + 192 * (int)this->m_OutFrameT.m_id;
      v38 = (void **)(v37 + 15797);
      v37 += 15801;
      *v37 = *v38;
      v37[1] = v38[1];
      v37[2] = v38[2];
      v37[3] = v38[3];
      sub_445FA0(&(&this->m_NoteItem[7].m_NotePic.m_texty)[1824 * (int)this->m_OutFrameT.m_id]);
      *(&this->m_NoteItem[17].m_HeadShot_NO_SEL[3].m_benable + 192 * (int)this->m_OutFrameT.m_id) = *(&this->m_NoteItem[6].m_NotePic.m_benable + 4 * (int)this->m_OutFrameT.m_id) - 38;
      *(&this->m_NoteItem[17].m_HeadShot_NO_SEL[3].m_bvisible + 192 * (int)this->m_OutFrameT.m_id) = *(&this->m_NoteItem[6].m_NotePic.m_bvisible + 4 * (int)this->m_OutFrameT.m_id) + 4;
      *(&this->m_NoteItem[17].m_HeadShot_NO_SEL[3].m_bfocus + 192 * (int)this->m_OutFrameT.m_id) = *(&this->m_NoteItem[17].m_HeadShot_NO_SEL[3].m_bvisible + 192 * (int)this->m_OutFrameT.m_id)
                                                                                                 + 26;
      *((_DWORD *)&this->m_NoteItem[17].m_HeadShot_NO_SEL[3].pDebugTex + 192 * (int)this->m_OutFrameT.m_id) = *(&this->m_NoteItem[17].m_HeadShot_NO_SEL[3].m_benable + 192 * (int)this->m_OutFrameT.m_id) + 38;
      sub_445FA0(&this->m_NoteItem[8].m_NoteState.m_pfather + 1824 * (int)this->m_OutFrameT.m_id);
      v39 = ((void **)(this)) + 192 * (int)this->m_OutFrameT.m_id;
      v40 = (void **)(v39 + 15821);
      v39 += 15825;
      *v39 = *v40;
      v39[1] = v40[1];
      v39[2] = v40[2];
      v39[3] = v40[3];
      sub_445FA0(&this->m_NoteItem[8].m_HeadShot_NO_SEL[48 * (int)this->m_OutFrameT.m_id].m_pfather);
      (&this->m_NoteItem[17].m_HeadShot_NO_SEL[3].m_fonttype)[192 * (int)this->m_OutFrameT.m_id] = (Parent_Data *)*(&this->m_NoteItem[17].m_HeadShot_NO_SEL[3].m_benable + 192 * (int)this->m_OutFrameT.m_id);
      (&this->m_NoteItem[17].m_HeadShot_NO_SEL[3].m_texty)[192 * (int)this->m_OutFrameT.m_id] = (gbRefObject *)(*(&this->m_NoteItem[17].m_HeadShot_NO_SEL[3].m_bfocus + 192 * (int)this->m_OutFrameT.m_id) + 2);
      *(_DWORD *)&this->m_NoteItem[17].m_HeadShot_NO_SEL[3].m_text[768 * (int)this->m_OutFrameT.m_id] = (unsigned long)((char *)(&this->m_NoteItem[17].m_HeadShot_NO_SEL[3].m_texty)[192 * (int)this->m_OutFrameT.m_id] + 26);
      *(_DWORD *)&this->m_NoteItem[17].m_HeadShot_NO_SEL[3].m_text[768 * (int)this->m_OutFrameT.m_id + 4] = *((_DWORD *)&this->m_NoteItem[17].m_HeadShot_NO_SEL[3].pDebugTex + 192 * (int)this->m_OutFrameT.m_id);
      sub_445FA0(&this->m_NoteItem[8].m_HeadShot_NO_SEL[48 * (int)this->m_OutFrameT.m_id + 1].m_pfather);
      v41 = ((void **)(this)) + 192 * (int)this->m_OutFrameT.m_id;
      v42 = (void **)(v41 + 15829);
      v41 += 15833;
      *v41 = *v42;
      v41[1] = v42[1];
      v41[2] = v42[2];
      v41[3] = v42[3];
      sub_445FA0(&this->m_NoteItem[8].m_HeadShot_NO_SEL[48 * (int)this->m_OutFrameT.m_id + 2].m_pfather);
      *((_DWORD *)&this->m_NoteItem[17].m_HeadShot_NO_SEL[4].m_childs.m_pData + 192 * (int)this->m_OutFrameT.m_id) = *(&this->m_NoteItem[6].m_NotePic.m_benable + 4 * (int)this->m_OutFrameT.m_id) - 38;
      *((_DWORD *)&this->m_NoteItem[17].m_HeadShot_NO_SEL[4].m_pfather + 192 * (int)this->m_OutFrameT.m_id) = *(&this->m_NoteItem[6].m_NotePic.m_bvisible + 4 * (int)this->m_OutFrameT.m_id) + 4;
      *(&this->m_NoteItem[17].m_HeadShot_NO_SEL[4].m_childs.capacity + 192 * (int)this->m_OutFrameT.m_id) = *((_DWORD *)&this->m_NoteItem[17].m_HeadShot_NO_SEL[4].m_pfather + 192 * (int)this->m_OutFrameT.m_id) + 26;
      *(&this->m_NoteItem[17].m_HeadShot_NO_SEL[4].m_childs.m_nSize + 192 * (int)this->m_OutFrameT.m_id) = *((_DWORD *)&this->m_NoteItem[17].m_HeadShot_NO_SEL[4].m_childs.m_pData + 192 * (int)this->m_OutFrameT.m_id) + 38;
      sub_445FA0(&this->m_NoteItem[8].m_HeadShot[48 * (int)this->m_OutFrameT.m_id + 2].m_pfather);
      v43 = ((void **)(this)) + 192 * (int)this->m_OutFrameT.m_id;
      v44 = (void **)(v43 + 15853);
      v43 += 15857;
      *v43 = *v44;
      v43[1] = v44[1];
      v43[2] = v44[2];
      v43[3] = v44[3];
      sub_445FA0(&this->m_NoteItem[8].m_HeadShot[48 * (int)this->m_OutFrameT.m_id + 3].m_pfather);
      *((_DWORD *)&this->m_NoteItem[17].m_HeadShot_NO_SEL[4].pDebugTex + 192 * (int)this->m_OutFrameT.m_id) = *((_DWORD *)&this->m_NoteItem[17].m_HeadShot_NO_SEL[4].m_childs.m_pData + 192 * (int)this->m_OutFrameT.m_id);
      *(&this->m_NoteItem[17].m_HeadShot_NO_SEL[4].m_bfocus + 192 * (int)this->m_OutFrameT.m_id) = *(&this->m_NoteItem[17].m_HeadShot_NO_SEL[4].m_childs.capacity + 192 * (int)this->m_OutFrameT.m_id)
                                                                                                 + 2;
      *(&this->m_NoteItem[17].m_HeadShot_NO_SEL[4].m_align + 192 * (int)this->m_OutFrameT.m_id) = *(&this->m_NoteItem[17].m_HeadShot_NO_SEL[4].m_bfocus
                                                                                                  + 192 * (int)this->m_OutFrameT.m_id)
                                                                                                + 26;
      *((_DWORD *)&this->m_NoteItem[17].m_HeadShot_NO_SEL[4].m_ratiow + 192 * (int)this->m_OutFrameT.m_id) = *(&this->m_NoteItem[17].m_HeadShot_NO_SEL[4].m_childs.m_nSize + 192 * (int)this->m_OutFrameT.m_id);
      sub_445FA0(&this->m_NoteItem[8].m_HeadShot[48 * (int)this->m_OutFrameT.m_id + 4].m_pfather);
      v45 = ((void **)(this)) + 192 * (int)this->m_OutFrameT.m_id;
      v46 = (void **)(v45 + 15861);
      v45 += 15865;
      *v45 = *v46;
      v45[1] = v46[1];
      v45[2] = v46[2];
      v45[3] = v46[3];
      sub_445FA0(&this->m_NoteItem[8].m_NoteTime.m_rect.right + 1824 * (int)this->m_OutFrameT.m_id);
      *((_DWORD *)&this->m_NoteItem[17].m_HeadShot[0].m_id + 192 * (int)this->m_OutFrameT.m_id) = *(&this->m_NoteItem[6].m_NotePic.m_benable
                                                                                                  + 4 * (int)this->m_OutFrameT.m_id)
                                                                                                - 38;
      *(&this->m_NoteItem[17].m_HeadShot[0].m_wndcolor.Color + 192 * (int)this->m_OutFrameT.m_id) = *(&this->m_NoteItem[6].m_NotePic.m_bvisible + 4 * (int)this->m_OutFrameT.m_id) + 4;
      *(&this->m_NoteItem[17].m_HeadShot[0].m_rect.left + 192 * (int)this->m_OutFrameT.m_id) = *(&this->m_NoteItem[17].m_HeadShot[0].m_wndcolor.Color
                                                                                               + 192
                                                                                               * (int)this->m_OutFrameT.m_id)
                                                                                             + 26;
      *(&this->m_NoteItem[17].m_HeadShot[0].m_rect.top + 192 * (int)this->m_OutFrameT.m_id) = *((_DWORD *)&this->m_NoteItem[17].m_HeadShot[0].m_id
                                                                                              + 192
                                                                                              * (int)this->m_OutFrameT.m_id)
                                                                                            + 38;
      sub_445FA0(&this->m_NoteItem[8].m_NoteLv[48 * (int)this->m_OutFrameT.m_id + 3].m_rect.right);
      v47 = ((void **)(this)) + 192 * (int)this->m_OutFrameT.m_id;
      v48 = (void **)(v47 + 15885);
      v47 += 15889;
      *v47 = *v48;
      v47[1] = v48[1];
      v47[2] = v48[2];
      v47[3] = v48[3];
      sub_445FA0(&this->m_NoteItem[8].m_NoteLv[48 * (int)this->m_OutFrameT.m_id + 4].m_rect.right);
      *(&this->m_NoteItem[17].m_HeadShot[0].m_childs.m_nSize + 192 * (int)this->m_OutFrameT.m_id) = *((_DWORD *)&this->m_NoteItem[17].m_HeadShot[0].m_id + 192 * (int)this->m_OutFrameT.m_id);
      *(&this->m_NoteItem[17].m_HeadShot[0].m_childs.capacity + 192 * (int)this->m_OutFrameT.m_id) = *(&this->m_NoteItem[17].m_HeadShot[0].m_rect.left + 192 * (int)this->m_OutFrameT.m_id) + 2;
      *(&this->m_NoteItem[17].m_HeadShot[0].m_childs.m_needscriptdel + 192 * (int)this->m_OutFrameT.m_id) = *(&this->m_NoteItem[17].m_HeadShot[0].m_childs.capacity + 192 * (int)this->m_OutFrameT.m_id) + 26;
      *(&this->m_NoteItem[17].m_HeadShot[0].m_bcreateok + 192 * (int)this->m_OutFrameT.m_id) = *(&this->m_NoteItem[17].m_HeadShot[0].m_rect.top
                                                                                               + 192
                                                                                               * (int)this->m_OutFrameT.m_id);
      sub_445FA0(&this->m_NoteItem[8].m_NotePic.m_rect.right + 1824 * (int)this->m_OutFrameT.m_id);
      v49 = ((void **)(this)) + 192 * (int)this->m_OutFrameT.m_id;
      v50 = (void **)(v49 + 15893);
      v49 += 15897;
      *v49 = *v50;
      v49[1] = v50[1];
      v49[2] = v50[2];
      v49[3] = v50[3];
      sub_445FA0(&this->m_NoteItem[8].m_NotePicName.m_rect.right + 1824 * (int)this->m_OutFrameT.m_id);
      this->m_OutFrameT.m_rect.left = 0;
      do
      {
        v51 = (this->m_OutFrameT.m_rect.left + 6 * (int)this->m_OutFrameT.m_id) << 7;
        *(int *)((char *)&this->m_NoteItem[18].m_HeadShot[0].m_align + v51) = (int)&(*(gbTexture **)((char *)&this->m_NoteItem[17].m_HeadShot_NO_SEL[0].pDebugTex + v51))[-1].InFmt.b_shift;
        v52 = (this->m_OutFrameT.m_rect.left + 6 * (int)this->m_OutFrameT.m_id) << 7;
        *(gbTexture **)((char *)&this->m_NoteItem[18].m_HeadShot[0].pDebugTex + v52) = *(gbTexture **)((char *)&this->m_NoteItem[17].m_HeadShot_NO_SEL[0].m_bfocus + v52);
        v53 = (this->m_OutFrameT.m_rect.left + 6 * (int)this->m_OutFrameT.m_id) << 7;
        *(_DWORD *)((char *)&this->m_NoteItem[18].m_HeadShot[0].m_ratiow + v53) = *(int *)((char *)&this->m_NoteItem[17].m_HeadShot_NO_SEL[0].m_align + v53);
        v54 = (this->m_OutFrameT.m_rect.left + 6 * (int)this->m_OutFrameT.m_id) << 7;
        *(_DWORD *)((char *)&this->m_NoteItem[18].m_HeadShot[0].m_ratioh + v54) = *(int *)((char *)&this->m_NoteItem[18].m_HeadShot[0].m_align + v54)
                                                                                + 38;
        v55 = (this->m_OutFrameT.m_rect.left + 6 * (int)this->m_OutFrameT.m_id) << 7;
        *(char **)((char *)&this->m_NoteItem[18].m_HeadShot[0].m_texty + v55) = *(char **)((char *)&this->m_NoteItem[17].m_HeadShot_NO_SEL[0].m_textx
                                                                                         + v55)
                                                                              - 12;
        v56 = (this->m_OutFrameT.m_rect.left + 6 * (int)this->m_OutFrameT.m_id) << 7;
        *(gbRefObject **)((char *)&this->m_NoteItem[18].m_HeadShot[0].m_textx + v56) = *(gbRefObject **)((char *)&this->m_NoteItem[17].m_HeadShot_NO_SEL[0].m_ratioh + v56);
        v57 = (this->m_OutFrameT.m_rect.left + 6 * (int)this->m_OutFrameT.m_id) << 7;
        *(Parent_Data **)((char *)&this->m_NoteItem[18].m_HeadShot[0].m_fonttype + v57) = *(Parent_Data **)((char *)&this->m_NoteItem[17].m_HeadShot_NO_SEL[0].m_texty + v57);
        v58 = (this->m_OutFrameT.m_rect.left + 6 * (int)this->m_OutFrameT.m_id) << 7;
        *(_DWORD *)&this->m_NoteItem[18].m_HeadShot[0].m_text[v58] = *(char **)((char *)&this->m_NoteItem[18].m_HeadShot[0].m_texty
                                                                              + v58)
                                                                   + 38;
        v59 = (this->m_OutFrameT.m_rect.left + 6 * (int)this->m_OutFrameT.m_id) << 7;
        *(_DWORD *)&this->m_NoteItem[18].m_HeadShot[0].m_text[v59 + 8] = *(_DWORD *)&this->m_NoteItem[17].m_HeadShot_NO_SEL[0].m_text[v59 + 4]
                                                                       - 12;
        v60 = (this->m_OutFrameT.m_rect.left + 6 * (int)this->m_OutFrameT.m_id) << 7;
        *(_DWORD *)&this->m_NoteItem[18].m_HeadShot[0].m_text[v60 + 4] = *(_DWORD *)&this->m_NoteItem[17].m_HeadShot_NO_SEL[0].m_text[v60];
        v61 = this->m_OutFrameT.m_rect.left + 6 * (int)this->m_OutFrameT.m_id;
        *(_DWORD *)&this->m_NoteItem[18].m_HeadShot[0].m_text[128 * v61 + 12] = *(_DWORD *)&this->m_NoteItem[17].m_HeadShot_NO_SEL[0].m_text[128 * v61 + 8];
        v62 = (this->m_OutFrameT.m_rect.left + 6 * (int)this->m_OutFrameT.m_id) << 7;
        *(_DWORD *)&this->m_NoteItem[18].m_HeadShot[0].m_text[v62 + 16] = *(_DWORD *)&this->m_NoteItem[18].m_HeadShot[0].m_text[v62 + 8]
                                                                        + 38;
        v63 = (this->m_OutFrameT.m_rect.left + 6 * (int)this->m_OutFrameT.m_id) << 7;
        *(gbTexture **)((char *)&this->m_NoteItem[18].m_HeadShot[0].m_ppic + v63) = (gbTexture *)&(*(_PlugInfo **)((char *)&this->m_NoteItem[17].m_HeadShot_NO_SEL[0].m_pbkInfo + v63))[-1]._tex_uvRB.v;
        v64 = (this->m_OutFrameT.m_rect.left + 6 * (int)this->m_OutFrameT.m_id) << 7;
        *(_PlugInfo **)((char *)&this->m_NoteItem[18].m_HeadShot[0].m_pbkInfo + v64) = *(_PlugInfo **)&this->m_NoteItem[17].m_HeadShot_NO_SEL[0].m_text[v64 + 16];
        v65 = (this->m_OutFrameT.m_rect.left + 6 * (int)this->m_OutFrameT.m_id) << 7;
        *(_PlugInfo **)((char *)&this->m_NoteItem[18].m_HeadShot[0].m_ppicInfo + v65) = *(_PlugInfo **)((char *)&this->m_NoteItem[17].m_HeadShot_NO_SEL[0].m_ppic + v65);
        v66 = (this->m_OutFrameT.m_rect.left + 6 * (int)this->m_OutFrameT.m_id) << 7;
        *(gbTexture **)((char *)&this->m_NoteItem[18].m_HeadShot[0].m_disablepic + v66) = (gbTexture *)(&(*(gbTexture **)((char *)&this->m_NoteItem[18].m_HeadShot[0].m_ppic + v66))->InFmt.Type + 2);
        v67 = this->m_OutFrameT.m_rect.left + 1;
        this->m_OutFrameT.m_rect.left = v67;
      }
      while ( v67 < 6 );
      this->m_OutFrameT.m_rect.left = 0;
      do
      {
        v68 = (this->m_OutFrameT.m_rect.left + 6 * (int)this->m_OutFrameT.m_id) << 7;
        *(gbTexture **)((char *)&this->m_NoteItem[18].m_HeadShot[0].m_pbk2 + v68) = (gbTexture *)&(*(_PlugInfo **)((char *)&this->m_NoteItem[17].m_HeadShot_NO_SEL[0].m_disablepicInfo + v68))[-1]._tex_uvRB.v;
        v69 = (this->m_OutFrameT.m_rect.left + 6 * (int)this->m_OutFrameT.m_id) << 7;
        *(_PlugInfo **)((char *)&this->m_NoteItem[18].m_HeadShot[0].m_disablepicInfo + v69) = *(_PlugInfo **)((char *)&this->m_NoteItem[17].m_HeadShot_NO_SEL[0].m_disablepic + v69);
        v70 = (this->m_OutFrameT.m_rect.left + 6 * (int)this->m_OutFrameT.m_id) << 7;
        *(_DWORD *)(&this->m_NoteItem[18].m_HeadShot[0].m_mouseoff + v70) = *(gbTexture **)((char *)&this->m_NoteItem[17].m_HeadShot_NO_SEL[0].m_pbk2
                                                                                          + v70);
        v71 = (this->m_OutFrameT.m_rect.left + 6 * (int)this->m_OutFrameT.m_id) << 7;
        *(int *)((char *)&this->m_NoteItem[18].m_HeadShot[0].m_FVF + v71) = (int)(&(*(gbTexture **)((char *)&this->m_NoteItem[18].m_HeadShot[0].m_pbk2 + v71))->InFmt.Type + 2);
        v72 = (this->m_OutFrameT.m_rect.left + 6 * (int)this->m_OutFrameT.m_id) << 7;
        *(void **)((char *)((void **)&(this->m_NoteItem[18].m_HeadShot[1])) + v72) = (void *)(*(int *)((char *)&this->m_NoteItem[17].m_HeadShot_NO_SEL[0].m_nTextW + v72) - 12);
        v73 = (this->m_OutFrameT.m_rect.left + 6 * (int)this->m_OutFrameT.m_id) << 7;
        *(int *)((char *)&this->m_NoteItem[18].m_HeadShot[0].m_nTextW + v73) = *(int *)((char *)&this->m_NoteItem[17].m_HeadShot_NO_SEL[0].m_FVF + v73);
        v74 = (this->m_OutFrameT.m_rect.left + 6 * (int)this->m_OutFrameT.m_id) << 7;
        *(unsigned int *)((char *)&this->m_NoteItem[18].m_HeadShot[1].m_fontcolor.Color + v74) = *(unsigned int *)((char *)((void **)&(this->m_NoteItem[17].m_HeadShot_NO_SEL[1])) + v74);
        v75 = (this->m_OutFrameT.m_rect.left + 6 * (int)this->m_OutFrameT.m_id) << 7;
        *(unsigned int *)((char *)&this->m_NoteItem[18].m_HeadShot[1].m_wndcolor.Color + v75) = (unsigned int)&(*(void **)((char *)((void **)&(this->m_NoteItem[18].m_HeadShot[1])) + v75))[1].Update_2ff0 + 2;
        v76 = (this->m_OutFrameT.m_rect.left + 6 * (int)this->m_OutFrameT.m_id) << 7;
        *(LONG *)((char *)&this->m_NoteItem[18].m_HeadShot[1].m_rect.left + v76) = *(LONG *)((char *)&this->m_NoteItem[17].m_HeadShot_NO_SEL[1].m_id
                                                                                           + v76)
                                                                                 - 12;
        v77 = (this->m_OutFrameT.m_rect.left + 6 * (int)this->m_OutFrameT.m_id) << 7;
        *(void **)((char *)&this->m_NoteItem[18].m_HeadShot[1].m_id + v77) = *(void **)((char *)&this->m_NoteItem[17].m_HeadShot_NO_SEL[1].m_wndcolor.Color
                                                                                      + v77);
        v78 = (this->m_OutFrameT.m_rect.left + 6 * (int)this->m_OutFrameT.m_id) << 7;
        *(LONG *)((char *)&this->m_NoteItem[18].m_HeadShot[1].m_rect.top + v78) = *(LONG *)((char *)&this->m_NoteItem[17].m_HeadShot_NO_SEL[1].m_rect.left
                                                                                          + v78);
        v79 = (this->m_OutFrameT.m_rect.left + 6 * (int)this->m_OutFrameT.m_id) << 7;
        *(LONG *)((char *)&this->m_NoteItem[18].m_HeadShot[1].m_rect.right + v79) = *(LONG *)((char *)&this->m_NoteItem[18].m_HeadShot[1].m_rect.left
                                                                                            + v79)
                                                                                  + 38;
        v80 = (this->m_OutFrameT.m_rect.left + 6 * (int)this->m_OutFrameT.m_id) << 7;
        *(UIWnd **)((char *)&this->m_NoteItem[18].m_HeadShot[1].m_pfather + v80) = (UIWnd *)(*(LONG *)((char *)&this->m_NoteItem[17].m_HeadShot_NO_SEL[1].m_rect.bottom + v80)
                                                                                           - 12);
        v81 = (this->m_OutFrameT.m_rect.left + 6 * (int)this->m_OutFrameT.m_id) << 7;
        *(LONG *)((char *)&this->m_NoteItem[18].m_HeadShot[1].m_rect.bottom + v81) = *(LONG *)((char *)&this->m_NoteItem[17].m_HeadShot_NO_SEL[1].m_rect.right
                                                                                             + v81);
        v82 = (this->m_OutFrameT.m_rect.left + 6 * (int)this->m_OutFrameT.m_id) << 7;
        *(char **)((char *)&this->m_NoteItem[18].m_HeadShot[1].m_childs.m_pData + v82) = *(char **)((char *)&this->m_NoteItem[17].m_HeadShot_NO_SEL[1].m_pfather
                                                                                                  + v82);
        v83 = (this->m_OutFrameT.m_rect.left + 6 * (int)this->m_OutFrameT.m_id) << 7;
        *(int *)((char *)&this->m_NoteItem[18].m_HeadShot[1].m_childs.capacity + v83) = (int)&(*(UIWnd **)((char *)&this->m_NoteItem[18].m_HeadShot[1].m_pfather + v83))->m_childs.m_pData
                                                                                                 + 2;
        v84 = this->m_OutFrameT.m_rect.left + 1;
        this->m_OutFrameT.m_rect.left = v84;
      }
      while ( v84 < 6 );
    }
    v85 = (int)this->m_OutFrameT.m_id + 1;
    this->m_OutFrameT.m_id = (void *)v85;
  }
  while ( v85 < 5 );
}

// 0x0047C1C0
int UITitle_JDHY::HandleDeviceLostA()
{
  RenderTarget *Instance_db10; // eax
  PAL3 *v3; // ecx
  PAL3 *v4; // ecx
  int v5; // eax
  RenderTarget *v6; // eax
  int result; // eax
  PAL3 *v8; // ecx
  unsigned __int8 v9; // bl
  PAL3 *v10; // ecx
  RenderTarget *v11; // eax
  PAL3 *v12; // ecx
  RenderTarget *v13; // eax

  Instance_db10 = (RenderTarget *)GetInstance_db10((PAL3 *)this);
  (((RenderTarget *)Instance_db10))->RenderTarget::OnDeviceLost(1);
  v4 = *(PAL3 **)GetInstance_db10(v3);
  v5 = 1061158912;
  if ( v4 )
    v5 = 1065353216;
  this->m_NoteItem[0].m_NoteMoney.m_bfocus = v5;
  this->m_NoteItem[0].m_NoteMoney.m_benable = v5;
  v6 = (RenderTarget *)GetInstance_db10(v4);
  LOBYTE(result) = (((RenderTarget *)v6))->RenderTarget::OnResetDevice(1);
  if ( (_BYTE)result )
  {
    v9 = g_bGameFlag2;
    g_bGameFlag2 = 0;
    (((PAL3 *)v8))->PAL3::Render();
    g_bGameFlag2 = v9;
    v11 = (RenderTarget *)GetInstance_db10(v10);
    (((RenderTarget *)v11))->RenderTarget::RenderToScreen();
    this->m_NoteItem[0].m_NoteMoney.m_bvisible = 0;
    v13 = (RenderTarget *)GetInstance_db10(v12);
    result = (int)(((RenderTarget *)v13))->RenderTarget::GetActiveTexture();
    if ( result )
    {
      if ( *(_DWORD *)(result + 84) )
        this->m_NoteItem[0].m_NoteMoney.m_bvisible = result;
    }
  }
  else
  {
    this->m_NoteItem[0].m_NoteMoney.m_bvisible = 0;
  }
  return result;
}

// 0x004B15F0
int UITitle_JDHY::InitNoteItems()
{
  gbTexture *m_ppic; // eax
  _PlugInfo *m_pbkInfo; // ecx
  int result; // eax
  LONG *p_top; // esi
  _DWORD *v6; // edi
  int v7; // [esp+ACh] [ebp-0x1C]
  int v8; // [esp+B0h] [ebp-0x18]
  int v9; // [esp+B4h] [ebp-0x14]
  _DWORD v10[4]; // [esp+B8h] [ebp-0x10] BYREF

  v10[1] = 42;
  m_ppic = (gbTexture *)this->m_NoteItem[79].m_NotePicName.m_ppic;
  m_pbkInfo = (_PlugInfo *)this->m_NoteItem[79].m_NotePicName.m_pbkInfo;
  result = (int)&m_ppic->NameCrc32;
  v10[0] = 12;
  v10[2] = result;
  v10[3] = (unsigned long)&m_pbkInfo->name[38];
  v7 = 0;
  p_top = (LONG *)&this->m_NoteItem[43].m_HeadShot[4].m_rect.top;
  do
  {
    LOBYTE(result) = g_bDebugMode;
    (*(void ( **)(LONG *, int *, _DWORD *, UITitle_JDHY *, char *, int, int))(*(p_top - 86) + 28))(
      p_top - 86,
      &byte_A00703,
      v10,
      this,
      "UI\\GameMainUI\\System\\Note",
      1,
      result);
    (((PalScript *)(p_top - 86)))->PalScript::OpenScript("UI\\GameMainUI\\System\\Note2.tga", g_bDebugMode);
    *((_BYTE *)p_top - 4) = 0;
    (*(void ( **)(LONG *, _DWORD))*(p_top - 86))(p_top - 86, 0);
    (*(void ( **)(LONG *, int *, _DWORD *, UITitle_JDHY *))(*p_top + 16))(p_top, &byte_A00703, v10, this);
    (((UIScene *)p_top))->UIScene::SetShow(0);
    v9 = v7 + 1;
    sprintf(&this->buf[16], &dir[20], v7 + 1);
    SetEnable((UICaption *)p_top);
    (*(void ( **)(LONG *, _DWORD))*p_top)(p_top, 0);
    (*(void ( **)(LONG *, int *, _DWORD *, UITitle_JDHY *))(p_top[38] + 16))(
      p_top + 38,
      &byte_A00703,
      v10,
      this);
    (*(void ( **)(LONG *, _DWORD))p_top[38])(p_top + 38, 0);
    v6 = (_DWORD *)(p_top + 76);
    v8 = 5;
    do
    {
      (*(void ( **)(_DWORD *, int *, _DWORD *, UITitle_JDHY *))(v6[190] + 16))(
        v6 + 190,
        &byte_A00703,
        v10,
        this);
      (*(void ( **)(_DWORD *, _DWORD))v6[190])(v6 + 190, 0);
      (*(void ( **)(_DWORD *, int *, _DWORD *, UITitle_JDHY *))(*v6 + 16))(v6, &byte_A00703, v10, this);
      (*(void ( **)(_DWORD *, _DWORD))*v6)(v6, 0);
      (*(void ( **)(_DWORD *, int *, _DWORD *, UITitle_JDHY *))(v6[458] + 16))(
        v6 + 458,
        &byte_A00703,
        v10,
        this);
      sub_446010(v6 + 458);
      (*(void ( **)(_DWORD *, _DWORD))v6[458])(v6 + 458, 0);
      v6 += 38;
      --v8;
    }
    while ( v8 );
    (*(void ( **)(LONG *, int *, _DWORD *, UITitle_JDHY *))(p_top[458] + 16))(
      p_top + 458,
      &byte_A00703,
      v10,
      this);
    sub_446010(p_top + 458);
    (*(void ( **)(LONG *, _DWORD))p_top[458])(p_top + 458, 0);
    (*(void ( **)(LONG *, int *, _DWORD *, UITitle_JDHY *))(p_top[496] + 16))(
      p_top + 496,
      &byte_A00703,
      v10,
      this);
    sub_446010(p_top + 496);
    (*(void ( **)(LONG *, _DWORD))p_top[496])(p_top + 496, 0);
    (*(void ( **)(LONG *, int *, _DWORD *, UITitle_JDHY *))(p_top[724] + 16))(
      p_top + 724,
      &byte_A00703,
      v10,
      this);
    (*(void ( **)(LONG *, _DWORD))p_top[724])(p_top + 724, 0);
    (*(void ( **)(LONG *, int *, _DWORD *, UITitle_JDHY *))(p_top[762] + 16))(
      p_top + 762,
      &byte_A00703,
      v10,
      this);
    sub_446010(p_top + 762);
    (*(void ( **)(LONG *, _DWORD))p_top[762])(p_top + 762, 0);
    p_top += 890;
    *((_BYTE *)&this->m_NoteItem[43].m_HeadShot[1].m_ratioh + v7) = 0;
    result = ++v7;
  }
  while ( v9 < 36 );
  return result;
}

// 0x004B1C00
int UITitle_JDHY::ResetNoteState()
{
  gbTexture *m_pbk2; // eax
  int result; // eax

  m_pbk2 = (gbTexture *)this->m_NoteItem[79].m_NotePicName.m_pbk2;
  if ( m_pbk2 )
  {
    result = (int)&m_pbk2[-1].nLevels + 3;
    if ( !result )
    {
      result = 1;
      *(_DWORD *)this->m_NoteItem[43].m_NoteID.m_text = 1;
      LOBYTE(this->m_NoteItem[43].m_NoteID.m_textx) = 1;
      *(_DWORD *)this->m_NoteItem[43].m_NoteItemBk.m_caption = 0;
      LOBYTE(this->m_NoteItem[43].m_NoteItemBk.m_disablepicInfo) = 0;
    }
  }
  else
  {
    result = 1;
    *(_DWORD *)this->m_NoteItem[43].m_NoteID.m_text = 0;
    LOBYTE(this->m_NoteItem[43].m_NoteID.m_textx) = 0;
    *(_DWORD *)this->m_NoteItem[43].m_NoteItemBk.m_caption = 1;
    LOBYTE(this->m_NoteItem[43].m_NoteItemBk.m_disablepicInfo) = 1;
  }
  return result;
}

// 0x004B2750
FILE * UITitle_JDHY::SaveData(double Data, int nVal)
{
  Actor *SaveDataManager; // eax
  FILE *v5; // edi
  void *v7; // esi
  double v8; // [esp-0x4] [ebp-0x94]
  int v9; // [esp+0x4] [ebp-0x8C]
  char Buffer[125]; // [esp+0x10] [ebp-0x80] BYREF
  __int16 v11; // [esp+0x8D] [ebp-0x3]
  char v12; // [esp+0x8F] [ebp-0x1]

  (((CGameData *)&g_gamefrm))->CGameData::Load(0);
  LODWORD(v8) = LODWORD(Data);
  SaveDataManager = (Actor *)GetSaveDataManager();
  v5 = (((Actor *)SaveDataManager))->Actor::DoSceneTransition(v8, v9);
  if ( v5 )
  {
    v7 = g_pMiniGame3;
    if ( g_pMiniGame3 )
    {
      (((ArcPastScene *)g_pMiniGame3))->ArcPastScene::FreeChildList();
      operator delete(v7);
      g_pMiniGame3 = 0;
      g_bSceneLoaded_0 = 0;
      g_nMiniGameParam = 1;
      g_nMiniGameState = 0;
    }
    (((PAL3 *)"SOFTWARE\\SOFTSTAR\\PAL3_SAVE"))->PAL3::WriteRegistry((DWORD)"SEEK", LODWORD(Data));
    return v5;
  }
  else
  {
    memset(Buffer, 0, sizeof(Buffer));
    v11 = 0;
    v12 = 0;
    sprintf(Buffer, "\\n            %s", (const char *)&dword_DDB83C);
    SetEnable((UICaption *)&this->m_NoteItem[80].m_HeadShot[2].m_fonttype);
    (((UIRoleSelect *)&this->m_NoteItem[80].m_HeadShot_NO_SEL[4].m_fonttype))->UIRoleSelect::SetByte(1);
    return 0;
  }
}

// 0x004B2920
char UITitle_JDHY::SaveData(int Data)
{
  Actor *SaveDataManager; // eax
  char *v5; // ebx
  Actor *v6; // eax
  __int64 v7; // rax
  int v8; // esi
  int v9; // edi
  int v10; // edi
  char *v11; // esi
  int v12; // eax
  int v13; // edx
  int v14; // [esp+0x0] [ebp-0x2F8]
  char **p_m_pRoleObj; // [esp+0x14] [ebp-0x2E4]
  char *v16; // [esp+0x18] [ebp-0x2E0]
  float v18; // [esp+0x20] [ebp-0x2D8]
  char v19[5]; // [esp+0x24] [ebp-0x2D4]
  char v20[67]; // [esp+0x29] [ebp-0x2CF] BYREF
  int v21; // [esp+0x6C] [ebp-0x28C]
  char v22[257]; // [esp+0x70] [ebp-0x288] BYREF
  __int16 v23; // [esp+0x171] [ebp-0x187]
  char v24; // [esp+0x173] [ebp-0x185]
  char Buffer[125]; // [esp+0x174] [ebp-0x184] BYREF
  __int16 v26; // [esp+0x1F1] [ebp-0x107]
  char v27; // [esp+0x1F3] [ebp-0x105]
  char v28[257]; // [esp+0x1F4] [ebp-0x104] BYREF
  __int16 v29; // [esp+0x2F5] [ebp-0x3]
  char v30; // [esp+0x2F7] [ebp-0x1]

  memset(v28, 0, sizeof(v28));
  v29 = 0;
  v30 = 0;
  SaveDataManager = (Actor *)GetSaveDataManager();
  if ( (((Actor *)SaveDataManager))->Actor::LoadActorModel(Data) )
  {
    sprintf(v28, "Save\\PAL3_%04d.JPG", Data);
    gbImage2D::WriteJpegImage(&g_PAL3_Instance.m_Image2D, v28, 100);
    v5 = (char *)this + 3560 * Data;
    v16 = (char *)v5;
    (((UIFrameWnd *)(v5 + 159616)))->UIFrameWnd::SetTextureByID((int)v28);
    (**((void ( ***)(int, int))v5 + 39904))((int)(v5 + 159616), 1);
    memset(v22, 0, sizeof(v22));
    v23 = 0;
    v24 = 0;
    v6 = (Actor *)GetSaveDataManager();
    (((Actor *)v6))->Actor::LoadSaveData((char *)Data);
    v7 = (__int64)v18;
    v8 = (int)v7 / 3600;
    v9 = (int)v7 / 60 % 60;
    v14 = (int)v7 % 60;
    if ( (int)v7 / 3600 < 100 )
      sprintf(v22, "%s %02d:%02d:%02d", &dword_DC643C, v8, v9, v14);
    else
      sprintf(v22, "%s %03d:%02d:%02d", &dword_DC643C, v8, v9, v14);
    SetEnable((UICaption *)(v5 + 158552));
    sprintf(v22, "%s %d", (const char *)&dword_DC633C, v21);
    SetEnable((UICaption *)(v5 + 158704));
    sprintf(v22, "%s %s", (const char *)&dword_DD933C, v20);
    SetEnable((UICaption *)(v5 + 159768));
    v10 = 0;
    p_m_pRoleObj = (char **)&g_RoleSlotBuf.m_partyActor.m_pRoleObj;
    v11 = (char *)(v5 + 157784);
    do
    {
      if ( v19[v10] )
      {
        v5[v10 + 158544] = 1;
        v12 = (**(int ( ***)(char *, int))v11)(v11, 1);
        LOBYTE(v12) = g_bDebugMode;
        (((UIStatic *)v11))->UIStatic::CreateFromTemplate((void *)(0x56F314)[v10], v12);
        LOBYTE(v13) = g_bDebugMode;
        ((UIStatic *)((UIStatic *)v11 - 5))->UIStatic::CreateFromTemplate((void *)(0x56F328)[v10], v13);
        (**((void ( ***)(int, _DWORD))v11 - 190))((int)(v11 - 760), 0);
        sprintf(v22, "%d %s", *p_m_pRoleObj, byte_DC6A3C);
        SetEnable((UICaption *)(v11 + 1072));
        v5 = (char *)v16;
      }
      else
      {
        (**(void ( ***)(char *, _DWORD))v11)(v11, 0);
        (**((void ( ***)(int, _DWORD))v11 - 190))((int)(v11 - 760), 0);
        v5[v10 + 158544] = 0;
      }
      ++v10;
      v11 += 152;
      p_m_pRoleObj += 352;
    }
    while ( (int)p_m_pRoleObj < (int)&((RoleSystem *)&stru_C059A0)->m_teamSlotOverlay.m_teamSlots[89] );
    /* [MISATTRIBUTED] ChoseCompose on UITitle_JDHY::this -> fix IDB name of callee */ ChoseCompose::LayoutItem((ChoseCompose *)this, Data, *((_DWORD *)v5 + 39090), *((_DWORD *)v5 + 39091), *((_DWORD *)v5 + 39092), *((_DWORD *)v5 + 39093));
    return (((PAL3 *)"SOFTWARE\\SOFTSTAR\\PAL3_SAVE"))->PAL3::WriteRegistry((DWORD)"SEEK", Data);
  }
  else
  {
    memset(Buffer, 0, sizeof(Buffer));
    v26 = 0;
    v27 = 0;
    sprintf(Buffer, "\\n            %s", (const char *)&dword_DDB73C);
    SetEnable((UICaption *)&this->m_NoteItem[80].m_HeadShot[2].m_fonttype);
    (((UIRoleSelect *)&this->m_NoteItem[80].m_HeadShot_NO_SEL[4].m_fonttype))->UIRoleSelect::SetByte(1);
    return ((int ( *)(_PlugInfo **, _DWORD))this->m_NoteItem[Data + 44].m_HeadShot_NO_SEL[4].m_pbkInfo->filepos)(
             &this->m_NoteItem[Data + 44].m_HeadShot_NO_SEL[4].m_pbkInfo,
             0);
  }
}

// 0x004B2C70
void UITitle_JDHY::RenderSlotEffects()
{
  int i; // edi
  CCBMagicWindow *v3; // [esp+0x0] [ebp-0x4]

  (((CCBControlWindow *)this))->CCBControlWindow::Render(v3) /* [ROWTABLE] */;
  if ( *((_BYTE *)&this->m_NoteItem[42].m_NotePic.m_pbkInfo + (unsigned int)this->m_NoteItem[42].m_NotePic.m_ppicInfo) )
  {
    for ( i = 0; i < 16; ++i )
    {
      if ( IsVisible((RenderTarget *)(&this->m_NoteItem[0].m_NotePic.m_fontcolor
                                    + 2336 * (int)this->m_NoteItem[42].m_NotePic.m_ppicInfo
                                    + 146 * i)) )
        (((ScreenEffect *)(&this->m_NoteItem[0].m_NotePic.m_fontcolor
                                           + 2336 * (int)this->m_NoteItem[42].m_NotePic.m_ppicInfo
                                           + 146 * i)))->ScreenEffect::Apply();
      if ( IsVisible((RenderTarget *)(&this->m_NoteItem[21].m_NoteLv[4].m_nTextW
                                    + 2336 * (int)this->m_NoteItem[42].m_NotePic.m_ppicInfo
                                    + 146 * i)) )
        (((ScreenEffect *)(&this->m_NoteItem[21].m_NoteLv[4].m_nTextW
                                           + 2336 * (int)this->m_NoteItem[42].m_NotePic.m_ppicInfo
                                           + 146 * i)))->ScreenEffect::Apply();
    }
  }
}

// 0x004B3100
int UITitle_JDHY::UITitle_JDHY_ForwardHitTest(int nVal)
{
  int v1; // ecx
  int v2; // edi
  int v3; // esi
  __int64 v5; // rax
  int v6; // ebx
  int v7; // ebp
  int v8; // eax
  CScreenMode *Instance; // eax
  CScreenMode *v10; // eax
  int v11; // [esp-0x10] [ebp-0x14]
  int v12; // [esp-0xC] [ebp-0x10]
  int v13; // [esp-0xC] [ebp-0x10]
  const void *v14; // [esp-0x8] [ebp-0xC]
  const void *v15; // [esp-0x8] [ebp-0xC]
  int v16; // [esp+0x0] [ebp-0x4]
  int a3; // [esp+0xC] [ebp+0x8]

  v3 = v1;
  if ( *(_DWORD *)(v1 + 286376) )
    return 1;
  v5 = (__int64)g_fGameTimer;
  v6 = (int)v5 / 3600;
  v7 = (int)v5 / 60 % 60;
  v11 = (int)v5 % 60;
  if ( (int)v5 / 3600 < 100 )
    sprintf((char *const)(v1 + 104), "%02d:%02d:%02d", v6, v7, v11);
  else
    sprintf((char *const)(v1 + 104), "%03d:%02d:%02d", v6, v7, v11);
  SetEnable((UICaption *)(v3 + 4544));
  sprintf((char *const)(v3 + 104), &dir[20], ((RoleSystem *)&stru_C059A0)->m_nMoveRole);
  SetEnable((UICaption *)(v3 + 4696));
  UITitle_JDHY_HandleNavigation(v2);
  (((CScreenMode *)v3))->CScreenMode::GetMouseDelta();
  UITitle_JDHY_HandleInput(v12);
  if ( !UIParabolaCtrl_GetState(v13) )
  {
    v8 = *(_DWORD *)(v3 + 286372);
    if ( v8 )
    {
      if ( v8 == 1 )
      {
        *(_DWORD *)(v3 + 286376) = 1;
        v14 = (const void *)off_5D11FC;
        Instance = (CScreenMode *)CScreenMode::GetInstance();
        (((CScreenMode *)Instance))->CScreenMode::AudioSetPosition(v14, 1);
        return 1;
      }
    }
    else
    {
      (((UITitle_JDHY *)v3))->UITitle_JDHY::SaveData(*(_DWORD *)(v3 + 286364));
      v15 = (const void *)off_5D11F8;
      v10 = (CScreenMode *)CScreenMode::GetInstance();
      (((CScreenMode *)v10))->CScreenMode::AudioSetPosition(v15, 1);
    }
  }
  if ( !UIParabolaCtrl_GetState(v16) )
    (*(MainEquipUI **)(v3 + 364))->MainEquipUI::HandleMessage(10);
  return (((SceneObj *)v3))->SceneObj::Update(nVal, a3);
}

// 0x004B3470
int UITitle_JDHY::UITitle_JDHY_OnMessage(int nVal)
{
  int v1; // ecx
  int v2; // esi
  int i; // edi
  CScreenMode *Instance; // eax
  int AudioManager; // eax
  int v6; // edi
  _DWORD *v7; // esi
  int result; // eax
  CScreenMode *v9; // eax
  CScreenMode *v10; // eax
  CScreenMode *v11; // eax
  CScreenMode *v12; // eax
  CScreenMode *v13; // eax
  CScreenMode *v14; // eax
  CScreenMode *v15; // eax
  CScreenMode *v16; // eax
  CScreenMode *v17; // eax
  int v18; // edi
  int v19; // eax
  int v20; // edx
  int v21; // edx
  CScreenMode *v22; // eax
  int v23; // eax
  double v24; // st7
  CScreenMode *v25; // eax
  gbAudioManager *v26; // eax
  float fProgressa; // [esp+0x0] [ebp-0x14]
  float fProgressb; // [esp+0x0] [ebp-0x14]
  float fProgressc; // [esp+0x0] [ebp-0x14]
  const void *fProgress; // [esp+0x0] [ebp-0x14]
  const void *fProgressd; // [esp+0x0] [ebp-0x14]
  const void *fProgresse; // [esp+0x0] [ebp-0x14]
  const void *fProgressf; // [esp+0x0] [ebp-0x14]
  const void *fProgressg; // [esp+0x0] [ebp-0x14]
  const void *fProgressh; // [esp+0x0] [ebp-0x14]
  const void *fProgressi; // [esp+0x0] [ebp-0x14]
  const void *fProgressj; // [esp+0x0] [ebp-0x14]
  const void *fProgressk; // [esp+0x0] [ebp-0x14]
  float v39; // [esp+0x4] [ebp-0x10]
  int *nMsg; // [esp+0x1C] [ebp+0x8]
  int nMsga; // [esp+0x1C] [ebp+0x8]
  int nMsgb; // [esp+0x1C] [ebp+0x8]
  int wParam; // [esp+0x20] [ebp+0xC]

  v2 = v1;
  switch ( nVal )
  {
    case 1000:
      if ( nMsg )
      {
        for ( i = 0; i < 8; ++i )
          sub_4B43E0((_DWORD *)v2, i);
        (((UISceneMap *)v2))->UISceneMap::ShowPage();
        (((StateUI *)v2))->StateUI::SaveData();
        if ( g_bRoleSystem_5CEFA9 )
        {
          sub_445E50(v2 + 154796);
          *(_DWORD *)(v2 + 286372) = 0;
        }
        else
        {
          sub_445E50(v2 + 154796);
          *(_DWORD *)(v2 + 286372) = 1;
        }
        UITitle_JDHY_ResetAndRefresh(*(_DWORD *)(v2 + 286372));
        *(_DWORD *)(v2 + 286376) = 0;
        if ( (g_dwGameFlags & 4) != 0 )
        {
          Instance = (CScreenMode *)CScreenMode::GetInstance();
          AudioManager = (((CScreenMode *)Instance))->CScreenMode::GetAudioManager();
          v6 = AudioManager;
          if ( AudioManager )
          {
            fProgressa = *(float *)(AudioManager + 212) * 100.0;
            (((CScreenMode *)(v2 + 285504)))->CScreenMode::SetProgress(fProgressa);
            fProgressb = *(float *)(v6 + 208) * 100.0;
            (((CScreenMode *)(v2 + 285776)))->CScreenMode::SetProgress(fProgressb);
            fProgressc = *(float *)(v6 + 204) * 100.0;
            (((CScreenMode *)(v2 + 285776)))->CScreenMode::SetProgress(fProgressc);
          }
        }
        else
        {
          (((CScreenMode *)(v2 + 285504)))->CScreenMode::SetProgress(0.0);
          (((CScreenMode *)(v2 + 285776)))->CScreenMode::SetProgress(0.0);
          (((CScreenMode *)(v2 + 285776)))->CScreenMode::SetProgress(0.0);
        }
        v7 = (_DWORD *)(v2 + 154480);
        *v7 = 0;
        v7[1] = 0;
        (((UICursor *)0))->UICursor::IRender();
        result = 1;
      }
      else
      {
        UITitle_JDHY_ResetAndRefresh(0);
        result = 1;
      }
      break;
    case 1001:
      if ( *(_BYTE *)(v1 + 290461) || *(_BYTE *)(v1 + 287725) )
      {
LABEL_86:
        result = 1;
      }
      else if ( nMsg > &byte_A00110 )
      {
        switch ( (unsigned int)nMsg )
        {
          case 0xA00701u:
            UITitle_JDHY_ScrollDown(1);
            result = 1;
            break;
          case 0xA00702u:
            UITitle_JDHY_ScrollUp(1);
            result = 1;
            break;
          case 0xA00704u:
            if ( *(_DWORD *)(v1 + 286372) )
            {
              *(_DWORD *)(v1 + 286372) = 0;
              UITitle_JDHY_ResetAndRefresh(0);
              (((UITitle_JDHY *)v2))->UITitle_JDHY::ResetNoteState();
              *(_DWORD *)(v2 + 154876) = 1;
              *(_BYTE *)(v2 + 154864) = 1;
              *(_DWORD *)(v2 + 155124) = 0;
              *(_BYTE *)(v2 + 155112) = 0;
            }
            else
            {
              *(_DWORD *)(v1 + 154876) = 1;
              *(_BYTE *)(v1 + 154864) = 1;
            }
            fProgress = (const void *)off_5D11E0;
            goto LABEL_41;
          case 0xA00705u:
            if ( *(_DWORD *)(v1 + 286372) == 1 )
            {
              *(_DWORD *)(v1 + 155124) = 1;
              *(_BYTE *)(v1 + 155112) = 1;
            }
            else
            {
              *(_DWORD *)(v1 + 286372) = 1;
              UITitle_JDHY_ResetAndRefresh(1);
              (((UITitle_JDHY *)v2))->UITitle_JDHY::ResetNoteState();
              *(_DWORD *)(v2 + 155124) = 1;
              *(_BYTE *)(v2 + 155112) = 1;
              *(_DWORD *)(v2 + 154876) = 0;
              *(_BYTE *)(v2 + 154864) = 0;
            }
            fProgress = (const void *)off_5D11E0;
            goto LABEL_41;
          case 0xA00708u:
            *(_BYTE *)(v1 + 286380) = 1;
            sprintf((char *const)(v1 + 104), "\\n        %s", (const char *)&dword_DD383C);
            SetEnable((UICaption *)(v2 + 289576));
            (((UIRoleSelect *)(v2 + 289120)))->UIRoleSelect::SetByte(1);
            fProgress = (const void *)off_5D11C0;
            goto LABEL_41;
          default:
            goto LABEL_42;
        }
      }
      else if ( nMsg == &byte_A00110 )
      {
        fProgressk = (const void *)off_5D11B8;
        v16 = (CScreenMode *)CScreenMode::GetInstance();
        (((CScreenMode *)v16))->CScreenMode::AudioSetPosition(fProgressk, 1);
        (*(MainEquipUI **)(v2 + 364))->MainEquipUI::HandleMessage(9);
        result = 1;
      }
      else
      {
        switch ( (unsigned int)nMsg )
        {
          case 0xA00102u:
            fProgressd = (const void *)off_5D11B8;
            v9 = (CScreenMode *)CScreenMode::GetInstance();
            (((CScreenMode *)v9))->CScreenMode::AudioSetPosition(fProgressd, 1);
            (*(MainEquipUI **)(v2 + 364))->MainEquipUI::HandleMessage(0);
            result = 1;
            break;
          case 0xA00103u:
            fProgresse = (const void *)off_5D11B8;
            v10 = (CScreenMode *)CScreenMode::GetInstance();
            (((CScreenMode *)v10))->CScreenMode::AudioSetPosition(fProgresse, 1);
            (*(MainEquipUI **)(v2 + 364))->MainEquipUI::HandleMessage(3);
            result = 1;
            break;
          case 0xA00104u:
            fProgressf = (const void *)off_5D11B8;
            v11 = (CScreenMode *)CScreenMode::GetInstance();
            (((CScreenMode *)v11))->CScreenMode::AudioSetPosition(fProgressf, 1);
            (*(MainEquipUI **)(v2 + 364))->MainEquipUI::HandleMessage(2);
            result = 1;
            break;
          case 0xA00105u:
            fProgressg = (const void *)off_5D11B8;
            v12 = (CScreenMode *)CScreenMode::GetInstance();
            (((CScreenMode *)v12))->CScreenMode::AudioSetPosition(fProgressg, 1);
            (*(MainEquipUI **)(v2 + 364))->MainEquipUI::HandleMessage(1);
            result = 1;
            break;
          case 0xA00106u:
            fProgressh = (const void *)off_5D11B8;
            v13 = (CScreenMode *)CScreenMode::GetInstance();
            (((CScreenMode *)v13))->CScreenMode::AudioSetPosition(fProgressh, 1);
            (*(MainEquipUI **)(v2 + 364))->MainEquipUI::HandleMessage(5);
            result = 1;
            break;
          case 0xA00107u:
            fProgressi = (const void *)off_5D11B8;
            v14 = (CScreenMode *)CScreenMode::GetInstance();
            (((CScreenMode *)v14))->CScreenMode::AudioSetPosition(fProgressi, 1);
            (*(MainEquipUI **)(v2 + 364))->MainEquipUI::HandleMessage(6);
            result = 1;
            break;
          case 0xA00108u:
            fProgressj = (const void *)off_5D11B8;
            v15 = (CScreenMode *)CScreenMode::GetInstance();
            (((CScreenMode *)v15))->CScreenMode::AudioSetPosition(fProgressj, 1);
            (*(MainEquipUI **)(v2 + 364))->MainEquipUI::HandleMessage(4);
            result = 1;
            break;
          default:
            goto LABEL_42;
        }
      }
      break;
    case 1002:
      switch ( (unsigned int)nMsg )
      {
        case 0xA00102u:
          *(_DWORD *)(v1 + 154488) = 0;
          if ( *(_BYTE *)(v1 + 154480) )
            goto LABEL_76;
          sub_4B43E0((_DWORD *)v1, 0);
          result = 1;
          break;
        case 0xA00103u:
          *(_DWORD *)(v1 + 154488) = 1;
          if ( *(_BYTE *)(v1 + 154481) )
            goto LABEL_76;
          sub_4B43E0((_DWORD *)v1, 1);
          result = 1;
          break;
        case 0xA00104u:
          *(_DWORD *)(v1 + 154488) = 2;
          if ( *(_BYTE *)(v1 + 154482) )
            goto LABEL_76;
          sub_4B43E0((_DWORD *)v1, 2);
          result = 1;
          break;
        case 0xA00105u:
          *(_DWORD *)(v1 + 154488) = 3;
          if ( *(_BYTE *)(v1 + 154483) )
            goto LABEL_76;
          sub_4B43E0((_DWORD *)v1, 3);
          result = 1;
          break;
        case 0xA00106u:
          *(_DWORD *)(v1 + 154488) = 5;
          if ( *(_BYTE *)(v1 + 154485) )
            goto LABEL_76;
          sub_4B43E0((_DWORD *)v1, 5);
          result = 1;
          break;
        case 0xA00107u:
          *(_DWORD *)(v1 + 154488) = 6;
          if ( *(_BYTE *)(v1 + 154486) )
            goto LABEL_76;
          sub_4B43E0((_DWORD *)v1, 6);
          result = 1;
          break;
        case 0xA00108u:
          *(_DWORD *)(v1 + 154488) = 4;
          if ( *(_BYTE *)(v1 + 154484) )
            goto LABEL_76;
          sub_4B43E0((_DWORD *)v1, 4);
          result = 1;
          break;
        case 0xA00109u:
          *(_DWORD *)(v1 + 154488) = 7;
          if ( !*(_BYTE *)(v1 + 154487) )
            sub_4B43E0((_DWORD *)v1, 7);
          goto LABEL_76;
        default:
LABEL_76:
          result = 1;
          break;
      }
      break;
    case 1003:
      switch ( (unsigned int)nMsg )
      {
        case 0xA00102u:
          *(_DWORD *)(v1 + 154488) = 0;
          *(_BYTE *)(v1 + 154480) = 0;
          result = 1;
          break;
        case 0xA00103u:
          *(_DWORD *)(v1 + 154488) = 1;
          *(_BYTE *)(v1 + 154481) = 0;
          result = 1;
          break;
        case 0xA00104u:
          *(_DWORD *)(v1 + 154488) = 2;
          *(_BYTE *)(v1 + 154482) = 0;
          result = 1;
          break;
        case 0xA00105u:
          *(_DWORD *)(v1 + 154488) = 3;
          *(_BYTE *)(v1 + 154483) = 0;
          result = 1;
          break;
        case 0xA00106u:
          *(_DWORD *)(v1 + 154488) = 5;
          *(_BYTE *)(v1 + 154485) = 0;
          result = 1;
          break;
        case 0xA00107u:
          *(_DWORD *)(v1 + 154488) = 6;
          *(_BYTE *)(v1 + 154486) = 0;
          result = 1;
          break;
        case 0xA00108u:
          *(_DWORD *)(v1 + 154488) = 4;
          *(_BYTE *)(v1 + 154484) = 0;
          result = 1;
          break;
        case 0xA00109u:
          *(_DWORD *)(v1 + 154488) = 7;
          *(_BYTE *)(v1 + 154487) = 0;
          goto LABEL_86;
        default:
          goto LABEL_86;
      }
      break;
    case 1019:
      if ( nMsg == &byte_A00709 )
      {
        nMsgb = *(int *)(v1 + 285736);
        v25 = (CScreenMode *)CScreenMode::GetInstance();
        v26 = (gbAudioManager *)(((CScreenMode *)v25))->CScreenMode::GetAudioManager();
        if ( v26 )
        {
          v39 = *(float *)&nMsgb * 0.0099999998;
          (((gbAudioManager *)v26))->gbAudioManager::SetMusicMasterVolume(v39);
        }
      }
      else if ( (char *)nMsg - (char *)&byte_A00709 == 7 )
      {
        nMsga = *(int *)(v1 + 286008);
        v22 = (CScreenMode *)CScreenMode::GetInstance();
        v23 = (((CScreenMode *)v22))->CScreenMode::GetAudioManager();
        if ( v23 )
        {
          v24 = *(float *)&nMsga * 0.0099999998;
          *(float *)(v23 + 208) = v24;
          *(float *)(v23 + 204) = v24;
          return 1;
        }
      }
      else if ( (char *)nMsg - (char *)&byte_A00709 == 771575 )
      {
        v18 = (__int64)*(float *)(v1 + 285456);
        v19 = *(_DWORD *)(v1 + 285496);
        if ( v18 <= v19 )
        {
          if ( v18 < v19 && v18 <= *(_DWORD *)(v1 + 286352) * (*(_DWORD *)(v1 + 285500) - 1) )
          {
            UITitle_JDHY_ScrollUp(0);
            result = 1;
            v21 = *(_DWORD *)(v2 + 285500) - 1;
            *(_DWORD *)(v2 + 285496) = v18;
            *(_DWORD *)(v2 + 285500) = v21;
            if ( v21 <= 1 )
            {
              *(_DWORD *)(v2 + 285500) = 1;
              return result;
            }
          }
        }
        else if ( v18 >= *(_DWORD *)(v1 + 285500) * *(_DWORD *)(v1 + 286352) )
        {
          UITitle_JDHY_ScrollDown(0);
          v20 = *(_DWORD *)(v2 + 285500);
          *(_DWORD *)(v2 + 285496) = v18;
          *(_DWORD *)(v2 + 285500) = v20 + 1;
          if ( v20 + 1 > 36 )
          {
            *(_DWORD *)(v2 + 285500) = 36;
            return 1;
          }
        }
      }
      result = 1;
      break;
    case 1021:
      if ( nMsg == &byte_A00704 )
      {
        sprintf((char *const)(v1 + 104), "\\n        %s", (const char *)&dword_DD8A3C);
        SetEnable((UICaption *)(v2 + 288208));
        (((UIRoleSelect *)(v2 + 287752)))->UIRoleSelect::SetByte(1);
        fProgress = (const void *)off_5D11C0;
LABEL_41:
        v17 = (CScreenMode *)CScreenMode::GetInstance();
        (((CScreenMode *)v17))->CScreenMode::AudioSetPosition(fProgress, 1);
      }
LABEL_42:
      result = 1;
      break;
    default:
      result = (((CGameData *)v1))->CGameData::OnMessage(nVal, (int)nMsg, wParam);
      break;
  }
  return result;
}
