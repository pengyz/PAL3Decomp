#pragma once
// Auto-generated: _Texture_Info
#include "pal3/ida_types.h"

#include "Misc/_Tex_uv.h"

class _Texture_Info {
public:
    char _tex_name[512]; // +0x0
    char _tex_lib[512]; // +0x200
    UINT _tex_libw; // +0x400
    UINT _tex_libh; // +0x404
    UINT _tex_origin_x; // +0x408
    UINT _tex_origin_y; // +0x40C
    UINT _tex_width; // +0x410
    UINT _tex_height; // +0x414
    _Tex_uv _tex_uvLT; // +0x418
    _Tex_uv _tex_uvLB; // +0x420
    _Tex_uv _tex_uvRB; // +0x428
    _Tex_uv _tex_uvRT; // +0x430
    UINT _tex_mode; // +0x438
    BYTE _tex_valid; // +0x43C
    char _tail_43D[3]; // +0x43D
    // total size: 0x440 (1088)

    CHAR * _CalculateUV(LPCSTR lpString); // 0x0053FCF0
};

typedef _Texture_Info Texture_Info;
