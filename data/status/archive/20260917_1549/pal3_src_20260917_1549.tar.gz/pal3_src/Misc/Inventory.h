#pragma once
// Auto-generated: Inventory
#include "pal3/ida_types.h"

#include "pal3/pal3_stl.h"
#include "Misc/PlayerItem.h"

class Inventory {
public:
    vector<PlayerItem> m_items; // +0x0
    char _gap_004[12]; // +0x4
    int m_curtype; // +0x10
    vector<PlayerItem> m_typeitems; // +0x14
    char _gap_018[12]; // +0x18
    int m_money; // +0x24
    // total size: 0x28 (40)

};
