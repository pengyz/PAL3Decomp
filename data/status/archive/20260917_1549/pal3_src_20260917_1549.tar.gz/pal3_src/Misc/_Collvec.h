#pragma once
// Auto-generated: _Collvec
#include "pal3/ida_types.h"

class _Collvec {
public:
    DWORD _Hand; // +0x0
    UINT _Page; // +0x4
    // total size: 0x8 (8)

};
