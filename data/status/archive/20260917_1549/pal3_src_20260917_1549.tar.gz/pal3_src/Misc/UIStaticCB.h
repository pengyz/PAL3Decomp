#include "Misc/UIStatic.h"
#pragma once
// Auto-generated: UIStaticCB
#include "pal3/ida_types.h"

class UIStaticCB : public UIStatic {
public:
    char _gap_000[152]; // +0x0
    int m_showct; // +0x98
    // total size: 0x9C (156)

};
