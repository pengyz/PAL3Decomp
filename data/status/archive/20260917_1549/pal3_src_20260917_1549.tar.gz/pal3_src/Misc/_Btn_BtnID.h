#pragma once
// Auto-generated: _Btn_BtnID
#include "pal3/ida_types.h"

class UIButton;

class _Btn_BtnID {
public:
    UIButton * _pBtn; // +0x0
    DWORD _btnID; // +0x4
    // total size: 0x8 (8)

};
