#pragma once
// Auto-generated: tagRoleSystemData
#include "pal3/ida_types.h"

class tagRoleSystemData {
public:
    int m_nEffParamBase0; // +0x0
    char _gap_004[16]; // +0x4
    int m_nEffParam14; // +0x14
    char _gap_018[16]; // +0x18
    int m_nEffTypeCode; // +0x28
    char _gap_02C[16]; // +0x2C
    int m_nEffParam3C; // +0x3C
    char _gap_040[16]; // +0x40
    int m_nEffParam50; // +0x50
    char _gap_054[16]; // +0x54
    int m_nTodo_064; // +0x64
    char _gap_068[76]; // +0x68
    int m_nEffParamB4; // +0xB4
    char _gap_0B8[16]; // +0xB8
    int m_nEffParamC8; // +0xC8
    char _gap_0CC[16]; // +0xCC
    int m_nEffParamDC; // +0xDC
    char _gap_0E0[16]; // +0xE0
    int m_nEffParamF0; // +0xF0
    char _gap_0F4[16]; // +0xF4
    float m_nEffParam_104; // +0x104
    char _gap_108[16]; // +0x108
    float m_nTodo_118; // +0x118
    char _gap_11C[56]; // +0x11C
    int m_nEffParam_154; // +0x154
    char _gap_158[16]; // +0x158
    int m_nTodo_168; // +0x168
    char _gap_16C[16]; // +0x16C
    int m_nEffParam_17C; // +0x17C
    char _gap_180[16]; // +0x180
    int m_nTodo_190; // +0x190
    // total size: 0x194 (404)

};
