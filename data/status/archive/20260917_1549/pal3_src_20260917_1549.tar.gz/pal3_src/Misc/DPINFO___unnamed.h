#pragma once
// Auto-generated: DPINFO___unnamed
#include "pal3/ida_types.h"

class DPINFO___unnamed {
public:
    _BYTE _tail_000[96]; // +0x0
    // total size: 0x60 (96)

};
