#include "Misc/UIButton.h"
#pragma once
// Auto-generated: UIButtonEX
#include "pal3/ida_types.h"

#include "Misc/_btnOPTDATA.h"

class UIButtonEX : public UIButton {
public:
    char _gap_000[344]; // +0x0
    _btnOPTDATA m_optData[3]; // +0x158
    // total size: 0x188 (392)

};
