#pragma once
// Auto-generated: CCBRoleStatePanelS
#include "pal3/ida_types.h"

#include "Misc/UIProgressBar.h"
#include "Misc/UIStatic.h"

class CCBRoleStatePanelS {
public:
    UIStatic m_Headbk; // +0x0
    UIStatic m_Head; // +0x98
    UIStatic m_Name; // +0x130
    UIStatic m_Jing; // +0x1C8
    UIProgressBar m_JingBar; // +0x260
    UIStatic m_JingVal; // +0x354
    UIStatic m_Shen; // +0x3EC
    UIProgressBar m_ShenBar; // +0x484
    UIStatic m_ShenVal; // +0x578
    UIStatic m_Qi; // +0x610
    UIProgressBar m_QiBar; // +0x6A8
    UIStatic m_QiVal; // +0x79C
    UIStatic m_Shade; // +0x834
    UIStatic m_Portrait; // +0x8CC
    UIStatic m_Level; // +0x964
    UIStatic m_ExpVal; // +0x9FC
    UIStatic m_NextLv; // +0xA94
    UIStatic m_WuLing[5]; // +0xB2C
    UIStatic m_FWSY; // +0xE24
    tagRECT m_FWSYrc; // +0xEBC
    // total size: 0xECC (3788)

};
