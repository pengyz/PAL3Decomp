#include "pal3/ida_defs.h"
#include "globals.h"
#include "pal3/pal3_constants.h"
#include "Misc/SceneMapPlayer.h"

// 0x004220F0
void SceneMapPlayer::ClearName()
{
  memset(this->m_szName, 0, sizeof(this->m_szName));
}
