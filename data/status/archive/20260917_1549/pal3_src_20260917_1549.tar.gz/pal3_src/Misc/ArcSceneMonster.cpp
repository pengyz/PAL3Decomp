#include "pal3/ida_defs.h"
#include "globals.h"
#include "pal3/pal3_constants.h"
#include "Misc/ArcSceneMonster.h"
#include "UI/UIScene.h"
#include "Misc/UIStatic.h"
#include "free_functions.h"

// Forward declarations for unnamed functions

// 0x00441E30
int ArcSceneMonster::HitTest(unsigned int *pPoint)
{
  LONG *v3; // ebx
  POINT v4; // rax
  int result; // eax
  POINT v6; // rax
  LONG m_nMonsterLevel; // ebp
  unsigned int v8; // ecx
  int m_nMonsterGold; // eax
  unsigned int v10; // edx
  POINT v11; // rax
  LONG m_nSkillCount; // ecx
  LONG v13; // eax
  LONG v14; // ecx
  LONG v15; // edx
  LONG m_nDropRate; // eax
  unsigned int v17; // ecx
  unsigned int v18; // edx
  bool v19; // zf
  POINT v20; // [esp-0x8] [ebp-0x28]
  RECT rc; // [esp+0x10] [ebp-0x10] BYREF

  v20.y = pPoint[1];
  v3 = (LONG *)(&this->m_pMonsterData + 3);
  v20.x = *pPoint;
  if ( !PtInRect((const RECT *)(&this->m_pMonsterData + 3), v20) )
    return 5;
  rc.left = (LONG)this->m_pSkillList;
  rc.top = *((_DWORD *)&this->m_pSkillList + 1);
  rc.right = *((_DWORD *)&this->m_pSkillList + 2);
  v4 = *(POINT *)pPoint;
  rc.bottom = this->m_nSkillCount;
  if ( PtInRect(&rc, v4) )
    return 0;
  rc.left = (LONG)this->m_pDropItems;
  rc.top = this->m_nDropRate;
  rc.right = *(&this->m_nDropRate + 1);
  v6 = *(POINT *)pPoint;
  rc.bottom = *(&this->m_nDropRate + 2);
  if ( PtInRect(&rc, v6) )
    return 1;
  if ( this->m_nMonsterMP - this->m_nMonsterHP <= 0 )
    return 5;
  m_nMonsterLevel = this->m_nMonsterLevel;
  rc.left = *v3;
  rc.top = m_nMonsterLevel;
  rc.right = *((_DWORD *)&this->m_pMonsterData + 5);
  v8 = (unsigned long)pPoint[1];
  m_nMonsterGold = this->m_nMonsterGold;
  rc.bottom = *((_DWORD *)&this->m_pMonsterData + 6);
  v10 = (unsigned long)*pPoint;
  rc.bottom = m_nMonsterLevel + m_nMonsterGold;
  if ( PtInRect(&rc, (POINT)__PAIR64__(v8, v10)) )
    return 2;
  rc.left = *v3;
  rc.top = *((_DWORD *)&this->m_pMonsterData + 4);
  rc.right = *((_DWORD *)&this->m_pMonsterData + 5);
  v11.y = pPoint[1];
  m_nSkillCount = this->m_nSkillCount;
  rc.bottom = *((_DWORD *)&this->m_pMonsterData + 6);
  v11.x = *pPoint;
  rc.top = m_nSkillCount;
  rc.bottom = m_nMonsterLevel;
  if ( PtInRect(&rc, v11) )
    return 3;
  v13 = *((_DWORD *)&this->m_pMonsterData + 4);
  v14 = *((_DWORD *)&this->m_pMonsterData + 5);
  rc.left = *v3;
  v15 = *((_DWORD *)&this->m_pMonsterData + 6);
  rc.top = v13;
  m_nDropRate = this->m_nDropRate;
  rc.right = v14;
  v17 = (unsigned long)pPoint[1];
  rc.bottom = v15;
  v18 = (unsigned long)*pPoint;
  rc.bottom = m_nDropRate;
  rc.top = m_nMonsterLevel;
  v19 = !PtInRect(&rc, (POINT)__PAIR64__(v17, v18));
  result = 4;
  if ( v19 )
    return 5;
  return result;
}

// 0x00487F80
int * ArcSceneMonster::CreateInfoPanel(
        
        int nVal,
        int nVal2,
        int id,
        int *pnVal,
        int nVal3)
{
  int v6; // ebp
  char *v8; // ebp
  int v9; // ecx
  int v10; // edx
  int v11; // eax
  int v12; // edx
  int v13; // ecx
  int v14; // edx
  int v15; // eax
  int v16; // edx
  int v17; // ecx
  int v18; // eax
  int v19; // eax
  int v20; // eax
  int v21; // edx
  int v22; // edx
  int v23; // edx
  int v24; // edx
  int v25; // edx
  int v26; // eax
  int v27; // edx
  int v28; // edx
  int v29; // edx
  int v30; // edx
  int v31; // edx
  int v32; // eax
  int *result; // eax
  int v34; // [esp+0x8C] [ebp-0x50]
  int v35; // [esp+0x9C] [ebp-0x40] BYREF
  int v36; // [esp+A0h] [ebp-0x3C]
  _DWORD v37[2]; // [esp+A4h] [ebp-0x38] BYREF
  int v38; // [esp+ACh] [ebp-0x30]
  int v39; // [esp+B4h] [ebp-0x28] BYREF
  int v40; // [esp+B8h] [ebp-0x24]
  int v41; // [esp+BCh] [ebp-0x20]
  int v42; // [esp+C0h] [ebp-0x1C]
  int v43; // [esp+C4h] [ebp-0x18] BYREF
  int v44; // [esp+C8h] [ebp-0x14]
  int v45; // [esp+CCh] [ebp-0x10]
  int v46; // [esp+D0h] [ebp-0xC]
  _DWORD v47[2]; // [esp+D4h] [ebp-0x8] BYREF
  _UNKNOWN *retaddr; // [esp+DCh] [ebp+0x0]

  if ( nVal <= 5 )
  {
    v34 = v6;
    v35 = *(_DWORD *)nVal2;
    v36 = *(_DWORD *)(nVal2 + 4);
    v37[0] = v35 + 29;
    v37[1] = v36 + 119;
    v8 = (char *)(&this->id + 4892 * nVal);
    (*(void ( **)(char *, _DWORD, int *, ArcSceneMonster *, int))(*((_DWORD *)v8 + 53723) + 16))(
      v8 + 214892,
      *(&g_ArcSceneMonsterTable + nVal),
      &v35,
      this,
      v34);
    LOBYTE(v9) = g_bDebugMode;
    (((UIStatic *)(v8 + 214892)))->UIStatic::CreateFromTemplate("UI\\GameMainUI\\Communal\\EquipTopFrame\\TopFrameL.tga", v9);
    v37[0] = v38;
    v10 = (int)*(&g_ArcSceneMonsterTable + nVal);
    v38 += 240;
    v11 = (*(int ( **)(char *, int, _DWORD *, ArcSceneMonster *))(*((_DWORD *)v8 + 53761) + 16))(
            v8 + 215044,
            v10,
            v37,
            this);
    LOBYTE(v11) = g_bDebugMode;
    (((UIStatic *)(v8 + 215044)))->UIStatic::CreateFromTemplate("UI\\GameMainUI\\Communal\\EquipTopFrame\\TopFrameLM.tga", v11);
    v12 = *((_DWORD *)v8 + 53799);
    v37[0] = v38;
    v38 += 14;
    (*(void ( **)(char *, _DWORD, _DWORD *, ArcSceneMonster *))(v12 + 16))(
      v8 + 215196,
      *(&g_ArcSceneMonsterTable + nVal),
      v37,
      this);
    LOBYTE(v13) = g_bDebugMode;
    (((UIStatic *)(v8 + 215196)))->UIStatic::CreateFromTemplate("UI\\GameMainUI\\Communal\\EquipTopFrame\\TopFrameM.tga", v13);
    v37[0] = v38;
    v14 = (int)*(&g_ArcSceneMonsterTable + nVal);
    v38 += 256;
    v15 = (*(int ( **)(char *, int, _DWORD *, ArcSceneMonster *))(*((_DWORD *)v8 + 53837) + 16))(
            v8 + 215348,
            v14,
            v37,
            this);
    LOBYTE(v15) = g_bDebugMode;
    (((UIStatic *)(v8 + 215348)))->UIStatic::CreateFromTemplate("UI\\GameMainUI\\Communal\\PropTopFrame\\TopFrameRM.tga", v15);
    v16 = *((_DWORD *)v8 + 53875);
    v37[0] = v38;
    v38 += 32;
    (*(void ( **)(char *, _DWORD, _DWORD *, ArcSceneMonster *))(v16 + 16))(
      v8 + 215500,
      *(&g_ArcSceneMonsterTable + nVal),
      v37,
      this);
    LOBYTE(v17) = g_bDebugMode;
    (((UIStatic *)(v8 + 215500)))->UIStatic::CreateFromTemplate("UI\\GameMainUI\\Communal\\EquipTopFrame\\TopFrameR.tga", v17);
    v18 = *(_DWORD *)(nVal2 + 4) + 16;
    v47[0] = *(_DWORD *)nVal2 + 44;
    v47[1] = v18;
    retaddr = (_UNKNOWN *)(v47[0] + 64);
    v19 = (*(int ( **)(char *, _DWORD, _DWORD *, ArcSceneMonster *))(*((_DWORD *)v8 + 53913) + 16))(
            v8 + 215652,
            *(&g_ArcSceneMonsterTable + nVal),
            v47,
            this);
    LOBYTE(v19) = g_bDebugMode;
    (((UIStatic *)(v8 + 215652)))->UIStatic::CreateFromTemplate(&"UI\\GameMainUI\\Communal\\AttFrameHead0.tga"[256 * nVal], v19);
    (**((void ( ***)(int, _DWORD))v8 + 53913))((int)(v8 + 215652), 0);
    v20 = *(_DWORD *)nVal2;
    v40 = *(_DWORD *)(nVal2 + 4);
    v39 = v20 + 106;
    v42 = v40 + 32;
    v21 = (int)*(&g_ArcSceneMonsterTable + nVal);
    v41 = v20 + 234;
    (*(void ( **)(char *, int, int *, ArcSceneMonster *))(*((_DWORD *)v8 + 53989) + 16))(
      v8 + 215956,
      v21,
      &v39,
      this);
    (((UIScene *)(v8 + 215956)))->UIScene::SetShow(0);
    sub_446010(v8 + 215956);
    v22 = *((_DWORD *)v8 + 53951);
    v40 = *(_DWORD *)(nVal2 + 4) + 22;
    v42 = v40 + 32;
    (*(void ( **)(char *, _DWORD, int *, ArcSceneMonster *))(v22 + 16))(
      v8 + 215804,
      *(&g_ArcSceneMonsterTable + nVal),
      &v39,
      this);
    (((UIScene *)(v8 + 215804)))->UIScene::SetShow(0);
    sub_446010(v8 + 215804);
    v40 = *(_DWORD *)(nVal2 + 4) + 42;
    v23 = (int)*(&g_ArcSceneMonsterTable + nVal);
    v42 = v40 + 32;
    (*(void ( **)(char *, int, int *, ArcSceneMonster *))(*((_DWORD *)v8 + 54027) + 16))(
      v8 + 216108,
      v23,
      &v39,
      this);
    (((UIScene *)(v8 + 216108)))->UIScene::SetShow(0);
    sub_446010(v8 + 216108);
    v24 = *((_DWORD *)v8 + 54065);
    v40 = *(_DWORD *)(nVal2 + 4) + 66;
    v42 = v40 + 32;
    (*(void ( **)(char *, _DWORD, int *, ArcSceneMonster *))(v24 + 16))(
      v8 + 216260,
      *(&g_ArcSceneMonsterTable + nVal),
      &v39,
      this);
    (((UIScene *)(v8 + 216260)))->UIScene::SetShow(0);
    sub_446010(v8 + 216260);
    v40 = *(_DWORD *)(nVal2 + 4) + 88;
    v25 = (int)*(&g_ArcSceneMonsterTable + nVal);
    v42 = v40 + 32;
    (*(void ( **)(char *, int, int *, ArcSceneMonster *))(*((_DWORD *)v8 + 54103) + 16))(
      v8 + 216412,
      v25,
      &v39,
      this);
    (**((void ( ***)(int, _DWORD))v8 + 54103))((int)(v8 + 216412), 0);
    sub_446010(v8 + 216412);
    v26 = *(_DWORD *)nVal2;
    v44 = *(_DWORD *)(nVal2 + 4);
    v43 = v26 + 230;
    v46 = v44 + 32;
    v27 = (int)*(&g_ArcSceneMonsterTable + nVal);
    v45 = v26 + 340;
    (*(void ( **)(char *, int, int *, ArcSceneMonster *))(*((_DWORD *)v8 + 54141) + 16))(
      v8 + 216564,
      v27,
      &v43,
      this);
    (((UIScene *)(v8 + 216564)))->UIScene::SetShow(0);
    sub_446010(v8 + 216564);
    v28 = *((_DWORD *)v8 + 54179);
    v44 = *(_DWORD *)(nVal2 + 4) + 22;
    v46 = v44 + 32;
    (*(void ( **)(char *, _DWORD, int *, ArcSceneMonster *))(v28 + 16))(
      v8 + 216716,
      *(&g_ArcSceneMonsterTable + nVal),
      &v43,
      this);
    (((UIScene *)(v8 + 216716)))->UIScene::SetShow(0);
    sub_446010(v8 + 216716);
    v44 = *(_DWORD *)(nVal2 + 4) + 42;
    v29 = (int)*(&g_ArcSceneMonsterTable + nVal);
    v46 = v44 + 32;
    (*(void ( **)(char *, int, int *, ArcSceneMonster *))(*((_DWORD *)v8 + 54217) + 16))(
      v8 + 216868,
      v29,
      &v43,
      this);
    (((UIScene *)(v8 + 216868)))->UIScene::SetShow(0);
    sub_446010(v8 + 216868);
    v30 = *((_DWORD *)v8 + 54255);
    v44 = *(_DWORD *)(nVal2 + 4) + 66;
    v46 = v44 + 32;
    (*(void ( **)(char *, _DWORD, int *, ArcSceneMonster *))(v30 + 16))(
      v8 + 217020,
      *(&g_ArcSceneMonsterTable + nVal),
      &v43,
      this);
    (((UIScene *)(v8 + 217020)))->UIScene::SetShow(0);
    sub_446010(v8 + 217020);
    v31 = (int)*(&g_ArcSceneMonsterTable + nVal);
    v32 = *((_DWORD *)v8 + 54293);
    v8 += 217172;
    v44 = *(_DWORD *)(nVal2 + 4) + 88;
    v46 = v44 + 32;
    (*(void ( **)(char *, int))(v32 + 16))(v8, v31);
    (((UIScene *)v8))->UIScene::SetShow(0);
    return (int *)sub_446010(v8);
  }
  return result;
}

// 0x00491F20
int * ArcSceneMonster::CreateMonsterUI(
        
        int nVal,
        int nVal2,
        int id,
        int *pnVal,
        int nVal3)
{
  int v6; // ebp
  char *v8; // ebp
  int v9; // eax
  int v10; // edx
  int v11; // ecx
  int v12; // edx
  int v13; // eax
  int v14; // edx
  int v15; // ecx
  int v16; // edx
  int v17; // eax
  int v18; // ecx
  int v19; // edx
  int v20; // ecx
  int v21; // ecx
  int v22; // edx
  int v23; // edx
  int v24; // edx
  int v25; // edx
  int v26; // edx
  int v27; // eax
  int v28; // edx
  int v29; // edx
  int v30; // edx
  int v31; // edx
  int v32; // edx
  int v33; // eax
  int *result; // eax
  int v35; // [esp+0x198] [ebp-0x50]
  int v36; // [esp+0x1A8] [ebp-0x40] BYREF
  int v37; // [esp+0x1B0] [ebp-0x38] BYREF
  int v38; // [esp+0x1B4] [ebp-0x34]
  int v39; // [esp+0x1B8] [ebp-0x30] BYREF
  int v40; // [esp+0x1BC] [ebp-0x2C]
  _DWORD v41[2]; // [esp+0x1C0] [ebp-0x28] BYREF
  int v42; // [esp+0x1C8] [ebp-0x20] BYREF
  int v43; // [esp+0x1D0] [ebp-0x18] BYREF
  int v44; // [esp+0x1D4] [ebp-0x14]
  int v45; // [esp+0x1D8] [ebp-0x10]
  int v46; // [esp+0x1DC] [ebp-0xC]
  _DWORD v47[2]; // [esp+0x1E0] [ebp-0x8] BYREF
  _UNKNOWN *retaddr; // [esp+0x1E8] [ebp+0x0]

  if ( nVal <= 5 )
  {
    v35 = v6;
    v39 = *(_DWORD *)nVal2;
    v40 = *(_DWORD *)(nVal2 + 4);
    v41[0] = v39 + 29;
    v41[1] = v40 + 119;
    v8 = (char *)(&this->id + 9980 * nVal);
    v9 = (*(int ( **)(char *, _DWORD, int *, ArcSceneMonster *, int))(*((_DWORD *)v8 + 39200) + 16))(
           v8 + 156800,
           *(&g_pfnCallback + nVal),
           &v39,
           this,
           v35);
    LOBYTE(v9) = g_bDebugMode;
    (((UIStatic *)(v8 + 156800)))->UIStatic::CreateFromTemplate("UI\\GameMainUI\\Communal\\EquipTopFrame\\TopFrameL.tga", v9);
    v10 = *((_DWORD *)v8 + 39238);
    v41[0] = v42;
    v42 += 240;
    (*(void ( **)(char *, _DWORD, _DWORD *, ArcSceneMonster *))(v10 + 16))(
      v8 + 156952,
      *(&g_pfnCallback + nVal),
      v41,
      this);
    LOBYTE(v11) = g_bDebugMode;
    (((UIStatic *)(v8 + 156952)))->UIStatic::CreateFromTemplate("UI\\GameMainUI\\Communal\\EquipTopFrame\\TopFrameLM.tga", v11);
    v41[0] = v42;
    v12 = (int)*(&g_pfnCallback + nVal);
    v42 += 14;
    v13 = (*(int ( **)(char *, int, _DWORD *, ArcSceneMonster *))(*((_DWORD *)v8 + 39276) + 16))(
            v8 + 157104,
            v12,
            v41,
            this);
    LOBYTE(v13) = g_bDebugMode;
    (((UIStatic *)(v8 + 157104)))->UIStatic::CreateFromTemplate("UI\\GameMainUI\\Communal\\EquipTopFrame\\TopFrameM.tga", v13);
    v14 = *((_DWORD *)v8 + 39314);
    v41[0] = v42;
    v42 += 256;
    (*(void ( **)(char *, _DWORD, _DWORD *, ArcSceneMonster *))(v14 + 16))(
      v8 + 157256,
      *(&g_pfnCallback + nVal),
      v41,
      this);
    LOBYTE(v15) = g_bDebugMode;
    (((UIStatic *)(v8 + 157256)))->UIStatic::CreateFromTemplate("UI\\GameMainUI\\Communal\\EquipTopFrame\\TopFrameRM.tga", v15);
    v41[0] = v42;
    v16 = (int)*(&g_pfnCallback + nVal);
    v42 += 32;
    v17 = (*(int ( **)(char *, int, _DWORD *, ArcSceneMonster *))(*((_DWORD *)v8 + 39352) + 16))(
            v8 + 157408,
            v16,
            v41,
            this);
    LOBYTE(v17) = g_bDebugMode;
    (((UIStatic *)(v8 + 157408)))->UIStatic::CreateFromTemplate("UI\\GameMainUI\\Communal\\EquipTopFrame\\TopFrameR.tga", v17);
    v18 = *(_DWORD *)nVal2 + 44;
    v47[1] = *(_DWORD *)(nVal2 + 4) + 16;
    v19 = *((_DWORD *)v8 + 39390);
    v47[0] = v18;
    retaddr = (_UNKNOWN *)(v18 + 64);
    (*(void ( **)(char *, _DWORD, _DWORD *, ArcSceneMonster *))(v19 + 16))(
      v8 + 157560,
      *(&g_pfnCallback + nVal),
      v47,
      this);
    LOBYTE(v20) = g_bDebugMode;
    (((UIStatic *)(v8 + 157560)))->UIStatic::CreateFromTemplate(&"UI\\GameMainUI\\Communal\\AttFrameHead0.tga"[256 * nVal], v20);
    (**((void ( ***)(int, _DWORD))v8 + 39390))((int)(v8 + 157560), 0);
    v21 = *(_DWORD *)(nVal2 + 4);
    v22 = *((_DWORD *)v8 + 39466);
    v37 = *(_DWORD *)nVal2 + 106;
    v38 = v21;
    v39 = v37 + 138;
    v40 = v21 + 32;
    (*(void ( **)(char *, _DWORD, int *, ArcSceneMonster *))(v22 + 16))(
      v8 + 157864,
      *(&g_pfnCallback + nVal),
      &v37,
      this);
    (*(void ( **)(char *, _DWORD, int *, ArcSceneMonster *))(*((_DWORD *)v8 + 39846) + 16))(
      v8 + 159384,
      *(&g_pfnCallback + nVal),
      &v37,
      this);
    (*(void ( **)(char *, _DWORD, int *, ArcSceneMonster *))(*((_DWORD *)v8 + 40226) + 16))(
      v8 + 160904,
      *(&g_pfnCallback + nVal),
      &v37,
      this);
    (((UIScene *)(v8 + 157864)))->UIScene::SetShow(0);
    sub_446010(v8 + 157864);
    v38 = *(_DWORD *)(nVal2 + 4) + 22;
    v23 = (int)*(&g_pfnCallback + nVal);
    v40 = v38 + 32;
    (*(void ( **)(char *, int, int *, ArcSceneMonster *))(*((_DWORD *)v8 + 39428) + 16))(
      v8 + 157712,
      v23,
      &v37,
      this);
    (*(void ( **)(char *, _DWORD, int *, ArcSceneMonster *))(*((_DWORD *)v8 + 39808) + 16))(
      v8 + 159232,
      *(&g_pfnCallback + nVal),
      &v37,
      this);
    (*(void ( **)(char *, _DWORD, int *, ArcSceneMonster *))(*((_DWORD *)v8 + 40188) + 16))(
      v8 + 160752,
      *(&g_pfnCallback + nVal),
      &v37,
      this);
    (((UIScene *)(v8 + 157712)))->UIScene::SetShow(0);
    sub_446010(v8 + 157712);
    v24 = *((_DWORD *)v8 + 39504);
    v38 = *(_DWORD *)(nVal2 + 4) + 42;
    v40 = v38 + 32;
    (*(void ( **)(char *, _DWORD, int *, ArcSceneMonster *))(v24 + 16))(
      v8 + 158016,
      *(&g_pfnCallback + nVal),
      &v37,
      this);
    (*(void ( **)(char *, _DWORD, int *, ArcSceneMonster *))(*((_DWORD *)v8 + 39884) + 16))(
      v8 + 159536,
      *(&g_pfnCallback + nVal),
      &v37,
      this);
    (*(void ( **)(char *, _DWORD, int *, ArcSceneMonster *))(*((_DWORD *)v8 + 40264) + 16))(
      v8 + 161056,
      *(&g_pfnCallback + nVal),
      &v37,
      this);
    (((UIScene *)(v8 + 158016)))->UIScene::SetShow(0);
    sub_446010(v8 + 158016);
    v38 = *(_DWORD *)(nVal2 + 4) + 66;
    v25 = (int)*(&g_pfnCallback + nVal);
    v40 = v38 + 32;
    (*(void ( **)(char *, int, int *, ArcSceneMonster *))(*((_DWORD *)v8 + 39542) + 16))(
      v8 + 158168,
      v25,
      &v37,
      this);
    (*(void ( **)(char *, _DWORD, int *, ArcSceneMonster *))(*((_DWORD *)v8 + 39922) + 16))(
      v8 + 159688,
      *(&g_pfnCallback + nVal),
      &v37,
      this);
    (*(void ( **)(char *, _DWORD, int *, ArcSceneMonster *))(*((_DWORD *)v8 + 40302) + 16))(
      v8 + 161208,
      *(&g_pfnCallback + nVal),
      &v37,
      this);
    (((UIScene *)(v8 + 158168)))->UIScene::SetShow(0);
    sub_446010(v8 + 158168);
    v26 = *((_DWORD *)v8 + 39580);
    v38 = *(_DWORD *)(nVal2 + 4) + 88;
    v40 = v38 + 32;
    (*(void ( **)(char *, _DWORD, int *, ArcSceneMonster *))(v26 + 16))(
      v8 + 158320,
      *(&g_pfnCallback + nVal),
      &v37,
      this);
    (*(void ( **)(char *, _DWORD, int *, ArcSceneMonster *))(*((_DWORD *)v8 + 39960) + 16))(
      v8 + 159840,
      *(&g_pfnCallback + nVal),
      &v37,
      this);
    (*(void ( **)(char *, _DWORD, int *, ArcSceneMonster *))(*((_DWORD *)v8 + 40340) + 16))(
      v8 + 161360,
      *(&g_pfnCallback + nVal),
      &v37,
      this);
    (((UIScene *)(v8 + 158320)))->UIScene::SetShow(0);
    sub_446010(v8 + 158320);
    v27 = *(_DWORD *)nVal2;
    v44 = *(_DWORD *)(nVal2 + 4);
    v43 = v27 + 230;
    v46 = v44 + 32;
    v28 = (int)*(&g_pfnCallback + nVal);
    v45 = v27 + 340;
    (*(void ( **)(char *, int, int *, ArcSceneMonster *))(*((_DWORD *)v8 + 39618) + 16))(
      v8 + 158472,
      v28,
      &v43,
      this);
    (*(void ( **)(char *, _DWORD, int *, ArcSceneMonster *))(*((_DWORD *)v8 + 39998) + 16))(
      v8 + 159992,
      *(&g_pfnCallback + nVal),
      &v43,
      this);
    (*(void ( **)(char *, _DWORD, int *, ArcSceneMonster *))(*((_DWORD *)v8 + 40378) + 16))(
      v8 + 161512,
      *(&g_pfnCallback + nVal),
      &v37,
      this);
    (((UIScene *)(v8 + 158472)))->UIScene::SetShow(0);
    sub_446010(v8 + 158472);
    v29 = *((_DWORD *)v8 + 39656);
    v44 = *(_DWORD *)(nVal2 + 4) + 22;
    v46 = v44 + 32;
    (*(void ( **)(char *, _DWORD, int *, ArcSceneMonster *))(v29 + 16))(
      v8 + 158624,
      *(&g_pfnCallback + nVal),
      &v43,
      this);
    (*(void ( **)(char *, _DWORD, int *, ArcSceneMonster *))(*((_DWORD *)v8 + 40036) + 16))(
      v8 + 160144,
      *(&g_pfnCallback + nVal),
      &v43,
      this);
    (*(void ( **)(char *, _DWORD, int *, ArcSceneMonster *))(*((_DWORD *)v8 + 40416) + 16))(
      v8 + 161664,
      *(&g_pfnCallback + nVal),
      &v37,
      this);
    (((UIScene *)(v8 + 158624)))->UIScene::SetShow(0);
    sub_446010(v8 + 158624);
    v44 = *(_DWORD *)(nVal2 + 4) + 42;
    v30 = (int)*(&g_pfnCallback + nVal);
    v46 = v44 + 32;
    (*(void ( **)(char *, int, int *, ArcSceneMonster *))(*((_DWORD *)v8 + 39694) + 16))(
      v8 + 158776,
      v30,
      &v43,
      this);
    (*(void ( **)(char *, _DWORD, int *, ArcSceneMonster *))(*((_DWORD *)v8 + 40074) + 16))(
      v8 + 160296,
      *(&g_pfnCallback + nVal),
      &v43,
      this);
    (*(void ( **)(char *, _DWORD, int *, ArcSceneMonster *))(*((_DWORD *)v8 + 40454) + 16))(
      v8 + 161816,
      *(&g_pfnCallback + nVal),
      &v37,
      this);
    (((UIScene *)(v8 + 158776)))->UIScene::SetShow(0);
    sub_446010(v8 + 158776);
    v31 = *((_DWORD *)v8 + 39732);
    v44 = *(_DWORD *)(nVal2 + 4) + 66;
    v46 = v44 + 32;
    (*(void ( **)(char *, _DWORD, int *, ArcSceneMonster *))(v31 + 16))(
      v8 + 158928,
      *(&g_pfnCallback + nVal),
      &v43,
      this);
    (*(void ( **)(char *, _DWORD, int *, ArcSceneMonster *))(*((_DWORD *)v8 + 40112) + 16))(
      v8 + 160448,
      *(&g_pfnCallback + nVal),
      &v43,
      this);
    (*(void ( **)(char *, _DWORD, int *, ArcSceneMonster *))(*((_DWORD *)v8 + 40492) + 16))(
      v8 + 161968,
      *(&g_pfnCallback + nVal),
      &v37,
      this);
    ((UIScene *)((UIScene *)v8 + 462))->UIScene::SetShow(0);
    sub_446010(v8 + 158928);
    v32 = (int)*(&g_pfnCallback + nVal);
    v33 = *((_DWORD *)v8 + 39770);
    v44 = *(_DWORD *)(nVal2 + 4) + 88;
    v46 = v44 + 32;
    (*(void ( **)(char *, int))(v33 + 16))(v8 + 159080, v32);
    (*(void ( **)(char *, _DWORD, int *, ArcSceneMonster *))(*((_DWORD *)v8 + 40150) + 16))(
      v8 + 160600,
      *(&g_pfnCallback + nVal),
      &v42,
      this);
    (*(void ( **)(char *, _DWORD, int *, ArcSceneMonster *))(*((_DWORD *)v8 + 40530) + 16))(
      v8 + 162120,
      *(&g_pfnCallback + nVal),
      &v36,
      this);
    (((UIScene *)(v8 + 159080)))->UIScene::SetShow(0);
    return (int *)sub_446010(v8 + 159080);
  }
  return result;
}

// 0x00499CC0
int * ArcSceneMonster::CreateStatusPanel(
        
        int nVal,
        int nVal2,
        int id,
        int *pnVal,
        int nVal3)
{
  int v6; // ebp
  char *v8; // ebp
  int v9; // ecx
  int v10; // edx
  int v11; // eax
  int v12; // edx
  int v13; // ecx
  int v14; // edx
  int v15; // eax
  int v16; // edx
  int v17; // ecx
  int v18; // eax
  int v19; // eax
  int v20; // eax
  int v21; // edx
  int v22; // edx
  int v23; // edx
  int v24; // edx
  int v25; // edx
  int v26; // ecx
  int v27; // edx
  int v28; // edx
  int v29; // edx
  int v30; // edx
  int v31; // ecx
  int v32; // edx
  int *result; // eax
  int v34; // [esp+0x8C] [ebp-0x50]
  int v35; // [esp+0x9C] [ebp-0x40] BYREF
  int v36; // [esp+A0h] [ebp-0x3C]
  _DWORD v37[2]; // [esp+A4h] [ebp-0x38] BYREF
  int v38; // [esp+ACh] [ebp-0x30]
  int v39; // [esp+B4h] [ebp-0x28] BYREF
  int v40; // [esp+B8h] [ebp-0x24]
  int v41; // [esp+BCh] [ebp-0x20]
  int v42; // [esp+C0h] [ebp-0x1C]
  int v43; // [esp+C4h] [ebp-0x18] BYREF
  int v44; // [esp+C8h] [ebp-0x14]
  int v45; // [esp+CCh] [ebp-0x10]
  int v46; // [esp+D0h] [ebp-0xC]
  _DWORD v47[2]; // [esp+D4h] [ebp-0x8] BYREF
  _UNKNOWN *retaddr; // [esp+DCh] [ebp+0x0]

  if ( nVal <= 5 )
  {
    v34 = v6;
    v35 = *(_DWORD *)nVal2;
    v36 = *(_DWORD *)(nVal2 + 4);
    v37[0] = v35 + 29;
    v37[1] = v36 + 119;
    v8 = (char *)(&this->id + 4892 * nVal);
    (*(void ( **)(char *, _DWORD, int *, ArcSceneMonster *, int))(*((_DWORD *)v8 + 39611) + 16))(
      v8 + 158444,
      *(&g_ArcSceneMonsterTable2 + nVal),
      &v35,
      this,
      v34);
    LOBYTE(v9) = g_bDebugMode;
    (((UIStatic *)(v8 + 158444)))->UIStatic::CreateFromTemplate("UI\\GameMainUI\\Communal\\EquipTopFrame\\TopFrameL.tga", v9);
    v37[0] = v38;
    v10 = (int)*(&g_ArcSceneMonsterTable2 + nVal);
    v38 += 240;
    v11 = (*(int ( **)(char *, int, _DWORD *, ArcSceneMonster *))(*((_DWORD *)v8 + 39649) + 16))(
            v8 + 158596,
            v10,
            v37,
            this);
    LOBYTE(v11) = g_bDebugMode;
    (((UIStatic *)(v8 + 158596)))->UIStatic::CreateFromTemplate("UI\\GameMainUI\\Communal\\EquipTopFrame\\TopFrameLM.tga", v11);
    v12 = *((_DWORD *)v8 + 39687);
    v37[0] = v38;
    v38 += 14;
    (*(void ( **)(char *, _DWORD, _DWORD *, ArcSceneMonster *))(v12 + 16))(
      v8 + 158748,
      *(&g_ArcSceneMonsterTable2 + nVal),
      v37,
      this);
    LOBYTE(v13) = g_bDebugMode;
    (((UIStatic *)(v8 + 158748)))->UIStatic::CreateFromTemplate("UI\\GameMainUI\\Communal\\EquipTopFrame\\TopFrameM.tga", v13);
    v37[0] = v38;
    v14 = (int)*(&g_ArcSceneMonsterTable2 + nVal);
    v38 += 256;
    v15 = (*(int ( **)(char *, int, _DWORD *, ArcSceneMonster *))(*((_DWORD *)v8 + 39725) + 16))(
            v8 + 158900,
            v14,
            v37,
            this);
    LOBYTE(v15) = g_bDebugMode;
    (((UIStatic *)(v8 + 158900)))->UIStatic::CreateFromTemplate("UI\\GameMainUI\\Communal\\PropTopFrame\\TopFrameRM.tga", v15);
    v16 = *((_DWORD *)v8 + 39763);
    v37[0] = v38;
    v38 += 32;
    (*(void ( **)(char *, _DWORD, _DWORD *, ArcSceneMonster *))(v16 + 16))(
      v8 + 159052,
      *(&g_ArcSceneMonsterTable2 + nVal),
      v37,
      this);
    LOBYTE(v17) = g_bDebugMode;
    (((UIStatic *)(v8 + 159052)))->UIStatic::CreateFromTemplate("UI\\GameMainUI\\Communal\\EquipTopFrame\\TopFrameR.tga", v17);
    v18 = *(_DWORD *)(nVal2 + 4) + 16;
    v47[0] = *(_DWORD *)nVal2 + 44;
    v47[1] = v18;
    retaddr = (_UNKNOWN *)(v47[0] + 64);
    v19 = (*(int ( **)(char *, _DWORD, _DWORD *, ArcSceneMonster *))(*((_DWORD *)v8 + 39801) + 16))(
            v8 + 159204,
            *(&g_ArcSceneMonsterTable2 + nVal),
            v47,
            this);
    LOBYTE(v19) = g_bDebugMode;
    (((UIStatic *)(v8 + 159204)))->UIStatic::CreateFromTemplate(&"UI\\GameMainUI\\Communal\\AttFrameHead0.tga"[256 * nVal], v19);
    (**((void ( ***)(int, _DWORD))v8 + 39801))((int)(v8 + 159204), 0);
    v20 = *(_DWORD *)nVal2;
    v40 = *(_DWORD *)(nVal2 + 4);
    v39 = v20 + 106;
    v42 = v40 + 32;
    v21 = (int)*(&g_ArcSceneMonsterTable2 + nVal);
    v41 = v20 + 234;
    (*(void ( **)(char *, int, int *, ArcSceneMonster *))(*((_DWORD *)v8 + 39877) + 16))(
      v8 + 159508,
      v21,
      &v39,
      this);
    (((UIScene *)(v8 + 159508)))->UIScene::SetShow(0);
    sub_446010(v8 + 159508);
    v22 = *((_DWORD *)v8 + 39839);
    v40 = *(_DWORD *)(nVal2 + 4) + 22;
    v42 = v40 + 32;
    (*(void ( **)(char *, _DWORD, int *, ArcSceneMonster *))(v22 + 16))(
      v8 + 159356,
      *(&g_ArcSceneMonsterTable2 + nVal),
      &v39,
      this);
    (((UIScene *)(v8 + 159356)))->UIScene::SetShow(0);
    sub_446010(v8 + 159356);
    v40 = *(_DWORD *)(nVal2 + 4) + 42;
    v23 = (int)*(&g_ArcSceneMonsterTable2 + nVal);
    v42 = v40 + 32;
    (*(void ( **)(char *, int, int *, ArcSceneMonster *))(*((_DWORD *)v8 + 39915) + 16))(
      v8 + 159660,
      v23,
      &v39,
      this);
    (((UIScene *)(v8 + 159660)))->UIScene::SetShow(0);
    sub_446010(v8 + 159660);
    v24 = *((_DWORD *)v8 + 39953);
    v40 = *(_DWORD *)(nVal2 + 4) + 66;
    v42 = v40 + 32;
    (*(void ( **)(char *, _DWORD, int *, ArcSceneMonster *))(v24 + 16))(
      v8 + 159812,
      *(&g_ArcSceneMonsterTable2 + nVal),
      &v39,
      this);
    (((UIScene *)(v8 + 159812)))->UIScene::SetShow(0);
    sub_446010(v8 + 159812);
    v40 = *(_DWORD *)(nVal2 + 4) + 88;
    v25 = (int)*(&g_ArcSceneMonsterTable2 + nVal);
    v42 = v40 + 32;
    (*(void ( **)(char *, int, int *, ArcSceneMonster *))(*((_DWORD *)v8 + 39991) + 16))(
      v8 + 159964,
      v25,
      &v39,
      this);
    (**((void ( ***)(int, _DWORD))v8 + 39991))((int)(v8 + 159964), 0);
    v26 = *(_DWORD *)(nVal2 + 4);
    v27 = *((_DWORD *)v8 + 40029);
    v43 = *(_DWORD *)nVal2 + 230;
    v44 = v26;
    v45 = v43 + 110;
    v46 = v26 + 32;
    (*(void ( **)(char *, _DWORD, int *, ArcSceneMonster *))(v27 + 16))(
      v8 + 160116,
      *(&g_ArcSceneMonsterTable2 + nVal),
      &v43,
      this);
    (((UIScene *)(v8 + 160116)))->UIScene::SetShow(0);
    sub_446010(v8 + 160116);
    v44 = *(_DWORD *)(nVal2 + 4) + 22;
    v28 = (int)*(&g_ArcSceneMonsterTable2 + nVal);
    v46 = v44 + 32;
    (*(void ( **)(char *, int, int *, ArcSceneMonster *))(*((_DWORD *)v8 + 40067) + 16))(
      v8 + 160268,
      v28,
      &v43,
      this);
    (((UIScene *)(v8 + 160268)))->UIScene::SetShow(0);
    sub_446010(v8 + 160268);
    v29 = *((_DWORD *)v8 + 40105);
    v44 = *(_DWORD *)(nVal2 + 4) + 42;
    v46 = v44 + 32;
    (*(void ( **)(char *, _DWORD, int *, ArcSceneMonster *))(v29 + 16))(
      v8 + 160420,
      *(&g_ArcSceneMonsterTable2 + nVal),
      &v43,
      this);
    (((UIScene *)(v8 + 160420)))->UIScene::SetShow(0);
    sub_446010(v8 + 160420);
    v44 = *(_DWORD *)(nVal2 + 4) + 66;
    v30 = (int)*(&g_ArcSceneMonsterTable2 + nVal);
    v46 = v44 + 32;
    (*(void ( **)(char *, int, int *, ArcSceneMonster *))(*((_DWORD *)v8 + 40143) + 16))(
      v8 + 160572,
      v30,
      &v43,
      this);
    (((UIScene *)(v8 + 160572)))->UIScene::SetShow(0);
    sub_446010(v8 + 160572);
    v31 = (int)*(&g_ArcSceneMonsterTable2 + nVal);
    v32 = *((_DWORD *)v8 + 40181);
    v8 += 160724;
    v44 = *(_DWORD *)(nVal2 + 4) + 88;
    v46 = v44 + 32;
    (*(void ( **)(char *, int))(v32 + 16))(v8, v31);
    (((UIScene *)v8))->UIScene::SetShow(0);
    return (int *)sub_446010(v8);
  }
  return result;
}

// 0x0052DC40
int ArcSceneMonster::CheckDistance(float fVal)
{
  unsigned int v2; // esi
  int v3; // edx
  char *m_pMonsterData; // edi
  float *i; // ecx

  if ( fVal < 0.0 )
    return 0;
  if ( fVal > (double)*((float *)&this->m_pMonsterData + 1) )
    return 0;
  v2 = *(_DWORD *)&this->id;
  v3 = 0;
  if ( !*(_DWORD *)&this->id )
    return 0;
  m_pMonsterData = (char *)this->m_pMonsterData;
  for ( i = (float *)(m_pMonsterData + 12); fVal > (double)*i; i += 8 )
  {
    if ( ++v3 >= v2 )
      return 0;
  }
  return (int)&m_pMonsterData[32 * v3];
}

// 0x0052DCA0
int ArcSceneMonster::ValidateRange(float fVal)
{
  unsigned int v2; // esi
  int v3; // edx
  float *i; // ecx

  if ( fVal < 0.0 )
    return 0;
  if ( fVal > (double)*((float *)&this->m_pMonsterData + 1) )
    return 0;
  v2 = *(_DWORD *)&this->id;
  v3 = 0;
  if ( !*(_DWORD *)&this->id )
    return 0;
  for ( i = (float *)((char *)this->m_pMonsterData + 12); fVal > (double)*i; i += 8 )
  {
    if ( ++v3 >= v2 )
      return 0;
  }
  return v3;
}
