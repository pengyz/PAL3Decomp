#pragma once
// Auto-generated: GhostParam
#include "pal3/ida_types.h"

class GhostParam {
public:
    char name[32]; // +0x0
    DWORD id; // +0x20
    int Type; // +0x24
    int HP; // +0x28
    int ATK; // +0x2C
    // total size: 0x30 (48)

};
