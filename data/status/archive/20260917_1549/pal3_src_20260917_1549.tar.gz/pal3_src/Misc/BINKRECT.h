#pragma once
// Auto-generated: BINKRECT
#include "pal3/ida_types.h"

class BINKRECT {
public:
    long Left; // +0x0
    long Top; // +0x4
    long Width; // +0x8
    long Height; // +0xC
    // total size: 0x10 (16)

};
