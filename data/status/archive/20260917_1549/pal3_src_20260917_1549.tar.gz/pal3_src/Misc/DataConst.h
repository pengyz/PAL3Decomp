#pragma once
// Auto-generated: DataConst
#include "pal3/ida_types.h"

class DataConst {
public:
    float val; // +0x0
    char name[32]; // +0x4
    // total size: 0x24 (36)

};
