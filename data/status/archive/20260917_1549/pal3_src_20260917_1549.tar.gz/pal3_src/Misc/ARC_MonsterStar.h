#pragma once
// Auto-generated: ARC_MonsterStar
#include "pal3/ida_types.h"

class ARC_MonsterStar {
public:
    int needexp; // +0x0
    int active; // +0x4
    int exp; // +0x8
    DWORD item; // +0xC
    // total size: 0x10 (16)

};
