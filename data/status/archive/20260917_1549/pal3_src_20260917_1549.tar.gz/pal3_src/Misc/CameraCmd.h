#pragma once
// Auto-generated: CameraCmd
#include "pal3/ida_types.h"

class CameraCmd {
public:
    int nCmdID; // +0x0
    int nValue; // +0x4
    // total size: 0x8 (8)

};
