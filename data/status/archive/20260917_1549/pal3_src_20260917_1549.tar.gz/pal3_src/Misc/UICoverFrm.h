#include "Misc/UIFrameWnd.h"
#pragma once
// Auto-generated: UICoverFrm
#include "pal3/ida_types.h"

#include "Misc/Average.h"
#include "Misc/MENU_TYPE.h"
#include "Misc/UIButtonEX.h"
#include "Misc/UIPar_Meteor.h"
#include "Misc/UIPar_Star.h"
#include "Misc/UIStatic.h"
#include "Misc/UIStaticEXA.h"
#include "Misc/_CLOUD.h"

class UILoadingFrm;
class UITitle_ArcSave;
class UITitle_JDHY;
class UITitle_QCYM;
class UITitle_XJTM;
class UITitle_YXXX;
class UIWnd;

class UICoverFrm : public UIFrameWnd {
public:
    char _gap_000[72]; // +0x0
    tagRECT rc; // +0x48
    char buf[256]; // +0x58
    UIStatic m_background; // +0x158
    char _gap_1F0[8]; // +0x1F0
    UIPar_Star m_Star[13]; // +0x1F8
    UIPar_Meteor m_Meteor; // +0x844
    _CLOUD m_cloud[10]; // +0x958
    char _gap_1150[120]; // +0x1150
    _CLOUD m_midCloud[5]; // +0x11C8
    char _gap_15C4[60]; // +0x15C4
    _CLOUD m_smlCloud[5]; // +0x1600
    char _gap_19FC[60]; // +0x19FC
    _CLOUD m_testCloud[9]; // +0x1A38
    char _gap_2164[108]; // +0x2164
    UIStatic m_mountainA; // +0x21D0
    char _gap_2268[8]; // +0x2268
    UIStatic m_mountainB; // +0x2270
    char _gap_2308[8]; // +0x2308
    UIStatic m_frame; // +0x2310
    char _gap_23A8[8]; // +0x23A8
    UIStatic m_Logo; // +0x23B0
    char _gap_2448[8]; // +0x2448
    BYTE m_isAlpha; // +0x2450
    char _gap_2451[3]; // +0x2451
    float m_alpha; // +0x2454
    UIStaticEXA m_tjA; // +0x2458
    char _gap_2518[8]; // +0x2518
    UIStaticEXA m_tjB; // +0x2520
    char _gap_25E0[8]; // +0x25E0
    UIButtonEX m_XDGS; // +0x25E8
    UIButtonEX m_QCYM; // +0x2770
    UIButtonEX m_XJTM; // +0x28F8
    UIButtonEX m_LKYX; // +0x2A80
    UIButtonEX m_YXXX; // +0x2C08
    UIButtonEX m_JDHY; // +0x2D90
    UIButtonEX * m_CtrlBtn[6]; // +0x2F18
    char _gap_2F1C[20]; // +0x2F1C
    int m_SelBtn; // +0x2F30
    BYTE m_ExitGame; // +0x2F34
    char _gap_2F35[3]; // +0x2F35
    UITitle_QCYM * pQCYM; // +0x2F38
    UITitle_JDHY * pJDHY; // +0x2F3C
    UITitle_YXXX * pYXXX; // +0x2F40
    UITitle_XJTM * pXJTM; // +0x2F44
    UITitle_ArcSave * pArcSave; // +0x2F48
    UILoadingFrm * pLoadingFrm; // +0x2F4C
    MENU_TYPE m_MenuType; // +0x2F50
    char _gap_2F51[3]; // +0x2F51
    Average m_timeAverage; // +0x2F54
    BYTE m_gotogame; // +0x2F6C
    char _gap_2F6D[3]; // +0x2F6D
    UINT m_flag; // +0x2F70
    UIStatic m_test; // +0x2F74
    char _gap_300C[644]; // +0x300C
    int m_nTodo_3290; // +0x3290
    int m_nTodo_3294; // +0x3294
    char _gap_3298[1]; // +0x3298
    BYTE m_nTodo_3299[4]; // +0x3299
    char _gap_329D[939]; // +0x329D
    int m_nTodo_3648; // +0x3648
    int m_nTodo_364C; // +0x364C
    char _gap_3650[152]; // +0x3650
    int m_nTodo_36E8; // +0x36E8
    int m_nTodo_36EC; // +0x36EC
    char _gap_36F0[4]; // +0x36F0
    int m_nTodo_36F4; // +0x36F4
    int m_nTodo_36F8; // +0x36F8
    int m_nTodo_36FC; // +0x36FC
    int m_nTodo_3700; // +0x3700
    char _gap_3704[148]; // +0x3704
    int m_nTodo_3798; // +0x3798
    char _gap_379C[308]; // +0x379C
    int m_nTodo_38D0; // +0x38D0
    char _gap_38D4[52]; // +0x38D4
    int m_nTodo_3908; // +0x3908
    char _tail_390C[348]; // +0x390C
    // total size: 0x3A68 (14952)

    virtual ~UICoverFrm() {}

    virtual void Render(); // 0x0052C450
    virtual double UpdateStarAnimation(int edi0, double result, int result_4, int nVal); // 0x0052C480
    void * _scalar_dtor(UIWnd *Block, char pData); // 0x0052BBB0
    virtual int OnMessage(int nVal, char *pszBuf, int nVal2); // 0x0052CA10
    int SetDefaultValues(); // 0x0044C840
    char UpdateAnimation(float fVal); // 0x0044C8A0
    int SetCoverTexture(int nTexPtr); // 0x0044DB50
    int * FindActiveSlot(); // 0x0044FF20
    int UpdateClouds(int nVal, int nVal2); // 0x00527230
    int ResetStarFrames(int nVal); // 0x00527370
    int ctor(); // 0x0052BA10
    UICoverFrm(); // 0x0052BD50
    int AnimateElements(); // 0x0052D5B0
    char LoadFromFile(char *pszFileName); // 0x0052D7C0
};
