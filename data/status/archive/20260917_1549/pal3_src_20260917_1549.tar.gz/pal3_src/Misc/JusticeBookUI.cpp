#include "pal3/ida_defs.h"
#include "globals.h"
#include "pal3/pal3_constants.h"
#include "Misc/JusticeBookUI.h"
#include "Misc/ARC_PlayerAtt.h"
#include "Misc/ArcSceneObject.h"
#include "Combat/CCBAttackSequen.h"
#include "Combat/CCBControlWindow.h"
#include "Combat/CCBMagicWindow.h"
#include "Data/CGameData.h"
#include "Render/CScreenMode.h"
#include "GameBase/GRPinput.h"
#include "Role/NPC.h"
#include "Misc/NameSys.h"
#include "Script/PalScript.h"
#include "Script/PalScriptMgr.h"
#include "Misc/PtrArray.h"
#include "Render/RenderTarget.h"
#include "Scene/SceneObj.h"
#include "Effect/ScreenEffect.h"
#include "Misc/TxtFile.h"
#include "Misc/UICaption.h"
#include "Misc/UIFrameWnd.h"
#include "UI/UIListBox.h"
#include "Misc/UIParticle.h"
#include "Misc/UIProgressBar.h"
#include "Misc/UIRoleDialog.h"
#include "Misc/UIRoleSelect.h"
#include "UI/UIScene.h"
#include "Misc/UISceneFrm.h"
#include "UI/UIWnd.h"
#include "Misc/_PlugInfo.h"
#include "free_functions.h"

// Forward declarations for unnamed functions

// 0x0044DA30
char JusticeBookUI::UpdateFadeAnim(float fDelta)
{
  char result; // al
  double v3; // st7

  result = this->m_tpID[88][5];
  if ( result )
  {
    v3 = fDelta * 80.0 + *(float *)&this->m_tpID[89][0];
    *(float *)&this->m_tpID[89][0] = v3;
    if ( v3 >= 255.0 )
    {
      this->m_tpID[89][0] = 1132396544;
      LOBYTE(this->m_tpID[88][5]) = 0;
    }
    (((NPC *)&this->m_tpID[82][3]))->NPC::UpdateAnim();
  }
  return result;
}

// 0x005282E0
int JusticeBookUI::ctor()
{
  char *m_text; // edi
  int v3; // ebp
  int *p_m_bcreateok; // edi
  int v5; // ebp

  this->bkWndX = 800;
  this->bkWndY = 600;
  NameSys::GetSys();
  sub_4422E0(&this->m_Exit.m_texarrayInfo[2]);
  sub_4422E0(&this->m_Exit.m_benable_snd + 4);
  sub_4422E0(&this->m_OutFrameT.m_disablepicInfo);
  sub_4422E0(&this->m_OutFrameR.m_ppicInfo);
  sub_4422E0(&this->m_OutFrameL.m_pbkInfo);
  sub_4422E0(&this->m_OutFrameB.m_text[12]);
  sub_4422E0(&this->m_JusticeBook.m_obj[0].m_pos.z);
  sub_4422E0(&this->m_JusticeBook.m_rotatetarget);
  (((UIProgressBar *)&this->m_Monster.m_obj[0].m_pos.y))->UIProgressBar::ctor();
  m_text = this->m_Name.m_text;
  v3 = 5;
  do
  {
    m_text += 12;
    --v3;
  }
  while ( v3 );
  (((UIProgressBar *)((char *)&this->m_Name + 156)))->UIProgressBar::ctor();
  sub_4422E0(&this->m_S.m_FVF);
  sub_4422E0(&this->m_Wuling[0].m_pbk2);
  // [AUTO-COMMENTED] (TxtFile *)&this->m_Wuling[1].m_FVF->TxtFile();
  p_m_bcreateok = (int *)&this->m_Sorcery[3].m_bcreateok;
  v5 = 5;
  do
  {
    ArraySort((int)p_m_bcreateok, 800, 2, 0 /* TODO: (int)ArcSceneObject::InitFromConfig */);
    p_m_bcreateok += 402;
    --v5;
  }
  while ( v5 );
  *(&this->m_Page + 341) = 0;
  (((ARC_PlayerAtt *)(&this->m_Page + 343)))->ARC_PlayerAtt::Refresh();
  *((_BYTE *)&this->m_Page + 44808) = 0;
  *((_BYTE *)&this->m_Page + 44809) = 0;
  *(_DWORD *)&this->m_Wuling[1].m_mouseoff = 0;
  return (int)this;
}

// 0x005284E0
JusticeBookUI::JusticeBookUI()
{
  (((UIRoleDialog *)(&this->m_Page + 343)))->UIRoleDialog::~UIRoleDialog();
  (((PalScript *)&this->m_Wuling[1].m_FVF))->PalScript::Cleanup();
  (((UIFrameWnd *)&this->m_Wuling[0].m_pbk2))->UIFrameWnd::_UIFrameWnd();
  (((UIFrameWnd *)&this->m_S.m_FVF))->UIFrameWnd::_UIFrameWnd();
  (((PalScript *)((char *)&this->m_Name + 156)))->PalScript::Reset();
  (((PalScript *)&this->m_Monster.m_obj[0].m_pos.y))->PalScript::Reset();
  (((UIFrameWnd *)&this->m_JusticeBook.m_rotatetarget))->UIFrameWnd::_UIFrameWnd();
  (((UIFrameWnd *)&this->m_JusticeBook.m_obj[0].m_pos.z))->UIFrameWnd::_UIFrameWnd();
  (((UIFrameWnd *)&this->m_OutFrameB.m_text[12]))->UIFrameWnd::_UIFrameWnd();
  (((UIFrameWnd *)&this->m_OutFrameL.m_pbkInfo))->UIFrameWnd::_UIFrameWnd();
  (((UIFrameWnd *)&this->m_OutFrameR.m_ppicInfo))->UIFrameWnd::_UIFrameWnd();
  (((UIFrameWnd *)&this->m_OutFrameT.m_disablepicInfo))->UIFrameWnd::_UIFrameWnd();
  (((UIFrameWnd *)(&this->m_Exit.m_benable_snd + 4)))->UIFrameWnd::_UIFrameWnd();
  (((UIFrameWnd *)&this->m_Exit.m_texarrayInfo[2]))->UIFrameWnd::_UIFrameWnd();
  (((UICaption *)&this->buf[248]))->UICaption::Destroy2();
  (((UIListBox *)this))->UIListBox::~UIListBox() /* [ROWTABLE] */;
}

// 0x00528ED0
int JusticeBookUI::JusticeBookUI_Render(int nVal)
{
  CCBControlWindow *v1; // ecx
  CCBControlWindow *v2; // ebx
  int result; // eax
  RenderTarget *p_m_bfocus; // esi
  int v5; // ebp
  CCBMagicWindow *v6; // [esp+0x0] [ebp-0x4]
  int v7; // [esp+0x0] [ebp-0x4]

  v2 = (CCBControlWindow *)v1;
  (((CCBControlWindow *)v1))->CCBControlWindow::Render(v6);
  if ( *((_BYTE *)&v2[286].m_CurCtrl_2 + 12) )
  {
    p_m_bfocus = (RenderTarget *)&v2[179].m_bfocus;
    v5 = 36;
    do
    {
      if ( IsVisible((RenderTarget *)((char *)p_m_bfocus - 21024)) )
        (((ScreenEffect *)&p_m_bfocus[-106].m_fInvScale))->ScreenEffect::Apply();
      LOBYTE(result) = IsVisible(p_m_bfocus);
      if ( (_BYTE)result )
        (((ScreenEffect *)p_m_bfocus))->ScreenEffect::Apply();
      p_m_bfocus = (RenderTarget *)((char *)p_m_bfocus + 584);
      --v5;
    }
    while ( v5 );
    *((_BYTE *)&v2[286].m_CurCtrl_2 + 12) = 0;
    *((_BYTE *)&v2[286].m_CurCtrl_2 + 13) = 1;
  }
  else
  {
    LOBYTE(result) = *((_BYTE *)&v2[286].m_CurCtrl_2 + 13);
    if ( (_BYTE)result )
      return SceneMgr_LoadMainUITexture(v7);
  }
  return result;
}

// 0x00528F50
int JusticeBookUI::ProcessInput(int nVal, int nVal2)
{
  POINT pt; // [esp+0x8] [ebp-0x58] BYREF
  RECT rc; // [esp+0x10] [ebp-0x50] BYREF
  RECT v7; // [esp+0x20] [ebp-0x40] BYREF
  RECT v8; // [esp+0x30] [ebp-0x30] BYREF
  RECT v9; // [esp+0x40] [ebp-0x20] BYREF
  RECT v10; // [esp+0x50] [ebp-0x10] BYREF

  if ( !LOBYTE(this->m_Wuling[1].m_pbk2) )
  {
    g_Input.GRPinput::GetCursorPos(&pt);
    rc.top = 179;
    v7.top = 179;
    rc.bottom = 348;
    v7.bottom = 348;
    v8.top = 406;
    v9.top = 406;
    v10.top = 406;
    v8.bottom = 575;
    v9.bottom = 575;
    v10.bottom = 575;
    rc.left = 199;
    rc.right = 337;
    v7.left = 464;
    v7.right = 602;
    v8.left = 128;
    v8.right = 266;
    v9.left = 334;
    v9.right = 472;
    v10.left = 540;
    v10.right = 678;
    if ( PtInRect(&rc, pt) )
    {
      sprintf(
        (char *const)&this->i,
        "%s\\n%s\\n",
        (const char *)&this->m_Sorcery[3].m_bvisible,
        (const char *)&this->m_Sorcery[3].m_nTextW);
    }
    else if ( PtInRect(&v7, pt) )
    {
      sprintf(
        (char *const)&this->i,
        "%s\\n%s\\n",
        &this->m_tpImmortal.m_caption[56],
        (const char *)&this->m_tpImmortal.m_nTodo_0EC + 12);
    }
    else if ( PtInRect(&v8, pt) )
    {
      sprintf(
        (char *const)&this->i,
        "%s\\n%s\\n",
        (const char *)&this->m_tpGhost_unopen,
        (const char *)&this->m_tpGhost_unopen.m_disablepic);
    }
    else if ( PtInRect(&v9, pt) )
    {
      sprintf(
        (char *const)&this->i,
        "%s\\n%s\\n",
        (const char *)&this->m_tpID[23][4],
        (const char *)&this->m_tpID[27][3]);
    }
    else if ( PtInRect(&v10, pt) )
    {
      sprintf(
        (char *const)&this->i,
        "%s\\n%s\\n",
        (const char *)&this->m_tpID[90][4],
        (const char *)&this->m_tpID[94][3]);
    }
    SetEnable((UICaption *)&this->m_OutFrameB.m_text[12]);
  }
  (((SceneObj *)this))->SceneObj::Update(nVal, nVal2) /* [ROWTABLE] */;
  return 1;
}

// 0x00529120
int JusticeBookUI::OnMessage(int nVal, char *pszBuf, int nVal2)
{
  DWORD TickCount; // eax
  int result; // eax
  int v7; // ecx
  int v8; // eax
  int *p_m_enable; // eax
  int v10; // ecx
  int *v11; // ebx
  int v12; // eax
  CScreenMode *Instance; // eax
  const void *v14; // [esp-0x8] [ebp-0x1C]
  int v15; // [esp-0x4] [ebp-0x18]
  int v16; // [esp+0x0] [ebp-0x14]
  int *v17; // [esp+0x0] [ebp-0x14]
  int pOut; // [esp+0xC] [ebp-0x8] BYREF
  int pOut2; // [esp+0x10] [ebp-0x4] BYREF

  switch ( nVal )
  {
    case 1000:
      if ( !pszBuf )
        goto LABEL_16;
      TickCount = GetTickCount();
      CRT_set_new_handler(TickCount);
      SceneMgr_LoadMainUITexture(v16);
      SetEnable((UICaption *)(&this->m_Page + 457));
      (((UIRoleSelect *)(&this->m_Page + 343)))->UIRoleSelect::SetByte(1);
      CountActiveParticles((UIParticle *)this, v17);
      return 1;
    case 1001:
      if ( pszBuf != (char *)&g_PlayerAttBuffer.id + 1 )
        goto LABEL_16;
      v7 = *(&this->m_Page + 342);
      v15 = *(_DWORD *)&this->m_Wuling[1].m_mouseoff;
      *(_DWORD *)(v7 + 15008) = v15;
      (((CCBAttackSequen *)v7))->CCBAttackSequen::FindSequenceSlot(v15);
      v8 = *(&this->m_Page + 342);
      qmemcpy((void *)(v8 + 6964), &this->m_Sorcery[3].m_childs.m_nSize, 0x1F68u);
      *(_BYTE *)(v8 + 15004) = 1;
      (*((CScreenMode **)&this->m_Page + 341))->CScreenMode::InitSceneAudio(2);
      goto LABEL_14;
    case 1002:
      if ( pszBuf != (char *)&g_PlayerAttBuffer.id + 1 )
        goto LABEL_16;
      *((_BYTE *)&this->m_Page + 44808) = 1;
      result = 1;
      break;
    case 1010:
      (((UISceneFrm *)this))->UISceneFrm::CallFaceMethod(*(_DWORD *)&this->m_Wuling[1].m_mouseoff, 0) /* [ROWTABLE] */;
      *(_DWORD *)&this->m_S.m_text[12] = 0;
      *(_DWORD *)&this->m_S.m_text[8] = 0;
      *(_DWORD *)&this->m_S.m_text[4] = 0;
      SetEnable((UICaption *)&this->m_OutFrameB.m_text[12]);
      SetEnable((UICaption *)&this->m_JusticeBook.m_rotatetarget);
      *(_DWORD *)&this->m_Wuling[1].m_mouseoff = 0;
      p_m_enable = (int *)&this->m_Monster.m_obj[3].m_enable;
      v10 = 5;
      do
      {
        *p_m_enable = 1;
        p_m_enable += 8;
        --v10;
      }
      while ( v10 );
      v14 = (const void *)off_5EB920;
      goto LABEL_15;
    case 1013:
      if ( pszBuf != &g_PlayerAttBuffer.Remark[2] )
        goto LABEL_16;
      *(&this->m_H.m_align + 8 * *(_DWORD *)&this->m_Wuling[1].m_mouseoff) = 0;
      *(_DWORD *)&this->m_S.m_text[12] = 0;
      *(_DWORD *)&this->m_S.m_text[8] = 0;
      *(_DWORD *)&this->m_S.m_text[4] = 0;
      *(_DWORD *)&this->m_Wuling[1].m_mouseoff = nVal2;
      (((UISceneFrm *)this))->UISceneFrm::CallFaceMethod(nVal2, 1u) /* [ROWTABLE] */;
      sprintf(
        (char *const)&this->i,
        "%s\\n%s\\n",
        (const char *)&this->m_Sorcery[3].m_bvisible + 1608 * *(_DWORD *)&this->m_Wuling[1].m_mouseoff,
        (const char *)&this->m_Sorcery[3].m_nTextW + 1608 * *(_DWORD *)&this->m_Wuling[1].m_mouseoff);
      SetEnable((UICaption *)&this->m_OutFrameB.m_text[12]);
      SetEnable((UICaption *)&this->m_JusticeBook.m_rotatetarget);
      v11 = (int *)&this->m_Monster.m_obj[3].m_enable;
      v12 = 5;
      do
      {
        *v11 = 0;
        v11 += 8;
        --v12;
      }
      while ( v12 );
LABEL_14:
      v14 = (const void *)off_5EB920;
LABEL_15:
      Instance = (CScreenMode *)CScreenMode::GetInstance();
      (((CScreenMode *)Instance))->CScreenMode::AudioSetPosition(v14, 1);
LABEL_16:
      result = 1;
      break;
    case 1016:
      if ( pszBuf == &g_PlayerAttBuffer.Remark[3] )
      {
        g_Input.GRPinput::GetMousePos(&pOut, &pOut2);
        *(float *)&this->m_S.m_text[4] = (double)pOut2 + *(float *)&this->m_S.m_text[4];
        *(float *)&this->m_S.m_text[8] = (double)pOut + *(float *)&this->m_S.m_text[8];
      }
      return 1;
    default:
      return (((CGameData *)this))->CGameData::OnMessage(nVal, (int)pszBuf, nVal2) /* [ROWTABLE] */;
  }
  return result;
}
