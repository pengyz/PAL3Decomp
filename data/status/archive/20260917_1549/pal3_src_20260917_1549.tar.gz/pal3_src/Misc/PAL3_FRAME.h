#pragma once
// Auto-generated: PAL3_FRAME
#include "pal3/ida_types.h"

class PAL3_FRAME {
public:
    char _tail_000[1]; // +0x0
    // total size: 0x1 (1)

    // Scalar-wrapper: ctors for IDA (Cls)int casts (no init code)
    PAL3_FRAME() {}
    PAL3_FRAME(int v) { *(char*)this = (char)v; }

};
