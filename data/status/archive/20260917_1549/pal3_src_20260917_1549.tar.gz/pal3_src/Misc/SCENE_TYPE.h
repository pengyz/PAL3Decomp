#pragma once
// Auto-generated: SCENE_TYPE
#include "pal3/ida_types.h"

class SCENE_TYPE {
public:
    char _tail_000[1]; // +0x0
    // total size: 0x1 (1)

    // Scalar-wrapper: ctors for IDA (Cls)int casts (no init code)
    SCENE_TYPE() {}
    SCENE_TYPE(int v) { *(char*)this = (char)v; }

};
