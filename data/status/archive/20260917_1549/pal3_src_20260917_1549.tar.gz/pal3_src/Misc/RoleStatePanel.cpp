#include "pal3/ida_defs.h"
#include "globals.h"
#include "pal3/pal3_constants.h"
#include "Misc/RoleStatePanel.h"
#include "Combat/CCBControlWindow.h"
#include "Combat/CCBMagicWindow.h"
#include "Combat/CCBRoleState.h"
#include "Combat/CCBUI.h"
#include "Misc/CCBUIPanel.h"
#include "Data/CGameData.h"
#include "Render/CScreenMode.h"
#include "Combat/CUtil.h"
#include "Misc/ComposeUI.h"
#include "UI/EquipUI.h"
#include "GameBase/GRPinput.h"
#include "Misc/LineupComp.h"
#include "UI/MagicUI.h"
#include "Misc/MainEquipUI.h"
#include "Misc/NameSys.h"
#include "GameBase/PAL3.h"
#include "Render/RenderTarget.h"
#include "Role/Role.h"
#include "Role/RoleSystem.h"
#include "Scene/SceneObj.h"
#include "Effect/ScreenEffect.h"
#include "UI/StateUI.h"
#include "Misc/UIBigMap.h"
#include "Misc/UIButton.h"
#include "Misc/UICaption.h"
#include "Misc/UIFrameWnd.h"
#include "UI/UIListBox.h"
#include "Misc/UIStatic.h"
#include "Misc/UITitle_JDHY.h"
#include "Misc/UITitle_XJTM.h"
#include "UI/UIWnd.h"
#include "Misc/_PlugInfo.h"
#include "Misc/s_RoleState.h"
#include "Misc/tagCmdData.h"
#include "free_functions.h"

// Forward declarations for unnamed functions
int sub_4A13E0(...);

// 0x004A1E40
int RoleStatePanel::InitUI()
{
  *((_DWORD *)this + 22) = 800;
  *((_DWORD *)this + 23) = 600;
  this->m_nScanIndex = 0;
  *(&this->m_nScanIndex + 1) = 0;
  *((_BYTE *)&this->m_nScanIndex + 264) = 0;
  *(_DWORD *)&this->m_bSlotFlags[7] = 0;
  this->m_bSlotFlags[11] = 0;
  this->m_bSlotFlags[12] = 0;
  sub_4422E0(&this->m_bSlotFlags[15]);
  sub_4422E0(&this->m_bSlotFlags[167]);
  sub_4422E0(&this->m_bSlotFlags[319]);
  sub_4422E0(&this->m_bSlotFlags[471]);
  sub_4422E0(&this->m_bSlotFlags[623]);
  sub_4422E0(&this->m_bSlotFlags[775]);
  NameSys::GetSys();
  NameSys::GetSys();
  NameSys::GetSys();
  NameSys::GetSys();
  NameSys::GetSys();
  NameSys::GetSys();
  NameSys::GetSys();
  NameSys::GetSys();
  NameSys::GetSys();
  sub_4422E0(&this->m_bSlotFlags[4023]);
  sub_4422E0(&this->m_bSlotFlags[4191]);
  sub_4422E0(&this->m_bSlotFlags[4343]);
  sub_4422E0(&this->m_bSlotFlags[154155]);
  sub_4422E0(&this->m_bSlotFlags[154307]);
  sub_4422E0(&this->m_bSlotFlags[154459]);
  sub_4422E0(&this->m_bSlotFlags[154611]);
  sub_4422E0(&this->m_roles[5].m_JingBar);
  NameSys::GetSys();
  this->m_roles[5].m_QiVal.m_rect.bottom = 0;
  this->m_pSubTab1 = 0;
  this->m_pSubTab2 = 0;
  *((_DWORD *)&this->m_pSubTab2 + 1) = 0;
  *((_DWORD *)&this->m_pSubTab2 + 2) = 0;
  *((_DWORD *)&this->m_pSubTab2 + 3) = 0;
  *((_DWORD *)&this->m_pSubTab2 + 4) = 0;
  this->m_nEquipSlot = 0;
  sub_4422E0(&this->m_bFlag2afd9 + 3);
  this->m_bSlotFlags[4] = 0;
  this->m_bSlotFlags[3] = 0;
  this->m_bSlotFlags[1] = 0;
  this->m_bSlotFlags[0] = 0;
  this->m_bSlotFlags[2] = 0;
  *(_DWORD *)&this->m_bSlotFlags[154127] = 0;
  *(_DWORD *)&this->m_bSlotFlags[154131] = 0;
  *(_DWORD *)&this->m_bSlotFlags[154135] = 0;
  *(_DWORD *)(&this->m_bFlag2afd9 + 155) = 0;
  return (int)this;
}

// 0x004A2450
RoleStatePanel::~RoleStatePanel()
{
  int result; // eax
  int v3; // [esp+0x0] [ebp-0x14]

  UIGameFrm_Destroy(v3);
  (((UIFrameWnd *)(&this->m_bFlag2afd9 + 3)))->UIFrameWnd::_UIFrameWnd();
  (((UICaption *)&this->m_roles[5].m_Qi.m_bfocus))->UICaption::Destroy2();
  (((UIFrameWnd *)&this->m_roles[5].m_JingBar))->UIFrameWnd::_UIFrameWnd();
  (((UIFrameWnd *)&this->m_bSlotFlags[154611]))->UIFrameWnd::_UIFrameWnd();
  (((UIFrameWnd *)&this->m_bSlotFlags[154459]))->UIFrameWnd::_UIFrameWnd();
  (((UIFrameWnd *)&this->m_bSlotFlags[154307]))->UIFrameWnd::_UIFrameWnd();
  (((UIFrameWnd *)&this->m_bSlotFlags[154155]))->UIFrameWnd::_UIFrameWnd();
  (((UIFrameWnd *)&this->m_bSlotFlags[4343]))->UIFrameWnd::_UIFrameWnd();
  (((UIFrameWnd *)&this->m_bSlotFlags[4191]))->UIFrameWnd::_UIFrameWnd();
  (((UIFrameWnd *)&this->m_bSlotFlags[4023]))->UIFrameWnd::_UIFrameWnd();
  (((UICaption *)&this->m_bSlotFlags[3679]))->UICaption::Destroy2();
  (((UICaption *)&this->m_bSlotFlags[3335]))->UICaption::Destroy2();
  (((UICaption *)&this->m_bSlotFlags[2991]))->UICaption::Destroy2();
  (((UICaption *)&this->m_bSlotFlags[2647]))->UICaption::Destroy2();
  (((UICaption *)&this->m_bSlotFlags[2303]))->UICaption::Destroy2();
  (((UICaption *)&this->m_bSlotFlags[1959]))->UICaption::Destroy2();
  (((UICaption *)&this->m_bSlotFlags[1615]))->UICaption::Destroy2();
  (((UICaption *)&this->m_bSlotFlags[1271]))->UICaption::Destroy2();
  (((UICaption *)&this->m_bSlotFlags[927]))->UICaption::Destroy2();
  (((UIFrameWnd *)&this->m_bSlotFlags[775]))->UIFrameWnd::_UIFrameWnd();
  (((UIFrameWnd *)&this->m_bSlotFlags[623]))->UIFrameWnd::_UIFrameWnd();
  (((UIFrameWnd *)&this->m_bSlotFlags[471]))->UIFrameWnd::_UIFrameWnd();
  (((UIFrameWnd *)&this->m_bSlotFlags[319]))->UIFrameWnd::_UIFrameWnd();
  (((UIFrameWnd *)&this->m_bSlotFlags[167]))->UIFrameWnd::_UIFrameWnd();
  (((UIFrameWnd *)&this->m_bSlotFlags[15]))->UIFrameWnd::_UIFrameWnd();
  (((UIListBox *)this))->UIListBox::~UIListBox() /* [ROWTABLE] */;
  result;
}

// 0x004A3900
int RoleStatePanel::SetItemData(int id, unsigned int data)
{
  char *v4; // edi
  int result; // eax

  if ( id <= 5 )
  {
    v4 = (char *)this + 3788 * id;
    (**((void ( ***)(int, _DWORD))v4 + 38785))((int)(v4 + 155140), (unsigned __int8)data);
    (**((void ( ***)(int, _DWORD))v4 + 38823))((int)(v4 + 155292), (unsigned __int8)data);
    (**((void ( ***)(int, _DWORD))v4 + 38861))((int)(v4 + 155444), (unsigned __int8)data);
    (**((void ( ***)(int, _DWORD))v4 + 38937))((int)(v4 + 155748), (unsigned __int8)data);
    (**((void ( ***)(int, _DWORD))v4 + 38998))((int)(v4 + 155992), (unsigned __int8)data);
    (**((void ( ***)(int, _DWORD))v4 + 39211))((int)(v4 + 156844), (unsigned __int8)data);
    (**((void ( ***)(int, _DWORD))v4 + 39272))((int)(v4 + 157088), (unsigned __int8)data);
    (**((void ( ***)(int, _DWORD))v4 + 39074))((int)(v4 + 156296), (unsigned __int8)data);
    (**((void ( ***)(int, _DWORD))v4 + 39135))((int)(v4 + 156540), (unsigned __int8)data);
    (**((void ( ***)(int, _DWORD))v4 + 39310))((int)(v4 + 157240), (unsigned __int8)data);
    (**((void ( ***)(int, _DWORD))v4 + 39348))((int)(v4 + 157392), (unsigned __int8)data);
    (**((void ( ***)(int, _DWORD))v4 + 39386))((int)(v4 + 157544), (unsigned __int8)data);
    (**((void ( ***)(int, _DWORD))v4 + 39424))((int)(v4 + 157696), (unsigned __int8)data);
    (**((void ( ***)(int, _DWORD))v4 + 39462))((int)(v4 + 157848), (unsigned __int8)data);
    (**((void ( ***)(int, _DWORD))v4 + 39500))((int)(v4 + 158000), (unsigned __int8)data);
    (**((void ( ***)(int, _DWORD))v4 + 39538))((int)(v4 + 158152), (unsigned __int8)data);
    (**((void ( ***)(int, _DWORD))v4 + 39576))((int)(v4 + 158304), (unsigned __int8)data);
    (**((void ( ***)(int, _DWORD))v4 + 39652))((int)(v4 + 158608), (unsigned __int8)data);
    (**((void ( ***)(int, _DWORD))v4 + 39614))((int)(v4 + 158456), (unsigned __int8)data);
    (((UITitle_XJTM *)this->m_pSubTab1))->UITitle_XJTM::SetMonsterState(id, data);
    (((UIBigMap *)this->m_pSubTab2))->UIBigMap::SetEntryVisible(id, data);
    (*((UITitle_XJTM **)&this->m_pSubTab2 + 1))->UITitle_XJTM::SetMonsterState2(id, data);
    return (((LineupComp *)this->m_roles[5].m_QiVal.m_rect.bottom))->LineupComp::DispatchSlotMethod(id, data);
  }
  return result;
}

// 0x004A4780
int RoleStatePanel::HandleDeviceLostB()
{
  RenderTarget *Instance_db10; // eax
  PAL3 *v3; // ecx
  PAL3 *v4; // ecx
  int v5; // eax
  RenderTarget *v6; // eax
  int result; // eax
  PAL3 *v8; // ecx
  unsigned __int8 v9; // bl
  PAL3 *v10; // ecx
  RenderTarget *v11; // eax
  PAL3 *v12; // ecx
  RenderTarget *v13; // eax

  Instance_db10 = (RenderTarget *)GetInstance_db10((PAL3 *)this);
  (((RenderTarget *)Instance_db10))->RenderTarget::OnDeviceLost(1);
  v4 = *(PAL3 **)GetInstance_db10(v3);
  v5 = 1061158912;
  if ( v4 )
    v5 = 1065353216;
  this->m_nDevLost2 = v5;
  this->m_nDevLost1 = v5;
  v6 = (RenderTarget *)GetInstance_db10(v4);
  LOBYTE(result) = (((RenderTarget *)v6))->RenderTarget::OnResetDevice(1);
  if ( (_BYTE)result )
  {
    v9 = g_bGameFlag2;
    g_bGameFlag2 = 0;
    (((PAL3 *)v8))->PAL3::Render();
    g_bGameFlag2 = v9;
    v11 = (RenderTarget *)GetInstance_db10(v10);
    (((RenderTarget *)v11))->RenderTarget::RenderToScreen();
    *(_DWORD *)(&this->m_bFlag2afd9 + 155) = 0;
    v13 = (RenderTarget *)GetInstance_db10(v12);
    result = (int)(((RenderTarget *)v13))->RenderTarget::GetActiveTexture();
    if ( result )
    {
      if ( *(_DWORD *)(result + 84) )
        *(_DWORD *)(&this->m_bFlag2afd9 + 155) = result;
    }
  }
  else
  {
    *(_DWORD *)(&this->m_bFlag2afd9 + 155) = 0;
  }
  return result;
}

// 0x004A4820
int RoleStatePanel::Render()
{
  int result; // eax

  result = *(_DWORD *)(&this->m_bFlag2afd9 + 155);
  if ( result )
    return crt_sub_00540D20();
  return result;
}

// 0x004A4890
int RoleStatePanel::GetSelected()
{
  int result; // eax
  int m_nScanIndex; // edx
  int v3; // edx

  result = 0;
  this->m_nScanIndex = 0;
  do
  {
    m_nScanIndex = this->m_nScanIndex;
    if ( this->m_bSlotFlags[m_nScanIndex] )
      ++result;
    v3 = m_nScanIndex + 1;
    this->m_nScanIndex = v3;
  }
  while ( v3 < 5 );
  return result;
}

// 0x004A48B0
void RoleStatePanel::InitSlots()
{
  unsigned int data; // [esp+0x8] [ebp+0x4]

  if ( this->RoleStatePanel::GetSelected() < 5 )
  {
    this->m_bSlotFlags[0] = data;
    this->RoleStatePanel::SetItemData(0, data);
    (((EquipUI *)this->m_pSubTab1))->EquipUI::SetSubTab(data);
    (((EquipUI *)this->m_pSubTab2))->EquipUI::SelectBigMapTab0(data);
    (*((EquipUI **)&this->m_pSubTab2 + 1))->EquipUI::SetSubTab2(data);
    (((EquipUI *)this->m_roles[5].m_QiVal.m_rect.bottom))->EquipUI::SelectTab0(data);
  }
  else
  {
    this->m_bSlotFlags[0] = 0;
    this->RoleStatePanel::SetItemData(0, 0);
    (((EquipUI *)this->m_pSubTab1))->EquipUI::SetSubTab(0);
    (((EquipUI *)this->m_pSubTab2))->EquipUI::SelectBigMapTab0(0);
    (*((EquipUI **)&this->m_pSubTab2 + 1))->EquipUI::SetSubTab2(0);
    (((EquipUI *)this->m_roles[5].m_QiVal.m_rect.bottom))->EquipUI::SelectTab0(0);
  }
}

// 0x004A4960
int RoleStatePanel::InitLayout()
{
  unsigned int data; // [esp+0x8] [ebp+0x4]

  if ( this->RoleStatePanel::GetSelected() < 5 )
  {
    this->m_bSlotFlags[1] = data;
    this->RoleStatePanel::SetItemData(1, data);
    (((StateUI *)this->m_pSubTab1))->StateUI::SelectSubTab1(data);
    (((StateUI *)this->m_pSubTab2))->StateUI::ForwardToBigMap(data);
    (*((StateUI **)&this->m_pSubTab2 + 1))->StateUI::SelectXJTMTab1(data);
    return (((StateUI *)this->m_roles[5].m_QiVal.m_rect.bottom))->StateUI::SelectTab1(data);
  }
  else
  {
    this->m_bSlotFlags[1] = 0;
    this->RoleStatePanel::SetItemData(1, 0);
    (((StateUI *)this->m_pSubTab1))->StateUI::SelectSubTab1(0);
    (((StateUI *)this->m_pSubTab2))->StateUI::ForwardToBigMap(0);
    (*((StateUI **)&this->m_pSubTab2 + 1))->StateUI::SelectXJTMTab1(0);
    return (((StateUI *)this->m_roles[5].m_QiVal.m_rect.bottom))->StateUI::SelectTab1(0);
  }
}

// 0x004A4A10
void RoleStatePanel::CreateWidgets()
{
  unsigned int data; // [esp+0x8] [ebp+0x4]

  if ( this->RoleStatePanel::GetSelected() < 5 )
  {
    this->m_bSlotFlags[2] = data;
    this->RoleStatePanel::SetItemData(2, data);
    (((StateUI *)this->m_pSubTab1))->StateUI::SelectSubTab2(data);
    (((StateUI *)this->m_pSubTab2))->StateUI::SelectBigMapTab2(data);
    (*((StateUI **)&this->m_pSubTab2 + 1))->StateUI::SelectXJTMTab2(data);
    (((StateUI *)this->m_roles[5].m_QiVal.m_rect.bottom))->StateUI::SelectTab2(data);
  }
  else
  {
    this->m_bSlotFlags[2] = 0;
    this->RoleStatePanel::SetItemData(2, 0);
    (((StateUI *)this->m_pSubTab1))->StateUI::SelectSubTab2(0);
    (((StateUI *)this->m_pSubTab2))->StateUI::SelectBigMapTab2(0);
    (*((StateUI **)&this->m_pSubTab2 + 1))->StateUI::SelectXJTMTab2(0);
    (((StateUI *)this->m_roles[5].m_QiVal.m_rect.bottom))->StateUI::SelectTab2(0);
  }
}

// 0x004A4AC0
int RoleStatePanel::SetSelectedData()
{
  unsigned int data; // [esp+0x8] [ebp+0x4]

  if ( this->RoleStatePanel::GetSelected() < 5 )
  {
    this->m_bSlotFlags[3] = data;
    this->RoleStatePanel::SetItemData(3, data);
    (((MagicUI *)this->m_pSubTab1))->MagicUI::SelectSubTab3(data);
    (((MagicUI *)this->m_pSubTab2))->MagicUI::SelectBigMapTab3(data);
    (*((MagicUI **)&this->m_pSubTab2 + 1))->MagicUI::SelectXJTMTab3(data);
    return (((MagicUI *)this->m_roles[5].m_QiVal.m_rect.bottom))->MagicUI::SelectTab3(data);
  }
  else
  {
    this->m_bSlotFlags[3] = 0;
    this->RoleStatePanel::SetItemData(3, 0);
    (((MagicUI *)this->m_pSubTab1))->MagicUI::SelectSubTab3(0);
    (((MagicUI *)this->m_pSubTab2))->MagicUI::SelectBigMapTab3(0);
    (*((MagicUI **)&this->m_pSubTab2 + 1))->MagicUI::SelectXJTMTab3(0);
    return (((MagicUI *)this->m_roles[5].m_QiVal.m_rect.bottom))->MagicUI::SelectTab3(0);
  }
}

// 0x004A4B70
void RoleStatePanel::Init()
{
  unsigned int data; // [esp+0x8] [ebp+0x4]

  if ( this->RoleStatePanel::GetSelected() < 5 )
  {
    this->m_bSlotFlags[4] = data;
    this->RoleStatePanel::SetItemData(4, data);
    (((MagicUI *)this->m_pSubTab1))->MagicUI::SelectSubTab4(data);
    (((MagicUI *)this->m_pSubTab2))->MagicUI::SelectBigMapTab4(data);
    (*((MagicUI **)&this->m_pSubTab2 + 1))->MagicUI::SelectXJTMTab4(data);
    (((MagicUI *)this->m_roles[5].m_QiVal.m_rect.bottom))->MagicUI::SelectTab4(data);
  }
  else
  {
    this->m_bSlotFlags[4] = 0;
    this->RoleStatePanel::SetItemData(4, 0);
    (((MagicUI *)this->m_pSubTab1))->MagicUI::SelectSubTab4(0);
    (((MagicUI *)this->m_pSubTab2))->MagicUI::SelectBigMapTab4(0);
    (*((MagicUI **)&this->m_pSubTab2 + 1))->MagicUI::SelectXJTMTab4(0);
    (((MagicUI *)this->m_roles[5].m_QiVal.m_rect.bottom))->MagicUI::SelectTab4(0);
  }
}

// 0x004A4C20
int RoleStatePanel::Create()
{
  RoleSystem *v2; // edi
  int v3; // ebp
  int v4; // edi
  int m_nScanIndex; // eax
  int v6; // eax
  int v7; // eax
  int v8; // ecx
  int v9; // eax
  int *v11; // [esp+0x0] [ebp-0x40]
  int v12; // [esp+0x18] [ebp-0x28]
  int a2[2]; // [esp+0x20] [ebp-0x20] BYREF
  int v14; // [esp+0x28] [ebp-0x18]
  int v15; // [esp+0x2C] [ebp-0x14]
  int p_DWORD; // [esp+0x30] [ebp-0x10] BYREF
  int v17; // [esp+0x34] [ebp-0xC]
  int v18; // [esp+0x38] [ebp-0x8]
  int v19; // [esp+0x3C] [ebp-0x4]

  gfxMgr->fSelfIllum = 1.0;
  lstrcpyA(byte_DE5F74, byte_DD9E3C);
  lstrcpyA(byte_DE5F77, byte_DD9F3C);
  lstrcpyA(byte_DE5F7A, byte_DDA03C);
  lstrcpyA(byte_DE5F7D, byte_DDA13C);
  lstrcpyA(byte_DE5F80, byte_DDA23C);
  lstrcpyA(byte_DE5F83, byte_DDA33C);
  lstrcpyA(byte_DE5F86, byte_DDA43C);
  lstrcpyA(byte_DE5F89, byte_DDA53C);
  lstrcpyA(byte_DE5F8C, byte_DDA63C);
  lstrcpyA(byte_DE5F8F, byte_DDA73C);
  (((CCBUIPanel *)this))->CCBUIPanel::InitScrollState() /* [ROWTABLE] */;
  this->RoleStatePanel::InitSlots();
  this->RoleStatePanel::InitLayout();
  this->RoleStatePanel::CreateWidgets();
  this->RoleStatePanel::SetSelectedData();
  this->RoleStatePanel::Init();
  v2 = (RoleSystem *)&g_RoleSlotBuf;
  do
  {
    (((RoleSystem *)v2))->RoleSystem::RecalcAggregatedStats(0);
    v2 = (RoleSystem *)((char *)v2 + 1408);
  }
  while ( (int)v2 < (int)&((RoleSystem *)&stru_C059A0)->m_nAnimCopy3 );
  v17 = 62;
  p_DWORD = 686;
  v18 = 796;
  v19 = 157;
  a2[1] = 0;
  a2[0] = 0;
  v14 = 148;
  v15 = 530;
  v12 = 147;
  v3 = 0;
  this->m_nScanIndex = 0;
  v4 = 60;
  do
  {
    m_nScanIndex = this->m_nScanIndex;
    if ( this->m_bSlotFlags[m_nScanIndex] )
    {
      if ( ++v3 <= 4 )
      {
        /* [MISATTRIBUTED] ComposeUI on RoleStatePanel::this -> fix IDB name of callee */ ComposeUI::ProcessChildItem((ComposeUI *)this, m_nScanIndex, &p_DWORD);
        /* [MISATTRIBUTED] CCBRoleState on RoleStatePanel::this -> fix IDB name of callee */ CCBRoleState::sub_4A3360((CCBRoleState *)this, (CHAR *)this->m_nScanIndex, (int)a2, v11);
        this->RoleStatePanel::SetItemData(this->m_nScanIndex, 1u);
        v4 += 122;
        a2[0] = v14;
        v14 += 148;
        v17 = v4;
        v19 = v4 + 95;
        v12 += 148;
      }
    }
    v6 = this->m_nScanIndex + 1;
    this->m_nScanIndex = v6;
  }
  while ( v6 < 5 );
  this->m_nScanIndex = 0;
  do
  {
    v7 = this->m_nScanIndex;
    if ( !this->m_bSlotFlags[v7] )
    {
      this->RoleStatePanel::SetItemData(v7, 0);
      if ( v3 < 4 )
      {
        sub_445FA0(&this->m_roles[this->m_nScanIndex].m_Shade);
        LOBYTE(v8) = g_bDebugMode;
        (((UIStatic *)&this->m_roles[this->m_nScanIndex].m_Shade))->UIStatic::CreateFromTemplate("UI\\GameMainUI\\State\\NoBodyFrame.tga", v8);
        ((void ( *)(UIStatic *, int))this->m_roles[this->m_nScanIndex].m_Shade.__vftable->ShowWindow)(
          &this->m_roles[this->m_nScanIndex].m_Shade,
          1);
        v12 += 148;
        ++v3;
      }
    }
    v9 = this->m_nScanIndex + 1;
    this->m_nScanIndex = v9;
  }
  while ( v9 < 5 );
  return /* [MISATTRIBUTED] s_RoleState on RoleStatePanel::this -> fix IDB name of callee */ s_RoleState::LoadAndSetupRole((s_RoleState *)this);
}

// 0x004A4FC0
BOOL RoleStatePanel::SetEquipSlotData()
{
  BOOL result; // eax

  this->m_nEquipSlot = 7;
  LOBYTE(gfxMgr->pSceneGraph->pnodebuf[713]) = 0;
  this->m_bFlag2afd8 = g_bRoleSystem_5CEFA9;
  g_bRoleSystem_5CEFA9 = 1;
  result = (((MainEquipUI *)this))->MainEquipUI::HandleMessage(7) /* [ROWTABLE] */;
  this->m_bFlag2afd9 = 1;
  return result;
}

// 0x004A5930
int RoleStatePanel::RenderThrottled()
{
  int result; // eax
  int i; // edi
  CCBMagicWindow *v4; // [esp+0x0] [ebp-0x4]

  this->RoleStatePanel::Render();
  result = this->m_nEquipSlot;
  switch ( result )
  {
    case 0:
      (((CCBControlWindow *)this))->CCBControlWindow::Render(v4) /* [ROWTABLE] */;
      result = *(_DWORD *)&this->m_bSlotFlags[154135];
      if ( this->m_bSlotFlags[result + 154127] )
      {
        for ( i = 0; i < 16; ++i )
        {
          if ( IsVisible((RenderTarget *)&this->m_bSlotFlags[9344 * *(_DWORD *)&this->m_bSlotFlags[154135]
                                                           + 4495
                                                           + 584 * i]) )
            (((ScreenEffect *)&this->m_bSlotFlags[9344 * *(_DWORD *)&this->m_bSlotFlags[154135]
                                                                  + 4495
                                                                  + 584 * i]))->ScreenEffect::Apply();
          LOBYTE(result) = IsVisible((RenderTarget *)&this->m_bSlotFlags[9344 * *(_DWORD *)&this->m_bSlotFlags[154135]
                                                                       + 79247
                                                                       + 584 * i]);
          if ( (_BYTE)result )
            (((ScreenEffect *)&this->m_bSlotFlags[9344 * *(_DWORD *)&this->m_bSlotFlags[154135]
                                                                  + 79247
                                                                  + 584 * i]))->ScreenEffect::Apply();
        }
      }
      break;
    case 1:
      result = (*(int ( **)(_DWORD))(**((_DWORD **)&this->m_pSubTab2 + 1) + 4))(*((_DWORD *)&this->m_pSubTab2
                                                                                          + 1));
      break;
    case 2:
      result = (*(int ( **)(void *))(*(_DWORD *)this->m_pSubTab2 + 4))(this->m_pSubTab2);
      break;
    case 3:
      result = (*(int ( **)(void *))(*(_DWORD *)this->m_pSubTab1 + 4))(this->m_pSubTab1);
      break;
    case 4:
      result = (*(int ( **)(LONG))(*(_DWORD *)this->m_roles[5].m_QiVal.m_rect.bottom + 4))(this->m_roles[5].m_QiVal.m_rect.bottom);
      break;
    case 5:
      result = (*(int ( **)(_DWORD))(**((_DWORD **)&this->m_pSubTab2 + 2) + 4))(*((_DWORD *)&this->m_pSubTab2
                                                                                          + 2));
      break;
    case 6:
      result = (*(int ( **)(_DWORD))(**((_DWORD **)&this->m_pSubTab2 + 3) + 4))(*((_DWORD *)&this->m_pSubTab2
                                                                                          + 3));
      break;
    case 7:
      result = (*(int ( **)(_DWORD))(**((_DWORD **)&this->m_pSubTab2 + 4) + 4))(*((_DWORD *)&this->m_pSubTab2
                                                                                          + 4));
      break;
    default:
      return result;
  }
  return result;
}

// 0x004A5A80
int RoleStatePanel::LayoutHandleNav()
{
  int result; // eax
  int v3; // eax

  if ( (byte_189598C & 1) == 0 )
  {
    LOBYTE(byte_189598C) = byte_189598C | 1;
    atexit((void ( *)())sub_4A13E0);
  }
  result = g_nUILayoutFlags;
  if ( g_nUILayoutFlags <= 0 )
  {
    result = *((_DWORD *)&this->m_pSubTab2 + 2);
    if ( *(_BYTE *)(result + 185228) )
    {
      if ( g_Input.KeyInfo[11].PressTime == 1 )
      {
        v3 = this->m_nEquipSlot + 1;
        this->m_nEquipSlot = v3;
        if ( v3 == 5 && !g_bRoleFlag1 )
          this->m_nEquipSlot = 6;
        if ( this->m_nEquipSlot == 6 && !g_bRoleFlag2 )
          this->m_nEquipSlot = 7;
        if ( this->m_nEquipSlot >= 8 )
          this->m_nEquipSlot = 0;
        return (((MainEquipUI *)this))->MainEquipUI::HandleMessage(this->m_nEquipSlot) /* [ROWTABLE] */;
      }
    }
  }
  return result;
}

// 0x004A5B30

// ---- synthesized vtable stubs (unresolved slots) ----
// [VFTABLE-STUB] original: ((void ( *)(UIStatic *, int))p_m_Jing->__vftable->ShowWindow)(p_m_Jing, 1)
static void pal3_vtbl_unk_0(UIStatic *, int);
// [VFTABLE-STUB] original: ((void ( *)(UIStatic *, _DWORD))p_m_Jing->__vftable->ShowWindow)(p_m_Jing, 0)
static void pal3_vtbl_unk_1(UIStatic *, _DWORD);
// [VFTABLE-STUB] original: ((void ( *)(UIStatic *, int))p_m_Name->__vftable->ShowWindow)(p_m_Name, 1)
static void pal3_vtbl_unk_2(UIStatic *, int);
// [VFTABLE-STUB] original: ((void ( *)(UIStatic *, _DWORD))p_m_Name->__vftable->ShowWindow)(p_m_Name, 0)
static void pal3_vtbl_unk_3(UIStatic *, _DWORD);
// [VFTABLE-STUB] original: ((void ( *)(UIStatic *, int))p_m_Head->__vftable->ShowWindow)(p_m_Head, 1)
static void pal3_vtbl_unk_4(UIStatic *, int);
// [VFTABLE-STUB] original: ((void ( *)(UIStatic *, _DWORD))p_m_Head->__vftable->ShowWindow)(p_m_Head, 0)
static void pal3_vtbl_unk_5(UIStatic *, _DWORD);

int RoleStatePanel::UpdateCaptions()
{
  int m_nScanIndex; // eax
  unsigned int v3; // eax
  char m_ppic; // cl
  float *v5; // eax
  int v6; // eax
  __int64 v7; // rax
  int v8; // ebx
  s_RoleState *v9; // ecx
  UIStatic *p_m_Jing; // ecx
  UIStatic *p_m_Name; // ecx
  UIStatic *p_m_Head; // ecx
  int result; // eax
  int v14; // esi
  CUtil *Mode; // eax
  CScreenMode *Instance; // eax
  gbAudioManager *AudioManager; // eax
  gbAudioManager *v18; // esi
  int v19; // [esp-0x8] [ebp-0x28]
  double v20; // [esp-0x4] [ebp-0x24]
  int v21; // [esp+0x4] [ebp-0x1C]
  int v22; // [esp+0x1C] [ebp-0x4]
  int nVal; // [esp+0x28] [ebp+0x8]
  int a3; // [esp+0x2C] [ebp+0xC]

  if ( this->m_bSlotFlags[11] )
  {
    this->m_nScanIndex = 0;
    do
    {
      m_nScanIndex = this->m_nScanIndex;
      if ( this->m_bSlotFlags[m_nScanIndex] )
      {
        v3 = 947 * m_nScanIndex;
        m_ppic = (char)this->m_roles[v3 / 0x3B3].m_JingBar.m_ppic;
        v5 = (float *)((char *)this + 4 * v3);
        if ( !m_ppic )
        {
          sprintf(
            (char *const)&this->m_nScanIndex + 8,
            "%d/%d",
            (int)v5[38976],
            *((_DWORD *)&g_RoleSlotBuf.m_partyActor.m_nAnimFrame + 352 * this->m_nScanIndex));
          SetEnable((UICaption *)&this->m_roles[this->m_nScanIndex].m_JingVal);
        }
        if ( !LOBYTE(this->m_roles[this->m_nScanIndex].m_QiBar.m_ppic) )
        {
          sprintf(
            (char *const)&this->m_nScanIndex + 8,
            "%d/%d",
            (int)*(float *)&this->m_roles[this->m_nScanIndex].m_QiBar.m_pbkInfo,
            *((_DWORD *)&g_RoleSlotBuf.m_partyActor.m_nAnimFrame + 352 * this->m_nScanIndex + 1));
          SetEnable((UICaption *)&this->m_roles[this->m_nScanIndex].m_QiVal);
        }
        if ( !LOBYTE(this->m_roles[this->m_nScanIndex].m_ShenBar.m_ppic) )
        {
          sprintf(
            (char *const)&this->m_nScanIndex + 8,
            "%d/%d",
            (int)*(float *)&this->m_roles[this->m_nScanIndex].m_ShenBar.m_pbkInfo,
            *((_DWORD *)&g_RoleSlotBuf.m_partyActor.m_nAnimFrame + 352 * this->m_nScanIndex + 2));
          SetEnable((UICaption *)&this->m_roles[this->m_nScanIndex].m_ShenVal);
        }
      }
      v6 = this->m_nScanIndex + 1;
      this->m_nScanIndex = v6;
    }
    while ( v6 < 5 );
    v7 = (__int64)g_fGameTimer;
    v8 = (int)v7 / 3600;
    v22 = (int)v7 / 60 % 60;
    v19 = (int)v7 % 60;
    if ( (int)v7 / 3600 < 100 )
      sprintf((char *const)&this->m_nScanIndex + 8, "%02d:%02d:%02d", v8, v22, v19);
    else
      sprintf((char *const)&this->m_nScanIndex + 8, "%03d:%02d:%02d", v8, v22, v19);
    SetEnable((UICaption *)&this->m_bSlotFlags[4191]);
    sprintf((char *const)&this->m_nScanIndex + 8, &dir[20], ((RoleSystem *)&stru_C059A0)->m_nMoveRole);
    SetEnable((UICaption *)&this->m_bSlotFlags[4343]);
  }
  this->RoleStatePanel::LayoutHandleNav();
  switch ( this->m_nEquipSlot )
  {
    case 0:
      (((SceneObj *)this))->SceneObj::Update(nVal, a3) /* [ROWTABLE] */;
      v9 = (s_RoleState *)&this->m_roles[5];
      if ( g_RoleSlotBuf.m_partyActor.m_szTexture[7] )
        ((void ( *)(s_RoleState *, int))v9->m_Headbk.__vftable->ShowWindow)(v9, 1);
      else
        ((void ( *)(s_RoleState *, _DWORD))v9->m_Headbk.__vftable->ShowWindow)(v9, 0);
      p_m_Jing = (UIStatic *)&this->m_roles[5].m_Jing;
      if ( g_RoleSlotBuf.m_partyActor.m_szTexture[8] )
        pal3_vtbl_unk_0(p_m_Jing, 1) /* [VFTABLE-STUB] */;
      else
        pal3_vtbl_unk_1(p_m_Jing, 0) /* [VFTABLE-STUB] */;
      p_m_Name = (UIStatic *)&this->m_roles[5].m_Name;
      if ( g_RoleSlotBuf.m_partyActor.m_szTexture[9] )
        pal3_vtbl_unk_2(p_m_Name, 1) /* [VFTABLE-STUB] */;
      else
        pal3_vtbl_unk_3(p_m_Name, 0) /* [VFTABLE-STUB] */;
      p_m_Head = (UIStatic *)&this->m_roles[5].m_Head;
      if ( g_RoleSlotBuf.m_partyActor.m_szTexture[10] )
        pal3_vtbl_unk_4(p_m_Head, 1) /* [VFTABLE-STUB] */;
      else
        pal3_vtbl_unk_5(p_m_Head, 0) /* [VFTABLE-STUB] */;
      result = 1;
      break;
    case 1:
      (*(void ( **)(_DWORD, int, int))(**((_DWORD **)&this->m_pSubTab2 + 1) + 8))(
        *((_DWORD *)&this->m_pSubTab2 + 1),
        nVal,
        a3);
      result = 1;
      break;
    case 2:
      (*(void ( **)(void *, int, int))(*(_DWORD *)this->m_pSubTab2 + 8))(this->m_pSubTab2, nVal, a3);
      result = 1;
      break;
    case 3:
      (*(void ( **)(void *, int, int))(*(_DWORD *)this->m_pSubTab1 + 8))(this->m_pSubTab1, nVal, a3);
      result = 1;
      break;
    case 4:
      (*(void ( **)(LONG, int, int))(*(_DWORD *)this->m_roles[5].m_QiVal.m_rect.bottom + 8))(
        this->m_roles[5].m_QiVal.m_rect.bottom,
        nVal,
        a3);
      result = 1;
      break;
    case 5:
      (*(void ( **)(_DWORD, int, int))(**((_DWORD **)&this->m_pSubTab2 + 2) + 8))(
        *((_DWORD *)&this->m_pSubTab2 + 2),
        nVal,
        a3);
      result = 1;
      break;
    case 6:
      (*(void ( **)(_DWORD, int, int))(**((_DWORD **)&this->m_pSubTab2 + 3) + 8))(
        *((_DWORD *)&this->m_pSubTab2 + 3),
        nVal,
        a3);
      result = 1;
      break;
    case 7:
      (*(void ( **)(_DWORD, int, int))(**((_DWORD **)&this->m_pSubTab2 + 4) + 8))(
        *((_DWORD *)&this->m_pSubTab2 + 4),
        nVal,
        a3);
      v14 = *((_DWORD *)&this->m_pSubTab2 + 4);
      if ( !*(_DWORD *)(v14 + 286376) )
        goto LABEL_43;
      LODWORD(v20) = *(_DWORD *)(v14 + 286364);
      (((UITitle_JDHY *)v14))->UITitle_JDHY::SaveData(v20, v21);
      result = 1;
      break;
    case 8:
      (((CGameData *)&g_gamefrm))->CGameData::Load((CUtil *)0xD);
      result = 1;
      break;
    case 9:
      Mode = (CUtil *)(((CGameData *)&g_gamefrm))->CGameData::GetMode();
      (((CGameData *)&g_gamefrm))->CGameData::Load(Mode);
      result = 1;
      break;
    case 0xA:
      if ( (g_dwGameFlags & 4) != 0 )
      {
        Instance = (CScreenMode *)CScreenMode::GetInstance();
        AudioManager = (gbAudioManager *)(((CScreenMode *)Instance))->CScreenMode::GetAudioManager();
        v18 = (gbAudioManager *)AudioManager;
        if ( AudioManager )
        {
          (((gbAudioManager *)AudioManager))->gbAudioManager::DetachAll3D();
          (((gbAudioManager *)v18))->gbAudioManager::StopSoundStream(0);
          (((gbAudioManager *)v18))->gbAudioManager::StopSoundStream(2);
          (((gbAudioManager *)v18))->gbAudioManager::StopSoundStream(1);
        }
      }
      (((CGameData *)&g_gamefrm))->CGameData::Load((CUtil *)4);
      LOBYTE(gfxMgr->pSceneGraph->pnodebuf[713]) = 0;
      g_nMiniGameParam = 0;
      g_nMiniGameState = 0;
      g_bSceneLoaded_0 = 1;
      goto LABEL_43;
    default:
LABEL_43:
      result = 1;
      break;
  }
  return result;
}

static void pal3_vtbl_unk_0(UIStatic *, int)
{
    
}
static void pal3_vtbl_unk_1(UIStatic *, _DWORD)
{
    
}
static void pal3_vtbl_unk_2(UIStatic *, int)
{
    
}
static void pal3_vtbl_unk_3(UIStatic *, _DWORD)
{
    
}
static void pal3_vtbl_unk_4(UIStatic *, int)
{
    
}
static void pal3_vtbl_unk_5(UIStatic *, _DWORD)
{
    
}

