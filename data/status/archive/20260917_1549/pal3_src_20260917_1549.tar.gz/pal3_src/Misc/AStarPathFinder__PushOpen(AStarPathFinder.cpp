#include "pal3/ida_defs.h"
#include "globals.h"
#include "pal3/pal3_constants.h"
#include "Misc/AStarPathFinder.h"

// 0x00401560
int AStarPathFinder::PushOpen(AStarPathFinder::NODE *)(AStarPathFinder::NODE *pNode)
{
  AStarPathFinder::NODE *OPEN; // edx
  AStarPathFinder::NODE *i; // ecx
  int result; // eax

  OPEN = this->OPEN;
  for ( i = OPEN->next; i; i = i->next )
  {
    if ( i->f >= (double)pNode->f )
      break;
    OPEN = i;
  }
  result = (int)OPEN->next;
  pNode->next = (AStarPathFinder::NODE *)result;
  OPEN->next = pNode;
  return result;
}
