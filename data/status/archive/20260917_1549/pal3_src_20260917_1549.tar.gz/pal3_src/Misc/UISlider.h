#pragma once
// Auto-generated: UISlider
#include "pal3/ida_types.h"

class UISlider {
public:
    _BYTE _tail_000[4]; // +0x0
    // total size: 0x4 (4)

    // Scalar-wrapper: ctors for IDA (Cls)int casts (no init code)
    UISlider() {}
    UISlider(int v) { *(int*)this = v; }

};
