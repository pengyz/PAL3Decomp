#pragma once
// Auto-generated: SceHeader
#include "pal3/ida_types.h"

class SceHeader {
public:
    BYTE flag[4]; // +0x0
    BYTE version; // +0x4
    char blocknum; // +0x5
    char _tail_006[1]; // +0x6
    // total size: 0x7 (7)

};
