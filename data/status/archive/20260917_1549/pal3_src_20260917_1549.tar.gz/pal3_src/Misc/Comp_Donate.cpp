#include "pal3/ida_defs.h"
#include "globals.h"
#include "pal3/pal3_constants.h"
#include "Misc/Comp_Donate.h"

// 0x0043A740
void Comp_Donate::Reset()
{
  g_fDonateValue = 12.0;
}
