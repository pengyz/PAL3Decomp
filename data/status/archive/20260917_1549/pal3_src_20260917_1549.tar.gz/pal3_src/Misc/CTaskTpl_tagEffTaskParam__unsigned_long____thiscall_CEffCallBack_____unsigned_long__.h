#include "Misc/tagEffTaskParam.h"
#include "Misc/CTaskTpl.h"
#pragma once
// Auto-generated: CTaskTpl<tagEffTaskParam, unsigned long (__thiscall CEffCallBack::*)(unsigned long)>
#include "pal3/ida_types.h"

class CEffCallBack;
typedef unsigned long (CEffCallBack::*_CEffCallBack_cb)(unsigned long);
template<>
class CTaskTpl<tagEffTaskParam, _CEffCallBack_cb> {
public:
    char _tail_000[36]; // +0x0
    // total size: 0x24 (36)

};
