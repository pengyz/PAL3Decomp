#pragma once
// Auto-generated: RenderTargetNode
#include "pal3/ida_types.h"

class RenderTargetNode {
public:
    _BYTE _tail_000[96]; // +0x0
    // total size: 0x60 (96)

    RenderTargetNode(); // 0x004BD830
};
