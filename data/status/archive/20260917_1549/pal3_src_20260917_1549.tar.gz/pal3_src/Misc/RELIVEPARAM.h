#pragma once
// Auto-generated: RELIVEPARAM
#include "pal3/ida_types.h"

class RELIVEPARAM {
public:
    float AlphaSpeed; // +0x0
    float fTimeCounter; // +0x4
    int nWaitSecond; // +0x8
    int nState; // +0xC
    // total size: 0x10 (16)

};
