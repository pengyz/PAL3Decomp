#pragma once
// Auto-generated: PlayerAtts
#include "pal3/ida_types.h"

class PlayerAtts {
public:
    char _gap_000[192]; // +0x0
    int m_nTodo_0C0; // +0xC0
    int m_nTodo_0C4; // +0xC4
    char _gap_0C8[4]; // +0xC8
    int m_nTodo_0CC; // +0xCC
    // total size: 0xD0 (208)

};
