#include "Misc/UIFrameWnd.h"
#pragma once
// Auto-generated: UITitle_YXXX
#include "pal3/ida_types.h"

#include "Misc/UIButton.h"
#include "Misc/UIStatic.h"

class UITitle_YXXX : public UIFrameWnd {
public:
    char _gap_000[72]; // +0x0
    tagRECT rc; // +0x48
    UIStatic m_OutFrameT; // +0x58
    char _gap_0F0[8]; // +0xF0
    UIStatic m_OutFrameR; // +0xF8
    char _gap_190[8]; // +0x190
    UIStatic m_OutFrameL; // +0x198
    char _gap_230[8]; // +0x230
    UIStatic m_OutFrameB; // +0x238
    char _gap_2D0[8]; // +0x2D0
    UIStatic m_background; // +0x2D8
    char _gap_370[8]; // +0x370
    UIStatic m_title; // +0x378
    char _gap_410[8]; // +0x410
    UIButton m_exit; // +0x418
    UIButton m_ZZRY; // +0x570
    UIButton m_XGWZ; // +0x6C8
    UIStatic m_WordBk; // +0x820
    char _tail_8B8[240]; // +0x8B8
    // total size: 0x9A8 (2472)

    virtual int Update(int nVal, int nVal2); // 0x0047E3E0
    int _scalar_dtor(void *Block, char); // 0x0047DD70
    virtual int HandleMsgDLL(HINSTANCE hinstDLL, DWORD fdwReason, LPVOID lpvReserved); // 0x0047E4E0
    int LayoutWidgets(); // 0x00459970
    void Create(); // 0x0047DCA0
    ~UITitle_YXXX(); // 0x0047DD90
    void Init(); // 0x0047DE40
    int * CreateTitle(char *pszBuf, unsigned int dwVal, int nVal); // 0x004AF770
};
