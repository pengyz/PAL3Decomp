#include "Misc/SceneMap.h"
#pragma once
// Auto-generated: SceneMapObj
#include "pal3/ida_types.h"

class Scene;

class SceneMapObj : public SceneMap {
public:
    char _gap_000[16]; // +0x0
    Scene * m_scene; // +0x10
    // total size: 0x14 (20)

};
