#pragma once
// Auto-generated: ARC_Reoccupy
#include "pal3/ida_types.h"

#include "pal3/pal3_stl.h"

class ARC_Reoccupy {
public:
    vector<unsigned int> m_id; // +0x0
    char _tail_004[12]; // +0x4
    // total size: 0x10 (16)

};
