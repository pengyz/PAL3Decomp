#include "UI/UIWnd.h"
#pragma once
// Auto-generated: UIFrameWnd
#include "pal3/ida_types.h"

#include "gbengine/gbTexture.h"
#include "gbengine/gbVFileSystem.h"

class UIWnd;

class UIFrameWnd : public UIWnd {
public:
    char _gap_000[68]; // +0x0
    gbTexture * m_pbktex; // +0x44
    // total size: 0x48 (72)

    virtual ~UIFrameWnd() {}

    virtual void RenderWithTexture(); // 0x00442E90
    virtual BOOL Update_2ff0(int nVal, int nVal2); // 0x00442FF0
    virtual void Destroy(); // 0x00442420
    void * _scalar_dtor(UIWnd *Block, char pData); // 0x00442E60
    virtual void Render(); // 0x00443950
    virtual BOOL UpdateIfVisible(int nVal, int nVal2); // 0x00443970
    virtual void Destroy_38f0(); // 0x004438F0
    virtual gbVFileSystem * LoadFrameResources(); // 0x004435A0
    UIFrameWnd(); // 0x0043BB70
    virtual BOOL Update_bbc0(int nVal, int nVal2); // 0x0043BBC0
    UIFrameWnd * _sdtor(char pData); // 0x00442370
    void _UIFrameWnd(); // 0x00442390
    gbVFileSystem * SetTextureByID(int nTexID); // 0x00442540
    void SetTextureByName(LPCSTR lpTexName, char bCalcUV); // 0x004425D0
    int CalculateLayout(); // 0x00442890
    virtual BOOL Update(int nVal, int nVal2); // 0x00442AD0
    void SetPosition(int nVal, int nVal2); // 0x00442C60
    int SetFrameParam(int nVal); // 0x00442C80
    UIFrameWnd * _sdtor_8(char a2); // 0x00442D20
    void _UIFrameWnd_ovl_00442d40(); // 0x00442D40
    void ctor(); // 0x00442E80
    void DestroyCallingCtor(); // 0x004431D0
    void _dtor_thunk(); // 0x004433C0
    void * InitSharedPanel(); // 0x004434C0
    void _UIFrameWnd_ovl_00443550(); // 0x00443550
    void _UIFrameWnd_Full(); // 0x00444AC0
    virtual int RenderAll(); // 0x00444AD0
    virtual BOOL ProcessInput(int nVal, int nVal2); // 0x00444D30
    BOOL IsOnScreen(int nVal, int nVal2); // 0x00450560
    int OnPaintUpdate(); // 0x0045A220
    BOOL ProcessTimer(BOOL bEnable, BOOL bReset, int nInterval, int nParam); // 0x00478880
    bool RollProbability(float fProb); // 0x0048CFB0
};
