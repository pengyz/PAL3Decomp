#include "Misc/tagEffTaskParam.h"
#include "Misc/CTaskTpl.h"
#pragma once
// Auto-generated: CTaskTpl<tagEffTaskParam, unsigned long (__thiscall CEffTime::*)(unsigned long)>
#include "pal3/ida_types.h"

class CEffTime;
typedef unsigned long (CEffTime::*_CEffTime_cb)(unsigned long);
template<>
class CTaskTpl<tagEffTaskParam, _CEffTime_cb> {
public:
    char _tail_000[36]; // +0x0
    // total size: 0x24 (36)

};
