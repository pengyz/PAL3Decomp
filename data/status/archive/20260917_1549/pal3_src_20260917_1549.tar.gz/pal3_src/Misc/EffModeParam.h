#pragma once
// Auto-generated: EffModeParam
#include "pal3/ida_types.h"

#include "Misc/eSkyEffPos.h"

class EffModeParam {
public:
    int nSide; // +0x0
    eSkyEffPos ePos; // +0x4
    char _gap_005[3]; // +0x5
    BYTE bAreaRand; // +0x8
    char _tail_009[3]; // +0x9
    // total size: 0xC (12)

};
