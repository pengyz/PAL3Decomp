#pragma once
// Auto-generated: tagCCBStageData
#include "pal3/ida_types.h"

class tagCCBStageData {
public:
    int m_nEffParamBase0; // +0x0
    char _gap_004[16]; // +0x4
    int m_nEffParam14; // +0x14
    char _gap_018[4]; // +0x18
    int m_nEffParam1C; // +0x1C
    int m_nEffTypeID; // +0x20
    char _gap_024[4]; // +0x24
    int m_nEffTypeCode; // +0x28
    // total size: 0x2C (44)

};
