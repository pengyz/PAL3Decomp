#pragma once
// Auto-generated: _Ctypevec
#include "pal3/ida_types.h"

class _Ctypevec {
public:
    DWORD _Hand; // +0x0
    UINT _Page; // +0x4
    short * _Table; // +0x8
    int _Delfl; // +0xC
    // total size: 0x10 (16)

};
