#pragma once
// Auto-generated: m_RoleState
#include "pal3/ida_types.h"

#include "Misc/UIButton.h"
#include "Misc/UIProgressBar.h"
#include "Misc/UIStatic.h"

class m_RoleState {
public:
    UIStatic m_Headbk; // +0x0
    UIButton m_Head; // +0x98
    UIStatic m_Name; // +0x1F0
    UIStatic m_Jing; // +0x288
    UIProgressBar m_JingBar; // +0x320
    UIStatic m_JingVal; // +0x414
    UIStatic m_Shen; // +0x4AC
    UIProgressBar m_ShenBar; // +0x544
    UIStatic m_ShenVal; // +0x638
    UIStatic m_Qi; // +0x6D0
    UIProgressBar m_QiBar; // +0x768
    UIStatic m_QiVal; // +0x85C
    UIStatic m_AttFrameHead; // +0x8F4
    UIStatic m_F; // +0x98C
    UIStatic m_W; // +0xA24
    UIStatic m_S; // +0xABC
    UIStatic m_Y; // +0xB54
    UIStatic m_Exp; // +0xBEC
    UIStatic m_RoleAtt[5]; // +0xC84
    UIStatic m_NeedArrow; // +0xF7C
    tagRECT m_NeedRc; // +0x1014
    // total size: 0x1024 (4132)

};
