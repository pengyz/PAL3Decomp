#pragma once
// Auto-generated: CSEHException
#include "pal3/ida_types.h"

class CSEHException {
public:
    DWORD m_dwOpts; // +0x0
    char m_szExceptionString[260]; // +0x4
    // total size: 0x108 (264)

};
