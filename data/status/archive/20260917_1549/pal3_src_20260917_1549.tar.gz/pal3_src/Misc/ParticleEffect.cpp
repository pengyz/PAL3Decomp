#include "pal3/ida_defs.h"
#include "globals.h"
#include "pal3/pal3_constants.h"
#include "Misc/ParticleEffect.h"
#include "Misc/String.h"
#include "Render/TextureLib.h"

// 0x0053F960
bool ParticleEffect::LoadFromFile(char *filename)
{
  gbVFile *v2; // eax
  gbVFile *v3; // ebp
  size_t FileSize; // esi
  char *v5; // eax
  unsigned int v6; // ecx
  const void *v7; // esi
  TextureLib *v8; // edi
  int v9; // eax
  int v10; // esi
  char *v11; // eax
  char *v12; // ecx
  char *v13; // eax
  char *v14; // esi
  bool result; // al
  size_t v16; // eax
  size_t v17; // esi
  char *v18; // edi
  TextureLib *v19; // edi
  int v20; // eax
  int v21; // esi
  char *v22; // eax
  char *v23; // ecx
  char *v24; // eax
  char *v25; // esi
  char *v26; // [esp+0x8] [ebp-0x28]
  CHAR String2[4]; // [esp+0x20] [ebp-0x10] BYREF
  TextureLib *v28; // [esp+0x24] [ebp-0xC]
  char *String; // [esp+0x28] [ebp-0x8]
  size_t v30; // [esp+0x2C] [ebp-0x4]
  void *Block; // [esp+0x34] [ebp+0x4]
  char *Blocka; // [esp+0x34] [ebp+0x4]

  v28 = (TextureLib *)this;
  memset(String2, 0, sizeof(String2));
  strncpy(String2, &filename[strlen(filename) - 3], 3u);
  if ( lstrcmpA(lpString1, String2) )
    return 0;
  v2 = (((gbVFileSystem *)g_pVFileSys))->gbVFileSystem::OpenFile(filename, 0x201u);
  v3 = (gbVFile *)v2;
  if ( !v2 )
    return 0;
  if ( *(_DWORD *)&v2[304] )
  {
    FileSize = (((gbVFileSystem *)g_pVFileSys))->gbVFileSystem::GetFileSize(v2);
    v30 = FileSize;
    Block = (void *)malloc(FileSize);
    v5 = (char *)malloc(FileSize);
    v6 = FileSize;
    v7 = *(const void **)&v3[304];
    String = (char *)v5;
    qmemcpy(Block, v7, v6);
    qmemcpy(v5, *(const void **)&v3[304], v6);
    (((gbVFileSystem *)g_pVFileSys))->gbVFileSystem::CloseFile(v3);
    v8 = (TextureLib *)v28;
    v9 = (((TextureLib *)v28))->TextureLib::ParseConfigFile(String);
    v10 = v9;
    if ( v9 )
    {
      v11 = (char *)operator new(1088 * v9);
      if ( v11 )
      {
        if ( v10 - 1 >= 0 )
        {
          v12 = (char *)(v11 + 1060);
          do
          {
            *((_DWORD *)v12 - 3) = 0;
            *((_DWORD *)v12 - 2) = 0;
            *((_DWORD *)v12 - 1) = 0;
            *(_DWORD *)v12 = 0;
            *((_DWORD *)v12 + 1) = 0;
            *((_DWORD *)v12 + 2) = 0;
            *((_DWORD *)v12 + 3) = 0;
            *((_DWORD *)v12 + 4) = 0;
            *(v12 - 1060) = 0;
            *(v12 - 548) = 0;
            *((_DWORD *)v12 - 8) = 256;
            *((_DWORD *)v12 - 9) = 256;
            *((_DWORD *)v12 - 6) = 0;
            *((_DWORD *)v12 - 7) = 0;
            *((_DWORD *)v12 - 5) = 256;
            *((_DWORD *)v12 + 5) = 0;
            v12[24] = 0;
            v12 += 1088;
            --v10;
          }
          while ( v10 );
        }
      }
      else
      {
        v11 = 0;
      }
      v8->m_pTexture = v11;
      v13 = strtok((char *)Block, Delimiter);
      if ( lstrcmpA(v13, "#endfile") )
      {
        do
        {
          v14 = strtok(0, Delimiter);
          v8->m_pResultTex->AddEntryFromConfig(v8, v14, Delimiter);
        }
        while ( lstrcmpA(v14, "#endfile") );
      }
      free(Block);
      free(String);
      result = 1;
      LOBYTE(v8[1].m_pResultTex) = 1;
      return result;
    }
    return 0;
  }
  v16 = (((gbVFileSystem *)g_pVFileSys))->gbVFileSystem::GetFileSize(v2);
  v17 = v16;
  if ( v16 == -1 || !v16 )
  {
    (((gbVFileSystem *)g_pVFileSys))->gbVFileSystem::CloseFile(v3);
    return 0;
  }
  v18 = (char *)operator new(v16);
  String = (char *)v18;
  Blocka = (char *)operator new(v17);
  (((gbVFileSystem *)g_pVFileSys))->gbVFileSystem::Read();
  (((gbVFileSystem *)g_pVFileSys))->gbVFileSystem::CloseFile(v3);
  qmemcpy(Blocka, v18, v17);
  v19 = (TextureLib *)v28;
  v20 = (((TextureLib *)v28))->TextureLib::ParseConfigFile(Blocka);
  v21 = v20;
  if ( !v20 )
    return 0;
  v22 = (char *)operator new(1088 * v20);
  if ( v22 )
  {
    if ( v21 - 1 >= 0 )
    {
      v23 = (char *)(v22 + 1060);
      do
      {
        *((_DWORD *)v23 - 3) = 0;
        *((_DWORD *)v23 - 2) = 0;
        *((_DWORD *)v23 - 1) = 0;
        *(_DWORD *)v23 = 0;
        *((_DWORD *)v23 + 1) = 0;
        *((_DWORD *)v23 + 2) = 0;
        *((_DWORD *)v23 + 3) = 0;
        *((_DWORD *)v23 + 4) = 0;
        *(v23 - 1060) = 0;
        *(v23 - 548) = 0;
        *((_DWORD *)v23 - 8) = 256;
        *((_DWORD *)v23 - 9) = 256;
        *((_DWORD *)v23 - 6) = 0;
        *((_DWORD *)v23 - 7) = 0;
        *((_DWORD *)v23 - 5) = 256;
        *((_DWORD *)v23 + 5) = 0;
        v23[24] = 0;
        v23 += 1088;
        --v21;
      }
      while ( v21 );
    }
  }
  else
  {
    v22 = 0;
  }
  v26 = (char *)String;
  v19->m_pTexture = v22;
  v24 = strtok(v26, Delimiter);
  if ( lstrcmpA(v24, "#endfile") )
  {
    do
    {
      v25 = strtok(0, Delimiter);
      v19->m_pResultTex->AddEntryFromConfig(v19, v25, Delimiter);
    }
    while ( lstrcmpA(v25, "#endfile") );
  }
  operator delete(String);
  operator delete(Blocka);
  result = 1;
  LOBYTE(v28[1].m_pResultTex) = 1;
  return result;
}
