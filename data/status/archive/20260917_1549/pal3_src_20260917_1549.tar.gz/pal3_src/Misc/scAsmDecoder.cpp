#include "pal3/ida_defs.h"
#include "globals.h"
#include "pal3/pal3_constants.h"
#include "Misc/scAsmDecoder.h"
#include "Role/Actor.h"
#include "Data/CGameData.h"
#include "Scene/CameraCtrl.h"
#include "Scene/CameraSystem.h"
#include "Role/Role.h"
#include "Misc/RoleAtt.h"
#include "Role/RoleSystem.h"
#include "Scene/SceneMgr.h"
#include "Script/ScriptSystem.h"
#include "UI/UIWnd.h"
#include "Misc/_Console.h"
#include "Misc/scAsmDecoder.h"
#include "free_functions.h"

// Forward declarations for unnamed functions

// 0x0040E5F0
int scAsmDecoder::Execute(int nVal, char pData)
{
  int v3; // ecx
  unsigned int v4; // eax
  scAsmDecoder *v5; // ecx
  int v6; // eax
  ScriptSystem *v7; // ecx

  v3 = ((RoleSystem *)&stru_C10DF0)->m_teamSlotOverlay.m_teamSlots[154];
  g_fEffectTimer = 10.0;
  if ( pData )
  {
    v4 = 8704 * nVal;
    *(float *)((char *)&((RoleSystem *)&stru_C059A0)->m_fMoveRole + v4) = *(float *)(((RoleSystem *)&stru_C10DF0)->m_teamSlotOverlay.m_teamSlots[154] + 20);
    *(float *)((char *)&((RoleSystem *)&stru_C059A0)->m_fMoveParamY + v4) = *(float *)(v3 + 24);
    *(float *)((char *)&((RoleSystem *)&stru_C059A0)->m_fMoveParamZ + v4) = *(float *)(v3 + 28);
    *(float *)((char *)&((RoleSystem *)&stru_C059A0)->m_fMoveParamZ + v4 + 4) = *(float *)(v3 + 32);
    *(float *)((char *)&((RoleSystem *)&stru_C059A0)->m_fMoveParamZ + v4 + 8) = *(float *)(v3 + 36);
    *(float *)((char *)&((RoleSystem *)&stru_C059A0)->m_fMoveParamZ + v4 + 12) = *(float *)(v3 + 40);
    *(float *)((char *)&((RoleSystem *)&stru_C059A0)->m_fCachePosZ + v4) = *(float *)(v3 + 4);
    *(float *)((char *)&((RoleSystem *)&stru_C059A0)->m_fMoveTargetX + v4) = *(float *)(v3 + 8);
    *(int *)((char *)&((RoleSystem *)&stru_C059A0)->m_fMoveTargetY + v4) = *(_DWORD *)(v3 + 12);
    *(int *)((char *)&((RoleSystem *)&stru_C059A0)->_embed_UIWnd_624.m_benable + v4) = *(_DWORD *)(v3 + 160);
    *(int *)((char *)&((RoleSystem *)&stru_C059A0)->_embed_UIWnd_624.m_bfocus + v4) = *(_DWORD *)(v3 + 164);
    *(_DWORD *)((char *)&((RoleSystem *)&stru_C059A0)->_embed_UIWnd_624 + v4 + 68) = *(_DWORD *)(v3 + 168);
    *(int *)((char *)&dword_C08154 + v4) = *(_DWORD *)(v3 + 8692);
    *(int *)((char *)&dword_C08158 + v4) = *(_DWORD *)(v3 + 8696);
    *(int *)((char *)&dword_C0815C + v4) = *(_DWORD *)(v3 + 8700);
    *(int *)((char *)&((RoleSystem *)&stru_C059A0)->_embed_UIWnd_624.m_childs.m_needscriptdel + v4) = *(_DWORD *)(v3 + 148);
    *(int *)((char *)&((RoleSystem *)&stru_C059A0)->_embed_UIWnd_624.m_bcreateok + v4) = *(_DWORD *)(v3 + 152);
    *(int *)((char *)&((RoleSystem *)&stru_C059A0)->_embed_UIWnd_624.m_bvisible + v4) = *(_DWORD *)(v3 + 156);
    *(int *)((char *)&dword_C08150 + v4) = *(_DWORD *)(v3 + 8688);
    ((RoleSystem *)&stru_C059A0)->m_teamSlotOverlay.m_teamSlots[v4 / 4 + 104] = *(_DWORD *)(v3 + 628);
  }
  ((RoleSystem *)&stru_C059A0)->m_teamSlotOverlay.m_teamSlots[2176 * (_DWORD)g_SceneMgr.m_nCurrentRoleSlot + 105] = 0;
  ((RoleSystem *)&stru_C059A0)->m_teamSlotOverlay.m_teamSlots[2176 * nVal + 105] = 1;
  (((RoleSystem *)(&((RoleSystem *)&stru_C059A0)->m_fCachePosY + 2176 * nVal)))->RoleSystem::Notify();
  (((CameraSystem *)(&((RoleSystem *)&stru_C059A0)->m_fCachePosY + 2176 * nVal)))->CameraSystem::BindToRoleSlot();
  g_SceneMgr.m_nCurrentRoleSlot = (scAsmDecoder *)nVal;
  if ( *((_DWORD *)&g_pCameraCtrl->m_nextYAW + 1) )
    (((_Console *)g_pCameraCtrl))->_Console::SetActive((int)(&((RoleSystem *)&stru_C059A0)->m_fCachePosY + 2176 * nVal));
  if ( nVal == 1 && g_RoleSystemMain.m_nMoveSubMode == 10 )
  {
    (((ScriptSystem *)&g_RoleSystemMain))->ScriptSystem::UpdatePositions();
    g_fScriptTimeAccum = fDeltaTime;
  }
  if ( (((CGameData *)&g_gamefrm))->CGameData::SetMode(0) )
    UITitle_BBTY_SetRemarkTextures((int)g_SceneMgr.m_nCurrentRoleSlot);
  v5 = g_SceneMgr.m_nCurrentRoleSlot;
  if ( g_SceneMgr.m_nCurrentRoleSlot == (scAsmDecoder *)2 )
  {
    if ( _strcmpi(&((RoleSystem *)&stru_C0A360)->m_nAnimState, dword_586194) )
    {
      (((Actor *)&((RoleSystem *)&stru_C0A360)->m_partyActor.m_Actor))->Actor::sub_536D20(dword_586194, 0);
      strcpy(&((RoleSystem *)&stru_C0A360)->m_nAnimState, dword_586194);
      ((RoleSystem *)&stru_C0A360)->RoleSystem::UpdateTransform();
    }
    v5 = g_SceneMgr.m_nCurrentRoleSlot;
  }
  v6 = 0;
  v7 = (ScriptSystem *)(&g_RoleSlotBuf.m_partyActor.m_Actor + 352 * (_DWORD)v5 + 1);
  while ( !*((_BYTE *)&v7->m_nSlotID + v6) )
  {
    if ( ++v6 > 4 )
      return (((ScriptSystem *)v7))->ScriptSystem::RunEvent(31, 0);
  }
  return (((ScriptSystem *)v7))->ScriptSystem::RunEvent(v6, 1);
}
