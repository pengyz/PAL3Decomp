#pragma once
// Auto-generated: NavigationInfo
#include "pal3/ida_types.h"

#include "Misc/NavFaceLayer.h"
#include "Misc/NavTileLayer.h"

class NavigationInfo {
public:
    int m_numlayer; // +0x0
    NavTileLayer m_tilelayer[2]; // +0x4
    NavFaceLayer m_facelayer[2]; // +0x14C
    // total size: 0x16C (364)

};
