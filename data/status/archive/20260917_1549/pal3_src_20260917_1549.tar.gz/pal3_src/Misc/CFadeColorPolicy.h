#include "Misc/CPolicy.h"
#pragma once
// Auto-generated: CFadeColorPolicy
#include "pal3/ida_types.h"

#include "gbengine/gbengine_types.h"

class CFadeColorPolicy : public CPolicy {
public:
    char _gap_000[12]; // +0x0
    gbVec3D _vBeginColor; // +0xC
    gbVec3D _vEndColor; // +0x18
    // total size: 0x24 (36)

};
