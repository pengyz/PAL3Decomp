#pragma once
// Auto-generated: tagPlayerSet
#include "pal3/ida_types.h"

#include "Misc/tagCmdData.h"

class tagPlayerSet {
public:
    tagCmdData LastRoleCmd; // +0x0
    int nMagicDefaultPage; // +0x2C
    int nItemDefaultPage; // +0x30
    // total size: 0x34 (52)

};
