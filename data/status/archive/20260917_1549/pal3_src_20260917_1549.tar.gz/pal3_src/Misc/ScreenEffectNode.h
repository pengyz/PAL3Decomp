#include "Misc/PAL3VisNode.h"
#pragma once
// Auto-generated: ScreenEffectNode
#include "pal3/ida_types.h"

class ScreenEffectNode : public PAL3VisNode {
public:
    char _tail_000[220]; // +0x0
    // total size: 0xDC (220)

    ScreenEffectNode(); // 0x004B7C30
    ~ScreenEffectNode(); // 0x004B7CE0
};
