#include "Misc/CTaskTpl_tagEffTaskParam_CEffCallBack.h"
#include "Misc/CEffObj.h"
#pragma once
// Auto-generated: CEffCallBack
#include "pal3/ida_types.h"

class CEffCallBack : public CEffObj, public CTaskTpl_tagEffTaskParam_CEffCallBack {
public:
    char _gap_000[48]; // +0x0
    float m_fStartX; // +0x30
    float m_fStartY; // +0x34
    float m_fStartZ; // +0x38
    UINT m_dwRunningID; // +0x3C
    // total size: 0x40 (64)

};
