#pragma once
// Auto-generated: tagRoleSlot
#include "pal3/ida_types.h"

class tagRoleSlot {
public:
    WORD nRoleID; // +0x0
    char _tail_002[894]; // +0x2
    // total size: 0x380 (896)

};
