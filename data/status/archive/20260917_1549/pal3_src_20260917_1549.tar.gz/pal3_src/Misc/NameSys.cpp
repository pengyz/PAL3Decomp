#include "pal3/ida_defs.h"
#include "globals.h"
#include "pal3/pal3_constants.h"
#include "Misc/NameSys.h"
#include "free_functions.h"

// Forward declarations for unnamed functions

// 0x0043A770
NameSys * NameSys::GetSys()
{
  int v0; // ecx
  int v1; // esi

  v1 = v0;
  sub_445AA0();
  sub_445EA0();
  *(_DWORD *)(v1 + 96) = 0;
  *(_DWORD *)(v1 + 196) = 0;
  *(_BYTE *)(v1 + 204) = 1;
  memset((void *)(v1 + 212), 0, 0x80u);
  *(_DWORD *)(v1 + 76) = 1065353216;
  *(_DWORD *)(v1 + 72) = 1065353216;
  *(_DWORD *)(v1 + 208) = 1;
  return (NameSys *)v1;
}
