#include "pal3/ida_defs.h"
#include "globals.h"
#include "pal3/pal3_constants.h"
#include "Misc/ScriptPoolPage.h"
#include "GameBase/InputSystem.h"
#include "Misc/_Console.h"
#include "free_functions.h"

// 0x0041D100
int ScriptPoolPage::ScriptPoolPage_Manage(int nVal)
{
  int result; // eax

  switch ( nVal )
  {
    case 0:
      *(_DWORD *)this->alloc_map = 0;
      this->free_paras_at_start = 1104150528;
      *(_DWORD *)&this->alloc_blocks[224] = 0;
      *(_DWORD *)&this->alloc_blocks[228] = 0;
      *(_DWORD *)&this->alloc_blocks[232] = 0;
      *(_DWORD *)&this->alloc_blocks[212] = 1150222336;
      *(_DWORD *)&this->alloc_blocks[200] = -1083490798;
      *(_DWORD *)&this->alloc_blocks[196] = -1090015724;
      break;
    case 1:
      *(_DWORD *)&this->alloc_blocks[224] = 0;
      *(_DWORD *)&this->alloc_blocks[228] = 0;
      *(_DWORD *)&this->alloc_blocks[232] = 0;
      *(_DWORD *)this->alloc_map = 0;
      this->free_paras_at_start = 1103128166;
      *(_DWORD *)&this->alloc_blocks[212] = 1143734272;
      *(_DWORD *)&this->alloc_blocks[200] = 1058309259;
      goto LABEL_6;
    case 2:
      *(_DWORD *)&this->alloc_blocks[224] = 0;
      *(_DWORD *)&this->alloc_blocks[228] = 0;
      *(_DWORD *)&this->alloc_blocks[232] = 0;
      *(_DWORD *)this->alloc_map = 0;
      this->free_paras_at_start = 1103128166;
      *(_DWORD *)&this->alloc_blocks[212] = 1143734272;
      *(_DWORD *)&this->alloc_blocks[200] = -1089174389;
      goto LABEL_6;
    case 3:
      *(_DWORD *)&this->alloc_blocks[224] = 0;
      *(_DWORD *)&this->alloc_blocks[228] = 0;
      *(_DWORD *)&this->alloc_blocks[232] = 0;
      *(_DWORD *)this->alloc_map = 0;
      this->free_paras_at_start = 1103128166;
      *(_DWORD *)&this->alloc_blocks[212] = 1143734272;
      *(_DWORD *)&this->alloc_blocks[200] = 0;
LABEL_6:
      *(_DWORD *)&this->alloc_blocks[196] = -1095887749;
      break;
    default:
      break;
  }
  *(_DWORD *)&this->alloc_blocks[204] = 0;
  ScriptPoolPage_Alloc((_Console *)this);
  InputSystem::ProcessKeyboard((InputSystem *)this);
  return result;
}
