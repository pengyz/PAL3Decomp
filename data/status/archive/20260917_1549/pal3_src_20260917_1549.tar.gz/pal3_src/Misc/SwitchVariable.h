#pragma once
// Auto-generated: SwitchVariable
#include "pal3/ida_types.h"

class SwitchVariable {
public:
    UINT m_switchlimit; // +0x0
    // total size: 0x4 (4)

};
