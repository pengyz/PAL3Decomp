#pragma once
// Auto-generated: _BIGMAP_ELEMENT
#include "pal3/ida_types.h"

class _BIGMAP_ELEMENT {
public:
    char _tail_000[1]; // +0x0
    // total size: 0x1 (1)

    // Scalar-wrapper: ctors for IDA (Cls)int casts (no init code)
    _BIGMAP_ELEMENT() {}
    _BIGMAP_ELEMENT(int v) { *(char*)this = (char)v; }

};
