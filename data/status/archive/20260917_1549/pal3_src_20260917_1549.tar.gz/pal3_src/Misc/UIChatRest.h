#include "UI/UIWnd.h"
#pragma once
// Auto-generated: UIChatRest
#include "pal3/ida_types.h"

#include "Misc/MUIDialog.h"
#include "Misc/RestScript.h"
#include "Misc/TimeCtl.h"
#include "Misc/UIButton.h"
#include "Misc/UIStatic.h"
#include "Misc/UITabBtn.h"

class Comp_DonateUI;
class PalScript;
class ScreenEffect;

class UIChatRest : public UIWnd {
public:
    char _gap_000[68]; // +0x0
    tagPOINT m_pt; // +0x44
    char _gap_04C[12]; // +0x4C
    int m_startX; // +0x58
    int m_startY; // +0x5C
    int mbWidth; // +0x60
    int mbHeight; // +0x64
    UIStatic m_FlagT; // +0x68
    UIStatic m_FlagB; // +0x100
    UIStatic m_FlagM[3]; // +0x198
    UIButton m_Chat; // +0x360
    UIButton m_Rest; // +0x4B8
    UIButton m_Exit; // +0x610
    UITabBtn m_TabBtn; // +0x768
    MUIDialog m_answerDlg; // +0x780
    char _gap_C88[36]; // +0xC88
    BYTE m_bAnswer; // +0xCAC
    char _gap_CAD[3]; // +0xCAD
    ScreenEffect * eft; // +0xCB0
    TimeCtl m_timewait; // +0xCB4
    BYTE m_isFadeOut; // +0xCC0
    BYTE m_isFadeIn; // +0xCC1
    char _gap_CC2[2]; // +0xCC2
    MUIDialog m_noenoughmsg; // +0xCC4
    char _gap_11CC[36]; // +0x11CC
    MUIDialog m_enough; // +0x11F0
    char _gap_16F8[36]; // +0x16F8
    MUIDialog m_restover; // +0x171C
    char _gap_1C24[36]; // +0x1C24
    UINT m_status; // +0x1C48
    BYTE m_isExit; // +0x1C4C
    char _gap_1C4D[3]; // +0x1C4D
    RestScript m_RestScript; // +0x1C50
    int m_CANREST_ID; // +0x2464
    int m_CANNOTREST_ID; // +0x2468
    int m_RESTOVER_ID; // +0x246C
    PalScript * pRest; // +0x2470
    PalScript * pCantRest; // +0x2474
    PalScript * pRestOver; // +0x2478
    BYTE m_bActive; // +0x247C
    char _gap_247D[3]; // +0x247D
    Comp_DonateUI * pC_DUI; // +0x2480
    BYTE m_bC_DUIOver; // +0x2484
    char _gap_2485[3]; // +0x2485
    UIStatic m_BK; // +0x2488
    BYTE m_FadeOutAlpha; // +0x2520
    char _gap_2521[3]; // +0x2521
    float m_age; // +0x2524
    float m_life; // +0x2528
    // total size: 0x252C (9516)

};
