#pragma once
// Auto-generated: FontPrintInfo
#include "pal3/ida_types.h"

#include "gbengine/gbengine_types.h"
#include "gbengine/gbPrintFont.h"

class FontPrintInfo {
public:
    gbFontType font; // +0x0
    char _gap_001[3]; // +0x1
    float x; // +0x4
    float y; // +0x8
    float z; // +0xC
    float endx; // +0x10
    float endy; // +0x14
    int strloc; // +0x18
    int strlen; // +0x1C
    float scalex; // +0x20
    float scaley; // +0x24
    gbColorQuad color; // +0x28
    // total size: 0x2C (44)

};
