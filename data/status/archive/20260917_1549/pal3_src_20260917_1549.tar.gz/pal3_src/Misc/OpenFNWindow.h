#pragma once
// Auto-generated: OpenFNWindow
#include "pal3/ida_types.h"

class OpenFNWindow {
public:
    float fWaitTime; // +0x0
    BYTE bOpen; // +0x4
    char _gap_005[3]; // +0x5
    int nOpenFlag; // +0x8
    // total size: 0xC (12)

};
