#include "pal3/ida_defs.h"
#include "globals.h"
#include "pal3/pal3_constants.h"
#include "Misc/MiniGame2Scene.h"

// 0x0052FBD0
gbOBBox * MiniGame2Scene::GetOBBox()
{
  gbOBBox *v2; // edi
  gbOBBox *result; // eax

  v2 = (gbOBBox *)&this[913];
  (((gbGeomNode *)&this[834]))->gbGeomNode::GetOBBox((gbOBBox *)&this[913]);
  result = (gbOBBox *)v2;
  *(float *)&this[925] = *(float *)&this[907] + *(float *)&this[925];
  *(float *)&this[926] = *(float *)&this[908] + *(float *)&this[926];
  *(float *)&this[927] = *(float *)&this[909] + *(float *)&this[927];
  return result;
}
