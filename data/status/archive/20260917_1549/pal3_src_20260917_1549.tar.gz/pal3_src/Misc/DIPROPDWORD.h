#pragma once
// Auto-generated: DIPROPDWORD
#include "pal3/ida_types.h"

#include "Misc/DIPROPHEADER.h"

class DIPROPDWORD {
public:
    DIPROPHEADER diph; // +0x0
    DWORD dwData; // +0x10
    // total size: 0x14 (20)

};
