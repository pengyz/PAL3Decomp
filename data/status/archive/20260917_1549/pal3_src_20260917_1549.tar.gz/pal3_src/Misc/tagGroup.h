#pragma once
// Auto-generated: tagGroup
#include "pal3/ida_types.h"

#include "Misc/tagListHead.h"

class tagGroup {
public:
    int cntEntries; // +0x0
    tagListHead listHead[64]; // +0x4
    // total size: 0x204 (516)

};
