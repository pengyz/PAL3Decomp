#pragma once
// Auto-generated: ScriptCounter
#include "pal3/ida_types.h"

class ScriptCounter {
public:
    int nMaxCount; // +0x0
    int nState; // +0x4
    int nCurCount; // +0x8
    int nResourceID; // +0xC
    // total size: 0x10 (16)

};
