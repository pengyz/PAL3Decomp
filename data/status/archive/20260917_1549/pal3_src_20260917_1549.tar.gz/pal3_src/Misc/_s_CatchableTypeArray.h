#pragma once
// Auto-generated: _s_CatchableTypeArray
#include "pal3/ida_types.h"

class _s_CatchableTypeArray {
public:
    int nCatchableTypes; // +0x0
    CatchableType * arrayOfCatchableTypes[1]; // +0x4
    // total size: 0x4 (4)

};
