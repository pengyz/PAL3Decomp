#pragma once
// Auto-generated: doubleint
#include "pal3/ida_types.h"

class __unnamed;

class doubleint {
public:
    __unnamed twoints; // +0x0
    char _tail_004[4]; // +0x4
    // total size: 0x8 (8)

};
