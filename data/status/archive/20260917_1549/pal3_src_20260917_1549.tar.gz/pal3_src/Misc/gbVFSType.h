#pragma once
// Auto-generated: gbVFSType
#include "pal3/ida_types.h"

class gbVFSType {
public:
    char _tail_000[1]; // +0x0
    // total size: 0x1 (1)

    // Scalar-wrapper: ctors for IDA (Cls)int casts (no init code)
    gbVFSType() {}
    gbVFSType(int v) { *(char*)this = (char)v; }

};
