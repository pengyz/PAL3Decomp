#pragma once
// Auto-generated: LEVELPARAM
#include "pal3/ida_types.h"

class LEVELPARAM {
public:
    int nMonster; // +0x0
    int nSecond; // +0x4
    // total size: 0x8 (8)

};
