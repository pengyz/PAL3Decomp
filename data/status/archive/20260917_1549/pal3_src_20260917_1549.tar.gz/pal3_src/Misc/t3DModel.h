#pragma once
// Auto-generated: t3DModel
#include "pal3/ida_types.h"

#include "pal3/pal3_stl.h"
#include "Misc/t3DObject.h"
#include "Misc/tMaterialInfo.h"

class t3DModel {
public:
    int numOfObjects; // +0x0
    int numOfMaterials; // +0x4
    vector<tMaterialInfo> pMaterials; // +0x8
    char _gap_00C[12]; // +0xC
    vector<t3DObject> pObject; // +0x18
    char _tail_01C[12]; // +0x1C
    // total size: 0x28 (40)

};
