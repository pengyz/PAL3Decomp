#include "UI/UIListBox.h"
#pragma once
// Auto-generated: CCBUIPanel
#include "pal3/ida_types.h"

#include "Misc/CCBPanelSlot.h"
#include "UI/UIItem.h"
#include "UI/UIScene.h"
#include "Misc/UIStatic.h"

class UIListBox;
class UIWnd;

class CCBUIPanel : public UIListBox {
public:
    char _gap_000[1344]; // +0x0
    int m_nPanelOffsetX; // +0x540
    int m_nPanelOffsetY; // +0x544
    char _gap_548[116]; // +0x548
    int m_nPanelX; // +0x5BC
    int m_nPanelY; // +0x5C0
    int m_nChildX; // +0x5C4
    int m_nChildY; // +0x5C8
    int m_nChildW; // +0x5CC
    int m_nChildH; // +0x5D0
    int m_nBorderL; // +0x5D4
    int m_nBorderR; // +0x5D8
    float m_fPanelW; // +0x5DC
    float m_fPanelH; // +0x5E0
    int m_nGridX; // +0x5E4
    int m_nGridY; // +0x5E8
    int m_nGridW; // +0x5EC
    int m_nGridH; // +0x5F0
    int m_nItemW; // +0x5F4
    int m_nItemH; // +0x5F8
    int m_nSpacingX; // +0x5FC
    int m_nSpacingY; // +0x600
    int m_nItemNum; // +0x604
    int m_nMaxItemNum; // +0x608
    char _gap_60C[12]; // +0x60C
    char * m_pVfTable; // +0x618
    char _gap_61C[228]; // +0x61C
    UIScene m_Scene_1792; // +0x700
    UIStatic m_Static_2136; // +0x858
    UIStatic m_Static_2288; // +0x8F0
    UIStatic m_Static_2440; // +0x988
    UIStatic m_Static_2592; // +0xA20
    UIStatic m_Static_2744; // +0xAB8
    UIScene m_Scene_2896; // +0xB50
    UIScene m_Scene_3240; // +0xCA8
    UIScene m_Scene_3584; // +0xE00
    UIItem m_Item_3928; // +0xF58
    char _gap_1040[156]; // +0x1040
    BYTE m_bActive; // +0x10DC
    char _gap_10DD[7]; // +0x10DD
    CCBPanelSlot m_Slots[30]; // +0x10E4
    int m_nTodo_48AC; // +0x48AC
    int m_nTodo_48B0; // +0x48B0
    int m_nTodo_48B4; // +0x48B4
    int m_EmbedPalScript; // +0x48B8
    char _gap_48BC[160]; // +0x48BC
    int m_nTodo_495C; // +0x495C
    int m_nTodo_4960; // +0x4960
    int m_nTodo_4964; // +0x4964
    int m_nTodo_4968; // +0x4968
    int m_nTodo_496C; // +0x496C
    int m_nTodo_4970; // +0x4970
    int m_nTodo_4974; // +0x4974
    int m_nTodo_4978; // +0x4978
    char _gap_497C[12]; // +0x497C
    int m_nTodo_4988; // +0x4988
    int m_nTodo_498C; // +0x498C
    int m_nTodo_4990; // +0x4990
    int m_nTodo_4994; // +0x4994
    int m_EmbedPlayerAtt; // +0x4998
    char _gap_499C[452]; // +0x499C
    int m_nTodo_4B60; // +0x4B60
    char _gap_4B64[908]; // +0x4B64
    int m_nPlayerAttOverlay; // +0x4EF0
    char _gap_4EF4[348]; // +0x4EF4
    int m_nTodo_5050; // +0x5050
    int m_nTodo_5054; // +0x5054
    char _gap_5058[96]; // +0x5058
    void * m_EmbedCaption; // +0x50B8
    char _gap_50BC[888]; // +0x50BC
    char m_Data[512]; // +0x5434
    char _tail_5634[44]; // +0x5634
    // total size: 0x5660 (22112)

    virtual ~CCBUIPanel() {}

    virtual BOOL ProcessInput(double st7_0); // 0x0044A1B0
    virtual void Destroy(UIListBox **thisa, int a3); // 0x00449990
    void _scalar_dtor(); // 0x004461D0
    virtual int OnMessage_a540(int nVal, int nVal2, int nVal3); // 0x0044A540
    virtual char RenderIfUnlocked(); // 0x00454550
    virtual BOOL ProcessInputIfUnlocked(int nVal, int nVal2); // 0x00454560
    void * _scalar_dtor(UIWnd *Block, char pData); // 0x00453E50
    virtual int OnMessage(int nVal, int nVal2, int nVal3); // 0x00454590
    CCBUIPanel(); // 0x004460D0
    void ctor_6200(); // 0x00446200
    void InitPanel(); // 0x004462C0
    void SetUserData(); // 0x00449980
    int CenterSlot(unsigned int nSlotIdx); // 0x00449AB0
    char FocusCurrentRole(); // 0x00449B90
    int UpdateSlotClipping(); // 0x00449C50
    char UpdateSlotPositions(int nVal); // 0x00449CF0
    void EnsureSize(int nVal, int nVal2); // 0x00449E60
    int SetAllSlotsVisible(unsigned __int8 bVisible); // 0x0044A180
    void ActivateSlot(unsigned int nSlotIdx); // 0x0044A4F0
    int ctor_3D10(); // 0x00453D10
    void ctor(); // 0x00453E70
    int UpdateButtonVisibility(); // 0x004544F0
    int InitSlots(); // 0x0048A170
    int InitScrollState(); // 0x004A3EC0
};
