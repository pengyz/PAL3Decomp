#pragma once
// Auto-generated: _Console__ConCmd
#include "pal3/ida_types.h"

class _Console__ConCmd {
public:
    _BYTE _tail_000[136]; // +0x0
    // total size: 0x88 (136)

};
