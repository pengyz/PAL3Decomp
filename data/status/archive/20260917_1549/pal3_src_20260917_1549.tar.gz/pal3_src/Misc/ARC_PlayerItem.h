#pragma once
// Auto-generated: ARC_PlayerItem
#include "pal3/ida_types.h"

class ARC_PlayerItem {
public:
    DWORD id; // +0x0
    int num; // +0x4
    short item; // +0x8
    // total size: 0xA (10)

};
