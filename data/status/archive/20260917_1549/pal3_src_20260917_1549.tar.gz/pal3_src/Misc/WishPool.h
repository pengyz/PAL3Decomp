#pragma once
// Auto-generated: WishPool
#include "pal3/ida_types.h"

class WishPool {
public:
    BYTE open; // +0x0
    char _gap_001[3]; // +0x1
    int money; // +0x4
    BYTE flower; // +0x8
    char _tail_009[3]; // +0x9
    // total size: 0xC (12)

};
