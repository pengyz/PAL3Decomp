#pragma once
// Auto-generated: NOTE_STATE
#include "pal3/ida_types.h"

class NOTE_STATE {
public:
    char _tail_000[1]; // +0x0
    // total size: 0x1 (1)

    // Scalar-wrapper: ctors for IDA (Cls)int casts (no init code)
    NOTE_STATE() {}
    NOTE_STATE(int v) { *(char*)this = (char)v; }

};
