#pragma once
// Auto-generated: tFace
#include "pal3/ida_types.h"

class tFace {
public:
    int vertIndex[3]; // +0x0
    int coordIndex[3]; // +0xC
    // total size: 0x18 (24)

};
