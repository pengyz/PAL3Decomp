#include "Misc/CEffObj.h"
#include "Effect/CEffGrid.h"
#pragma once
// Auto-generated: CEffTrackGrid
#include "pal3/ida_types.h"

class CEffTrackGrid : public CEffGrid, public CEffObj {
public:
    char _gap_000[4292]; // +0x0
    int m_nCurrTrackPos; // +0x10C4
    float m_fx; // +0x10C8
    float m_fy; // +0x10CC
    float m_fz; // +0x10D0
    // total size: 0x10D4 (4308)

};
