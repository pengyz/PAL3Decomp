#include "pal3/ida_defs.h"
#include "globals.h"
#include "pal3/pal3_constants.h"
#include "Misc/NavFaceLayer.h"
#include "Misc/NavFace.h"
#include "Misc/UITitle_BBTY.h"

// 0x00452540
// attributes: thunk
int NavFaceLayer::GetVertexNum()
{
  return accessor_00452550();
}

// 0x00452560
// attributes: thunk
gbVec3D *NavFaceLayer::GetVertexBuf()
{
  return UITitle_BBTY::_nearby_452570();
}
