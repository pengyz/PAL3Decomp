#include "pal3/ida_defs.h"
#include "globals.h"
#include "pal3/pal3_constants.h"
#include "Misc/ScriptVM.h"
#include "Misc/BINK.h"
#include "Combat/CCBStageRole.h"
#include "Misc/CG_Entry.h"
#include "Render/CScreenMode.h"
#include "Scene/CameraCtrl.h"
#include "Misc/FightInfo.h"
#include "GameBase/GRPinput.h"
#include "Misc/GeomNode.h"
#include "Role/Object3D.h"
#include "Misc/OpenSceneFile.h"
#include "GameBase/PAL3.h"
#include "Script/PalScript.h"
#include "Script/PalScriptMgr.h"
#include "Misc/PtrArray.h"
#include "Render/RenderTarget3.h"
#include "Role/Role.h"
#include "Misc/RoleCameraCtrl.h"
#include "Role/RoleSystem.h"
#include "Scene/Scene.h"
#include "Scene/SceneMgr.h"
#include "Misc/ScriptSystemData.h"
#include "Misc/UIBigMap.h"
#include "Misc/scAsmDecoder.h"
#include "Misc/tagRoleSystemData.h"
#include "free_functions.h"

// Forward declarations for unnamed functions

// 0x00423880
void ScriptVM::ProcessFrame()
{
  int i; // eax
  float v3; // edi
  int v4; // eax
  void **m_nPathParam; // eax
  float *v6; // eax
  float v7; // ecx
  char *m_pPathKeys; // [esp-0xC] [ebp-0x24]
  void **v9; // [esp+0x0] [ebp-0x18]

  /* [MISATTRIBUTED] BINK on ScriptVM::this -> fix IDB name of callee */ BINK::Destroy((BINK *)this);
  for ( i = this->m_nPathStep; i; i = this->m_nPathStep )
  {
    LODWORD(v3) = LODWORD(this->m_fPathStartZ) + 76;
    v4 = i - 1;
    this->m_fPathStartZ = v3;
    this->m_nPathStep = v4;
    if ( !v4 || LODWORD(v3) == LODWORD(this->m_fPathStartY) )
    {
      m_nPathParam = (void **)this->m_nPathParam;
      this->m_nPathParam = (int)(m_nPathParam + 1);
      operator delete(*m_nPathParam);
      if ( this->m_nPathStep )
      {
        v6 = (float *)this->m_nPathParam;
        v7 = *v6;
        this->m_fPathStartX = *v6;
        LODWORD(this->m_fPathStartY) = LODWORD(v7) + 4028;
        this->m_fPathStartZ = v7;
        this->m_nPathParam = (int)v6;
      }
      else
      {
        this->m_fPathStartX = 0.0;
        this->m_fPathStartY = 0.0;
        this->m_fPathStartZ = 0.0;
        this->m_nPathParam = 0;
        this->m_fPathEndX = 0.0;
        m_pPathKeys = (char *)this->m_pPathKeys;
        this->m_fPathEndY = 0.0;
        this->m_ptr_358 = 0;
        this->m_pPathCurrent = 0;
        operator delete(m_pPathKeys);
      }
    }
  }
  GetActorMgr();
  (((RenderTarget3 *)this != 0 ? (RenderTarget3 *)&this->m_bufTail : 0))->RenderTarget3::_nearby_4b6ca0(v9);
}

// 0x00424C20
void ScriptVM::ExecuteBlock()
{
  char v2; // al
  int v3; // eax
  int v4; // eax
  CScreenMode *v5; // ecx
  PtrArray *SoundList; // eax
  float z; // ecx
  int RolePtr; // eax
  float v16; // eax
  int v17; // ebx
  float v18; // eax
  int v19; // ecx
  float x; // eax
  float v23; // ecx
  int v26; // eax
  gbVec3D *v29; // ecx
  float v30; // edx
  char v32; // dl
  int v36; // eax
  CScreenMode *v37; // ecx
  char v38; // al
  PtrArray *v39; // eax
  float v40; // eax
  _DWORD *v43; // edi
  RoleSystem *v44; // ecx
  CScreenMode *v45; // ecx
  char v46; // al
  PtrArray *v47; // eax
  RoleSystem *v49; // ecx
  char v50; // al
  CScreenMode *v51; // ecx
  CScreenMode *v52; // ecx
  PtrArray *v53; // eax
  float v57; // eax
  gbMatrix4 *v62; // edi
  int v63; // ebx
  float *p_xy; // eax
  int v65; // ecx
  int v66; // edx
  int v68; // ebp
  int v72; // eax
  int v73; // ecx
  char v83; // al
  char *v84; // eax
  float *v85; // edi
  float v90; // ecx
  PtrArray *v92; // eax
  int v93; // eax
  PalScriptMgr *v94; // ecx
  int v95; // eax
  CScreenMode *v96; // ecx
  PtrArray *v97; // eax
  char v98; // al
  float v100; // eax
  int v102; // eax
  int v103; // eax
  char v104; // al
  CScreenMode *v108; // ecx
  int v109; // eax
  int v110; // eax
  PalScriptMgr *v112; // ecx
  int v113; // eax
  int v114; // eax
  PtrArray *v115; // eax
  int v116; // ecx
  char v117; // al
  float v118; // edx
  float v120; // eax
  float y; // ecx
  float v122; // edx
  PtrArray *v123; // eax
  int v125; // eax
  float v129; // eax
  float v130; // ecx
  float v131; // edx
  CScreenMode *v134; // ecx
  PtrArray *v136; // eax
  bool v137; // al
  float v140; // ecx
  float v142; // eax
  char v144; // al
  char v145; // al
  CScreenMode *v146; // ecx
  PtrArray *v147; // eax
  CScreenMode *v148; // ecx
  PtrArray *v149; // eax
  __int64 v153; // rax
  int v154; // ecx
  int v155; // ecx
  int v156; // eax
  int v157; // edx
  float v160; // edx
  float v161; // eax
  float v163; // edi
  float v164; // ebx
  RoleSystem **m_pCmdList; // ecx
  int v167; // ecx
  Scene **v170; // edx
  int x_low; // edi
  float v172; // ecx
  float v175; // ecx
  PtrArray *v178; // eax
  char *v179; // eax
  int v180; // [esp-0x4] [ebp-0x114]
  float nType; // [esp+0x0] [ebp-0x110]
  int nTypea; // [esp+0x0] [ebp-0x110]
  int fVal; // [esp+0x4] [ebp-0x10C]
  float fVala; // [esp+0x4] [ebp-0x10C]
  int v185; // [esp+0x8] [ebp-0x108]
  int v186; // [esp+0x8] [ebp-0x108]
  unsigned __int8 v187; // [esp+0xC] [ebp-0x104]
  unsigned __int8 v188; // [esp+0xC] [ebp-0x104]
  unsigned __int8 v189; // [esp+0xC] [ebp-0x104]
  gbVec3D pfVal2; // [esp+0x1C] [ebp-F4h] BYREF
  gbVec3D pParams; // [esp+0x28] [ebp-E8h] BYREF
  gbVec3D nSceneIdx; // [esp+0x34] [ebp-DCh] BYREF
  gbVec3D v193; // [esp+0x40] [ebp-D0h] BYREF
  gbVec3D v194; // [esp+0x4C] [ebp-C4h] BYREF
  int v195; // [esp+0x58] [ebp-B8h]
  int v196; // [esp+0x5C] [ebp-B4h]
  float pData[3]; // [esp+0x60] [ebp-B0h] BYREF
  float v198[3]; // [esp+0x6C] [ebp-A4h] BYREF
  gbMatrix4 v199; // [esp+0x78] [ebp-0x98] BYREF
  gbMatrix4 pMatrix; // [esp+C4h] [ebp-0x4C] BYREF
  RoleSystem *v206; // [esp+0x114] [ebp+0x4]
  char v207; // [esp+0x118] [ebp+0x8]
  int v208; // [esp+0x11C] [ebp+0xC]
v2 = *((_BYTE *)&this->m_nTodo_0A8 + 6);
  if ( !v2 )
    return;
  switch ( this->m_nTodo_0F4 )
  {
    case 0:
      if ( !v208 )
      {
        PalScriptMgr::ClearAllScript();
        if ( !v3 )
        {
          (*((PalScriptMgr **)&this->m_nPauseState + 11))->PalScriptMgr::Destroy();
          *(&this->m_nPathStep + 3) = v4;
          (((RoleSystem *)((RoleSystem *)&stru_C10DF0)->m_teamSlotOverlay.m_teamSlots[154]))->RoleSystem::Notify();
          v185 = *(&this->m_nPathStep + 3);
          SoundList = (((CScreenMode *)v5))->CScreenMode::GetSoundList();
          (((PtrArray *)SoundList))->PtrArray::SetResolution(0, v185);
          (((PalScriptMgr *)_ESI))->PalScriptMgr::ExecuteScriptByID();
          goto LABEL_99;
        }
      }
      return;
    case 1:
      if ( !v208 )
      {
        if ( *((_BYTE *)&this->m_ptr_20 + 48) )
          goto LABEL_254;
        (*((gbVisNode **)&this->m_ptr_20 + 15))->gbVisNode::SetTimeScale(1.0);
        (*(void (**)(_DWORD, _DWORD))(**(&this->m_ptr_20 + 15) + 24))(*((_DWORD *)&this->m_ptr_20 + 15), 0);
        *((_BYTE *)&this->m_ptr_20 + 48) = 4;
        goto LABEL_55;
      }
      return;
    case 2:
      if ( !v208 )
      {
        if ( *((_BYTE *)&this->m_ptr_20 + 48) )
          goto LABEL_254;
        gbGeomNode::SetAnimLoop(*((gbGeomNode **)&this->m_ptr_20 + 15), 1);
        (*((gbVisNode **)&this->m_ptr_20 + 15))->gbVisNode::SetTimeScale(1.0);
        (*(void (**)(_DWORD, _DWORD))(**(&this->m_ptr_20 + 15) + 24))(*((_DWORD *)&this->m_ptr_20 + 15), 0);
        goto LABEL_54;
      }
      return;
    case 3:
      if ( *((_BYTE *)&this->m_ptr_20 + 48) )
        goto LABEL_254;
      __asm
      {
        fld     g_fEffectTimer
        fcomp   _flt_1_2
        fnstsw  ax
      }
      if ( (_AX & 0x100) == 0 )
      {
        *((_BYTE *)&this->m_ptr_20 + 48) = 1;
        *((_DWORD *)&this->m_ptr_20 + 6) = *(&this->m_nTodo_0A8 + 11);
        *((_DWORD *)&this->m_ptr_20 + 7) = *(&this->m_nTodo_0A8 + 12);
        *((_DWORD *)&this->m_ptr_20 + 8) = this->m_nTodo_0DC;
        __asm
        {
          fld     dword ptr [esi+0x0E0]
          fmul    _flt_0_01745329f
        }
        *((_DWORD *)&this->m_ptr_20 + 10) = 0;
        __asm
        {
          fst     [esp+0x108+var_D0]
          fsin
          fld     [esp+0x108+var_D0]
          fcos
          fstp    [esp+0x108+var_BC]
        }
        z = v194.z;
        // __asm { fstp    dword ptr [esi+0x44] }
        *((float *)&this->m_ptr_20 + 9) = _ET1;
        *((float *)&this->m_ptr_20 + 11) = z;
        __asm
        {
          fld     dword ptr [esi+0x44]
          fmul    _flt_280_0
          fstp    dword ptr [esi+0x44]
        }
        *((float *)&this->m_ptr_20 + 9) = _ET1;
        __asm
        {
          fld     dword ptr [esi+0x48]
          fmul    _flt_280_0
          fstp    dword ptr [esi+0x48]
        }
        *((float *)&this->m_ptr_20 + 10) = _ET1;
        __asm
        {
          fld     dword ptr [esi+0x4C]
          fmul    _flt_280_0
          fstp    dword ptr [esi+0x4C]
        }
        *((float *)&this->m_ptr_20 + 11) = _ET1;
        *((_DWORD *)&this->m_ptr_20 + 13) = 0;
        (((PalScriptMgr *)_ESI))->PalScriptMgr::RunCommand(0);
        goto LABEL_55;
      }
      return;
    case 4:
      if ( *((_BYTE *)&this->m_ptr_20 + 48) )
        goto LABEL_254;
      __asm
      {
        fld     g_fEffectTimer
        fcomp   _flt_1_2
        fnstsw  ax
      }
      if ( (_AX & 0x100) == 0 )
      {
        *((_BYTE *)&this->m_ptr_20 + 48) = 1;
        *((_DWORD *)&this->m_ptr_20 + 6) = *(&this->m_nTodo_0A8 + 11);
        *((_DWORD *)&this->m_ptr_20 + 7) = *(&this->m_nTodo_0A8 + 12);
        *((_DWORD *)&this->m_ptr_20 + 8) = this->m_nTodo_0DC;
        RolePtr = (*((RoleSystem **)this->m_pCmdList + 4))->RoleSystem::GetRolePtr(*(&this->m_nTodo_0F4 + 2));
        // __asm { fld     dword ptr [esi+0x38] }
        _EDI = (_DWORD *)RolePtr;
        __asm
        {
          fsub    dword ptr [edi+0x80]
          fdiv    g_fScriptTileSize
        }
        LODWORD(v16) = _ftol();
        __asm
        {
          fld     dword ptr [esi+0x40]
          fsub    dword ptr [edi+0x88]
        }
        v17 = LODWORD(v16);
        nSceneIdx.x = v16;
        __asm { fdiv    g_fScriptTileSize }
        LODWORD(v18) = _ftol();
        __asm
        {
          fld     _flt_0_0
          fild    [esp+0x104+nSceneIdx]
        }
        nSceneIdx.y = v18;
        __asm
        {
          fadd    _flt_0_5
          fmul    g_fScriptTileSize
          fadd    dword ptr [edi+0x80]
          fstp    [esp+0x104+pParams]
          fild    [esp+0x104+var_D8]
          fadd    _flt_0_5
          fmul    g_fScriptTileSize
          fadd    dword ptr [edi+0x88]
          fstp    [esp+0x104+var_E0]
        }
        if ( v17 >= 0 )
        {
          v19 = _EDI[38];
          if ( v17 < v19 && v18 >= 0.0 && SLODWORD(v18) < _EDI[39] )
          {
            __asm { fstp    st }
            _EDX = _EDI[40];
            _ECX = v17 + LODWORD(v18) * v19;
            __asm { fld     dword ptr [edx+ecx*8] }
          }
        }
        x = pParams.x;
        v23 = pParams.z;
        // __asm { fstp    dword ptr [esi+0x3C] }
        *((float *)&this->m_ptr_20 + 7) = _ET1;
        *((float *)&this->m_ptr_20 + 6) = x;
        *((float *)&this->m_ptr_20 + 8) = v23;
        __asm
        {
          fld     dword ptr [esi+0x3C]
          fsub    dword ptr [flt_56AA3C]
          fstp    dword ptr [esi+0x3C]
        }
        *((float *)&this->m_ptr_20 + 7) = _ET1;
        *((_DWORD *)&this->m_ptr_20 + 2) = *(&this->m_nTodo_0A8 + 11);
        *((_DWORD *)&this->m_ptr_20 + 3) = *(&this->m_nTodo_0A8 + 12);
        *((_DWORD *)&this->m_ptr_20 + 4) = this->m_nTodo_0DC;
        *((_DWORD *)&this->m_ptr_20 + 9) = 0;
        *((_DWORD *)&this->m_ptr_20 + 10) = 1133248512;
        *((_DWORD *)&this->m_ptr_20 + 11) = 0;
        v26 = *((_DWORD *)&this->m_ptr_20 + 14);
        *((_DWORD *)&this->m_ptr_20 + 13) = 0;
        if ( v26 == 3 )
        {
          (*((gbVisNode **)&this->m_ptr_20 + 15))->gbVisNode::SetTimeScale(0.0);
          (*(void (**)(_DWORD, _DWORD))(**(&this->m_ptr_20 + 15) + 24))(*((_DWORD *)&this->m_ptr_20 + 15), 0);
        }
        (((PalScriptMgr *)_ESI))->PalScriptMgr::RunCommand(0);
        goto LABEL_55;
      }
      return;
    case 5:
      if ( *((_DWORD *)&this->m_nTodo_0F4 + 1) == 1 )
      {
        if ( !v207 && this->ScriptVM::IsRunning() )
        {
          _EAX = ((RoleSystem *)&stru_C10DF0)->m_teamSlotOverlay.m_teamSlots[154];
          _EDI = &this->m_ptr_20 + 2;
          v29 = (gbVec3D *)(&this->m_ptr_20 + 9);
          __asm
          {
            fld     dword ptr [edi]
            fsub    dword ptr [eax+0x0A0]
            fld     dword ptr [edi+4]
            fsub    dword ptr [eax+0x0A4]
            fstp    [esp+0x104+var_E4]
            fld     dword ptr [edi+8]
            fsub    dword ptr [eax+0x0A8]
          }
          *((_DWORD *)&this->m_ptr_20 + 10) = LODWORD(pParams.y);
          // __asm { fstp    [esp+0x104+var_E0] }
          v30 = pParams.z;
          __asm { fstp    dword ptr [ecx] }
          v29->x = _ET1;
          *((float *)&this->m_ptr_20 + 11) = v30;
          __asm
          {
            fld     dword ptr [esi+0x48]
            fcomp   _flt_40_0
            fnstsw  ax
          }
          if ( (_EAX & 0x4100) != 0 )
          {
            *((_DWORD *)&this->m_ptr_20 + 10) = 0;
            (((gbVec3D *)v29))->gbVec3D::Normalize();
            (((ScriptVM *)_ESI))->ScriptVM::GetRolePosition(1u);
            FightInfo();
            (((ScriptVM *)_ESI))->ScriptVM::CallFunction(0xBu, 0);
            goto LABEL_247;
          }
          v29->x = 0.0;
          *((_DWORD *)&this->m_ptr_20 + 10) = 0;
          *((_DWORD *)&this->m_ptr_20 + 11) = 0;
        }
      }
      else
      {
        if ( !*((_BYTE *)&this->m_nTodo_0A8 + 7) )
          goto LABEL_254;
        v32 = *((_BYTE *)&this->m_ptr_20 + 48);
        if ( v32 )
        {
          if ( v32 != 3 )
            goto LABEL_254;
        }
        _EDI = (RoleSystem *)((RoleSystem *)&stru_C10DF0)->m_teamSlotOverlay.m_teamSlots[154];
        _ECX = &this->m_ptr_20 + 2;
        __asm
        {
          fld     dword ptr [ecx+4]
          fsub    dword ptr [edi+0x0A4]
          fcomp   _flt_40_0
          fnstsw  ax
        }
        if ( (_AX & 0x4100) != 0 )
        {
          if ( v32 )
          {
            v36 = *(&this->m_nPauseState + 134);
            *((_DWORD *)&this->m_pCmdList + 2) = 2;
            *((_DWORD *)&this->m_ptr_20 + 6) = *(_DWORD *)(v36 + 3076);
          }
          else
          {
            *((_DWORD *)&this->m_pCmdList + 2) = 1;
            *((_DWORD *)&this->m_ptr_20 + 6) = 0;
          }
          *((_DWORD *)&this->m_pCmdList + 7) = 1;
          *((_BYTE *)&this->m_ptr_20 + 48) = 4;
          (((RoleSystem *)_EDI))->RoleSystem::SetMoveTarget((float *)&this->m_ptr_20 + 2, 1);
          (((RoleSystem *)_EDI))->RoleSystem::GetMoveState();
          v38 = *((_BYTE *)&this->m_nTodo_0A8 + 6);
          if ( v38 != -1 )
          {
            *((_BYTE *)&this->m_nTodo_0A8 + 6) = v38 - 1;
            v39 = (((CScreenMode *)v37))->CScreenMode::GetSoundList();
            (((PtrArray *)v39))->PtrArray::SetResolution((int)_ESI, 0);
            goto LABEL_254;
          }
          goto LABEL_248;
        }
      }
      return;
    case 6:
      if ( !*((_BYTE *)&this->m_ptr_20 + 48) )
      {
        pfVal2.x = *((float *)&this->m_ptr_20 + 2);
        // __asm { fld     [esp+0x104+pfVal2] }
        v40 = *((float *)&this->m_ptr_20 + 4);
        pfVal2.y = *((float *)&this->m_ptr_20 + 3);
        pfVal2.z = v40;
        _EAX = v206;
        __asm
        {
          fsub    dword ptr [eax+4]
          fstp    [esp+0x104+pfVal2]
          fld     dword ptr [eax+8]
          fchs
          fstp    [esp+0x104+var_F0]
          fld     [esp+0x104+var_EC]
          fsub    dword ptr [eax+0x0C]
          fstp    [esp+0x104+var_EC]
        }
        (((gbVec3D *)&pfVal2))->gbVec3D::Length();
        __asm
        {
          fld     _flt_12_0
          fmul    _flt_4_0
          fcompp
          fnstsw  ax
        }
        if ( (_AX & 0x4100) == 0 )
        {
          v43 = (_DWORD *)((RoleSystem *)&stru_C10DF0)->m_teamSlotOverlay.m_teamSlots[154];
          v44 = (RoleSystem *)((RoleSystem *)&stru_C10DF0)->m_teamSlotOverlay.m_teamSlots[154];
          *(_DWORD *)(((RoleSystem *)&stru_C10DF0)->m_teamSlotOverlay.m_teamSlots[154] + 1284) = 0;
          (((RoleSystem *)v44))->RoleSystem::UpdateTransform();
          *((_BYTE *)&this->m_ptr_20 + 48) = 1;
          *((_DWORD *)&this->m_ptr_20 + 9) = 0;
          *((_DWORD *)&this->m_ptr_20 + 10) = 0;
          *((_DWORD *)&this->m_ptr_20 + 11) = 0;
          *((_DWORD *)&this->m_ptr_20 + 6) = (unsigned long)v43[40];
          *((_DWORD *)&this->m_ptr_20 + 7) = (unsigned long)v43[41];
          *((_DWORD *)&this->m_ptr_20 + 8) = (unsigned long)v43[42];
          (*((gbVisNode **)&this->m_ptr_20 + 15))->gbVisNode::SetTimeScale(2.0);
          (*(void (**)(_DWORD, _DWORD))(**(&this->m_ptr_20 + 15) + 24))(*((_DWORD *)&this->m_ptr_20 + 15), 0);
          v46 = *((_BYTE *)&this->m_nTodo_0A8 + 6);
          if ( v46 != -1 )
            *((_BYTE *)&this->m_nTodo_0A8 + 6) = v46 - 1;
          v47 = (((CScreenMode *)v45))->CScreenMode::GetSoundList();
          (((PtrArray *)v47))->PtrArray::SetResolution((int)_ESI, 0);
          (((PalScriptMgr *)_ESI))->PalScriptMgr::RunCommand(0);
        }
      }
      return;
    case 7:
    case 8:
      if ( v207 == 2 && !*((_BYTE *)&this->m_ptr_20 + 48) )
      {
        __asm
        {
          fld     dword ptr [esi+0x0E0]
          fadd    _flt_90_0
        }
        *((_BYTE *)&this->m_ptr_20 + 48) = 1;
        // __asm { fstp    dword ptr [esi+0x38] }
        *((float *)&this->m_ptr_20 + 6) = _ET1;
        v49 = (RoleSystem *)((RoleSystem *)&stru_C10DF0)->m_teamSlotOverlay.m_teamSlots[154];
        *(_DWORD *)(((RoleSystem *)&stru_C10DF0)->m_teamSlotOverlay.m_teamSlots[154] + 1284) = 0;
        (((RoleSystem *)v49))->RoleSystem::UpdateTransform();
        (((RoleSystem *)_ESI))->RoleSystem::ProcessAction();
        (((PalScriptMgr *)_ESI))->PalScriptMgr::RunCommand(0);
        v50 = *((_BYTE *)&this->m_nTodo_0A8 + 6);
        if ( v50 != -1 )
          *((_BYTE *)&this->m_nTodo_0A8 + 6) = v50 - 1;
        v51 = (CScreenMode *)g_pCameraCtrl;
        if ( !*((_DWORD *)&g_pCameraCtrl->m_nextYAW + 1) )
          goto LABEL_89;
        (((CameraCtrl *)&g_pCameraCtrl))->CameraCtrl::InitParams(&this->m_ptr_20 + 2);
        v53 = (((CScreenMode *)v52))->CScreenMode::GetSoundList();
        (((PtrArray *)v53))->PtrArray::SetResolution((int)_ESI, 0);
      }
      return;
    case 9:
      if ( *((_BYTE *)&this->m_ptr_20 + 48) )
        goto LABEL_254;
      pfVal2.x = *((float *)&this->m_ptr_20 + 2);
      // __asm { fld     [esp+0x104+pfVal2] }
      pfVal2.y = *((float *)&this->m_ptr_20 + 3);
      _EAX = v206;
      __asm { fsub    dword ptr [eax+4] }
      pfVal2.z = *((float *)&this->m_ptr_20 + 4);
      __asm
      {
        fstp    [esp+0x104+pfVal2]
        fld     dword ptr [eax+8]
        fchs
        fstp    [esp+0x104+var_F0]
        fld     [esp+0x104+var_EC]
        fsub    dword ptr [eax+0x0C]
        fstp    [esp+0x104+var_EC]
      }
      (((gbVec3D *)&pfVal2))->gbVec3D::Length();
      __asm
      {
        fld     _flt_12_0
        fmul    _flt_0_5
        fcompp
        fnstsw  ax
      }
      if ( (_AX & 0x4100) == 0 )
      {
        (((PalScriptMgr *)_ESI))->PalScriptMgr::ExecuteScriptByID();
LABEL_54:
        *((_BYTE *)&this->m_ptr_20 + 48) = 1;
LABEL_55:
        v2 = *((_BYTE *)&this->m_nTodo_0A8 + 6);
        goto LABEL_56;
      }
      return;
    case 0xA:
      if ( !*((_BYTE *)&this->m_ptr_20 + 48) )
      {
        __asm
        {
          fld     dword ptr [esi+0x140]
          fsub    dword ptr [esi+0x134]
          fld     dword ptr [esi+0x144]
          fsub    dword ptr [esi+0x138]
        }
        _EDI = (float *)(&this->m_ptr_20 + 9);
        __asm
        {
          fstp    [esp+0x104+var_E4]
          fld     dword ptr [esi+0x148]
          fsub    dword ptr [esi+0x13C]
        }
        *((_DWORD *)&this->m_ptr_20 + 10) = LODWORD(pParams.y);
        // __asm { fstp    [esp+0x104+var_E0] }
        v57 = pParams.z;
        __asm { fstp    dword ptr [edi] }
        *_EDI = _ET1;
        *((float *)&this->m_ptr_20 + 11) = v57;
        ((gbVec3D *)((gbVec3D *)&this->m_ptr_20 + 3))->gbVec3D::Normalize();
        __asm
        {
          fld     dword ptr g_RoleSystemData+0x12C
          fld     st
          fmul    dword ptr [edi]
        }
        __asm { fstp    dword ptr [edi] }
        *_EDI = _ET1;
        __asm
        {
          fld     st
          fmul    dword ptr [edi+4]
          fstp    dword ptr [edi+4]
        }
        *((float *)&this->m_ptr_20 + 10) = _ET1;
        __asm
        {
          fmul    dword ptr [edi+8]
          fstp    dword ptr [edi+8]
        }
        *((float *)&this->m_ptr_20 + 11) = _ET1;
        v206->m_nCoreState = 0;
        (((RoleSystem *)v206))->RoleSystem::UpdateTransform();
        *((_BYTE *)&this->m_ptr_20 + 48) = 1;
        goto LABEL_99;
      }
      return;
    case 0xB:
      if ( v207 == 1 && !*((_BYTE *)&this->m_ptr_20 + 48) )
      {
        v62 = (gbMatrix4 *)&v199;
        v63 = 4;
        do
        {
          v62 = (gbMatrix4 *)((char *)v62 + 12);
          --v63;
        }
        while ( v63 );
        p_xy = (float *)&v199.xy;
        v65 = 4;
        do
        {
          *(p_xy - 1) = *((float *)&this->m_ptr_20 + 2);
          v66 = *((_DWORD *)&this->m_ptr_20 + 4);
          *p_xy = 0.0;
          *((_DWORD *)p_xy + 1) = v66;
          p_xy += 3;
          --v65;
        }
        while ( v65 );
        (((Object3D *)_ESI))->Object3D::SetTransform(&pMatrix);
        v194.x = -12.0;
        // __asm { fld     [esp+0x104+var_C] }
        _EAX = (char *)(&v194.x + (_DWORD)g_SceneMgr.m_nCurrentRoleSlot);
        v194.y = 4.0;
        v194.z = 4.0;
        v195 = 1091567616;
        v196 = 1094713344;
        __asm
        {
          fadd    dword ptr [eax]
          fld     dword ptr [esp+0x104+var_98]
        }
        v193.x = 100000.0;
        v68 = 0;
        __asm { fsub    st, st(1) }
        _EBX = (float *)&v206->m_fontcolor.Color;
        _EDI = &v199.xz;
        __asm
        {
          fstp    dword ptr [esp+0x104+var_98]
          fadd    [esp+0x104+var_98.xw]
          fstp    [esp+0x104+var_98.xw]
          fld     [esp+0x104+var_4]
          fadd    dword ptr [eax]
          fld     [esp+0x104+var_98.zx]
          fsub    st, st(1)
          fstp    [esp+0x104+var_98.zx]
          fadd    [esp+0x104+var_98.zw]
          fstp    [esp+0x104+var_98.zw]
        }
        do
        {
          __asm
          {
            fld     dword ptr [ebx]
            fsub    dword ptr [edi-8]
            fstp    [esp+0x104+pParams]
            fld     dword ptr [ebx+4]
            fsub    dword ptr [edi-4]
          }
          pfVal2.x = pParams.x;
          __asm
          {
            fstp    [esp+0x104+var_E4]
            fld     dword ptr [ebx+8]
            fsub    dword ptr [edi]
          }
          pfVal2.y = pParams.y;
          // __asm { fstp    [esp+0x104+var_E0] }
          pfVal2.z = pParams.z;
          (((gbVec3D *)&pfVal2))->gbVec3D::Length();
          __asm
          {
            fcom    [esp+0x104+var_D0]
            fnstsw  ax
          }
          if ( (_AX & 0x100) != 0 )
          {
            v72 = *((_DWORD *)_EDI - 1);
            v73 = *(_DWORD *)_EDI;
            *((float *)&this->m_ptr_20 + 6) = *(_EDI - 2);
            // __asm { fstp    [esp+0x104+var_D0] }
            *((_DWORD *)&this->m_ptr_20 + 7) = v72;
            *((_DWORD *)&this->m_ptr_20 + 8) = v73;
            *((_DWORD *)&this->m_pCmdList + 2) = v68;
          }
          else
          {
            __asm { fstp    st }
          }
          ++v68;
          _EDI += 3;
        }
        while ( v68 < 4 );
        __asm
        {
          fld     [esp+0x104+var_D0]
          fcomp   dword ptr [flt_56AB24]
          fnstsw  ax
        }
        if ( (_AX & 0x100) == 0 )
          goto LABEL_103;
        _EBP = &this->m_ptr_20 + 6;
        if ( !(((PalScriptMgr *)_ESI))->PalScriptMgr::CmdUpdateRolePath(_EBX, (float *)&this->m_ptr_20 + 6) )
          goto LABEL_103;
        _EDI = (float *)(&this->m_ptr_20 + 9);
        *((_DWORD *)&this->m_ptr_20 + 9) = *((_DWORD *)&this->m_ptr_20 + 2);
        *((_DWORD *)&this->m_ptr_20 + 10) = *((_DWORD *)&this->m_ptr_20 + 3);
        *((_DWORD *)&this->m_ptr_20 + 11) = *((_DWORD *)&this->m_ptr_20 + 4);
        __asm
        {
          fld     dword ptr [edi]
          fsub    dword ptr [ebp+0]
          fstp    dword ptr [edi]
        }
        *_EDI = _ET1;
        __asm
        {
          fld     dword ptr [edi+4]
          fsub    dword ptr [ebp+4]
          fstp    dword ptr [edi+4]
        }
        _EDI[1] = _ET1;
        __asm
        {
          fld     dword ptr [edi+8]
          fsub    dword ptr [ebp+8]
          fstp    dword ptr [edi+8]
        }
        _EDI[2] = _ET1;
        *((_DWORD *)&this->m_ptr_20 + 10) = 0;
        ((gbVec3D *)((gbVec3D *)&this->m_ptr_20 + 3))->gbVec3D::Normalize();
        __asm
        {
          fld     dword ptr g_RoleSystemData+0x12C
          fld     st
          fmul    dword ptr [edi]
        }
        __asm { fstp    dword ptr [edi] }
        *_EDI = _ET1;
        __asm
        {
          fld     st
          fmul    dword ptr [edi+4]
          fstp    dword ptr [edi+4]
        }
        *((float *)&this->m_ptr_20 + 10) = _ET1;
        __asm
        {
          fmul    dword ptr [edi+8]
          fstp    dword ptr [edi+8]
        }
        *((float *)&this->m_ptr_20 + 11) = _ET1;
        (((RoleSystem *)v206))->RoleSystem::SetMoveTarget((float *)&this->m_ptr_20 + 6, 1);
        (((RoleSystem *)v206))->RoleSystem::GetMoveState();
        (((RoleSystem *)_ESI))->RoleSystem::ProcessAction();
        v83 = *((_BYTE *)&this->m_nTodo_0A8 + 6);
        *((_BYTE *)&this->m_ptr_20 + 48) = 1;
        if ( v83 == -1 )
          goto LABEL_89;
        goto LABEL_88;
      }
      return;
    case 0xC:
      if ( v207 == 1 )
      {
        if ( g_SceneMgr.m_nCurrentRoleSlot != *((scAsmDecoder **)&this->m_nTodo_0F4 + 1) )
        {
          v84 = (((PalScript *)g_PAL3_Instance.m_nTodo_140))->PalScript::SetAppName("cantopen");
          goto LABEL_179;
        }
        if ( !*((_BYTE *)&this->m_ptr_20 + 48) )
        {
          _EBP = v206;
          *((_DWORD *)&this->m_ptr_20 + 6) = *((_DWORD *)&this->m_ptr_20 + 2);
          *((_DWORD *)&this->m_ptr_20 + 7) = *((_DWORD *)&this->m_ptr_20 + 3);
          *((_DWORD *)&this->m_ptr_20 + 8) = *((_DWORD *)&this->m_ptr_20 + 4);
          __asm
          {
            fld     dword ptr [esi+0x28]
            fsub    dword ptr [ebp+0x0A0]
            fstp    [esp+0x104+pParams]
            fld     dword ptr [esi+0x2C]
            fsub    dword ptr [ebp+0x0A4]
          }
          pfVal2.x = pParams.x;
          __asm
          {
            fstp    [esp+0x104+var_E4]
            fld     dword ptr [esi+0x30]
            fsub    dword ptr [ebp+0x0A8]
          }
          pfVal2.y = pParams.y;
          // __asm { fstp    [esp+0x104+var_E0] }
          pfVal2.z = pParams.z;
          (((gbVec3D *)&pfVal2))->gbVec3D::Length();
          __asm
          {
            fcomp   _flt_600_0
            fnstsw  ax
          }
          if ( (_AX & 0x100) == 0 )
            goto LABEL_103;
          _EBX = &v206->m_fontcolor;
          if ( !(((PalScriptMgr *)_ESI))->PalScriptMgr::CmdUpdateRolePath((float *)&v206->m_fontcolor.Color, (float *)&this->m_ptr_20 + 6) )
            goto LABEL_103;
          *((_DWORD *)&this->m_ptr_20 + 13) = 0;
          __asm
          {
            fld     dword ptr [ebx]
            fsub    dword ptr [esi+0x28]
            fstp    [esp+0x104+pParams]
            fld     dword ptr [ebx+4]
            fsub    dword ptr [esi+0x2C]
          }
          pfVal2.x = pParams.x;
          __asm
          {
            fstp    [esp+0x104+var_E4]
            fld     dword ptr [ebx+8]
            fsub    dword ptr [esi+0x30]
          }
          // __asm { fstp    [esp+0x104+var_E0] }
          pfVal2.y = 0.0;
          pfVal2.z = pParams.z;
          (((gbVec3D *)&pfVal2))->gbVec3D::Length();
          __asm
          {
            fld     _flt_12_0
            fmul    _flt_3_0
            fsubp   st(1), st
            fcomp   _flt_1_0
            fnstsw  ax
          }
          if ( (_AX & 0x100) != 0 )
          {
            *((_BYTE *)&this->m_ptr_20 + 48) = 2;
            (((RoleSystem *)v206))->RoleSystem::GetMoveState();
            (((RoleSystem *)v206))->RoleSystem::GetActionByIndex(8);
          }
          else
          {
            (((gbVec3D *)&pfVal2))->gbVec3D::Normalize();
            if ( *((_DWORD *)&this->m_nTodo_0F4 + 1) == 2 )
            {
              __asm
              {
                fld     dword ptr [esi+0x370]
                fchs
                fld     [esp+0x104+pfVal2]
                fmul    st, st(1)
              }
            }
            else
            {
              __asm
              {
                fld     _flt_12_0
                fchs
                fld     st
                fmul    [esp+0x104+pfVal2]
              }
            }
            __asm
            {
              fstp    [esp+0x104+pfVal2]
              fld     [esp+0x104+var_F0]
              fmul    st, st(1)
            }
            __asm
            {
              fstp    [esp+0x110+var_F0]
              fld     [esp+0x110+var_EC]
              fmul    st, st(1)
              fstp    [esp+0x110+var_EC]
              fstp    st
              fld     [esp+0x110+pfVal2]
              fadd    dword ptr [esi+0x28]
              fld     [esp+0x110+var_F0]
              fadd    dword ptr [esi+0x2C]
              fstp    [esp+0x110+var_E4]
              fld     [esp+0x110+var_EC]
              fadd    dword ptr [esi+0x30]
            }
            *((_DWORD *)&this->m_ptr_20 + 7) = LODWORD(pParams.y);
            // __asm { fstp    [esp+0x110+var_E0] }
            v90 = pParams.z;
            __asm { fstp    dword ptr [edi] }
            v85 = (float *)(&this->m_ptr_20 + 6);
            *v85 = _ET1;
            *((float *)&this->m_ptr_20 + 8) = v90;
            FightInfo();
            (((ScriptVM *)_ESI))->ScriptVM::CallFunction(1u, 0);
            (((PalScriptMgr *)_ESI))->PalScriptMgr::ExecuteOpcode();
          }
          v83 = *((_BYTE *)&this->m_nTodo_0A8 + 6);
          if ( v83 != -1 )
LABEL_88:
            *((_BYTE *)&this->m_nTodo_0A8 + 6) = v83 - 1;
          goto LABEL_89;
        }
      }
      return;
    case 0xE:
      if ( !v208 && !*((_BYTE *)&this->m_ptr_20 + 48) )
      {
        if ( *((_DWORD *)&this->m_nTodo_0F4 + 1) )
        {
          PalScriptMgr::ClearAllScript();
          if ( !v93 )
          {
            (((RoleSystem *)v206))->RoleSystem::Notify();
            goto LABEL_96;
          }
        }
        else
        {
          *((_BYTE *)&this->m_ptr_20 + 48) = 1;
          (((RoleSystem *)v206))->RoleSystem::Notify();
          v97 = (((CScreenMode *)v96))->CScreenMode::GetSoundList();
          (((PtrArray *)v97))->PtrArray::SetResolution((int)_ESI, 0);
          if ( *((_DWORD *)&this->m_ptr_20 + 14) == 3 )
          {
            (*((gbVisNode **)&this->m_ptr_20 + 15))->gbVisNode::SetTimeScale(2.0);
            (*(void (**)(_DWORD, _DWORD))(**(&this->m_ptr_20 + 15) + 24))(
              *((_DWORD *)&this->m_ptr_20 + 15),
              0);
          }
LABEL_99:
          v98 = *((_BYTE *)&this->m_nTodo_0A8 + 6);
          if ( v98 != -1 )
            *((_BYTE *)&this->m_nTodo_0A8 + 6) = v98 - 1;
        }
      }
      return;
    case 0xF:
      if ( v207 == 1 )
      {
        _EDI = v206;
        pfVal2.x = *((float *)&this->m_ptr_20 + 2);
        __asm
        {
          fld     [esp+0x104+pfVal2]
          fsub    dword ptr [edi+4]
        }
        pfVal2.y = *((float *)&this->m_ptr_20 + 3);
        v100 = *((float *)&this->m_ptr_20 + 4);
        __asm
        {
          fstp    [esp+0x104+pParams]
          fld     dword ptr [edi+8]
          fchs
          fstp    [esp+0x104+var_E4]
        }
        pfVal2.z = v100;
        __asm
        {
          fld     [esp+0x104+var_EC]
          fsub    dword ptr [edi+0x0C]
        }
        // __asm { fstp    [esp+0x104+var_E0] }
        pfVal2 = pParams;
        (((gbVec3D *)&pfVal2))->gbVec3D::Length();
        __asm
        {
          fcomp   _flt_600_0
          fnstsw  ax
        }
        if ( (_AX & 0x4100) == 0 )
          goto LABEL_103;
        if ( *(&this->m_nPauseState + 11) )
          goto LABEL_254;
        __asm
        {
          fld     dword ptr [esi+0x0E0]
          fadd    dword ptr [flt_56AA54]
        }
        // __asm { fstp    [esp+0x10C+fVal]; fVal }
        RoleSystem::StartPathMove(
          v206,
          *((char **)&this->m_nTodo_0F4 + 1),
          *((_DWORD *)&this->m_nTodo_0F4 + 2),
          (char *)this->m_nPauseState,
          *(&this->m_nPauseState + 1),
          fVala,
          (int)_ESI);
      }
      return;
    case 0x10:
      if ( v207 == 1 )
      {
        PalScriptMgr::ClearAllScript();
        if ( !v102 )
        {
LABEL_96:
          (((PalScriptMgr *)v94))->PalScriptMgr::Destroy();
          *(&this->m_nPathStep + 3) = v95;
          v186 = v95;
          fVal = 0;
          goto LABEL_90;
        }
        goto LABEL_254;
      }
      return;
    case 0x11:
      if ( v207 == 2 && this->ScriptVM::IsRunning() )
      {
        (((PalScriptMgr *)_ESI))->PalScriptMgr::CmdPushCmd07(1u);
        *((_BYTE *)&this->m_ptr_20 + 48) = 1;
        goto LABEL_253;
      }
      return;
    case 0x13:
      if ( v207 == 2 && this->ScriptVM::IsRunning() )
      {
        (((ScriptVM *)_ESI))->ScriptVM::SetRolePosition(0);
        (((RoleSystem *)_ESI))->RoleSystem::ExecScriptDataCmd((int *)&this->m_ptr_20 + 2);
        (((PalScriptMgr *)_ESI))->PalScriptMgr::CmdRoleMoveSmooth(0, v187);
        (((PalScriptMgr *)_ESI))->PalScriptMgr::CmdPushCmd07(1u);
        (((PalScriptMgr *)_ESI))->PalScriptMgr::CmdPushCmd10(1u);
        (((ScriptVM *)_ESI))->ScriptVM::SetRolePosition(1u);
        (((ScriptVM *)_ESI))->ScriptVM::CallFunction(1u, 0);
        (((PalScriptMgr *)_ESI))->PalScriptMgr::ExecuteOpcode();
      }
      return;
    case 0x14:
      if ( v207 == 1 )
      {
LABEL_56:
        if ( v2 != -1 )
          *((_BYTE *)&this->m_nTodo_0A8 + 6) = v2 - 1;
        goto LABEL_254;
      }
      return;
    case 0x15:
    case 0x1E:
    case 0x25:
      return;
    case 0x16:
      if ( v207 != 2 )
        return;
      pParams.x = *((float *)&this->m_ptr_20 + 2);
      v103 = *((unsigned __int8 *)&this->m_ptr_20 + 48);
      pParams.y = *((float *)&this->m_ptr_20 + 3);
      pParams.z = *((float *)&this->m_ptr_20 + 4);
      if ( !v103 )
      {
        // __asm { fild    dword ptr [esi+0x0F8] }
        *((_BYTE *)&this->m_ptr_20 + 48) = 1;
        // __asm { fstp    [esp+0x104+var_E4] }
        goto LABEL_119;
      }
      if ( v103 == 2 )
      {
        *((_BYTE *)&this->m_ptr_20 + 48) = 3;
LABEL_119:
        /* [MISATTRIBUTED] PalScriptMgr on ScriptVM::this -> fix IDB name of callee */ PalScriptMgr::RunCommand((PalScriptMgr *)this, 0);
        *((_DWORD *)&this->m_pCmdList + 7) = (((PalScriptMgr *)_ESI))->PalScriptMgr::IsPosInBounds((float *)v206);
        v104 = *((_BYTE *)&this->m_nTodo_0A8 + 6);
        if ( v104 != -1 )
          *((_BYTE *)&this->m_nTodo_0A8 + 6) = v104 - 1;
        v51 = (CScreenMode *)g_pCameraCtrl;
        if ( *((_DWORD *)&g_pCameraCtrl->m_nextYAW + 1) )
          (((CameraCtrl *)&g_pCameraCtrl))->CameraCtrl::InitParams(&pParams);
        goto LABEL_89;
      }
      return;
    case 0x17:
      (((Object3D *)_ESI))->Object3D::SetTransform(&v199);
      __asm
      {
        fld     [esp+0x104+var_50]
        fcomp   [esp+0x104+var_58]
        fnstsw  ax
      }
      if ( (_AX & 0x4100) != 0 )
      {
        // __asm { fld     [esp+0x104+var_58] }
      }
      else
        // __asm { fld     [esp+0x104+var_50] }
      __asm { fmul    _flt_0_5 }
      _EDI = v206;
      _EBP = (float *)(&this->m_ptr_20 + 2);
      __asm
      {
        fstp    [esp+0x104+nSceneIdx]
        fld     dword ptr [ebp+0]
        fsub    dword ptr [edi+0x0A0]
        fstp    [esp+0x104+pParams]
        fld     dword ptr [ebp+4]
        fsub    dword ptr [edi+0x0A4]
      }
      pfVal2.x = pParams.x;
      __asm
      {
        fstp    [esp+0x104+var_E4]
        fld     dword ptr [ebp+8]
        fsub    dword ptr [edi+0x0A8]
      }
      pfVal2.y = pParams.y;
      // __asm { fstp    [esp+0x104+var_E0] }
      pfVal2.z = pParams.z;
      (((gbVec3D *)&pfVal2))->gbVec3D::Length();
      v109 = *((_DWORD *)&this->m_nTodo_0F4 + 2);
      // __asm { fstp    [esp+0x104+var_D0] }
      if ( !v109 )
      {
        if ( v207 != 1 )
          return;
        goto LABEL_143;
      }
      v110 = v109 - 1;
      if ( !v110 )
      {
        if ( v207 != 2 )
          return;
        goto LABEL_143;
      }
      if ( v110 != 1 )
        goto LABEL_143;
      if ( v207 != 1 )
      {
        if ( v207 != 2 )
          return;
LABEL_143:
        if ( !*((_BYTE *)&this->m_ptr_20 + 48) )
        {
          v115 = (((CScreenMode *)v108))->CScreenMode::GetSoundList();
          (((PtrArray *)v115))->PtrArray::SetResolution((int)_ESI, 0);
          if ( v207 == 2 )
          {
            *((_BYTE *)&this->m_nTodo_0A8 + 7) = *((_BYTE *)&this->m_nTodo_0A8 + 7) == 0;
            v116 = *((_DWORD *)&this->m_ptr_20 + 14);
            *((_BYTE *)&this->m_ptr_20 + 48) = 3;
            if ( v116 == 3 )
            {
              (*(void (**)(_DWORD, _DWORD))(**(&this->m_ptr_20 + 15) + 24))(
                *((_DWORD *)&this->m_ptr_20 + 15),
                0);
              (*((gbVisNode **)&this->m_ptr_20 + 15))->gbVisNode::SetTimeScale(2.0);
              (((PalScriptMgr *)_ESI))->PalScriptMgr::RunCommand(0);
            }
            v117 = *((_BYTE *)&this->m_nTodo_0A8 + 6);
            if ( v117 != -1 )
              *((_BYTE *)&this->m_nTodo_0A8 + 6) = v117 - 1;
            if ( *((_DWORD *)&this->m_nTodo_0F4 + 1) == 1 )
              *((_BYTE *)&this->m_nTodo_0A8 + 41) = *((_BYTE *)&this->m_nTodo_0A8 + 7);
          }
          else
          {
            pfVal2.x = *_EBP;
            // __asm { fld     [esp+0x104+pfVal2] }
            // __asm { fsub    dword ptr [edi+0x0A0] }
            v118 = *((float *)&this->m_ptr_20 + 4);
            pfVal2.y = *((float *)&this->m_ptr_20 + 3);
            __asm
            {
              fld     [esp+0x104+var_F0]
              fsub    dword ptr [edi+0x0A4]
            }
            pfVal2.z = v118;
            __asm
            {
              fstp    [esp+0x104+var_F0]
              fld     [esp+0x104+var_EC]
              fsub    dword ptr [edi+0x0A8]
              fstp    [esp+0x104+var_EC]
              fdiv    [esp+0x104+var_D0]
              fstp    [esp+0x104+pfVal2]
              fld     [esp+0x104+var_F0]
              fdiv    [esp+0x104+var_D0]
              fstp    [esp+0x104+var_F0]
              fld     [esp+0x104+var_EC]
              fdiv    [esp+0x104+var_D0]
              fstp    [esp+0x104+var_EC]
              fld     [esp+0x104+var_D0]
              fsub    [esp+0x104+nSceneIdx]
              fld     st
              fmul    [esp+0x104+pfVal2]
              fld     [esp+0x104+var_F0]
              fmul    st, st(2)
              fstp    [esp+0x104+var_F0]
              fld     [esp+0x104+var_EC]
              fmul    st, st(2)
              fstp    [esp+0x104+var_EC]
              fadd    dword ptr [edi+0x0A0]
              fstp    [esp+0x104+pfVal2]
              fld     [esp+0x104+var_F0]
              fadd    dword ptr [edi+0x0A4]
              fstp    [esp+0x104+var_F0]
              fld     [esp+0x104+var_EC]
              fadd    dword ptr [edi+0x0A8]
              fstp    [esp+0x104+var_EC]
              fcomp   _flt_600_0
              fnstsw  ax
            }
            if ( (_AX & 0x100) != 0 )
            {
              v120 = pfVal2.x;
              y = pfVal2.y;
              v122 = pfVal2.z;
              *((_DWORD *)&this->m_ptr_20 + 13) = 0;
              *((float *)&this->m_ptr_20 + 6) = v120;
              *((float *)&this->m_ptr_20 + 7) = y;
              *((float *)&this->m_ptr_20 + 8) = v122;
              v123 = (((CScreenMode *)LODWORD(y)))->CScreenMode::GetSoundList();
              (((PtrArray *)v123))->PtrArray::SetResolution((int)_ESI, 0);
              __asm
              {
                fld     dword ptr [edi+4]
                fsub    dword ptr [ebp+0]
                fstp    [esp+0x104+pParams]
                fld     dword ptr [edi+8]
                fsub    dword ptr [ebp+4]
              }
              pfVal2.x = pParams.x;
              __asm
              {
                fstp    [esp+0x104+var_E4]
                fld     dword ptr [edi+0x0C]
                fsub    dword ptr [ebp+8]
              }
              // __asm { fstp    [esp+0x104+var_E0] }
              pfVal2.y = 0.0;
              pfVal2.z = pParams.z;
              (((gbVec3D *)&pfVal2))->gbVec3D::Length();
              __asm
              {
                fsub    [esp+0x104+nSceneIdx]
                fld     dword ptr [flt_56AB10]
                fadd    st, st
                fsubp   st(1), st
                fcomp   _flt_0_0
                fnstsw  ax
              }
              if ( (_AX & 0x100) != 0 )
              {
                *((_BYTE *)&this->m_ptr_20 + 48) = 2;
                (((RoleSystem *)v206))->RoleSystem::IsPathComplete((float *)&this->m_ptr_20 + 2, 1);
                (((RoleSystem *)v206))->RoleSystem::GetMoveState();
                (((RoleSystem *)v206))->RoleSystem::GetActionByIndex(11);
                (((ScriptVM *)_ESI))->ScriptVM::UpdatePauseState();
              }
              else
              {
                FightInfo();
                (((PalScriptMgr *)_ESI))->PalScriptMgr::CmdRoleMoveDirect(v187);
                (((ScriptVM *)_ESI))->ScriptVM::CallFunction(0x4Du, 0);
                (((PalScriptMgr *)_ESI))->PalScriptMgr::ExecuteOpcode();
              }
            }
          }
        }
        return;
      }
      if ( v206->m_partyActor.m_nState != *(&this->m_nTodo_0F4 + 2) )
        goto LABEL_103;
      __asm
      {
        fld     [esp+0x104+var_D0]
        fcomp   dword ptr [flt_56AB40]
        fnstsw  ax
      }
      if ( (_AX & 0x100) == 0
        || !(((PalScriptMgr *)_ESI))->PalScriptMgr::CmdUpdateRolePath((float *)&v206->m_fontcolor.Color, (float *)&this->m_ptr_20 + 2) )
      {
LABEL_103:
        v84 = (((PalScript *)g_PAL3_Instance.m_nTodo_140))->PalScript::SetAppName("outdist");
        goto LABEL_179;
      }
      PalScriptMgr::ClearAllScript();
      if ( !v113 )
      {
        (((PalScriptMgr *)v112))->PalScriptMgr::Destroy();
        *(&this->m_nPathStep + 3) = v114;
      }
      return;
    case 0x18:
      if ( v207 == 11 )
      {
        g_RoleSystemExtra1.m_partyActor.m_pRoleObj = (char *)1;
        RoleSystem::GetActionByIndex(&g_RoleSystemExtra1, 51);
        RoleSystem::NotifySceneChange(&g_RoleSystemExtra1);
        g_RoleSystemExtra1.RoleSystem::SetTargetRotation((gbVec3D *)(&this->m_ptr_20 + 2));
        (((PalScriptMgr *)_ESI))->PalScriptMgr::CmdPushCmd15(0);
        (((PalScriptMgr *)_ESI))->PalScriptMgr::CmdCameraOrbitPos(*((_DWORD *)&this->m_ptr_20 + 2), *((float *)&this->m_ptr_20 + 3), *((float *)&this->m_ptr_20 + 4), 1u);
        (((PalScriptMgr *)_ESI))->PalScriptMgr::CmdCameraOrbitPos(*(_DWORD *)(((RoleSystem *)&stru_C10DF0)->m_teamSlotOverlay.m_teamSlots[154] + 160), *(float *)(((RoleSystem *)&stru_C10DF0)->m_teamSlotOverlay.m_teamSlots[154] + 164), *(float *)(((RoleSystem *)&stru_C10DF0)->m_teamSlotOverlay.m_teamSlots[154] + 168), 0);
        (((RoleSystem *)_ESI))->RoleSystem::ExecScriptDataIdx(1065353216);
        (((PalScriptMgr *)_ESI))->PalScriptMgr::CmdPushCmd15(1u);
        (((ScriptVM *)_ESI))->ScriptVM::CallFunction(0xBu, 0);
        (((PalScriptMgr *)_ESI))->PalScriptMgr::ExecuteOpcode();
        return;
      }
      if ( v207 != 1 || *((_BYTE *)&this->m_ptr_20 + 48) )
        return;
      (*((PalScriptMgr **)&this->m_nPauseState + 11))->PalScriptMgr::Destroy();
      *(&this->m_nPathStep + 3) = v125;
      if ( !v125 )
        goto LABEL_245;
LABEL_238:
      *((_BYTE *)&this->m_ptr_20 + 48) = 1;
      goto LABEL_254;
    case 0x1A:
      if ( v207 != 1 || *((_BYTE *)&this->m_ptr_20 + 48) )
        return;
      (((PalScriptMgr *)_ESI))->PalScriptMgr::BuildCmdTransform(&pMatrix);
      __asm
      {
        fld     [esp+0x104+var_C]
        fmul    _flt_0_5
      }
      _EDI = &this->m_ptr_20 + 2;
      pParams.y = 0.0;
      _EBP = v206;
      __asm
      {
        fstp    [esp+0x104+nSceneIdx]
        fld     dword ptr [esi+0x0E0]
        fmul    _flt_0_01745329f
      }
      pfVal2 = *(gbVec3D *)(&this->m_ptr_20 + 2);
      __asm
      {
        fld     st
        fcos
      }
      __asm
      {
        fchs
        fstp    [esp+0x104+var_C4]
        fsin
        fld     _flt_12_0
        fadd    st, st
        fadd    [esp+0x104+nSceneIdx]
        fld     [esp+0x104+var_C4]
        fmul    st, st(1)
        fstp    [esp+0x104+pParams]
        fxch    st(1)
        fmul    st, st(1)
        fxch    st(1)
        fstp    st
        fld     [esp+0x104+pParams]
        fadd    [esp+0x104+pfVal2]
        fstp    [esp+0x104+pfVal2]
        fld     [esp+0x104+var_F0]
        fadd    [esp+0x104+var_E4]
        fstp    [esp+0x104+var_F0]
        fld     [esp+0x104+var_EC]
        fadd    st, st(1)
        fstp    [esp+0x104+var_EC]
        fstp    st
        fld     dword ptr [edi]
        fsub    dword ptr [ebp+0x0A0]
        fstp    [esp+0x104+pParams]
        fld     dword ptr [edi+4]
        fsub    dword ptr [ebp+0x0A4]
      }
      v193.x = pParams.x;
      __asm
      {
        fstp    [esp+0x104+var_E4]
        fld     dword ptr [edi+8]
        fsub    dword ptr [ebp+0x0A8]
      }
      v193.y = pParams.y;
      // __asm { fstp    [esp+0x104+var_E0] }
      v193.z = pParams.z;
      (((gbVec3D *)&v193))->gbVec3D::Length();
      __asm
      {
        fcomp   _flt_600_0
        fnstsw  ax
      }
      if ( (_AX & 0x100) == 0
        || !(((PalScriptMgr *)_ESI))->PalScriptMgr::CmdUpdateRolePath((float *)&v206->m_fontcolor.Color, &pfVal2.x) )
      {
        goto LABEL_249;
      }
      v129 = pfVal2.x;
      v130 = pfVal2.y;
      v131 = pfVal2.z;
      *((_DWORD *)&this->m_ptr_20 + 13) = 0;
      *((float *)&this->m_ptr_20 + 6) = v129;
      *((float *)&this->m_ptr_20 + 7) = v130;
      *((float *)&this->m_ptr_20 + 8) = v131;
      __asm
      {
        fld     dword ptr [ebp+4]
        fsub    dword ptr [edi]
        fstp    [esp+0x104+pParams]
        fld     dword ptr [ebp+8]
        fsub    dword ptr [edi+4]
      }
      v193.x = pParams.x;
      __asm
      {
        fstp    [esp+0x104+var_E4]
        fld     dword ptr [ebp+0x0C]
        fsub    dword ptr [edi+8]
      }
      // __asm { fstp    [esp+0x104+var_E0] }
      v193.y = 0.0;
      v193.z = pParams.z;
      (((gbVec3D *)&v193))->gbVec3D::Length();
      __asm
      {
        fsub    [esp+0x104+nSceneIdx]
        fld     dword ptr [flt_56AB10]
        fadd    st, st
        fsubp   st(1), st
        fcomp   _flt_0_0
        fnstsw  ax
      }
      if ( (_AX & 0x100) != 0 )
      {
        *((_BYTE *)&this->m_ptr_20 + 48) = 2;
        (((RoleSystem *)v206))->RoleSystem::IsPathComplete((float *)&this->m_ptr_20 + 2, 1);
        (((RoleSystem *)v206))->RoleSystem::GetMoveState();
        (((RoleSystem *)v206))->RoleSystem::GetActionByIndex(11);
        goto LABEL_254;
      }
      FightInfo();
      (((ScriptVM *)_ESI))->ScriptVM::CallFunction(2u, 0);
      goto LABEL_247;
    case 0x1B:
      if ( v207 != 1 || *((_BYTE *)&this->m_ptr_20 + 48) )
        return;
      __asm
      {
        fld     dword ptr [esi+0x218]
        fadd    dword ptr [esi+0x224]
        fld     dword ptr [esi+0x228]
        fadd    dword ptr [esi+0x21C]
      }
      _EDI = v206;
      __asm
      {
        fstp    [esp+0x104+var_E4]
        fld     dword ptr [esi+0x22C]
        fadd    dword ptr [esi+0x220]
        fstp    [esp+0x104+var_E0]
        fmul    _flt_0_5
        fstp    [esp+0x104+pfVal2]
        fld     [esp+0x104+var_E4]
        fmul    _flt_0_5
        fstp    [esp+0x104+var_F0]
        fld     [esp+0x104+var_E0]
        fmul    _flt_0_5
        fstp    [esp+0x104+var_EC]
        fld     [esp+0x104+pfVal2]
        fsub    dword ptr [edi+0x0A0]
        fstp    [esp+0x104+pParams]
        fld     [esp+0x104+var_F0]
        fsub    dword ptr [edi+0x0A4]
      }
      nSceneIdx.x = pParams.x;
      __asm
      {
        fstp    [esp+0x104+var_E4]
        fld     [esp+0x104+var_EC]
        fsub    dword ptr [edi+0x0A8]
      }
      nSceneIdx.y = pParams.y;
      // __asm { fstp    [esp+0x104+var_E0] }
      nSceneIdx.z = pParams.z;
      (((gbVec3D *)&nSceneIdx))->gbVec3D::Length();
      __asm
      {
        fcomp   _flt_100_0
        fnstsw  ax
      }
      if ( (_AX & 0x100) != 0 )
      {
        *((_DWORD *)&this->m_ptr_20 + 13) = 0;
        *((_BYTE *)&this->m_ptr_20 + 48) = 1;
        v136 = (((CScreenMode *)v134))->CScreenMode::GetSoundList();
        (((PtrArray *)v136))->PtrArray::SetResolution((int)_ESI, 0);
        (((RoleSystem *)v206))->RoleSystem::IsPathComplete(&pfVal2.x, 1);
        (((RoleSystem *)v206))->RoleSystem::GetActionByIndex(11);
      }
      goto LABEL_254;
    case 0x1C:
      if ( v207 != 2 )
        return;
      if ( *((_DWORD *)&this->m_nTodo_0F4 + 1) == 1 )
      {
        v137 = *((_BYTE *)&this->m_nTodo_0A8 + 7) == 0;
        *((_BYTE *)&this->m_nTodo_0A8 + 7) = v137;
        *((_BYTE *)&this->m_nTodo_0A8 + 41) = v137;
      }
      goto LABEL_254;
    case 0x1D:
      if ( v207 || !this->ScriptVM::IsRunning() )
        return;
      if ( SceneMgr::GetValidPartyCount() >= *((_DWORD *)&this->m_nTodo_0F4 + 1) )
      {
        _EDI = (float *)(&this->m_ptr_20 + 2);
        pfVal2.x = *((float *)&this->m_ptr_20 + 2);
        pfVal2.y = *((float *)&this->m_ptr_20 + 3);
        _EAX = v206;
        v140 = *((float *)&this->m_ptr_20 + 4);
        pfVal2.y = 0.0;
        __asm
        {
          fld     dword ptr [eax+4]
          fsub    [esp+0x104+pfVal2]
        }
        pfVal2.z = v140;
        __asm
        {
          fstp    [esp+0x104+pParams]
          fld     dword ptr [eax+8]
          fstp    [esp+0x104+var_E4]
          fld     dword ptr [eax+0x0C]
          fsub    [esp+0x104+var_EC]
        }
        // __asm { fstp    [esp+0x104+var_E0] }
        nSceneIdx = pParams;
        (((gbVec3D *)&nSceneIdx))->gbVec3D::Length();
        __asm
        {
          fld     _flt_12_0
          fmul    _flt_3_0
          fcompp
          fnstsw  ax
        }
        if ( (_AX & 0x100) == 0 )
        {
          (((ScriptVM *)_ESI))->ScriptVM::SetRolePosition(0);
          FightInfo();
          (((PalScriptMgr *)_ESI))->PalScriptMgr::CmdRoleMoveSmooth(1, v187);
          (((PalScriptMgr *)_ESI))->PalScriptMgr::CmdPushCmd07(1u);
          (((ScriptVM *)_ESI))->ScriptVM::CallFunction(1u, 0);
          __asm
          {
            fld     dword ptr [edi+4]
            fsub    _flt_7_0
          }
          v142 = *((float *)&this->m_ptr_20 + 4);
          pfVal2.x = *_EDI;
          pfVal2.z = v142;
          // __asm { fstp    [esp+0x108+var_F0] }
          (((PalScriptMgr *)_ESI))->PalScriptMgr::CmdRoleMoveSmooth(0, v188);
          (((ScriptVM *)_ESI))->ScriptVM::ExecuteOpcode(&pfVal2, 0, 0);
          (((PalScriptMgr *)_ESI))->PalScriptMgr::CmdPushCmd05(0);
          (((ScriptVM *)_ESI))->ScriptVM::SetRolePosition(1u);
LABEL_253:
          (((PalScriptMgr *)_ESI))->PalScriptMgr::ExecuteOpcode();
LABEL_254:
          (*((PalScriptMgr **)&this->m_nPauseState + 11))->PalScriptMgr::Destroy();
        }
      }
      else
      {
        v84 = (((PalScript *)g_PAL3_Instance.m_nTodo_140))->PalScript::SetAppName("lessweight");
LABEL_179:
        (((PalScriptMgr *)&stru_DBA134))->PalScriptMgr::ShowTextBox(v84);
      }
      return;
    case 0x1F:
      if ( v207 != 2 || *((_BYTE *)&this->m_ptr_20 + 48) )
        return;
      __asm
      {
        fild    dword ptr [esi+0x0F8]
        fld     dword ptr [esi+0x28]
        fstp    [esp+0x104+pData]
      }
      __asm
      {
        fst     [esp+0x10C+var_AC]
        fld     dword ptr [esi+0x30]
        fstp    [esp+0x10C+var_A8]
      }
      // __asm { fsub    dword ptr [esi+0x2C] }
      __asm
      {
        fabs
        fmul    _flt_0_25
        fstp    dword ptr [esp+0x110+nType]; nType
      }
      ScriptVM::ExecuteOpcode(this, pData, LOBYTE(nType), 0);
      (((PalScriptMgr *)_ESI))->PalScriptMgr::CmdPushCmd05(0);
      (((ScriptVM *)_ESI))->ScriptVM::CallFunction(1u, 0);
      (((PalScriptMgr *)_ESI))->PalScriptMgr::RunCommand(0);
      goto LABEL_253;
    case 0x20:
      if ( v207 || *((_BYTE *)&this->m_ptr_20 + 48) )
        return;
      *((_BYTE *)&this->m_ptr_20 + 48) = 1;
      (((UIBigMap *)v206))->UIBigMap::Update((int *)&this->m_ptr_20 + 2, 1);
      (((PalScriptMgr *)_ESI))->PalScriptMgr::RunCommand(0);
      goto LABEL_254;
    case 0x21:
      if ( !v208 && !v207 && this->ScriptVM::IsRunning() )
      {
        __asm
        {
          fld     dword ptr [esi+0x2C]
          fsub    _flt_5_0
        }
        _EDI = &this->m_ptr_20 + 2;
        // __asm { fstp    [esp+0x110+nSceneIdx] }
        FightInfo();
        __asm { fld     dword ptr [edi] }
        __asm
        {
          fstp    [esp+0x104+var_A4]
          fld     dword ptr [esi+0x30]
        }
        v198[1] = nSceneIdx.x;
        // __asm { fstp    [esp+0x110+var_9C] }
        (((ScriptVM *)_ESI))->ScriptVM::ExecuteOpcode(v198, 0, 0);
        (((PalScriptMgr *)_ESI))->PalScriptMgr::CmdPushCmd04(*(&this->m_nPauseState + 11), 0);
        (((PalScriptMgr *)_ESI))->PalScriptMgr::CmdPushCmd05(0);
        v144 = *((_BYTE *)&this->m_nTodo_0A8 + 6);
        if ( v144 != -1 )
          *((_BYTE *)&this->m_nTodo_0A8 + 6) = v144 - 1;
        (((PalScriptMgr *)_ESI))->PalScriptMgr::ExecuteOpcode();
LABEL_89:
        v186 = 0;
        fVal = (int)_ESI;
LABEL_90:
        v92 = (((CScreenMode *)v51))->CScreenMode::GetSoundList();
        (((PtrArray *)v92))->PtrArray::SetResolution(fVal, v186);
      }
      return;
    case 0x22:
      if ( v207 == 2 && this->ScriptVM::IsRunning() )
      {
        __asm
        {
          fld     _flt_12_0
          fmul    dword ptr [flt_56AA3C]
        }
        nSceneIdx.x = *((float *)&this->m_nTodo_0F4 + 1);
        if ( SLODWORD(nSceneIdx.x) > 0 )
        {
          __asm
          {
            fstp    st
            fild    [esp+0x104+nSceneIdx]
          }
        }
        __asm
        {
          fld     dword ptr [esi+0x0E0]
          fcos
        }
        pfVal2.y = 0.0;
        __asm
        {
          fld     dword ptr [esi+0x0E0]
          fsin
          fstp    [esp+0x108+var_EC]
          fld     st(1)
          fmul    st, st(1)
          fstp    [esp+0x108+pfVal2]
          fstp    st
          fmul    [esp+0x108+var_EC]
          fld     [esp+0x108+pfVal2]
          fadd    dword ptr [esi+0x28]
          fstp    [esp+0x108+pfVal2]
          fld     [esp+0x108+var_F0]
          fadd    dword ptr [esi+0x2C]
          fstp    [esp+0x108+var_F0]
          fadd    dword ptr [esi+0x30]
          fstp    [esp+0x108+var_EC]
        }
        (((ScriptVM *)_ESI))->ScriptVM::GetRolePosition(1u);
        (((ScriptVM *)_ESI))->ScriptVM::ExecuteOpcode(&pfVal2, 0, 0);
        (((ScriptVM *)_ESI))->ScriptVM::GetRolePosition(0);
        (((PalScriptMgr *)_ESI))->PalScriptMgr::CmdPushCmd05(0);
        v145 = *((_BYTE *)&this->m_nTodo_0A8 + 6);
        if ( v145 != -1 )
          *((_BYTE *)&this->m_nTodo_0A8 + 6) = v145 - 1;
        (((PalScriptMgr *)_ESI))->PalScriptMgr::RunCommand(0);
        (((PalScriptMgr *)_ESI))->PalScriptMgr::ExecuteOpcode();
      }
      return;
    case 0x23:
      if ( !v207 && this->ScriptVM::IsRunning() )
      {
        (((RoleSystem *)_ESI))->RoleSystem::ExecScriptDataA();
        (((PalScriptMgr *)_ESI))->PalScriptMgr::CmdPushCmd04(*(&this->m_nPauseState + 11), 1u);
        v147 = (((CScreenMode *)v146))->CScreenMode::GetSoundList();
        (((PtrArray *)v147))->PtrArray::SetResolution((int)_ESI, 0);
        (((PalScriptMgr *)_ESI))->PalScriptMgr::ExecuteOpcode();
      }
      return;
    case 0x24:
      if ( (!v207 || v207 == 2) && this->ScriptVM::IsRunning() )
      {
        (((RoleSystem *)((RoleSystem *)&stru_C10DF0)->m_teamSlotOverlay.m_teamSlots[154]))->RoleSystem::Notify();
        (((RoleSystem *)_ESI))->RoleSystem::ExecScriptDataB();
        (((ScriptVM *)_ESI))->ScriptVM::CallFunction(1u, 1);
        (((ScriptVM *)_ESI))->ScriptVM::GetRolePosition(0);
        (((PalScriptMgr *)_ESI))->PalScriptMgr::CmdPushCmd10(0);
        (((PalScriptMgr *)_ESI))->PalScriptMgr::CmdPushCmd04(*(&this->m_nPauseState + 11), 0);
        (((PalScriptMgr *)_ESI))->PalScriptMgr::RunCommand(0);
        (((PalScriptMgr *)_ESI))->PalScriptMgr::ExecuteOpcode();
        v149 = (((CScreenMode *)v148))->CScreenMode::GetSoundList();
        (((PtrArray *)v149))->PtrArray::SetResolution((int)_ESI, 0);
        (((PalScriptMgr *)_ESI))->PalScriptMgr::ExecuteScriptByID();
      }
      return;
    case 0x26:
      if ( !this->ScriptVM::IsRunning() )
        return;
      if ( v207 )
      {
        if ( v207 != 3 || !*((_DWORD *)&this->m_nTodo_0F4 + 2) )
          return;
        *((_DWORD *)&this->m_ptr_20 + 13) = 0;
        pParams = *(gbVec3D *)(&this->m_ptr_20 + 2);
        __asm
        {
          fld     [esp+0x108+var_E4]
          fsub    _flt_200_0
        }
        // __asm { fstp    [esp+0x108+var_E4] }
        (((ScriptVM *)_ESI))->ScriptVM::SetRolePosition(0);
        FightInfo();
        (((ScriptVM *)_ESI))->ScriptVM::ExecuteOpcode(&pParams, 0, 1);
        (((PalScriptMgr *)_ESI))->PalScriptMgr::CmdPushCmd04(*((_DWORD *)&this->m_nTodo_0F4 + 2), 0);
      }
      else
      {
        if ( !*((_DWORD *)&this->m_nTodo_0F4 + 1) )
          return;
        if ( !v208 )
          return;
        __asm
        {
          fld     [esp+0x104+arg_C]
          fadd    dword ptr [esi+0x54]
          fst     dword ptr [esi+0x54]
        }
        *((float *)&this->m_ptr_20 + 13) = _ET1;
        __asm
        {
          fcomp   _flt_4_0
          fnstsw  ax
        }
        if ( (_AX & 0x100) != 0 )
          return;
        *((_DWORD *)&this->m_ptr_20 + 13) = 0;
        pParams = *(gbVec3D *)(&this->m_ptr_20 + 2);
        __asm
        {
          fld     [esp+0x108+var_E4]
          fadd    _flt_200_0
        }
        // __asm { fstp    [esp+0x108+var_E4] }
        (((ScriptVM *)_ESI))->ScriptVM::SetRolePosition(0);
        FightInfo();
        (((ScriptVM *)_ESI))->ScriptVM::ExecuteOpcode(&pParams, 0, 1);
        (((PalScriptMgr *)_ESI))->PalScriptMgr::CmdPushCmd04(*((_DWORD *)&this->m_nTodo_0F4 + 1), 0);
      }
      (((ScriptVM *)_ESI))->ScriptVM::SetRolePosition(1u);
      (((PalScriptMgr *)_ESI))->PalScriptMgr::ExecuteOpcode();
      return;
    case 0x27:
      if ( !this->ScriptVM::IsRunning() )
        return;
      _EDI = (_DWORD *)(*((RoleSystem **)this->m_pCmdList + 4))->RoleSystem::GetRolePtr(*(&this->m_nTodo_0F4 + 2));
      v153 = *((_DWORD *)&this->m_nTodo_0E0 + 1) + *((_DWORD *)&this->m_nTodo_0E0 + 3);
      __asm { fld     _flt_0_0 }
      LODWORD(v153) = v153 - HIDWORD(v153);
      HIDWORD(v153) = *((_DWORD *)&this->m_nTodo_0E0 + 2);
      v154 = v153;
      LODWORD(v153) = *((_DWORD *)&this->m_nTodo_0E0 + 4);
      v155 = v154 >> 1;
      LODWORD(nSceneIdx.x) = v155;
      // __asm { fild    [esp+0x104+nSceneIdx] }
      __asm { fadd    _flt_0_5 }
      v156 = (HIDWORD(v153) + (int)v153) / 2;
      __asm { fmul    g_fScriptTileSize }
      LODWORD(nSceneIdx.y) = v156;
      __asm
      {
        fadd    dword ptr [edi+0x80]
        fstp    [esp+0x104+pParams]
        fild    [esp+0x104+var_D8]
        fadd    _flt_0_5
        fmul    g_fScriptTileSize
        fadd    dword ptr [edi+0x88]
        fstp    [esp+0x104+var_E0]
      }
      if ( v155 >= 0 )
      {
        v157 = _EDI[38];
        if ( v155 < v157 && v156 >= 0 && v156 < _EDI[39] )
        {
          __asm { fstp    st }
          _EAX = v155 + v157 * v156;
          _ECX = _EDI[40];
          __asm { fld     dword ptr [ecx+eax*8] }
        }
      }
      v160 = pParams.x;
      v161 = pParams.z;
      // __asm { fstp    dword ptr [esi+0x2C] }
      *((float *)&this->m_ptr_20 + 3) = _ET1;
      *((float *)&this->m_ptr_20 + 2) = v160;
      *((float *)&this->m_ptr_20 + 4) = v161;
      pfVal2.x = *((float *)&this->m_ptr_20 + 2);
      pfVal2.y = *((float *)&this->m_ptr_20 + 3);
      v180 = *((_DWORD *)&this->m_nTodo_0F4 + 1);
      pfVal2.z = *((float *)&this->m_ptr_20 + 4);
      (*((RoleSystem **)this->m_pCmdList + 4))->RoleSystem::SetRoleParam(v180, &pfVal2.x, 0, 0);
      __asm
      {
        fst     [esp+0x104+var_F0]
        fstp    [esp+0x104+var_CC]
        fld     [esp+0x104+var_EC]
        fadd    _flt_80_0
      }
      v193.x = pfVal2.x;
      // __asm { fstp    [esp+0x110+var_C8] }
      FightInfo();
      (((PalScriptMgr *)_ESI))->PalScriptMgr::CmdRoleMoveSmooth(0, v187);
      (((ScriptVM *)_ESI))->ScriptVM::ExecuteOpcode(&pfVal2, 0, 1);
      (((PalScriptMgr *)_ESI))->PalScriptMgr::CmdPushCmd14(*((_DWORD *)&this->m_nTodo_0F4 + 1), 0);
      FightInfo();
      goto LABEL_247;
    case 0x28:
      if ( !this->ScriptVM::IsRunning() || v207 )
        return;
      LODWORD(nSceneIdx.x) = (*(&this->m_nTodo_0F4 + 2) + 1) % 2;
      if ( LODWORD(nSceneIdx.x) )
      {
        v163 = *(float *)&this->m_nPauseState;
        v164 = *((float *)&this->m_nPauseState + 1);
      }
      else
      {
        v163 = *((float *)&this->m_nTodo_0F4 + 1);
        v164 = *((float *)&this->m_nTodo_0F4 + 2);
      }
      v193.x = v163;
      m_pCmdList = (RoleSystem **)this->m_pCmdList;
      v193.y = v164;
      _EAX = (_DWORD *)(((RoleSystem *)m_pCmdList[4]))->RoleSystem::GetRolePtr(SLODWORD(nSceneIdx.x));
      // __asm { fild    [esp+0x104+var_D0] }
      pfVal2.y = 0.0;
      __asm
      {
        fadd    _flt_0_5
        fmul    g_fScriptTileSize
        fadd    dword ptr [eax+0x80]
        fstp    [esp+0x104+pfVal2]
        fild    [esp+0x104+var_CC]
        fadd    _flt_0_5
        fmul    g_fScriptTileSize
        fadd    dword ptr [eax+0x88]
        fstp    [esp+0x104+var_EC]
      }
      if ( v163 >= 0.0 )
      {
        v167 = _EAX[38];
        if ( SLODWORD(v163) < v167 && v164 >= 0.0 && SLODWORD(v164) < _EAX[39] )
        {
          _EAX = _EAX[40];
          _EDX = LODWORD(v163) + v167 * LODWORD(v164);
          __asm
          {
            fld     dword ptr [eax+edx*8]
            fstp    [esp+0x104+var_F0]
          }
        }
      }
      v194 = pfVal2;
      pParams.x = *((float *)&this->m_ptr_20 + 2);
      v170 = (Scene **)this->m_pCmdList;
      nTypea = LODWORD(v163);
      x_low = LODWORD(nSceneIdx.x);
      v172 = *((float *)&this->m_ptr_20 + 4);
      pParams.y = *((float *)&this->m_ptr_20 + 3);
      pParams.z = v172;
      (((Scene *)v170[4]))->Scene::GetTileHeight(SLODWORD(nSceneIdx.x), nTypea, SLODWORD(v164), 0);
      // __asm { fstp    [esp+0x104+var_E4] }
      (((PalScriptMgr *)_ESI))->PalScriptMgr::BuildCmdTransform(&pMatrix);
      __asm
      {
        fld     [esp+0x104+var_8]
        fadd    [esp+0x104+var_E4]
      }
      // __asm { fstp    [esp+0x108+var_E4] }
      (((ScriptVM *)_ESI))->ScriptVM::SetRolePosition(0);
      FightInfo();
      (((ScriptVM *)_ESI))->ScriptVM::ExecuteOpcode(&pParams, 0, 1);
      (((ScriptVM *)_ESI))->ScriptVM::GetRolePosition(1u);
      (((PalScriptMgr *)_ESI))->PalScriptMgr::CmdPushCmd14(x_low, 1u);
      (((ScriptVM *)_ESI))->ScriptVM::GetRolePosition(0);
      FightInfo();
      (((ScriptVM *)_ESI))->ScriptVM::SetRolePosition(1u);
      goto LABEL_253;
    case 0x29:
      if ( !this->ScriptVM::IsRunning() )
        return;
      if ( v207 == 10 )
        goto LABEL_238;
      FightInfo();
      (((PalScriptMgr *)_ESI))->PalScriptMgr::CmdRoleMoveDirect(v187);
      (((PalScriptMgr *)_ESI))->PalScriptMgr::CmdRoleMoveSmooth(0, v189);
      (((PalScriptMgr *)_ESI))->PalScriptMgr::CmdPushCmd07(1u);
      goto LABEL_246;
    case 0x2A:
      if ( v207 != 1 )
        return;
      if ( !this->ScriptVM::IsRunning() )
        return;
      _EAX = ((RoleSystem *)&stru_C10DF0)->m_teamSlotOverlay.m_teamSlots[154];
      if ( *(&this->m_nTodo_0F4 + 2) != *(_DWORD *)(((RoleSystem *)&stru_C10DF0)->m_teamSlotOverlay.m_teamSlots[154] + 628) )
        return;
      __asm
      {
        fld     dword ptr [esi+0x28]
        fsub    dword ptr [eax+0x0A0]
        fstp    [esp+0x104+pParams]
        fld     dword ptr [esi+0x2C]
        fsub    dword ptr [eax+0x0A4]
      }
      v194.x = pParams.x;
      __asm
      {
        fstp    [esp+0x104+var_E4]
        fld     dword ptr [esi+0x30]
        fsub    dword ptr [eax+0x0A8]
      }
      v194.y = pParams.y;
      // __asm { fstp    [esp+0x104+var_E0] }
      v194.z = pParams.z;
      (((gbVec3D *)&v194))->gbVec3D::Length();
      __asm
      {
        fcomp   _flt_600_0
        fnstsw  ax
      }
      if ( (_AX & 0x100) != 0 )
      {
        v175 = *((float *)&this->m_ptr_20 + 4);
        _EAX = ((RoleSystem *)&stru_C10DF0)->m_teamSlotOverlay.m_teamSlots[154];
        nSceneIdx.x = *((float *)&this->m_ptr_20 + 2);
        // __asm { fld     [esp+0x104+nSceneIdx] }
        nSceneIdx.z = v175;
        nSceneIdx.y = 0.0;
        __asm
        {
          fsub    dword ptr [eax+4]
          fld     dword ptr [eax+8]
          fchs
          fstp    [esp+0x104+var_C0]
          fld     [esp+0x104+var_D4]
          fsub    dword ptr [eax+0x0C]
        }
        // __asm { fstp    [esp+0x104+var_BC] }
        nSceneIdx.y = v194.y;
        // __asm { fstp    [esp+0x104+nSceneIdx] }
        nSceneIdx.z = v194.z;
        (((gbVec3D *)&nSceneIdx))->gbVec3D::Length();
        __asm
        {
          fld     [esp+0x104+nSceneIdx]
          fdiv    st, st(1)
        }
        _EAX = ((RoleSystem *)&stru_C10DF0)->m_teamSlotOverlay.m_teamSlots[154];
        __asm
        {
          fstp    [esp+0x10C+nSceneIdx]
          fld     [esp+0x10C+var_D8]
          fdiv    st, st(1)
          fstp    [esp+0x10C+var_D8]
          fld     [esp+0x10C+var_D4]
          fdiv    st, st(1)
          fstp    [esp+0x10C+var_D4]
          fsub    dword ptr [flt_56AB44]
          fld     st
          fmul    [esp+0x10C+nSceneIdx]
          fstp    [esp+0x10C+nSceneIdx]
          fld     st
          fmul    [esp+0x10C+var_D8]
          fstp    [esp+0x10C+var_D8]
          fmul    [esp+0x10C+var_D4]
          fstp    [esp+0x10C+var_D4]
          fld     [esp+0x10C+nSceneIdx]
          fadd    dword ptr [eax+4]
          fld     [esp+0x10C+var_D8]
          fadd    dword ptr [eax+8]
          fstp    [esp+0x10C+var_C0]
          fld     [esp+0x10C+var_D4]
          fadd    dword ptr [eax+0x0C]
        }
        nSceneIdx.y = v194.y;
        // __asm { fstp    [esp+0x110+var_BC] }
        // __asm { fstp    [esp+0x110+nSceneIdx] }
        nSceneIdx.z = v194.z;
LABEL_245:
        FightInfo();
        (((PalScriptMgr *)_ESI))->PalScriptMgr::CmdRoleMoveDirect(v187);
LABEL_246:
        (((ScriptVM *)_ESI))->ScriptVM::CallFunction(1u, 0);
LABEL_247:
        (((PalScriptMgr *)_ESI))->PalScriptMgr::ExecuteOpcode();
LABEL_248:
        v178 = (((CScreenMode *)v37))->CScreenMode::GetSoundList();
        (((PtrArray *)v178))->PtrArray::SetResolution((int)_ESI, 0);
      }
      else
      {
LABEL_249:
        v179 = (((PalScript *)g_PAL3_Instance.m_nTodo_140))->PalScript::SetAppName("outdist");
        (((PalScriptMgr *)&stru_DBA134))->PalScriptMgr::ShowTextBox(v179);
      }
      goto LABEL_254;
    default:
      goto LABEL_254;
  }
}

// 0x0042C1A0
BOOL ScriptVM::IsRunning()
{
  return !this->m_nPathStep && !*((_BYTE *)&this->m_ptr_20 + 48);
}

// 0x0042C730
gbVFileSystem * ScriptVM::OpenSceneScript()
{
  const char *v2; // eax
  const char *v3; // edi
  gbVFileSystem *result; // eax
  OpenSceneFile v5; // [esp+0xC] [ebp-0x114] BYREF
  char Buffer[260]; // [esp+0x10] [ebp-0x110] BYREF
  int v7; // [esp+0x11C] [ebp-0x4]

  v2 = (const char *)UISceneUpdate();
  sprintf(Buffer, "%s%s", "scene\\", v2);
  v7 = 0;
  v3 = a4CCvd;
  if ( !(_BYTE)g_ScriptSystemData.m_nScriptFlag )
    v3 = a4C1Cvd;
  strcpy(Buffer, v3);
  (((GeomNode *)(&this->m_ptr_20 + 14)))->GeomNode::InitFromFile((const gbGeomNode *)Buffer, 0);
  (*(void ( **)(_DWORD, _DWORD))(**(&this->m_ptr_20 + 15) + 24))(*((_DWORD *)&this->m_ptr_20 + 15), 0);
  (*((gbVisNode **)&this->m_ptr_20 + 15))->gbVisNode::SetTimeScale(0.0);
  v7 = -1;
  (((OpenSceneFile *)&v5))->OpenSceneFile::~OpenSceneFile();
  return result;
}

// 0x0042C810
char ScriptVM::UpdatePauseState()
{
  char v1; // al
  int m_nPauseState; // edx
  int v3; // eax
  int v4; // ebp
  int v5; // edi
  PalScriptMgr *v6; // esi

  v1 = *((_BYTE *)&this->m_nTodo_0A8 + 6);
  if ( v1 != -1 )
    *((_BYTE *)&this->m_nTodo_0A8 + 6) = v1 - 1;
  m_nPauseState = this->m_nPauseState;
  LOBYTE(v3) = *((_BYTE *)&this->m_nTodo_0A8 + 7) == 0;
  *((_BYTE *)&this->m_nTodo_0A8 + 7) = v3;
  if ( m_nPauseState == 1 )
  {
    LOBYTE(g_ScriptSystemData.m_nScriptFlag) = (_BYTE)v3 == 0;
    v4 = 0;
    v5 = *((_DWORD *)this->m_pCmdList + 4);
    v3 = *(_DWORD *)(v5 + 220);
    if ( v3 > 0 )
    {
      v6 = (PalScriptMgr *)(v5 + 224);
      do
      {
        if ( v6->m_nCmdType == 37 )
          (((PalScriptMgr *)v6))->PalScriptMgr::LoadSceneGeometry(g_ScriptSystemData.m_nScriptFlag);
        v3 = *(_DWORD *)(v5 + 220);
        ++v4;
        v6 = (PalScriptMgr *)((char *)v6 + 896);
      }
      while ( v4 < v3 );
    }
  }
  return v3;
}

// 0x0042C950
int ScriptVM::ExecuteOpcode(void *pData, unsigned __int8 nType, int nCount)
{
  int v5; // ecx
  int v6; // edx
  int v7; // eax
  int *p_m_nPathMode; // ebx
  int v9; // edx
  int v10; // eax
  int m_nPathStep; // eax
  char *m_ptr_358; // edi
  float m_fPathEndY; // ecx
  int result; // eax
  void *v15; // esi
  _DWORD *v16; // eax
  float x; // eax
  float v18; // edx
  float v19; // ecx
  int v20; // esi
  unsigned int v21; // eax
  _DWORD *v22; // eax
  float v23; // eax
  float v24; // edx
  int v25; // eax
  int v26; // edi
  gbVec3D *RoleName; // eax
  gbVec3D *v28; // edi
  float y; // edx
  float z; // ecx
  int v31; // edx
  float v32; // edx
  float v33; // ecx
  int v34; // edx
  gbVec3D v35; // [esp+0xC] [ebp-0x5C] BYREF
  int v36; // [esp+0x18] [ebp-0x50]
  _DWORD v37[19]; // [esp+0x1C] [ebp-0x4C] BYREF
  unsigned __int8 v38; // [esp+0x78] [ebp+0x10]

  (((CG_Entry *)v37))->CG_Entry::GetCGEntry();
  v5 = *((_DWORD *)&this->m_ptr_20 + 2);
  v6 = *((_DWORD *)&this->m_ptr_20 + 3);
  v37[1] = nType;
  v7 = *((_DWORD *)&this->m_ptr_20 + 4);
  v37[3] = v5;
  v37[5] = v7;
  v37[4] = v6;
  p_m_nPathMode = (int *)&this->m_nPathMode;
  v9 = *((_DWORD *)pData + 1);
  v10 = *((_DWORD *)pData + 2);
  v37[6] = *(_DWORD *)pData;
  v37[7] = v9;
  v37[8] = v10;
  m_nPathStep = this->m_nPathStep;
  LOBYTE(v37[0]) = 1;
  v37[2] = 0;
  v37[15] = (unsigned __int8)nCount;
  v37[16] = v38;
  if ( !m_nPathStep
    || (m_ptr_358 = this->m_ptr_358, m_fPathEndY = this->m_fPathEndY, m_ptr_358 == (char *)LODWORD(m_fPathEndY)) )
  {
    v15 = (void *)operator new(0xFBCu);
    if ( p_m_nPathMode[11] )
    {
      v21 = (unsigned long)p_m_nPathMode[8];
      if ( v21 >= p_m_nPathMode[9] + 4 * p_m_nPathMode[10] - 4 )
      {
        v26 = ((int)(v21 - p_m_nPathMode[4]) >> 2) + 1;
        RoleName = (gbVec3D *)(((RoleSystem *)p_m_nPathMode))->RoleSystem::GetRoleName(2 * v26);
        v28 = (gbVec3D *)((char *)RoleName + 4 * v26);
        LODWORD(v28->x) = (unsigned long)v15;
        (((gbVec3D *)&v35))->gbVec3D::Copy(p_m_nPathMode[3], RoleName);
        y = v35.y;
        p_m_nPathMode[1] = LODWORD(v35.x);
        z = v35.z;
        *((float *)p_m_nPathMode + 2) = y;
        v31 = v36;
        *((float *)p_m_nPathMode + 3) = z;
        p_m_nPathMode[4] = v31;
        (((gbVec3D *)&v35))->gbVec3D::Copy((int)v15, v28);
        v32 = v35.y;
        p_m_nPathMode[5] = LODWORD(v35.x);
        v33 = v35.z;
        *((float *)p_m_nPathMode + 6) = v32;
        v34 = v36;
        *((float *)p_m_nPathMode + 7) = v33;
        p_m_nPathMode[8] = v34;
      }
      else
      {
        v22 = (_DWORD *)(v21 + 4);
        p_m_nPathMode[8] = (int)v22;
        *v22 = (_DWORD)v15;
        (((gbVec3D *)&v35))->gbVec3D::Copy((int)v15, (gbVec3D *)p_m_nPathMode[8]);
        v23 = v35.y;
        p_m_nPathMode[5] = LODWORD(v35.x);
        v24 = v35.z;
        *((float *)p_m_nPathMode + 6) = v23;
        v25 = v36;
        *((float *)p_m_nPathMode + 7) = v24;
        p_m_nPathMode[8] = v25;
      }
    }
    else
    {
      p_m_nPathMode[10] = 2;
      v16 = (_DWORD *)operator new(8u);
      p_m_nPathMode[9] = (int)v16;
      v16[1] = (_DWORD)v15;
      (((gbVec3D *)&v35))->gbVec3D::Copy((int)v15 + 1976, (gbVec3D *)(p_m_nPathMode[9] + 4));
      x = v35.x;
      v18 = v35.z;
      v19 = v35.y;
      v20 = v36;
      p_m_nPathMode[1] = LODWORD(v35.x);
      *((float *)p_m_nPathMode + 2) = v19;
      *((float *)p_m_nPathMode + 3) = v18;
      p_m_nPathMode[4] = v20;
      *((float *)p_m_nPathMode + 5) = x;
      *((float *)p_m_nPathMode + 6) = v19;
      *((float *)p_m_nPathMode + 7) = v18;
      p_m_nPathMode[8] = v20;
    }
    m_ptr_358 = (char *)p_m_nPathMode[7];
    p_m_nPathMode[7] = (int)(m_ptr_358 + 76);
    if ( !m_ptr_358 )
      goto LABEL_16;
    goto LABEL_15;
  }
  this->m_ptr_358 = m_ptr_358 + 76;
  if ( m_ptr_358 + 76 != (char *)LODWORD(m_fPathEndY) )
  {
    if ( !m_ptr_358 )
    {
LABEL_16:
      result = (unsigned long)(p_m_nPathMode[11] + 1);
      p_m_nPathMode[11] = result;
      return result;
    }
LABEL_15:
    qmemcpy(m_ptr_358, v37, 0x4Cu);
    goto LABEL_16;
  }
  if ( m_ptr_358 )
    qmemcpy(m_ptr_358, v37, 0x4Cu);
  (((ScriptVM *)p_m_nPathMode))->ScriptVM::GetString();
  result = this->m_nPathStep + 1;
  this->m_nPathStep = result;
  return result;
}

// 0x0042CD90
int ScriptVM::CallFunction(unsigned __int8 nFuncID, int nArgCount)
{
  int *p_m_nPathMode; // ebx
  int m_nPathStep; // eax
  char *m_ptr_358; // edi
  float m_fPathEndY; // ecx
  int result; // eax
  void *v9; // esi
  _DWORD *v10; // eax
  float v11; // ecx
  float v12; // edx
  float x; // eax
  int v14; // esi
  unsigned int v15; // eax
  _DWORD *v16; // eax
  float v17; // edx
  float v18; // ecx
  int v19; // edx
  int v20; // edi
  gbVec3D *RoleName; // eax
  int *v22; // edi
  float y; // ecx
  float z; // eax
  int v25; // ecx
  int v26; // ecx
  gbVec3D v27; // [esp+0xC] [ebp-0x5C] BYREF
  int v28; // [esp+0x18] [ebp-0x50]
  _DWORD v29[19]; // [esp+0x1C] [ebp-0x4C] BYREF

  (((CG_Entry *)v29))->CG_Entry::GetCGEntry();
  p_m_nPathMode = (int *)&this->m_nPathMode;
  v29[15] = nFuncID;
  LOBYTE(v29[0]) = 3;
  m_nPathStep = this->m_nPathStep;
  v29[16] = nArgCount;
  if ( !m_nPathStep
    || (m_ptr_358 = this->m_ptr_358, m_fPathEndY = this->m_fPathEndY, m_ptr_358 == (char *)LODWORD(m_fPathEndY)) )
  {
    v9 = (void *)operator new(0xFBCu);
    if ( p_m_nPathMode[11] )
    {
      v15 = (unsigned long)p_m_nPathMode[8];
      if ( v15 >= p_m_nPathMode[9] + 4 * p_m_nPathMode[10] - 4 )
      {
        v20 = ((int)(v15 - p_m_nPathMode[4]) >> 2) + 1;
        RoleName = (gbVec3D *)(((RoleSystem *)p_m_nPathMode))->RoleSystem::GetRoleName(2 * v20);
        v22 = (int *)(&RoleName->x + v20);
        *v22 = (int)v9;
        (((gbVec3D *)&v27))->gbVec3D::Copy(p_m_nPathMode[3], RoleName);
        y = v27.y;
        p_m_nPathMode[1] = LODWORD(v27.x);
        z = v27.z;
        *((float *)p_m_nPathMode + 2) = y;
        v25 = v28;
        *((float *)p_m_nPathMode + 3) = z;
        p_m_nPathMode[4] = v25;
        v26 = (unsigned long)(*v22 + 4028);
        p_m_nPathMode[5] = (unsigned long)*v22;
        p_m_nPathMode[6] = v26;
        p_m_nPathMode[7] = (int)v9;
        p_m_nPathMode[8] = (int)v22;
      }
      else
      {
        v16 = (_DWORD *)(v15 + 4);
        p_m_nPathMode[8] = (int)v16;
        *v16 = (_DWORD)v9;
        (((gbVec3D *)&v27))->gbVec3D::Copy((int)v9, (gbVec3D *)p_m_nPathMode[8]);
        v17 = v27.y;
        p_m_nPathMode[5] = LODWORD(v27.x);
        v18 = v27.z;
        *((float *)p_m_nPathMode + 6) = v17;
        v19 = v28;
        *((float *)p_m_nPathMode + 7) = v18;
        p_m_nPathMode[8] = v19;
      }
    }
    else
    {
      p_m_nPathMode[10] = 2;
      v10 = (_DWORD *)operator new(8u);
      p_m_nPathMode[9] = (int)v10;
      v10[1] = (_DWORD)v9;
      (((gbVec3D *)&v27))->gbVec3D::Copy((int)v9 + 1976, (gbVec3D *)(p_m_nPathMode[9] + 4));
      v11 = v27.y;
      v12 = v27.z;
      x = v27.x;
      v14 = v28;
      p_m_nPathMode[1] = LODWORD(v27.x);
      *((float *)p_m_nPathMode + 2) = v11;
      *((float *)p_m_nPathMode + 3) = v12;
      p_m_nPathMode[4] = v14;
      *((float *)p_m_nPathMode + 5) = x;
      *((float *)p_m_nPathMode + 6) = v11;
      *((float *)p_m_nPathMode + 7) = v12;
      p_m_nPathMode[8] = v14;
    }
    m_ptr_358 = (char *)p_m_nPathMode[7];
    p_m_nPathMode[7] = (int)(m_ptr_358 + 76);
    if ( !m_ptr_358 )
      goto LABEL_16;
    goto LABEL_15;
  }
  this->m_ptr_358 = m_ptr_358 + 76;
  if ( m_ptr_358 + 76 != (char *)LODWORD(m_fPathEndY) )
  {
    if ( !m_ptr_358 )
    {
LABEL_16:
      result = (unsigned long)(p_m_nPathMode[11] + 1);
      p_m_nPathMode[11] = result;
      return result;
    }
LABEL_15:
    qmemcpy(m_ptr_358, v29, 0x4Cu);
    goto LABEL_16;
  }
  if ( m_ptr_358 )
    qmemcpy(m_ptr_358, v29, 0x4Cu);
  (((ScriptVM *)p_m_nPathMode))->ScriptVM::GetString();
  result = this->m_nPathStep + 1;
  this->m_nPathStep = result;
  return result;
}

// 0x0042D4B0
int ScriptVM::SetRolePosition(unsigned __int8 pData)
{
  int *p_m_nPathMode; // ebx
  char *m_ptr_358; // edi
  float m_fPathEndY; // ecx
  int result; // eax
  void *v7; // esi
  _DWORD *v8; // eax
  float x; // eax
  float v10; // ecx
  int v11; // esi
  float v12; // edx
  unsigned int v13; // eax
  _DWORD *v14; // eax
  float v15; // edx
  float v16; // ecx
  int v17; // edx
  int v18; // edi
  gbVec3D *RoleName; // eax
  int *v20; // edi
  float y; // ecx
  float z; // eax
  int v23; // ecx
  int v24; // ecx
  gbVec3D v25; // [esp+0xC] [ebp-0x5C] BYREF
  int v26; // [esp+0x18] [ebp-0x50]
  _DWORD v27[19]; // [esp+0x1C] [ebp-0x4C] BYREF

  (((CG_Entry *)v27))->CG_Entry::GetCGEntry();
  p_m_nPathMode = (int *)&this->m_nPathMode;
  LOBYTE(v27[0]) = 8;
  v27[15] = pData;
  if ( !this->m_nPathStep
    || (m_ptr_358 = this->m_ptr_358, m_fPathEndY = this->m_fPathEndY, m_ptr_358 == (char *)LODWORD(m_fPathEndY)) )
  {
    v7 = (void *)operator new(0xFBCu);
    if ( p_m_nPathMode[11] )
    {
      v13 = (unsigned long)p_m_nPathMode[8];
      if ( v13 >= p_m_nPathMode[9] + 4 * p_m_nPathMode[10] - 4 )
      {
        v18 = ((int)(v13 - p_m_nPathMode[4]) >> 2) + 1;
        RoleName = (gbVec3D *)(((RoleSystem *)p_m_nPathMode))->RoleSystem::GetRoleName(2 * v18);
        v20 = (int *)(&RoleName->x + v18);
        *v20 = (int)v7;
        (((gbVec3D *)&v25))->gbVec3D::Copy(p_m_nPathMode[3], RoleName);
        y = v25.y;
        p_m_nPathMode[1] = LODWORD(v25.x);
        z = v25.z;
        *((float *)p_m_nPathMode + 2) = y;
        v23 = v26;
        *((float *)p_m_nPathMode + 3) = z;
        p_m_nPathMode[4] = v23;
        v24 = (unsigned long)(*v20 + 4028);
        p_m_nPathMode[5] = (unsigned long)*v20;
        p_m_nPathMode[6] = v24;
        p_m_nPathMode[7] = (int)v7;
        p_m_nPathMode[8] = (int)v20;
      }
      else
      {
        v14 = (_DWORD *)(v13 + 4);
        p_m_nPathMode[8] = (int)v14;
        *v14 = (_DWORD)v7;
        (((gbVec3D *)&v25))->gbVec3D::Copy((int)v7, (gbVec3D *)p_m_nPathMode[8]);
        v15 = v25.y;
        p_m_nPathMode[5] = LODWORD(v25.x);
        v16 = v25.z;
        *((float *)p_m_nPathMode + 6) = v15;
        v17 = v26;
        *((float *)p_m_nPathMode + 7) = v16;
        p_m_nPathMode[8] = v17;
      }
    }
    else
    {
      p_m_nPathMode[10] = 2;
      v8 = (_DWORD *)operator new(8u);
      p_m_nPathMode[9] = (int)v8;
      v8[1] = (_DWORD)v7;
      (((gbVec3D *)&v25))->gbVec3D::Copy((int)v7 + 1976, (gbVec3D *)(p_m_nPathMode[9] + 4));
      x = v25.x;
      v10 = v25.y;
      v11 = v26;
      v12 = v25.z;
      p_m_nPathMode[1] = LODWORD(v25.x);
      *((float *)p_m_nPathMode + 2) = v10;
      *((float *)p_m_nPathMode + 3) = v12;
      p_m_nPathMode[4] = v11;
      *((float *)p_m_nPathMode + 5) = x;
      *((float *)p_m_nPathMode + 6) = v10;
      *((float *)p_m_nPathMode + 7) = v12;
      p_m_nPathMode[8] = v11;
    }
    m_ptr_358 = (char *)p_m_nPathMode[7];
    p_m_nPathMode[7] = (int)(m_ptr_358 + 76);
    if ( !m_ptr_358 )
      goto LABEL_16;
    goto LABEL_15;
  }
  this->m_ptr_358 = m_ptr_358 + 76;
  if ( m_ptr_358 + 76 != (char *)LODWORD(m_fPathEndY) )
  {
    if ( !m_ptr_358 )
    {
LABEL_16:
      result = (unsigned long)(p_m_nPathMode[11] + 1);
      p_m_nPathMode[11] = result;
      return result;
    }
LABEL_15:
    qmemcpy(m_ptr_358, v27, 0x4Cu);
    goto LABEL_16;
  }
  if ( m_ptr_358 )
    qmemcpy(m_ptr_358, v27, 0x4Cu);
  (((ScriptVM *)p_m_nPathMode))->ScriptVM::GetString();
  result = this->m_nPathStep + 1;
  this->m_nPathStep = result;
  return result;
}

// 0x0042D670
int ScriptVM::GetRolePosition(unsigned __int8 pData)
{
  int *p_m_nPathMode; // ebx
  char *m_ptr_358; // edi
  float m_fPathEndY; // ecx
  int result; // eax
  void *v7; // esi
  _DWORD *v8; // eax
  float x; // eax
  float v10; // ecx
  int v11; // esi
  float v12; // edx
  unsigned int v13; // eax
  _DWORD *v14; // eax
  float v15; // edx
  float v16; // ecx
  int v17; // edx
  int v18; // edi
  gbVec3D *RoleName; // eax
  int *v20; // edi
  float y; // ecx
  float z; // eax
  int v23; // ecx
  int v24; // ecx
  gbVec3D v25; // [esp+0xC] [ebp-0x5C] BYREF
  int v26; // [esp+0x18] [ebp-0x50]
  _DWORD v27[19]; // [esp+0x1C] [ebp-0x4C] BYREF

  (((CG_Entry *)v27))->CG_Entry::GetCGEntry();
  p_m_nPathMode = (int *)&this->m_nPathMode;
  LOBYTE(v27[0]) = 9;
  v27[15] = pData;
  if ( !this->m_nPathStep
    || (m_ptr_358 = this->m_ptr_358, m_fPathEndY = this->m_fPathEndY, m_ptr_358 == (char *)LODWORD(m_fPathEndY)) )
  {
    v7 = (void *)operator new(0xFBCu);
    if ( p_m_nPathMode[11] )
    {
      v13 = (unsigned long)p_m_nPathMode[8];
      if ( v13 >= p_m_nPathMode[9] + 4 * p_m_nPathMode[10] - 4 )
      {
        v18 = ((int)(v13 - p_m_nPathMode[4]) >> 2) + 1;
        RoleName = (gbVec3D *)(((RoleSystem *)p_m_nPathMode))->RoleSystem::GetRoleName(2 * v18);
        v20 = (int *)(&RoleName->x + v18);
        *v20 = (int)v7;
        (((gbVec3D *)&v25))->gbVec3D::Copy(p_m_nPathMode[3], RoleName);
        y = v25.y;
        p_m_nPathMode[1] = LODWORD(v25.x);
        z = v25.z;
        *((float *)p_m_nPathMode + 2) = y;
        v23 = v26;
        *((float *)p_m_nPathMode + 3) = z;
        p_m_nPathMode[4] = v23;
        v24 = (unsigned long)(*v20 + 4028);
        p_m_nPathMode[5] = (unsigned long)*v20;
        p_m_nPathMode[6] = v24;
        p_m_nPathMode[7] = (int)v7;
        p_m_nPathMode[8] = (int)v20;
      }
      else
      {
        v14 = (_DWORD *)(v13 + 4);
        p_m_nPathMode[8] = (int)v14;
        *v14 = (_DWORD)v7;
        (((gbVec3D *)&v25))->gbVec3D::Copy((int)v7, (gbVec3D *)p_m_nPathMode[8]);
        v15 = v25.y;
        p_m_nPathMode[5] = LODWORD(v25.x);
        v16 = v25.z;
        *((float *)p_m_nPathMode + 6) = v15;
        v17 = v26;
        *((float *)p_m_nPathMode + 7) = v16;
        p_m_nPathMode[8] = v17;
      }
    }
    else
    {
      p_m_nPathMode[10] = 2;
      v8 = (_DWORD *)operator new(8u);
      p_m_nPathMode[9] = (int)v8;
      v8[1] = (_DWORD)v7;
      (((gbVec3D *)&v25))->gbVec3D::Copy((int)v7 + 1976, (gbVec3D *)(p_m_nPathMode[9] + 4));
      x = v25.x;
      v10 = v25.y;
      v11 = v26;
      v12 = v25.z;
      p_m_nPathMode[1] = LODWORD(v25.x);
      *((float *)p_m_nPathMode + 2) = v10;
      *((float *)p_m_nPathMode + 3) = v12;
      p_m_nPathMode[4] = v11;
      *((float *)p_m_nPathMode + 5) = x;
      *((float *)p_m_nPathMode + 6) = v10;
      *((float *)p_m_nPathMode + 7) = v12;
      p_m_nPathMode[8] = v11;
    }
    m_ptr_358 = (char *)p_m_nPathMode[7];
    p_m_nPathMode[7] = (int)(m_ptr_358 + 76);
    if ( !m_ptr_358 )
      goto LABEL_16;
    goto LABEL_15;
  }
  this->m_ptr_358 = m_ptr_358 + 76;
  if ( m_ptr_358 + 76 != (char *)LODWORD(m_fPathEndY) )
  {
    if ( !m_ptr_358 )
    {
LABEL_16:
      result = (unsigned long)(p_m_nPathMode[11] + 1);
      p_m_nPathMode[11] = result;
      return result;
    }
LABEL_15:
    qmemcpy(m_ptr_358, v27, 0x4Cu);
    goto LABEL_16;
  }
  if ( m_ptr_358 )
    qmemcpy(m_ptr_358, v27, 0x4Cu);
  (((ScriptVM *)p_m_nPathMode))->ScriptVM::GetString();
  result = this->m_nPathStep + 1;
  this->m_nPathStep = result;
  return result;
}

// 0x0042FB60
char * ScriptVM::GetString()
{
  char *v2; // ebx
  _DWORD *v3; // eax
  char *v4; // edi
  char *result; // eax
  int *v6; // ebx
  int *v7; // esi
  int v8; // ecx
  int *m_ptr_20; // eax
  int *v10; // eax
  int *v11; // esi
  int v12; // ecx
  int v13; // ebp
  size_t v14; // eax
  char *v15; // eax
  int *m_bufReadPtr; // ecx
  char *v17; // edi
  int *v18; // eax
  char *v19; // edx
  int v20; // ebp
  int *p_m_bufHead; // ebp
  int *p_m_bufWritePtr; // esi
  int v23; // edx
  int v24; // ecx
  int v25; // [esp+0xC] [ebp-0x18]
  char *v26; // [esp+0x10] [ebp-0x14]
  int m_bufCapacity; // [esp+0x1C] [ebp-0x8]

  v2 = (char *)operator new(0xFBCu);
  if ( *((_DWORD *)&this->m_ptr_20 + 3) )
  {
    m_ptr_20 = (int *)this->m_ptr_20;
    if ( (unsigned int)m_ptr_20 >= *((_DWORD *)&this->m_ptr_20 + 1) + 4 * *((_DWORD *)&this->m_ptr_20 + 2) - 4 )
    {
      v13 = (((int)m_ptr_20 - this->m_bufReadPtr) >> 2) + 1;
      v25 = v13;
      v14 = 8 * v13;
      if ( (v13 & 0x10000000) != 0 )
        v14 = 0;
      v15 = (char *)operator new(v14);
      m_bufReadPtr = (int *)this->m_bufReadPtr;
      v26 = (char *)v15;
      v17 = (char *)&v15[4 * ((unsigned int)(2 * v13) >> 2)];
      v18 = this->m_ptr_20 + 1;
      v19 = (char *)v17;
      if ( m_bufReadPtr != v18 )
      {
        do
        {
          v20 = (unsigned long)(*m_bufReadPtr++);
          *(_DWORD *)v19 = v20;
          v19 += 4;
        }
        while ( m_bufReadPtr != v18 );
        v13 = v25;
      }
      operator delete(*((void **)&this->m_ptr_20 + 1));
      *((_DWORD *)&this->m_ptr_20 + 1) = (unsigned long)v26;
      *((_DWORD *)&this->m_ptr_20 + 2) = 2 * v13;
      result = (char *)&v17[4 * v13];
      *(_DWORD *)result = (_DWORD)v2;
      m_bufCapacity = this->m_bufCapacity;
      p_m_bufHead = (int *)&this->m_bufHead;
      p_m_bufWritePtr = (int *)&this->m_bufWritePtr;
      v23 = *(_DWORD *)v17 + 4028;
      *p_m_bufHead = *(_DWORD *)v17;
      p_m_bufHead[1] = v23;
      p_m_bufHead[2] = m_bufCapacity;
      p_m_bufHead[3] = (int)v17;
      v24 = *(_DWORD *)result;
      *p_m_bufWritePtr = *(_DWORD *)result;
      p_m_bufWritePtr[1] = v24 + 4028;
      p_m_bufWritePtr[2] = (int)v2;
      p_m_bufWritePtr[3] = (int)result;
    }
    else
    {
      v10 = (int *)(m_ptr_20 + 1);
      this->m_ptr_20 = v10;
      v11 = (int *)&this->m_bufWritePtr;
      *v10 = (int)v2;
      result = (char *)v11[3];
      v12 = *(_DWORD *)result;
      *v11 = *(_DWORD *)result;
      v11[1] = v12 + 4028;
      v11[2] = (int)v2;
      v11[3] = (int)result;
    }
  }
  else
  {
    *((_DWORD *)&this->m_ptr_20 + 2) = 2;
    v3 = (_DWORD *)operator new(8u);
    *((_DWORD *)&this->m_ptr_20 + 1) = (unsigned long)v3;
    v3[1] = (_DWORD)v2;
    v4 = (char *)(v2 + 1976);
    result = (char *)(*((_DWORD *)&this->m_ptr_20 + 1) + 4);
    v6 = (int *)&this->m_bufHead;
    v7 = (int *)&this->m_bufWritePtr;
    v8 = *(_DWORD *)result;
    *v7 = *(_DWORD *)result;
    *v6 = v8;
    v7[1] = v8 + 4028;
    v6[1] = v8 + 4028;
    v7[2] = (int)v4;
    v6[2] = (int)v4;
    v7[3] = (int)result;
    v6[3] = (int)result;
  }
  return result;
}

// 0x004366C0
int ScriptVM::GetObjectByID(int nObjID)
{
  int v1; // eax
  int v2; // eax
  int result; // eax

  v1 = *(_DWORD *)(((GRPinput *)&stru_D8C2B8)->KeyInfo[147].CountMode + 16);
  if ( v1 )
  {
    v2 = v1 - 1;
    if ( v2 )
    {
      result = v2 - 1;
      if ( result )
        return result;
      if ( !nObjID && !*(_DWORD *)(((GRPinput *)&stru_D8C2B8)->KeyInfo[147].CountMode + 24) )
        goto LABEL_6;
    }
    else if ( !nObjID || !*(_DWORD *)(((GRPinput *)&stru_D8C2B8)->KeyInfo[147].CountMode + 24) )
    {
LABEL_6:
      result = 0;
      *(_DWORD *)(((GRPinput *)&stru_D8C2B8)->KeyInfo[147].CountMode + 24) = 0;
      return result;
    }
    result = 1;
    *(_DWORD *)(((GRPinput *)&stru_D8C2B8)->KeyInfo[147].CountMode + 24) = 1;
  }
  else
  {
    result = nObjID;
    *(_DWORD *)(((GRPinput *)&stru_D8C2B8)->KeyInfo[147].CountMode + 24) = nObjID;
  }
  return result;
}
