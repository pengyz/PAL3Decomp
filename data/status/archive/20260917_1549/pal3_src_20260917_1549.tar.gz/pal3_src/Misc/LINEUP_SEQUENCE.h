#pragma once
// Auto-generated: LINEUP_SEQUENCE
#include "pal3/ida_types.h"

class LINEUP_SEQUENCE {
public:
    BYTE Role_Sequence[5]; // +0x0
    // total size: 0x5 (5)

};
