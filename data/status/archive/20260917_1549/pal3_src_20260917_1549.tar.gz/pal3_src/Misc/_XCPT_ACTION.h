#pragma once
// Auto-generated: _XCPT_ACTION
#include "pal3/ida_types.h"

class _XCPT_ACTION {
public:
    DWORD XcptNum; // +0x0
    int SigNum; // +0x4
    char * XcptAction; // +0x8
    // total size: 0xC (12)

};
