#include "Misc/tagEffTaskParam.h"
#include "Misc/CTaskTpl.h"
#pragma once
// Auto-generated: CTaskTpl<tagEffTaskParam, unsigned long (__thiscall CEffBink::*)(unsigned long)>
#include "pal3/ida_types.h"

class CEffBink;
typedef unsigned long (CEffBink::*_CEffBink_cb)(unsigned long);
template<>
class CTaskTpl<tagEffTaskParam, _CEffBink_cb> {
public:
    char _tail_000[36]; // +0x0
    // total size: 0x24 (36)

};
