#include "Misc/CPolicy.h"
#pragma once
// Auto-generated: CRotateEmitterPolicy
#include "pal3/ida_types.h"

#include "gbengine/gbengine_types.h"

class CRotateEmitterPolicy : public CPolicy {
public:
    char _gap_000[12]; // +0x0
    gbVec3D _vAxis; // +0xC
    float _fSpeed; // +0x18
    float _fAngle; // +0x1C
    // total size: 0x20 (32)

};
