#pragma once
// Auto-generated: _better_note
#include "pal3/ida_types.h"

class _better_note {
public:
    int best_second; // +0x0
    int best_num; // +0x4
    // total size: 0x8 (8)

};
