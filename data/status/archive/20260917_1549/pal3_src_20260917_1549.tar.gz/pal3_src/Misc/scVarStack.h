#pragma once
// Auto-generated: scVarStack
#include "pal3/ida_types.h"

#include "Misc/scVARIANT.h"

class scVarStack {
public:
    int m_counter; // +0x0
    scVARIANT m_vararray[32]; // +0x4
    // total size: 0x104 (260)

};
