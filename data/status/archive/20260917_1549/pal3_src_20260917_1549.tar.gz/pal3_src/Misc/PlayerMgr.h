#pragma once
// Auto-generated: PlayerMgr
#include "pal3/ida_types.h"

class PlayerMgr {
public:
    struct PoisonState;


    struct PoisonState {
        unsigned char _pad[1];
    };
    char _tail_000[1]; // +0x0
    // total size: 0x1 (1)

    // Scalar-wrapper: ctors for IDA (Cls)int casts (no init code)
    PlayerMgr() {}
    PlayerMgr(int v) { *(char*)this = (char)v; }

};
