#include "Misc/UIFrameWnd.h"
#pragma once
// Auto-generated: UITitle_BBTY
#include "pal3/ida_types.h"

#include "Misc/UIButton.h"
#include "Misc/UIButtonEXA.h"
#include "Misc/UIStatic.h"

class UIWnd;

class UITitle_BBTY : public UIFrameWnd {
public:
    char _gap_000[72]; // +0x0
    tagRECT rc; // +0x48
    int bkWndX; // +0x58
    int bkWndY; // +0x5C
    int i; // +0x60
    int j; // +0x64
    char buf[256]; // +0x68
    UIStatic m_background; // +0x168
    char _gap_200[8]; // +0x200
    UIStatic m_remark; // +0x208
    char _gap_2A0[8]; // +0x2A0
    UIButtonEXA m_btn[3]; // +0x2A8
    UIButton m_exit; // +0x710
    UIStatic m_Name; // +0x868
    char _gap_900[8]; // +0x900
    UIStatic m_Left; // +0x908
    char _gap_9A0[8]; // +0x9A0
    UIStatic m_Right; // +0x9A8
    char _gap_A40[8]; // +0xA40
    UIStatic m_FlagT; // +0xA48
    char _gap_AE0[8]; // +0xAE0
    UIStatic m_FlagB; // +0xAE8
    char _gap_B80[8]; // +0xB80
    UIButton m_Start; // +0xB88
    UIButton m_Notes; // +0xCE0
    char _tail_E38[1612]; // +0xE38
    // total size: 0x1484 (5252)

    virtual ~UITitle_BBTY() {}

    virtual void Render(); // 0x00445CD0
    virtual double UpdateFrame(double result, int arg0, int arg0a); // 0x004520A0
    void * _scalar_dtor(UIWnd *Block, char pData); // 0x00451D80
    virtual int OnMessage(int nVal, int nVal2, int nVal3); // 0x00452420
    UITitle_BBTY(); // 0x00451CC0
    void ctor(); // 0x00451DA0
    int CreateFromScript(); // 0x00451E50
    void SetRemarkTextures(int nVal); // 0x004524B0
};
