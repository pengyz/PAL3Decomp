#pragma once
// Auto-generated: gbEmitterSphere
#include "pal3/ida_types.h"

class gbEmitterSphere {
public:
    float hotspot; // +0x0
    float falloff; // +0x4
    // total size: 0x8 (8)

};
