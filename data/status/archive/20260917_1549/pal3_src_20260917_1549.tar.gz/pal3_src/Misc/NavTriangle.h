#pragma once
// Auto-generated: NavTriangle
#include "pal3/ida_types.h"

#include "gbengine/gbengine_types.h"

class NavTriangle {
public:
    gbVec3D up; // +0x0
    gbVec3D forward; // +0xC
    gbVec3D side; // +0x18
    // total size: 0x24 (36)

};
