#pragma once
// Auto-generated: tagEffGroup
#include "pal3/ida_types.h"

class tagEffGroup {
public:
    int nValidObj; // +0x0
    UINT dwEffObjTypeCRC[16]; // +0x4
    char Task[256]; // +0x44
    // total size: 0x144 (324)

};
