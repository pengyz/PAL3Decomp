#pragma once
// Auto-generated: gbActorMgr
#include "pal3/ida_types.h"

#include "gbengine/gbResManager.h"

class gbActorMgr {
public:
    gbResManager AllActorDef; // +0x0
    // total size: 0xC (12)

};
