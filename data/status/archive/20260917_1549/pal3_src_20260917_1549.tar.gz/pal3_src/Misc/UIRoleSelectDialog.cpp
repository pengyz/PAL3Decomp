#include "pal3/ida_defs.h"
#include "globals.h"
#include "pal3/pal3_constants.h"
#include "Misc/UIRoleSelectDialog.h"
#include "Role/Actor.h"
#include "Combat/CCBControlWindow.h"
#include "Combat/CCBItemWindow.h"
#include "Combat/CCBMagicWindow.h"
#include "Combat/CCBResultWindow.h"
#include "Combat/CCBStage.h"
#include "Data/CGameData.h"
#include "Render/CScreenMode.h"
#include "GameBase/GRPinput.h"
#include "Misc/PtrArray.h"
#include "Role/RoleSystem.h"
#include "Scene/SceneObj.h"
#include "Misc/UIButton.h"
#include "Misc/UICaption.h"
#include "Misc/UIFrameWnd.h"
#include "UI/UIListBox.h"
#include "UI/UINote.h"
#include "UI/UIQuadManager.h"
#include "UI/UIRenderObj.h"
#include "UI/UIScene.h"
#include "Misc/UISceneMap.h"
#include "Misc/UIStatic.h"
#include "Misc/UITextArea.h"
#include "Misc/_PlugInfo.h"
#include "free_functions.h"

// Forward declarations for unnamed functions

// 0x00451980

// ---- synthesized vtable stubs (unresolved slots) ----
// [VFTABLE-STUB] original: ((void ( *)(UIRoleSelectDialog *, _DWORD))this->__vftable->ShowWindow)(this, 0)
static void pal3_vtbl_unk_0(UIRoleSelectDialog *, _DWORD);

int UIRoleSelectDialog::CreateDialog(int id, void *pRect, int parent, char *tex)
{
  int v6; // eax
  void *m_id; // edx
  int result; // eax
  _DWORD v9[2]; // [esp+0x18] [ebp-0x10] BYREF
  int v10; // [esp+0x20] [ebp-0x8]
  int v11; // [esp+0x24] [ebp-0x4]

  (((CCBItemWindow *)this))->CCBItemWindow::Create(id, (tagRECT *)pRect, parent) /* [ROWTABLE] */;
  (((UINote *)&this->m_list.m_column[1].items.m_nSize))->UINote::Create(0, (int)pRect, (int)this, "ui\\flex\\note");
  sub_445FA0(&this->m_list.m_column[1].items.m_nSize);
  v6 = *((_DWORD *)pRect + 3);
  v10 = *((_DWORD *)pRect + 2) - *(_DWORD *)pRect - 16;
  m_id = this->m_bk.m_id;
  v11 = v6 - *((_DWORD *)pRect + 1) - 16;
  v9[0] = 8;
  v9[1] = 0;
  (*((void ( **)(void **, _DWORD, _DWORD *, UIRoleSelectDialog *, _DWORD, _DWORD, _DWORD))m_id + 7))(
    &this->m_bk.m_id,
    0,
    v9,
    this,
    0,
    0,
    0);
  (((UIListBox *)&this->m_bk.m_id))->UIListBox::SetFirstShow((int)"_seldlg", v10 - v9[0]);
  UIListBox_SetItemData(1);
  sub_446010(&this->m_bk.m_id);
  (((UIListBox *)&this->m_bk.m_id))->UIListBox::GetSel((int)"ui\\scene\\SelPic.tga", 0);
  pal3_vtbl_unk_0(this, 0) /* [VFTABLE-STUB] */;
  *(_DWORD *)&this->m_list.m_column[0].head[60] = 20;
  (((UIListBox *)&this->m_bk.m_id))->UIListBox::SetLockSel();
  return result;
}

static void pal3_vtbl_unk_0(UIRoleSelectDialog *, _DWORD)
{
    
}


// 0x005295F0
UIRoleSelectDialog::UIRoleSelectDialog()
{
  this->m_bk.m_id = (void *)800;
  this->m_bk.m_rect.left = 600;
  LOBYTE(this->m_ani.m_texarray.m_ptex[2]) = 0;
  sub_4422E0(&this->m_ani.m_texarray.m_ptex[4]);
  // [AUTO-COMMENTED] (CCBResultWindow *)&this->m_list.m_scrollbar.m_texarrayInfo[5]->CCBResultWindow();
  this->m_list.m_column[1].head[36] = 0;
  *(_DWORD *)&this->m_list.m_column[1].head[32] = 0;
  *(_DWORD *)&this->m_list.m_column[1].head[28] = 0;
  this->m_list.m_column[1].head[56] = 0;
  *(_DWORD *)&this->m_list.m_column[1].head[52] = 0;
  *(_DWORD *)&this->m_list.m_column[1].head[48] = 0;
  sub_4422E0(&this->m_list.m_column[1].head[60]);
  sub_4422E0(&this->m_list.m_column[3].head[44]);
  sub_4422E0(&this->m_list.m_scrollRc.right);
  (((UITextArea *)&this->m_maxlen))->UITextArea::InitAfterClear();
  *(_DWORD *)&this->m_list.m_column[1].head[44] = 32;
  *(_DWORD *)&this->m_list.m_column[1].head[40] = 32;
  *(_DWORD *)&this->m_list.m_column[5].head[28] = 64;
  *(_DWORD *)&this->m_list.m_column[5].head[32] = 58;
  this->m_list.m_column[6].items.m_pData = (char *)28;
  this->m_list.m_firstshow = 1065353216;
  this->m_list.m_onsel = 1060152279;
  this->m_list.m_locksel = 1036831949;
  this->m_list.m_scrollRc.left = 1008981770;
  *(_DWORD *)&this->m_list.m_column[5].head[40] = 0;
  *(_DWORD *)&this->m_list.m_column[5].head[36] = 0;
  *(_DWORD *)&this->m_list.m_column[5].head[44] = 800;
  *(_DWORD *)&this->m_list.m_column[5].head[48] = 600;
  *(&this->m_mode + 46) = 0;
  *((_BYTE *)&this->m_mode + 196) = 1;
  (int)this;
}

// 0x00529790
void UIRoleSelectDialog::ctor()
{
  UIQuadManager *Instance; // eax

  Instance = (UIQuadManager *)UIQuadManager::GetInstance();
  (((UIRenderObj *)Instance))->UIRenderObj::~UIRenderObj();
  UITextArea_Destroy();
  (((UIFrameWnd *)&this->m_list.m_scrollRc.right))->UIFrameWnd::_UIFrameWnd();
  (((UIFrameWnd *)&this->m_list.m_column[3].head[44]))->UIFrameWnd::_UIFrameWnd();
  (((UIFrameWnd *)&this->m_list.m_column[1].head[60]))->UIFrameWnd::_UIFrameWnd();
  (((UIFrameWnd *)&this->m_list.m_scrollbar.m_texarrayInfo[5]))->UIFrameWnd::_UIFrameWnd_Full();
  (((UIFrameWnd *)&this->m_ani.m_texarray.m_ptex[4]))->UIFrameWnd::_UIFrameWnd();
  (((UIListBox *)this))->UIListBox::~UIListBox() /* [ROWTABLE] */;
}

// 0x00529CF0
void UIRoleSelectDialog::Render()
{
  float *p_m_ratioh; // edi
  int *p_width; // ebx
  CCBMagicWindow *v4; // [esp+0x0] [ebp-0x20]
  char *v5; // [esp+0x4] [ebp-0x1C]
  int v6; // [esp+0x8] [ebp-0x18]

  (((UISceneMap *)this))->UISceneMap::Render_529c80() /* [ROWTABLE] */;
  v6 = 0;
  if ( *(int *)&this->m_list.m_column[6].head[48] > 0 )
  {
    p_m_ratioh = (float *)&this->m_face.m_ratioh;
    p_width = (int *)&this->m_list.m_column[5].width;
    v5 = (char *)&this->m_list.m_column[5].head[52];
    do
    {
      if ( *(_DWORD *)v5 <= 1u )
        sub_445FA0(p_m_ratioh);
      (*(void ( **)(float *))(*(_DWORD *)p_m_ratioh + 4))(p_m_ratioh);
      v5 += 4;
      p_width += 2;
      p_m_ratioh += 46;
      ++v6;
    }
    while ( v6 < *(_DWORD *)&this->m_list.m_column[6].head[48] );
  }
  (((CCBControlWindow *)this))->CCBControlWindow::Render(v4) /* [ROWTABLE] */;
}

// 0x00529E40
double UIRoleSelectDialog::HandleInput(
        
        double st6_0,
        double result,
        int arg0,
        int arg0a)
{
  double v5; // st7
  DWORD TickCount; // eax
  DWORD v8; // eax
  unsigned int v9; // ecx
  BOOL ( *v10)(const RECT *, POINT); // ebp
  int v11; // edi
  DWORD v12; // eax
  DWORD v13; // eax
  int v14; // ebx
  int v15; // kr00_4
  int v16; // ebx
  CScreenMode *Instance; // eax
  int v18; // ebp
  int v19; // ebx
  int v20; // ebx
  int v21; // eax
  int v22; // ecx
  int v23; // ebp
  int v24; // eax
  bool v25; // dl
  bool v26; // al
  int v27; // ecx
  int v28; // edx
  CCBStage *v29; // eax
  float *v30; // ebx
  int v31; // eax
  int v32; // eax
  int v33; // ecx
  char *v34; // eax
  CCBStage *v35; // eax
  int v36; // ecx
  char *v37; // eax
  int capacity; // eax
  double v39; // st7
  double v40; // st7
  double v41; // st7
  int v42; // ecx
  double v43; // st7
  double v44; // st7
  int v45; // ecx
  double v46; // st7
  int v47; // ecx
  double v48; // st7
  double v49; // st7
  int v50; // ecx
  UIQuadManager *v51; // eax
  int v52; // eax
  gbTexture *v53; // eax
  CCBStage *v54; // eax
  const void *v55; // [esp+0x4] [ebp-0x74]
  char *v56; // [esp+0x8] [ebp-0x70]
  char *v57; // [esp+0x8] [ebp-0x70]
  char *v58; // [esp+0x8] [ebp-0x70]
  int v59; // [esp+0xC] [ebp-0x6C]
  char v60; // [esp+0x1C] [ebp-0x5C]
  char v61; // [esp+0x1D] [ebp-0x5B]
  bool v62; // [esp+0x1E] [ebp-0x5A]
  char v63; // [esp+0x1F] [ebp-0x59]
  int v64; // [esp+0x28] [ebp-0x50]
  int v65; // [esp+0x2C] [ebp-0x4C]
  POINT Point; // [esp+0x30] [ebp-0x48] BYREF
  POINT pt; // [esp+0x38] [ebp-0x40] BYREF
  float v68; // [esp+0x40] [ebp-0x38]
  float v69; // [esp+0x44] [ebp-0x34]
  float v70; // [esp+0x4C] [ebp-0x2C]
  float v71; // [esp+0x50] [ebp-0x28]
  int v72; // [esp+0x58] [ebp-0x20]
  int v73; // [esp+0x5C] [ebp-0x1C]
  int v74; // [esp+0x60] [ebp-0x18]
  int v75; // [esp+0x64] [ebp-0x14]
  int v76; // [esp+0x68] [ebp-0x10]
  int v77; // [esp+0x6C] [ebp-0xC]
  int v78; // [esp+0x74] [ebp-0x4]

  if ( !this->m_list.m_column[1].head[36] )
  {
    TickCount = GetTickCount();
    *(_DWORD *)&this->m_list.m_column[1].head[28] = TickCount;
    *(_DWORD *)&this->m_list.m_column[1].head[32] = TickCount;
    this->m_list.m_column[1].head[36] = 1;
  }
  v8 = GetTickCount();
  v9 = v8 - *(_DWORD *)&this->m_list.m_column[1].head[32];
  *(_DWORD *)&this->m_list.m_column[1].head[28] = v8;
  if ( v9 > 0x898 )
  {
    *(_DWORD *)&this->m_list.m_column[1].head[32] = v8;
    this->m_list.m_column[1].head[36] = 0;
    (((CCBResultWindow *)&this->m_list.m_scrollbar.m_texarrayInfo[5]))->CCBResultWindow::SetDirty();
    ((void ( *)(_PlugInfo **, _DWORD))this->m_list.m_scrollbar.m_texarrayInfo[5]->filepos)(
      &this->m_list.m_scrollbar.m_texarrayInfo[5],
      0);
    this->m_list.m_column[1].head[20] = 1;
  }
  v64 = *(_DWORD *)&this->m_list.m_column[5].head[44] - *(_DWORD *)&this->m_list.m_column[5].head[36];
  v10 = PtInRect;
  v65 = *(_DWORD *)&this->m_list.m_column[5].head[48] - *(_DWORD *)&this->m_list.m_column[5].head[40];
  v11 = 0;
  if ( *(int *)&this->m_list.m_column[6].head[48] > 0 )
  {
    while ( 1 )
    {
      (*(void ( **)(_DWORD, _DWORD))(*((_DWORD *)&this->m_face.m_ratioh + 46 * v11) + 8))(
        LODWORD(st6_0),
        HIDWORD(st6_0));
      if ( *(_DWORD *)&this->m_list.m_column[5].head[4 * v11 + 52] == 3 )
        goto LABEL_125;
      g_Input.GRPinput::GetCursorPos(&pt);
      v60 = 0;
      if ( PtInRect((const RECT *)&this->m_list.m_column[5].head[36], pt) )
      {
        if ( !this->m_list.m_column[1].head[56] )
        {
          v12 = GetTickCount();
          *(_DWORD *)&this->m_list.m_column[1].head[48] = v12;
          *(_DWORD *)&this->m_list.m_column[1].head[52] = v12;
          this->m_list.m_column[1].head[56] = 1;
        }
        v13 = GetTickCount();
        v14 = *(_DWORD *)&this->m_list.m_column[1].head[52];
        *(_DWORD *)&this->m_list.m_column[1].head[48] = v13;
        if ( v13 - v14 > 0x64 )
        {
          *(_DWORD *)&this->m_list.m_column[1].head[52] = v13;
          this->m_list.m_column[1].head[56] = 0;
          (**(void ( ***)(char *, int))&this->m_list.m_column[1].head[60])(
            &this->m_list.m_column[1].head[60],
            1);
          (**(void ( ***)(char *, _DWORD))&this->m_list.m_column[3].head[44])(
            &this->m_list.m_column[3].head[44],
            0);
        }
        v60 = 1;
      }
      else
      {
        (**(void ( ***)(char *, _DWORD))&this->m_list.m_column[1].head[60])(
          &this->m_list.m_column[1].head[60],
          0);
        (**(void ( ***)(char *, _DWORD))&this->m_list.m_column[3].head[44])(
          &this->m_list.m_column[3].head[44],
          0);
      }
      v15 = *(_DWORD *)&this->m_list.m_column[5].head[28];
      v72 = pt.x - v15 / 2;
      v16 = *(_DWORD *)&this->m_list.m_column[5].head[32];
      v74 = pt.x + v15 - v15 / 2;
      v75 = v16 + pt.y - v16 / 2;
      v73 = pt.y - v16 / 2;
      sub_445FA0(&this->m_list.m_column[1].head[60]);
      sub_445FA0(&this->m_list.m_column[3].head[44]);
      if ( g_Input.KeyInfo[0].PressTime == 1 && !LOBYTE(this->m_ani.m_texarray.m_ptex[2]) )
      {
        if ( v60 )
        {
          (**(void ( ***)(char *, _DWORD))&this->m_list.m_column[1].head[60])(
            &this->m_list.m_column[1].head[60],
            0);
          (**(void ( ***)(char *, int))&this->m_list.m_column[3].head[44])(
            &this->m_list.m_column[3].head[44],
            1);
          v55 = (const void *)off_5ED1D4;
          Instance = (CScreenMode *)CScreenMode::GetInstance();
          (((CScreenMode *)Instance))->CScreenMode::AudioSetPosition(v55, 1);
        }
        *((_BYTE *)&this->m_mode + 180) = 0;
      }
      v18 = *(_DWORD *)&this->m_list.m_column[1].head[44];
      v19 = *(_DWORD *)&this->m_list.m_column[1].head[40];
      v77 = (__int64)(*(float *)&this->m_list.m_column[6].head[8 * v11] - (double)(v18 / 2));
      v5 = *((float *)&this->m_list.m_column[5].width + 2 * v11) - (double)(v19 / 2);
      v76 = (__int64)v5;
      v20 = v76 + v19;
      v21 = *(_DWORD *)&this->m_list.m_column[5].head[32];
      v78 = v18 + v77;
      v22 = pt.y - v21 / 2;
      v23 = v22 + 45;
      v24 = pt.x - *(_DWORD *)&this->m_list.m_column[5].head[28] / 2;
      v73 = v22;
      v72 = v24;
      v75 = v22 + 45;
      v74 = v24 + 45;
      if ( *(_DWORD *)&this->m_list.m_column[5].head[4 * v11 + 52] == 1 )
        goto LABEL_72;
      if ( v24 < v76 )
      {
        if ( v74 <= v76 )
        {
          v23 = v75;
        }
        else
        {
          if ( v22 > v77 && v22 < v78 )
          {
            v23 = v75;
            v61 = 1;
            goto LABEL_30;
          }
          v23 = v75;
          if ( v75 > v77 && v75 < v78 )
          {
            v61 = 1;
            goto LABEL_30;
          }
        }
      }
      v61 = 0;
LABEL_30:
      v62 = v24 < v20 && v74 > v20 && (v22 > v77 && v22 < v78 || v23 > v77 && v23 < v78);
      if ( v22 < v77 && v23 > v77 )
      {
        if ( v24 > v76 && v24 < v20 )
          goto LABEL_45;
        if ( v74 > v76 && v74 < v20 )
        {
          v23 = v75;
LABEL_45:
          v63 = 1;
          goto LABEL_48;
        }
        v23 = v75;
      }
      v63 = 0;
LABEL_48:
      v25 = v22 < v78 && v23 > v78 && (v24 > v76 && v24 < v20 || v74 > v76 && v74 < v20);
      v26 = v22 > v77 && v24 > v76 && v74 < v20 && v75 < v78;
      if ( (v61 || v62 || v63 || v25 || v26) && v60 && g_Input.KeyInfo[0].PressTime == 1 )
      {
        v27 = *(_DWORD *)&this->m_list.m_column[6].head[48];
        v28 = this->m_list.m_column[5].items.m_needscriptdel + 1;
        this->m_list.m_column[5].items.m_needscriptdel = v28;
        if ( v28 >= v27 )
        {
          v56 = (char *)off_5ED1D0;
          v29 = (CCBStage *)CScreenMode::GetInstance();
          (((CCBStage *)v29))->CCBStage::PlaySound(v56, v59);
        }
        LOBYTE(v28) = *((_BYTE *)&this->m_mode + 196);
        v30 = (float *)(&this->m_face.m_ratioh + 46 * v11);
        (((UIStatic *)v30))->UIStatic::CreateFromTemplate("SubGame\\KillFlyer\\FlyerDie.tga", v28);
        *(_DWORD *)&this->m_list.m_column[5].head[4 * v11 + 52] = 1;
        *(_DWORD *)&this->m_list.m_column[7].head[4 * v11 + 44] = 1050253722;
        goto LABEL_73;
      }
LABEL_72:
      v30 = (float *)(&this->m_face.m_ratioh + 46 * v11);
LABEL_73:
      v31 = *(_DWORD *)&this->m_list.m_column[5].head[4 * v11 + 52];
      if ( v31 )
      {
        v32 = v31 - 1;
        if ( v32 )
        {
          if ( v32 == 1 && !LOBYTE(this->m_list.m_scrollRc.top) )
          {
            (**(void ( ***)(float *, _DWORD))v30)(v30, 0);
            v33 = *(_DWORD *)&this->m_list.m_column[6].head[48];
            v34 = this->m_list.m_column[5].items.m_pData + 1;
            this->m_list.m_column[5].items.m_pData = v34;
            if ( (int)v34 >= v33 )
            {
              LOBYTE(this->m_list.m_scrollRc.top) = 1;
              v57 = (char *)off_5ED1D0;
              v35 = (CCBStage *)CScreenMode::GetInstance();
              (((CCBStage *)v35))->CCBStage::PlaySound(v57, v59);
            }
            *(_DWORD *)&this->m_list.m_column[5].head[4 * v11 + 52] = 3;
          }
        }
        else
        {
          *(float *)&this->m_list.m_column[6].head[8 * v11] = *(float *)&this->m_list.m_column[6].head[8 * v11]
                                                            + *(float *)&this->m_list.m_column[7].head[4 * v11 + 44];
          *(float *)&this->m_list.m_column[7].head[4 * v11 + 44] = *(float *)&this->m_list.m_column[7].head[4 * v11 + 44]
                                                                 + 0.0099999998;
          v5 = (double)(*(_DWORD *)&this->m_list.m_column[5].head[48] - 2 * (int)this->m_list.m_column[6].items.m_pData);
          if ( v5 <= *(float *)&this->m_list.m_column[6].head[8 * v11] )
          {
            (**(void ( ***)(float *, _DWORD))v30)(v30, 0);
            *(&this->m_list.m_column[5].width + 2 * v11) = 1137180672;
            *(_DWORD *)&this->m_list.m_column[6].head[8 * v11 + 24] = 1137180672;
            *(_DWORD *)&this->m_list.m_column[6].head[8 * v11] = 1133903872;
            *(_DWORD *)&this->m_list.m_column[6].head[8 * v11 + 28] = 1133903872;
            *(_DWORD *)&this->m_list.m_column[6].head[4 * v11 + 52] = 0;
            if ( !LOBYTE(this->m_list.m_scrollRc.top) )
            {
              v36 = *(_DWORD *)&this->m_list.m_column[6].head[48];
              v37 = this->m_list.m_column[5].items.m_pData + 1;
              this->m_list.m_column[5].items.m_pData = v37;
              if ( (int)v37 >= v36 )
                LOBYTE(this->m_list.m_scrollRc.top) = 1;
              *(_DWORD *)&this->m_list.m_column[5].head[4 * v11 + 52] = 3;
              capacity = this->m_list.m_column[5].items.capacity;
              ++this->m_list.m_column[5].items.m_nSize;
              this->m_list.m_column[5].items.capacity = *(&this->m_list.m_column[7].width + v11) + capacity;
            }
          }
        }
        goto LABEL_125;
      }
      if ( this->m_list.m_column[6].head[v11 + 20] )
      {
        *(float *)&this->m_list.m_column[6].head[8 * v11 + 24] = (float)(*(_DWORD *)&this->m_list.m_column[5].head[36]
                                                                       + rand() % v64);
        *(float *)&this->m_list.m_column[6].head[8 * v11 + 28] = (float)(*(_DWORD *)&this->m_list.m_column[5].head[40]
                                                                       + rand() % v65);
        *((float *)&this->m_list.m_column[6].items.capacity + 2 * v11) = *(float *)&this->m_list.m_column[6].head[8 * v11 + 24]
                                                                       - *((float *)&this->m_list.m_column[5].width
                                                                         + 2 * v11);
        v39 = *(float *)&this->m_list.m_column[6].head[8 * v11 + 28] - *(float *)&this->m_list.m_column[6].head[8 * v11];
        *((float *)&this->m_list.m_column[6].items.m_nSize + 2 * v11) = v39;
        v70 = *((float *)&this->m_list.m_column[6].items.capacity + 2 * v11);
        v71 = v39;
        v68 = *(float *)&this->m_list.m_column[7].head[8 * v11 + 8];
        v40 = *(float *)&this->m_list.m_column[7].head[8 * v11 + 12];
        v69 = *(float *)&this->m_list.m_column[7].head[8 * v11 + 12];
        v5 = acos((v40 * v71 + v68 * v70) / (sqrt(v69 * v69 + v68 * v68) + sqrt(v71 * v71 + v70 * v70))) * 57.29578;
        if ( *((float *)&this->m_list.m_column[6].items.capacity + 2 * v11) < 0.0 )
          v5 = 180.0 - v5 + 180.0;
        v30[40] = v5;
        *((_BYTE *)v30 + 172) = 0;
        this->m_list.m_column[6].head[v11 + 20] = 0;
        goto LABEL_125;
      }
      if ( *((float *)&this->m_list.m_column[5].width + 2 * v11) >= (double)*(float *)&this->m_list.m_column[6].head[8 * v11 + 24] )
      {
        if ( *((float *)&this->m_list.m_column[5].width + 2 * v11) > (double)*(float *)&this->m_list.m_column[6].head[8 * v11 + 24] )
        {
          v43 = *((float *)&this->m_list.m_column[5].width + 2 * v11);
          if ( *(&this->m_list.m_column[7].items.capacity + v11) )
            v44 = v43 - *(float *)&this->m_list.m_column[7].head[4 * v11 + 56];
          else
            v44 = v43 - *(float *)&this->m_list.m_column[7].head[4 * v11 + 44];
          *((float *)&this->m_list.m_column[5].width + 2 * v11) = v44;
          v5 = (double)(unsigned int)&this->m_list.m_column[6].items.m_pData[*(_DWORD *)&this->m_list.m_column[5].head[36]];
          if ( v5 >= *((float *)&this->m_list.m_column[5].width + 2 * v11) )
          {
            v45 = *(_DWORD *)&this->m_list.m_column[6].head[4 * v11 + 52] + 1;
            *(_DWORD *)&this->m_list.m_column[6].head[4 * v11 + 52] = v45;
            if ( v45 >= 2 )
            {
              *(_DWORD *)&this->m_list.m_column[5].head[4 * v11 + 52] = 2;
              *(_DWORD *)&this->m_list.m_column[6].head[4 * v11 + 52] = 0;
            }
            goto LABEL_124;
          }
          v5 = *((float *)&this->m_list.m_column[5].width + 2 * v11);
          if ( v5 <= *(float *)&this->m_list.m_column[6].head[8 * v11 + 24] )
          {
            *(&this->m_list.m_column[5].width + 2 * v11) = *(_DWORD *)&this->m_list.m_column[6].head[8 * v11 + 24];
            goto LABEL_124;
          }
        }
      }
      else
      {
        if ( *(&this->m_list.m_column[7].items.capacity + v11) )
          v41 = *(float *)&this->m_list.m_column[7].head[4 * v11 + 56];
        else
          v41 = *(float *)&this->m_list.m_column[7].head[4 * v11 + 44];
        *((float *)&this->m_list.m_column[5].width + 2 * v11) = v41
                                                              + *((float *)&this->m_list.m_column[5].width + 2 * v11);
        v5 = (double)(*(_DWORD *)&this->m_list.m_column[5].head[44]
                    - (unsigned int)this->m_list.m_column[6].items.m_pData);
        if ( v5 < *((float *)&this->m_list.m_column[5].width + 2 * v11) )
        {
          v42 = *(_DWORD *)&this->m_list.m_column[6].head[4 * v11 + 52] + 1;
          *(_DWORD *)&this->m_list.m_column[6].head[4 * v11 + 52] = v42;
          if ( v42 >= 2 )
          {
            *(_DWORD *)&this->m_list.m_column[5].head[4 * v11 + 52] = 2;
            *(_DWORD *)&this->m_list.m_column[6].head[4 * v11 + 52] = 0;
          }
          goto LABEL_124;
        }
        v5 = *((float *)&this->m_list.m_column[5].width + 2 * v11);
        if ( v5 >= *(float *)&this->m_list.m_column[6].head[8 * v11 + 24] )
        {
          *(&this->m_list.m_column[5].width + 2 * v11) = *(_DWORD *)&this->m_list.m_column[6].head[8 * v11 + 24];
LABEL_124:
          this->m_list.m_column[6].head[v11 + 20] = 1;
          goto LABEL_125;
        }
      }
      if ( *(float *)&this->m_list.m_column[6].head[8 * v11] >= (double)*(float *)&this->m_list.m_column[6].head[8 * v11 + 28] )
      {
        v5 = *(float *)&this->m_list.m_column[6].head[8 * v11];
        if ( v5 > *(float *)&this->m_list.m_column[6].head[8 * v11 + 28] )
        {
          v48 = *(float *)&this->m_list.m_column[6].head[8 * v11];
          if ( *(&this->m_list.m_column[7].items.capacity + v11) )
            v49 = v48 - *(float *)&this->m_list.m_column[7].head[4 * v11 + 56];
          else
            v49 = v48 - *(float *)&this->m_list.m_column[7].head[4 * v11 + 44];
          *(float *)&this->m_list.m_column[6].head[8 * v11] = v49;
          v5 = (double)(unsigned int)&this->m_list.m_column[6].items.m_pData[*(_DWORD *)&this->m_list.m_column[5].head[40]];
          if ( v5 >= *(float *)&this->m_list.m_column[6].head[8 * v11] )
          {
            v50 = *(_DWORD *)&this->m_list.m_column[6].head[4 * v11 + 52] + 1;
            *(_DWORD *)&this->m_list.m_column[6].head[4 * v11 + 52] = v50;
            if ( v50 >= 2 )
            {
              *(_DWORD *)&this->m_list.m_column[5].head[4 * v11 + 52] = 2;
              *(_DWORD *)&this->m_list.m_column[6].head[4 * v11 + 52] = 0;
            }
            goto LABEL_124;
          }
          v5 = *(float *)&this->m_list.m_column[6].head[8 * v11];
          if ( v5 <= *(float *)&this->m_list.m_column[6].head[8 * v11 + 28] )
            goto LABEL_124;
        }
      }
      else
      {
        if ( *(&this->m_list.m_column[7].items.capacity + v11) )
          v46 = *(float *)&this->m_list.m_column[7].head[4 * v11 + 56];
        else
          v46 = *(float *)&this->m_list.m_column[7].head[4 * v11 + 44];
        *(float *)&this->m_list.m_column[6].head[8 * v11] = v46 + *(float *)&this->m_list.m_column[6].head[8 * v11];
        v5 = (double)(*(_DWORD *)&this->m_list.m_column[5].head[48]
                    - (unsigned int)this->m_list.m_column[6].items.m_pData);
        if ( v5 <= *(float *)&this->m_list.m_column[6].head[8 * v11] )
        {
          v47 = *(_DWORD *)&this->m_list.m_column[6].head[4 * v11 + 52] + 1;
          *(_DWORD *)&this->m_list.m_column[6].head[4 * v11 + 52] = v47;
          if ( v47 >= 2 )
          {
            *(_DWORD *)&this->m_list.m_column[5].head[4 * v11 + 52] = 2;
            *(_DWORD *)&this->m_list.m_column[6].head[4 * v11 + 52] = 0;
          }
          goto LABEL_124;
        }
        v5 = *(float *)&this->m_list.m_column[6].head[8 * v11];
        if ( v5 >= *(float *)&this->m_list.m_column[6].head[8 * v11 + 28] )
          goto LABEL_124;
      }
LABEL_125:
      if ( ++v11 >= *(_DWORD *)&this->m_list.m_column[6].head[48] )
      {
        v10 = PtInRect;
        break;
      }
    }
  }
  if ( LOBYTE(this->m_list.m_scrollRc.top)
    && (int)this->m_list.m_column[5].items.m_pData >= *(_DWORD *)&this->m_list.m_column[6].head[48] )
  {
    (*(void ( **)(int *, int))this->m_maxlen)(&this->m_maxlen, 1);
    (**(void ( ***)(char *, _DWORD))&this->m_list.m_column[1].head[60])(&this->m_list.m_column[1].head[60], 0);
    (**(void ( ***)(char *, _DWORD))&this->m_list.m_column[3].head[44])(&this->m_list.m_column[3].head[44], 0);
  }
  if ( *(&this->m_mode + 40) == 2 )
  {
    sprintf(
      (char *const)&this->m_bk.m_rect.top,
      "\\n\\n %s %d %s\\n %s %d \n",
      (const char *)&dword_DD353C,
      this->m_list.m_column[5].items.m_nSize,
      (const char *)&dword_DDC23C,
      (const char *)&dword_DD363C,
      this->m_list.m_column[5].items.capacity);
    SetEnable((UICaption *)&this->m_list.m_scrollRc.right);
    (*(void ( **)(LONG *, int))this->m_list.m_scrollRc.right)(&this->m_list.m_scrollRc.right, 1);
    v51 = (UIQuadManager *)UIQuadManager::GetInstance();
    (((UIRenderObj *)v51))->UIRenderObj::~UIRenderObj();
    LOBYTE(this->m_ani.m_texarray.m_ptex[2]) = 1;
  }
  v52 = *(_DWORD *)&this->m_list.m_column[6].head[48];
  if ( (int)this->m_list.m_column[5].items.m_pData >= v52 && v52 > 0 )
    this->m_list.m_column[5].items.m_pData = 0;
  g_Input.GRPinput::GetCursorPos(&Point);
  v53 = (gbTexture *)this->m_ani.m_texarray.m_ptex[3];
  if ( v53 == (gbTexture *)1 )
  {
    if ( v10((const RECT *)&this->m_list.m_column[5].head[36], Point) )
      this->m_ani.m_texarray.m_ptex[3] = (gbTexture *)2;
  }
  else if ( v53 == (gbTexture *)2 && !v10((const RECT *)&this->m_list.m_column[5].head[36], Point) )
  {
    this->m_ani.m_texarray.m_ptex[3] = (gbTexture *)1;
  }
  if ( LOBYTE(this->m_ani.m_texarray.m_ptex[2]) )
  {
    if ( !v10((const RECT *)&this->m_list.m_column[5].head[36], Point) && g_Input.KeyInfo[1].PressTime == 1
      || v10((const RECT *)&this->m_list.m_column[5].head[36], Point) && g_Input.KeyInfo[0].PressTime == 1 )
    {
      this->UIRoleSelectDialog::SubtractFromStats();
      return v5;
    }
    if ( *(int *)&this->m_list.m_column[6].head[48] <= 0 )
      this->UIRoleSelectDialog::SubtractFromStats();
    goto LABEL_149;
  }
  if ( v10((const RECT *)&this->m_list.m_column[5].head[36], Point)
    || g_Input.KeyInfo[1].PressTime != 1
    || !*((_BYTE *)&this->m_mode + 180) )
  {
LABEL_149:
    (((SceneObj *)this))->SceneObj::Update(SLODWORD(st6_0), SHIDWORD(st6_0)) /* [ROWTABLE] */;
    return v5;
  }
  this->UIRoleSelectDialog::SubtractFromStats();
  v58 = (char *)off_5ED1D0;
  v54 = (CCBStage *)CScreenMode::GetInstance();
  (((CCBStage *)v54))->CCBStage::PlaySound(v58, v59);
  return v5;
}

// 0x0052AA50
int UIRoleSelectDialog::SubtractFromStats()
{
  ((RoleSystem *)&stru_C059A0)->m_nMoveRole += this->m_list.m_column[5].items.capacity;
  g_RoleSlotBuf.m_partyActor.m_dwMatMsg[2] -= *(_DWORD *)&this->m_list.m_column[1].head[24];
  if ( (int)g_RoleSlotBuf.m_partyActor.m_dwMatMsg[2] <= 0 )
    g_RoleSlotBuf.m_partyActor.m_dwMatMsg[2] = 1;
  if ( this->m_ani.m_texarray.m_ptex[3] == (gbTexture *)2 )
    this->m_ani.m_texarray.m_ptex[3] = (gbTexture *)1;
  return (((CGameData *)&g_gamefrm))->CGameData::Load(0);
}

// 0x0052AAB0

// ---- synthesized vtable stubs (unresolved slots) ----
// [VFTABLE-STUB] original: ((void ( *)(UIStatic *, int))v9->__vftable->ShowWindow)(v9, 1)
static void pal3_vtbl_unk_0(UIStatic *, int);

int UIRoleSelectDialog::ProcessDialog()
{
  char *v3; // edi
  char *v4; // esi
  double v5; // st7
  DWORD Time; // eax
  int v7; // eax
  int v8; // edx
  UIStatic *v9; // esi
  int *p_m_itemheight; // edi
  int v11; // edx
  float *p_m_ratioh; // esi
  int *p_width; // edi
  int v14; // edx
  CScreenMode *Instance; // eax
  const void *v16; // [esp-0x10] [ebp-0x14]
  int nVal; // [esp+0xC] [ebp+0x8]
  int *nMsg; // [esp+0x10] [ebp+0xC]
  int nMsga; // [esp+0x10] [ebp+0xC]
  int nMsgb; // [esp+0x10] [ebp+0xC]
  float nMsge; // [esp+0x10] [ebp+0xC]
  int nMsgc; // [esp+0x10] [ebp+0xC]
  int nMsgd; // [esp+0x10] [ebp+0xC]
  int wParam; // [esp+0x14] [ebp+0x10]

  if ( nVal != 1000 )
  {
    if ( nVal != 1009 )
      return (((CGameData *)this))->CGameData::OnMessage(nVal, (int)nMsg, wParam) /* [ROWTABLE] */;
    if ( nMsg == &byte_80AB20 )
    {
      (*(void ( **)(int *, _DWORD))this->m_maxlen)(&this->m_maxlen, 0);
      (*(void ( **)(LONG *, _DWORD))this->m_list.m_scrollRc.right)(&this->m_list.m_scrollRc.right, 0);
      LOBYTE(this->m_ani.m_texarray.m_ptex[2]) = 1;
      return 1;
    }
    return 1;
  }
  if ( !nMsg )
  {
    g_nSceneState = 2;
    if ( this->m_ani.m_texarray.m_ptex[3] == (gbTexture *)2 )
      this->m_ani.m_texarray.m_ptex[3] = (gbTexture *)1;
    return 1;
  }
  nMsga = 0;
  v3 = (char *)&this->m_list.m_column[7].head[32];
  v4 = (char *)&this->m_list.m_column[6].head[28];
  do
  {
    *((_DWORD *)v3 - 37) = 0;
    *((_DWORD *)v4 - 8) = 1137180672;
    *((_DWORD *)v4 - 1) = 1137180672;
    *((_DWORD *)v4 - 7) = 1133903872;
    *(_DWORD *)v4 = 1133903872;
    this->m_list.m_column[6].head[nMsga + 20] = 1;
    *(_DWORD *)v3 = 0;
    *((_DWORD *)v4 + 16) = 0;
    *((_DWORD *)v4 + 17) = 1065353216;
    *((_DWORD *)v4 + 10) = *((_DWORD *)v4 - 8);
    *((_DWORD *)v4 + 11) = *((_DWORD *)v4 - 7);
    *((_DWORD *)v3 - 16) = 0;
    v3 += 4;
    v4 += 8;
    v5 = (double)(rand() % 12 - 6) * 0.1 + 0.80000001;
    *((float *)v3 + 2) = v5;
    *((float *)v3 + 5) = v5 * 1.6;
    *((_DWORD *)v3 + 8) = 0;
    *((_DWORD *)v3 + 11) = 0;
    ++nMsga;
  }
  while ( nMsga < 3 );
  LOBYTE(this->m_list.m_scrollRc.top) = 0;
  LOBYTE(this->m_ani.m_texarray.m_ptex[2]) = 0;
  this->m_ani.m_texarray.m_ptex[3] = 0;
  this->m_list.m_column[5].items.m_nSize = 0;
  this->m_list.m_column[5].items.capacity = 0;
  this->m_list.m_column[5].items.m_pData = 0;
  this->m_list.m_column[5].items.m_needscriptdel = 0;
  Time = timeGetTime();
  CRT_set_new_handler(Time);
  nMsgb = (__int64)(*(float *)&this->m_list.m_firstshow * 100.0);
  if ( nMsgb <= 0
    || (nMsge = (double)nMsgb * 10.24,
        ++*(_DWORD *)&g_TempBuffer1024[912],
        g_nCombatRandSeed = 214013 * g_nCombatRandSeed + 2531011,
        (((int)g_nCombatRandSeed >> 16) & 0x3FF) >= (int)nMsge) )
  {
    LOBYTE(this->m_ani.m_texarray.m_ptex[2]) = 1;
  }
  else
  {
    nMsgc = 0;
    *(_DWORD *)&this->m_list.m_column[6].head[48] = 1;
    ++*(_DWORD *)&g_TempBuffer1024[912];
    g_nCombatRandSeed = 214013 * g_nCombatRandSeed + 2531011;
    if ( (((int)g_nCombatRandSeed >> 16) & 0x3FF) < (int)102.39999 )
      *(_DWORD *)&this->m_list.m_column[6].head[48] = 3;
    v7 = *(_DWORD *)&this->m_list.m_column[6].head[48];
    if ( v7 == 3 )
    {
      this->m_list.m_column[7].items.capacity = 1;
      v8 = rand() % 100 + 100;
      this->m_list.m_column[7].width = v8;
      LOBYTE(v8) = *((_BYTE *)&this->m_mode + 196);
      (((UIStatic *)&this->m_face.m_ratioh))->UIStatic::CreateFromTemplate("SubGame\\KillFlyer\\Flyer_gold.tga", v8);
      (*(void ( **)(float *, int))LODWORD(this->m_face.m_ratioh))(&this->m_face.m_ratioh, 1);
      nMsgd = 1;
      if ( *(int *)&this->m_list.m_column[6].head[48] > 1 )
      {
        v9 = (UIStatic *)(&this->m_static.m_bInvalidate + 20);
        p_m_itemheight = (int *)&this->m_list.m_itemheight;
        do
        {
          *(p_m_itemheight - 3) = 0;
          v11 = rand() % 20 + 1;
          *p_m_itemheight = v11;
          LOBYTE(v11) = *((_BYTE *)&this->m_mode + 196);
          (((UIStatic *)v9))->UIStatic::CreateFromTemplate("SubGame\\KillFlyer\\Flyer_nor.tga", v11);
          pal3_vtbl_unk_0(v9, 1) /* [VFTABLE-STUB] */;
          ++p_m_itemheight;
          v9 = (UIStatic *)((char *)v9 + 184);
          ++nMsgd;
        }
        while ( nMsgd < *(_DWORD *)&this->m_list.m_column[6].head[48] );
      }
    }
    else if ( v7 > 0 )
    {
      p_m_ratioh = (float *)&this->m_face.m_ratioh;
      p_width = (int *)&this->m_list.m_column[7].width;
      do
      {
        *(p_width - 3) = 0;
        v14 = rand() % 20 + 1;
        *p_width = v14;
        LOBYTE(v14) = *((_BYTE *)&this->m_mode + 196);
        (((UIStatic *)p_m_ratioh))->UIStatic::CreateFromTemplate("SubGame\\KillFlyer\\Flyer_nor.tga", v14);
        (**(void ( ***)(float *, int))p_m_ratioh)(p_m_ratioh, 1);
        ++p_width;
        p_m_ratioh += 46;
        ++nMsgc;
      }
      while ( nMsgc < *(_DWORD *)&this->m_list.m_column[6].head[48] );
    }
    LOBYTE(this->m_ani.m_texarray.m_ptex[2]) = 0;
    v16 = (const void *)off_5ED1D0;
    Instance = (CScreenMode *)CScreenMode::GetInstance();
    (((CScreenMode *)Instance))->CScreenMode::AudioSetPosition(v16, 0);
  }
  g_nSceneState = 1;
  this->m_ani.m_texarray.m_ptex[3] = (gbTexture *)2;
  return 1;
}

static void pal3_vtbl_unk_0(UIStatic *, int)
{
    
}


// 0x0052BBD0
void UIRoleSelectDialog::DestroyStatics()
{
  sub_4422E0(this);
  sub_4422E0(&this->m_bk.m_currect.right);
  sub_4422E0(&this->m_ani.m_childs);
  sub_4422E0(&this->m_face.m_rect.right);
  ctor_17((UIButton *)&this->m_static.m_id);
  sub_4422E0(&this->m_list.m_scrollbar.m_bPress);
  sub_4422E0(&this->m_list.m_scrollbar.m_texarray.m_ptex[7]);
  ctor_17((UIButton *)&this->m_list.m_column[0].head[16]);
  sub_4422E0(&this->m_list.m_column[3].head[8]);
}

// 0x0052BC90
void UIRoleSelectDialog::DestroyFrames()
{
  (((UIFrameWnd *)&this->m_list.m_column[3].head[8]))->UIFrameWnd::_UIFrameWnd();
  (((UIButton *)&this->m_list.m_column[0].head[16]))->UIButton::~UIButton();
  (((UIFrameWnd *)&this->m_list.m_scrollbar.m_texarray.m_ptex[7]))->UIFrameWnd::_UIFrameWnd();
  (((UIFrameWnd *)&this->m_list.m_scrollbar.m_bPress))->UIFrameWnd::_UIFrameWnd();
  (((UIButton *)&this->m_static.m_id))->UIButton::~UIButton();
  (((UIFrameWnd *)&this->m_face.m_rect.right))->UIFrameWnd::_UIFrameWnd();
  (((UIFrameWnd *)&this->m_ani.m_childs))->UIFrameWnd::_UIFrameWnd();
  (((UIFrameWnd *)&this->m_bk.m_currect.right))->UIFrameWnd::_UIFrameWnd();
  (((UIFrameWnd *)this))->UIFrameWnd::_UIFrameWnd() /* [ROWTABLE] */;
}

// 0x0052D200
char UIRoleSelectDialog::IsRoleSelectable(int nVal)
{
  int v3; // eax
  int *i; // ecx

  if ( *((_BYTE *)&((RoleSystem *)&stru_C059A0)->m_nRetryCount + nVal) )
  {
    v3 = 0;
    for ( i = &this->m_mode + 25; *i == nVal; ++i )
    {
      if ( ++v3 >= 4 )
        return 1;
    }
  }
  return 0;
}
