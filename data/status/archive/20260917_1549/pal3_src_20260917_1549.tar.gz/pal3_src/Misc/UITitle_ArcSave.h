#include "Misc/UIFrameWnd.h"
#pragma once
// Auto-generated: UITitle_ArcSave
#include "pal3/ida_types.h"

#include "Misc/MUIDialog.h"

class PalScript;
class UIWnd;

class UITitle_ArcSave : public UIFrameWnd {
public:
    char _gap_000[72]; // +0x0
    MUIDialog m_YesNo; // +0x48
    char _tail_550[2644]; // +0x550
    // total size: 0xFA4 (4004)

    virtual ~UITitle_ArcSave() {}

    virtual void Render(); // 0x0047C370
    virtual int ProcessPageAction(struct PalScript *p, int nVal); // 0x0047C3A0
    virtual void Destroy(); // 0x0047BDF0
    void * _scalar_dtor(UIWnd *Block, char pData); // 0x0047BD00
    virtual int OnMessage(int nVal, int nVal2, int nVal3); // 0x0047C430
    int ctor(); // 0x0047BBF0
    UITitle_ArcSave(); // 0x0047BD20
};
