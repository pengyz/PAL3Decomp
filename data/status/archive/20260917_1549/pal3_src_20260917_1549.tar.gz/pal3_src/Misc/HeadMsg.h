#pragma once
// Auto-generated: HeadMsg
#include "pal3/ida_types.h"

#include "pal3/pal3_stl.h"

class HeadMsg {
public:
    char _gap_000[4]; // +0x0
    BYTE m_bEnable; // +0x4
    char _gap_005[3]; // +0x5
    string m_szMsg; // +0x8
    char _gap_00C[12]; // +0xC
    float m_fTime; // +0x18
    int m_nType; // +0x1C
    int m_nY; // +0x20
    // total size: 0x24 (36)

};
