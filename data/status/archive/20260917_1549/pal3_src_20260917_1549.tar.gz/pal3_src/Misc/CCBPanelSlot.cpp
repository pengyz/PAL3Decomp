#include "pal3/ida_defs.h"
#include "globals.h"
#include "pal3/pal3_constants.h"
#include "Misc/CCBPanelSlot.h"
#include "Misc/TextureLibDataBase.h"

// 0x00443200
void CCBPanelSlot::Render()
{
  gbMatrixStack *v1; // edi
  int m_nDimH2; // edx
  int v4; // ecx
  float v5; // ecx
  unsigned int v6; // ecx
  TextureLibDataBase *v7; // ecx
  float v8; // [esp+0x2C] [ebp-0x74]
  gbColorQuad v9; // [esp+0x30] [ebp-0x70] BYREF
  int v10; // [esp+0x34] [ebp-0x6C]
  int v11; // [esp+0x48] [ebp-0x58]
  float v12; // [esp+0x4C] [ebp-0x54]
  struct gbVec3D v13; // [esp+0x50] [ebp-0x50] BYREF
  _BYTE v14[64]; // [esp+0x60] [ebp-0x40] BYREF

  v1 = gfxMgr->pMatrixStack[1];
  (((gbMatrixStack *)v1))->gbMatrixStack::Push();
  m_nDimH2 = this->m_nDimH2;
  v4 = this->m_nEdgeR2 - (this->m_nEdgeR2 - this->m_nMarginX2) / 2;
  v10 = 0;
  v12 = *(float *)&v4;
  v11 = this->m_nEdgeB2 - (this->m_nEdgeB2 - m_nDimH2) / 2;
  v12 = ((double)SLODWORD(v12) + (double)SLODWORD(v12)) / (double)g_DrvInfo.width
      - 1.0
      + ((double)*(int *)&this->m_Widget[92] + (double)*(int *)&this->m_Widget[92]) / (double)g_DrvInfo.width
      - 1.0;
  *(float *)&v11 = 1.0
                 - ((double)v11 + (double)v11) / (double)g_DrvInfo.height
                 + 1.0
                 - ((double)*(int *)&this->m_Widget[96] + (double)*(int *)&this->m_Widget[96])
                 / (double)g_DrvInfo.height;
  (((gbMatrixStack *)v1))->gbMatrixStack::Translate(*v12,   *(float *)&v11,   0.0);
  (((gbMatrixStack *)v1))->gbMatrixStack::Scale(0.125,   0.16666667,   1.0);
  if ( *(_DWORD *)&this->m_Widget[64] <= 2u )
  {
    v5 = *(float *)&this->m_Widget[60];
    v13.x = 0.0;
    v13.y = 0.0;
    v13.z = 1.0;
    (((gbMatrixStack *)v1))->gbMatrixStack::Rotate(v5,  *v13);
  }
  (((gbMatrixStack *)v1))->gbMatrixStack::Scale(8.0,   6.0,   1.0);
  *(float *)&v9.Color = -*(float *)&v11;
  v8 = -v12;
  (((gbMatrixStack *)v1))->gbMatrixStack::Translate(*v8,   *(float *)&v9.Color,   0.0);
  if ( *(_DWORD *)&this->m_Widget[20] )
  {
    v10 = *(_DWORD *)&this->m_Widget[24];
    v9.Color = v6;
    (((TextureLibDataBase *)v7))->TextureLibDataBase::_GetItemNum(&this->m_nMarginX2);
  }
  (((gbMatrixStack *)v1))->gbMatrixStack::Pop();
}
