#include "Misc/UIStaticEX.h"
#pragma once
// Auto-generated: UIStaticEXA
#include "pal3/ida_types.h"

class UIStaticEXA : public UIStaticEX {
public:
    char _gap_000[184]; // +0x0
    int center_x; // +0xB8
    int center_y; // +0xBC
    // total size: 0xC0 (192)

};
