#pragma once
// Auto-generated: _count_string
#include "pal3/ida_types.h"

class _count_string {
public:
    short Length; // +0x0
    short MaximumLength; // +0x2
    char * Buffer; // +0x4
    // total size: 0x8 (8)

};
