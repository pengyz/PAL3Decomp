#pragma once
// Auto-generated: CLoad3DS
#include "pal3/ida_types.h"

#include "gbengine/gbVFileSystem.h"

class CLoad3DS {
public:
    gbVFile * m_FilePointer; // +0x0
    char m_pBuffer[20]; // +0x4
    int m_nTodo_018; // +0x18
    int m_nTodo_01C; // +0x1C
    int m_nTodo_020; // +0x20
    // total size: 0x24 (36)

};
