#include "pal3/ida_defs.h"
#include "globals.h"
#include "pal3/pal3_constants.h"
#include "Misc/UITitle_QCYM.h"
#include "GameBase/PAL3.h"
#include "Render/RenderTarget.h"
#include "free_functions.h"

// 0x00529BE0
int UITitle_QCYM::HandleDeviceLostC()
{
  RenderTarget *Instance_db10; // eax
  PAL3 *v3; // ecx
  PAL3 *v4; // ecx
  int v5; // eax
  RenderTarget *v6; // eax
  int result; // eax
  PAL3 *v8; // ecx
  unsigned __int8 v9; // bl
  PAL3 *v10; // ecx
  RenderTarget *v11; // eax
  PAL3 *v12; // ecx
  RenderTarget *v13; // eax

  Instance_db10 = (RenderTarget *)GetInstance_db10((PAL3 *)this);
  (((RenderTarget *)Instance_db10))->RenderTarget::OnDeviceLost(1);
  v4 = *(PAL3 **)GetInstance_db10(v3);
  v5 = 1061158912;
  if ( v4 )
    v5 = 1065353216;
  this->m_btn[2].m_texarray.m_ptex[11] = (gbTexture *)v5;
  this->m_btn[2].m_texarray.m_ptex[10] = (gbTexture *)v5;
  v6 = (RenderTarget *)GetInstance_db10(v4);
  LOBYTE(result) = (((RenderTarget *)v6))->RenderTarget::OnResetDevice(1);
  if ( (_BYTE)result )
  {
    v9 = g_bGameFlag2;
    g_bGameFlag2 = 0;
    (((PAL3 *)v8))->PAL3::Render();
    g_bGameFlag2 = v9;
    v11 = (RenderTarget *)GetInstance_db10(v10);
    (((RenderTarget *)v11))->RenderTarget::RenderToScreen();
    this->m_btn[2].m_texarray.m_ptex[9] = 0;
    v13 = (RenderTarget *)GetInstance_db10(v12);
    result = (int)(((RenderTarget *)v13))->RenderTarget::GetActiveTexture();
    if ( result )
    {
      if ( *(_DWORD *)(result + 84) )
        this->m_btn[2].m_texarray.m_ptex[9] = (gbTexture *)result;
    }
  }
  else
  {
    this->m_btn[2].m_texarray.m_ptex[9] = 0;
  }
  return result;
}
