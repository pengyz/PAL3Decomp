#include "Misc/PalScriptWaitObj.h"
#include "UI/UIWnd.h"
#pragma once
// Auto-generated: UICaption
#include "pal3/ida_types.h"

#include "gbengine/gbTexture.h"
#include "gbengine/gbVFileSystem.h"

class UIScene;

class UICaption : public UIWnd, public PalScriptWaitObj {
public:
    char _gap_000[76]; // +0x0
    gbTexture * m_tex; // +0x4C
    int m_numline; // +0x50
    int m_lineheight; // +0x54
    int m_curline; // +0x58
    float m_linetime; // +0x5C
    // total size: 0x60 (96)

    virtual ~UICaption() {}

    virtual void Render(); // 0x0043AD40
    virtual BOOL Update2(int nVal, int nVal2); // 0x0043AB20
    virtual void Destroy(); // 0x0043AB00
    UIScene * _sdtor(UIScene *Block, char pData); // 0x0043A7F0
    virtual gbVFileSystem * CreateChildWidget(int id, void *pRect, gbVFileSystem *parent, const char *pszName, char pData, char pData2); // 0x0043A870
    void Destroy2(); // 0x0043A810
    UICaption * _sdtor_5(char a2); // 0x0043B4B0
    void SetEnable(int szName, int bEnable); // 0x004427C0
    void DestroyPanel(); // 0x004461F0
    void DestroyAll(); // 0x0044BDA0
    UICaption * _sdtor_24(char a2); // 0x0044BE00
    void LayoutDefault(); // 0x00450320
};
