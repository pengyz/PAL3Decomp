#include "pal3/ida_defs.h"
#include "globals.h"
#include "pal3/pal3_constants.h"
#include "Misc/UISceneFace.h"
#include "Role/RoleSystem.h"
#include "UI/UIListBox.h"
#include "Misc/UIProgressBar.h"
#include "Misc/UIScenePanel.h"
#include "Misc/UIScrollBar.h"
#include "free_functions.h"

// 0x0052D010
int UISceneFace::SetFaceVisible(int nVal, unsigned int dwVal)
{
  char *v4; // edi
  int result; // eax

  v4 = (char *)this + 1552 * nVal;
  (**((void ( ***)(int, _DWORD))v4 + 606))((int)(v4 + 2424), (unsigned __int8)dwVal);
  (**((void ( ***)(int, _DWORD))v4 + 644))((int)(v4 + 2576), (unsigned __int8)dwVal);
  (**((void ( ***)(int, _DWORD))v4 + 682))((int)(v4 + 2728), (unsigned __int8)dwVal);
  (**((void ( ***)(int, _DWORD))v4 + 720))((int)(v4 + 2880), (unsigned __int8)dwVal);
  (**((void ( ***)(int, _DWORD))v4 + 758))((int)(v4 + 3032), (unsigned __int8)dwVal);
  (**((void ( ***)(int, _DWORD))v4 + 819))((int)(v4 + 3276), (unsigned __int8)dwVal);
  (**((void ( ***)(int, _DWORD))v4 + 857))((int)(v4 + 3428), (unsigned __int8)dwVal);
  (**((void ( ***)(int, _DWORD))v4 + 895))((int)(v4 + 3580), (unsigned __int8)dwVal);
  result = (**((int ( ***)(int, _DWORD))v4 + 956))((int)(v4 + 3824), (unsigned __int8)dwVal);
  LOBYTE(result) = dwVal;
  *((_BYTE *)&this[5].m_state[0].m_disablepic + nVal + 1) = dwVal;
  return result;
}

// 0x0052D0D0
int UISceneFace::ResetAllSlots()
{
  int i; // esi
  int result; // eax

  for ( i = 0; i < 5; ++i )
    result = this->UISceneFace::SetFaceVisible(i, 0);
  return result;
}

// 0x0052D0F0
int UISceneFace::UpdateFacePosition()
{
  UISceneFace *v1; // ebx
  int result; // eax
  int v3; // ebp
  int *v4; // edi
  char *p_m_ratioh; // esi
  float fValue; // [esp+0x0] [ebp-0x28]
  float fValuea; // [esp+0x0] [ebp-0x28]
  float fValueb; // [esp+0x0] [ebp-0x28]
  float fValuec; // [esp+0x0] [ebp-0x28]
  int v11; // [esp+0x18] [ebp-0x10]
  int v12; // [esp+0x20] [ebp-0x8]
this->UISceneFace::ResetAllSlots();
  result = 0;
  v12 = 192;
  v3 = 0;
  v4 = (int *)(&g_RoleSlotBuf.m_partyActor.m_nAnimFrame + 4);
  p_m_ratioh = (char *)&v1[1].m_state[0].m_ratioh;
  do
  {
    if ( *((_BYTE *)&((RoleSystem *)&stru_C059A0)->m_nRetryCount + v3) )
    {
      LayoutSlot((UIScenePanel *)v1);
      (((UISceneFace *)v1))->UISceneFace::SetFaceVisible(v3, 1u);
      v11 = v12 + 10;
      v12 += 202;
      (((UIListBox *)p_m_ratioh))->UIListBox::GetCurSel();
      fValue = (float)*(v4 - 2);
      (((UIScrollBar *)p_m_ratioh))->UIScrollBar::SetRange(fValue);
      *((_DWORD *)p_m_ratioh + 28) = 1065353216;
      (((UIListBox *)(p_m_ratioh + 548)))->UIListBox::GetCurSel();
      fValuea = (float)*v4;
      (((UIScrollBar *)(p_m_ratioh + 548)))->UIScrollBar::SetRange(fValuea);
      *((_DWORD *)p_m_ratioh + 165) = 1065353216;
      fValueb = (float)v4[10];
      (((UIProgressBar *)p_m_ratioh))->UIProgressBar::FindChildByName(fValueb);
      fValuec = (float)v4[12];
      (((UIProgressBar *)(p_m_ratioh + 548)))->UIProgressBar::FindChildByName(fValuec);
      result = v11;
}
    v4 += 352;
    ++v3;
    p_m_ratioh += 1552;
  }
  while ( (int)v4 < (int)&((RoleSystem *)&stru_C059A0)->m_teamSlotOverlay.m_teamSlots[164] );
  BYTE1(this->m_bk.m_FVF) = 1;
  return result;
}
