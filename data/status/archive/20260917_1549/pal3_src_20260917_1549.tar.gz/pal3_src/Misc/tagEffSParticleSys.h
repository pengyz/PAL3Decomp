#pragma once
// Auto-generated: tagEffSParticleSys
#include "pal3/ida_types.h"

class tagEffSParticleSys {
public:
    int m_nEffCount; // +0x0
    char _gap_004[4]; // +0x4
    float m_vSpawnPos[2]; // +0x8
    float m_vSpawnOffset[2]; // +0x10
    int m_nSpawnFlags; // +0x18
    int m_nSpawnCount; // +0x1C
    float m_fSpawnSize; // +0x20
    int m_nSpawnLife; // +0x24
    float m_fSpawnBright; // +0x28
    int m_nSpawnEffect; // +0x2C
    BYTE m_bSpawnActive; // +0x30
    char _gap_031[7]; // +0x31
    float m_vSpawn2Pos[2]; // +0x38
    int m_nSpawn2Flags; // +0x40
    int m_nSpawn2Count; // +0x44
    float m_fSpawn2Size; // +0x48
    int m_nSpawn2Color; // +0x4C
    int m_nSpawn2Life; // +0x50
    int m_nSpawn2Bright; // +0x54
    int m_nSpawn2Effect; // +0x58
    int m_nSpawn2Rand; // +0x5C
    BYTE m_bSpawn2Active; // +0x60
    char _gap_061[7]; // +0x61
    float m_vSpawn3Pos[2]; // +0x68
    float m_vSpawn3Rand[2]; // +0x70
    int m_nSpawn3Flags; // +0x78
    int m_nSpawn3Count; // +0x7C
    float m_fSpawn3Size; // +0x80
    int m_nSpawn3Color; // +0x84
    float m_fSpawn3Bright; // +0x88
    int m_nSpawn3Life; // +0x8C
    BYTE m_bSpawn3Active; // +0x90
    char _gap_091[655]; // +0x91
    int m_ptLastSpawn[2]; // +0x320
    // total size: 0x328 (808)

};
