#pragma once
// Auto-generated: tagScriptCmd
#include "pal3/ida_types.h"

class tagScriptCmd {
public:
    short cmd_id; // +0x0
    char _gap_002[2]; // +0x2
    int handler; // +0x4
    int param; // +0x8
    int flags; // +0xC
    // total size: 0x10 (16)

};
