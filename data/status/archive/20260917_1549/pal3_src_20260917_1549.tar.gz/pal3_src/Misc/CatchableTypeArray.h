#pragma once
// Auto-generated: CatchableTypeArray
#include "pal3/ida_types.h"

class CatchableTypeArray {
public:
    int nCatchableTypes; // +0x0
    // total size: 0x4 (4)

};
