#include "pal3/ida_defs.h"
#include "globals.h"
#include "pal3/pal3_constants.h"
#include "Misc/CJ_FindFile.h"
#include "Misc/BINK.h"
#include "Combat/CCBItemWindow.h"
#include "UI/UINote.h"
#include "Misc/UIProgressBar.h"
#include "UI/UIScene.h"
#include "Misc/UIScrollBar.h"
#include "Misc/UIStatic.h"
#include "UI/UIWnd.h"
#include "free_functions.h"

// Forward declarations for unnamed functions

// 0x00450F90
int CJ_FindFile::Create(int id, void *pRect, int parent, char *tex)
{
  int v6; // eax
  int v7; // ebx
  int v8; // edx
  int v9; // eax
  int v10; // ebx
  int v11; // ebx
  int v12; // eax
  int v13; // eax
  int a2; // [esp+0x3C] [ebp-0x10] BYREF
  int v16; // [esp+0x40] [ebp-0xC]
  int v17; // [esp+0x44] [ebp-0x8]
  int v18; // [esp+0x48] [ebp-0x4]

  *(_DWORD *)pRect = 0;
  *(_DWORD *)&this->m_strRoot[20] = 458;
  *((_DWORD *)pRect + 2) = 800;
  *((_DWORD *)pRect + 3) = 594;
  (((CCBItemWindow *)this))->CCBItemWindow::Create(id, (tagRECT *)pRect, parent) /* [ROWTABLE] */;
  (((UINote *)&this->m_strRoot[80]))->UINote::Create(0, (int)pRect, 0, "ui\\flex\\dlg");
  *(_DWORD *)&this->m_strRoot[148] = 1048576000;
  v18 = g_DrvInfo.height - 8;
  v16 = g_DrvInfo.height - 520;
  v6 = *(_DWORD *)&this->m_fileName[100];
  a2 = 8;
  v17 = 264;
  (*(void ( **)(char *, int, int *, CJ_FindFile *))(v6 + 16))(&this->m_fileName[100], 2, &a2, this);
  v7 = *(_DWORD *)&this->m_strRoot[24];
  v8 = *(_DWORD *)&this->m_strRoot[16];
  v9 = *(_DWORD *)&this->m_fileName[256];
  v16 = 8;
  v10 = v7 - v8;
  a2 = 256;
  v17 = 600;
  v18 = 144;
  (*(void ( **)(char *, int, int *, CJ_FindFile *))(v9 + 16))(&this->m_fileName[256], 1, &a2, this);
  sub_446010(&this->m_fileName[256]);
  (*(void ( **)(char *, int, int *, CJ_FindFile *))(*(_DWORD *)&this->m_strRoot[272] + 16))(
    &this->m_strRoot[272],
    2,
    &a2,
    this);
  (((UIScene *)&this->m_strRoot[272]))->UIScene::LoadResource("ui\\scene\\page");
  UIScene_SetController(0x40000000);
  SetVideoRect((BINK *)this);
  sub_445FA0(&this->m_strRoot[272]);
  v11 = (v10 - 134) / 2;
  a2 = v11;
  v17 = v11 + 134;
  v12 = *(_DWORD *)&this->m_strbuf[36];
  v18 = 600;
  v16 = 580;
  (*(void ( **)(char *, _DWORD, int *, CJ_FindFile *))(v12 + 16))(&this->m_strbuf[36], 0, &a2, this);
  sub_445FA0(&this->m_strbuf[36]);
  (((UIStatic *)&this->m_strbuf[36]))->UIStatic::CreateFromTemplate("ui\\scene\\timeclose.tga", 0);
  v13 = *(_DWORD *)&this->m_strbuf[188];
  a2 = v11;
  v17 = v11 + 134;
  v18 = 600;
  v16 = 568;
  (*(void ( **)(char *, _DWORD, int *, CJ_FindFile *))(v13 + 16))(&this->m_strbuf[188], 0, &a2, this);
  sub_43FEC0(&a2);
  (((UIScene *)&this->m_strbuf[188]))->UIScene::GetChildCount();
  (((UIScene *)&this->m_strbuf[188]))->UIScene::GetChildAt();
  (((UIScrollBar *)&this->m_strbuf[188]))->UIScrollBar::SetRange(4.0);
  (((UIProgressBar *)&this->m_strbuf[188]))->UIProgressBar::FindChildByName(0.0);
  *(_DWORD *)&this->m_strbuf[300] = 1120403456;
  sub_43FDB0((float *)&this->m_strbuf[188], 4);
  (((UIWnd *)&this->m_strbuf[188]))->UIWnd::GetHeight(9);
  (((UIWnd *)&this->m_strbuf[188]))->UIWnd::GetWidth(4);
  (((UIWnd *)&this->m_strbuf[188]))->UIWnd::GetPosition(9);
  return (**(int ( ***)(char *, _DWORD))&this->m_strbuf[188])(&this->m_strbuf[188], 0);
}
