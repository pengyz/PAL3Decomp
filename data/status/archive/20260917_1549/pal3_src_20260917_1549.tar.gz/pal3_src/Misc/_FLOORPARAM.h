#pragma once
// Auto-generated: _FLOORPARAM
#include "pal3/ida_types.h"

class _FLOORPARAM {
public:
    tagPOINT m_GoundPt; // +0x0
    BYTE m_Valid; // +0x8
    char _tail_009[3]; // +0x9
    // total size: 0xC (12)

};
