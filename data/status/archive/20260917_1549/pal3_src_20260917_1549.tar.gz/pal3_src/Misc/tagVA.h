#pragma once
// Auto-generated: tagVA
#include "pal3/ida_types.h"

#include "Misc/ECBVAKind.h"

class tagVA {
public:
    ECBVAKind eKind; // +0x0
    char _gap_001[3]; // +0x1
    int nSrc; // +0x4
    int nDest; // +0x8
    int nStart; // +0xC
    int nEnd; // +0x10
    BYTE bValid; // +0x14
    char _tail_015[3]; // +0x15
    // total size: 0x18 (24)

};
