#pragma once
// Auto-generated: CG_Scene_ArrayErase
#include "pal3/ida_types.h"

class CG_Scene_ArrayErase {
public:
    _BYTE _tail_000[4]; // +0x0
    // total size: 0x4 (4)

    // Scalar-wrapper: ctors for IDA (Cls)int casts (no init code)
    CG_Scene_ArrayErase() {}
    CG_Scene_ArrayErase(int v) { *(int*)this = v; }

};
