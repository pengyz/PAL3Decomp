#pragma once
// Auto-generated: Param0
#include "pal3/ida_types.h"

#include "Misc/localVar0.h"

class Param0 {
public:
    localVar0 loc; // +0x0
    DWORD retAddr; // +0xC
    DWORD pOut; // +0x10
    DWORD pIn; // +0x14
    DWORD n; // +0x18
    // total size: 0x1C (28)

};
