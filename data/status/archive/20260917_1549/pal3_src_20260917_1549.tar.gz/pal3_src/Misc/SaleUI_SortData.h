#pragma once
// Auto-generated: SaleUI_SortData
#include "pal3/ida_types.h"

class SaleUI_SortData {
public:
    _BYTE _tail_000[4]; // +0x0
    // total size: 0x4 (4)

    // Scalar-wrapper: ctors for IDA (Cls)int casts (no init code)
    SaleUI_SortData() {}
    SaleUI_SortData(int v) { *(int*)this = v; }

    operator int() const { return *(int*)this; }
    void operator=(int v) { *(int*)this = v; }
};
