#pragma once
// Auto-generated: SPECIAL_ACTION
#include "pal3/ida_types.h"

class SPECIAL_ACTION {
public:
    _BYTE _tail_000[4]; // +0x0
    // total size: 0x4 (4)

    // Scalar-wrapper: ctors for IDA (Cls)int casts (no init code)
    SPECIAL_ACTION() {}
    SPECIAL_ACTION(int v) { *(int*)this = v; }

};
