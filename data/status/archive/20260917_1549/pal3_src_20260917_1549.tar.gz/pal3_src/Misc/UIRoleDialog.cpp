#include "pal3/ida_defs.h"
#include "globals.h"
#include "pal3/pal3_constants.h"
#include "Misc/UIRoleDialog.h"
#include "Data/CGameData.h"
#include "Render/CScreenMode.h"
#include "GameBase/GRPinput.h"
#include "Misc/MUIDialog.h"
#include "Misc/PtrArray.h"
#include "Scene/SceneObj.h"
#include "Misc/UICaption.h"
#include "UI/UIDialog.h"
#include "Misc/UIFrameWnd.h"
#include "UI/UIScene.h"
#include "Misc/UITitle.h"
#include "Misc/UITitle_BBTY.h"
#include "UI/UIWnd.h"
#include "free_functions.h"

// Forward declarations for unnamed functions

// 0x004A1410
UIRoleDialog::~UIRoleDialog()
{
  (((UITitle *)this))->UITitle::HideAll() /* [ROWTABLE] */;
  (((UICaption *)(&this[1].m_bk.m_openstyle + 2)))->UICaption::Destroy2();
  (((UICaption *)&this->m_static.m_childs.capacity))->UICaption::Destroy2();
  (((UIFrameWnd *)&this->m_face.m_rect.top))->UIFrameWnd::_UIFrameWnd();
  (((UIFrameWnd *)&this->m_ani.m_pfather))->UIFrameWnd::_UIFrameWnd();
  UITextArea_Destroy();
  g_nUILayoutFlags = 0;
  this->UIWnd::Destroy();
}

// 0x004A1A80
void * UIRoleDialog::RemoveChild(void *pChild, char bDelete)
{
  void *result; // eax

  ((void ( *)(UIWnd **))this->m_bk.m_pfather->m_fontcolor.Color)(&this->m_bk.m_pfather);
  (((UITitle_BBTY *)this))->UITitle_BBTY::Render() /* [ROWTABLE] */;
  return result;
}

// 0x004A1AA0
BOOL UIRoleDialog::ProcessFrame(int nVal, int nVal2)
{
  DWORD TickCount; // eax
  DWORD v6; // eax
  unsigned int v7; // ecx
  char *m_id; // eax
  char *v9; // eax
  int v10; // eax

  if ( !LOBYTE(this[1].m_static.m_rect.bottom) )
    return 0;
  if ( !nVal2 )
    return (((UIFrameWnd *)this))->UIFrameWnd::Update_bbc0(nVal, 0) /* [ROWTABLE] */;
  if ( !LOBYTE(this[1].m_static.m_bcreateok) && this->m_bmodal )
  {
    if ( !LOBYTE(this[1].m_static.m_childs.m_needscriptdel) )
    {
      TickCount = GetTickCount();
      this[1].m_static.m_childs.capacity = TickCount;
      this[1].m_static.m_childs.m_nSize = TickCount;
      LOBYTE(this[1].m_static.m_childs.m_needscriptdel) = 1;
    }
    v6 = GetTickCount();
    v7 = v6 - this[1].m_static.m_childs.m_nSize;
    this[1].m_static.m_childs.capacity = v6;
    if ( v7 > 0x258 )
    {
      this[1].m_static.m_childs.m_nSize = v6;
      LOBYTE(this[1].m_static.m_childs.m_needscriptdel) = 0;
      LOBYTE(this[1].m_static.m_bcreateok) = 1;
    }
    return (((UIFrameWnd *)this))->UIFrameWnd::Update_bbc0(nVal, nVal2) /* [ROWTABLE] */;
  }
  m_id = (char *)this[1].m_static.m_id;
  if ( !m_id )
  {
    m_pfather->ShowWindow(&this->m_ani.m_pfather, 1);
    (*(void ( **)(int *, int))this->m_static.m_childs.capacity)(
      &this->m_static.m_childs.capacity,
      1);
    LOBYTE(this[1].m_id) = 1;
    if ( g_Input.KeyInfo[7].PressTime != 1 )
      goto LABEL_22;
    goto LABEL_21;
  }
  v9 = (char *)(m_id - 2);
  if ( v9 )
  {
    if ( v9 == (char *)1 && this->m_ani.m_id == (void *)2 )
      (*(void ( **)(LONG *, int))this->m_face.m_rect.top)(&this->m_face.m_rect.top, 1);
    goto LABEL_22;
  }
  m_pfather->ShowWindow(&this->m_ani.m_pfather, 1);
  (*(void ( **)(int *, int))this->m_static.m_childs.capacity)(&this->m_static.m_childs.capacity, 1);
  (**((void ( ***)(int *, int))&this[1].m_bk.m_openstyle + 2))(&this[1].m_bk.m_openstyle + 2, 1);
  LOBYTE(this[1].m_id) = 1;
  LOBYTE(this[1].m_ani.m_texarray.m_ptex[2]) = 1;
  if ( g_Input.KeyInfo[7].PressTime == 1 )
  {
LABEL_21:
    ((void ( *)(UIRoleDialog *, int, int, _DWORD))this->UIDialog::UIWnd::__vftable->OnMessage)(
      this,
      1001,
      655362,
      0);
    goto LABEL_22;
  }
  if ( g_Input.KeyInfo[8].PressTime == 1 )
    ((void ( *)(UIRoleDialog *, int, int, _DWORD))this->UIDialog::UIWnd::__vftable->OnMessage)(
      this,
      1001,
      655363,
      0);
LABEL_22:
  v10 = (int)this[1].m_static.m_id;
  if ( v10 < 0 )
    return (((UIFrameWnd *)this))->UIFrameWnd::Update_bbc0(nVal, nVal2) /* [ROWTABLE] */;
  if ( v10 <= 2 )
  {
    if ( !this->m_bmodal )
      return (((UIFrameWnd *)this))->UIFrameWnd::Update_bbc0(nVal, nVal2) /* [ROWTABLE] */;
  }
  else
  {
    if ( v10 != 3 || !this->m_bmodal )
      return (((UIFrameWnd *)this))->UIFrameWnd::Update_bbc0(nVal, nVal2) /* [ROWTABLE] */;
    if ( g_Input.KeyInfo[0].PressTime == 1
      || g_Input.KeyInfo[7].PressTime == 1
      || g_Input.KeyInfo[8].PressTime == 1
      || g_Input.KeyInfo[6].PressTime == 1
      || g_Input.KeyInfo[2].PressTime == 1
      || g_Input.KeyInfo[3].PressTime == 1
      || g_Input.KeyInfo[4].PressTime == 1
      || g_Input.KeyInfo[5].PressTime == 1
      || g_Input.KeyInfo[11].PressTime == 1 )
    {
      this[1].m_static.m_rect.left = 2;
      /* [MISATTRIBUTED] MUIDialog on UIRoleDialog::this -> fix IDB name of callee */ MUIDialog::InvokeCallback((MUIDialog *)this);
      return (((UIFrameWnd *)this))->UIFrameWnd::Update_bbc0(nVal, nVal2) /* [ROWTABLE] */;
    }
  }
  (((SceneObj *)this))->SceneObj::Update(nVal, 1) /* [ROWTABLE] */;
  return 1;
}

// 0x004A1D10
int UIRoleDialog::OnCommand(int nVal, int nVal2, int nVal3)
{
  char v6; // cl
  CScreenMode *Instance; // eax
  char v8; // cl
  const void *v9; // [esp-0x8] [ebp-0xC]

  if ( nVal != 1001 )
    return (((CGameData *)this))->CGameData::OnMessage(nVal, nVal2, nVal3) /* [ROWTABLE] */;
  if ( nVal2 == 655362 )
  {
    if ( LOBYTE(this[1].m_static.m_bcreateok) )
    {
      v8 = BYTE1(this[1].m_static.m_bcreateok);
      this[1].m_static.m_rect.left = 0;
      if ( !v8 )
        goto LABEL_9;
      v9 = (const void *)off_5CC578;
      goto LABEL_8;
    }
    LOBYTE(this[1].m_id) = 0;
    return 1;
  }
  if ( nVal2 != 655363 )
    return 1;
  if ( LOBYTE(this[1].m_static.m_bcreateok) )
  {
    v6 = BYTE1(this[1].m_static.m_bcreateok);
    this[1].m_static.m_rect.left = 1;
    if ( !v6 )
    {
LABEL_9:
      /* [MISATTRIBUTED] MUIDialog on UIRoleDialog::this -> fix IDB name of callee */ MUIDialog::InvokeCallback((MUIDialog *)this);
      return 1;
    }
    v9 = (const void *)off_5CC578;
LABEL_8:
    Instance = (CScreenMode *)CScreenMode::GetInstance();
    (((CScreenMode *)Instance))->CScreenMode::AudioSetPosition(v9, 1);
    goto LABEL_9;
  }
  LOBYTE(this[1].m_ani.m_texarray.m_ptex[2]) = 0;
  return 1;
}

// 0x004BF1C0
void UIRoleDialog::Create(int nVal)
{
  ((void ( *)(UIRoleDialog *, _DWORD))this->UIDialog::UIWnd::__vftable->Destroy)(this, 0);
}

// 0x004BF1D0
int UIRoleDialog::Destroy(int nVal)
{
  UIRoleDialog *v2; // edi
  gbRenderInfoObj *v3; // esi
  gbRenderEffect *m_bmodal; // ecx
  gbMatrix4 *Top; // eax
  int result; // eax
v3 = (((gbSceneGraph *)gfxMgr->pSceneGraph))->gbSceneGraph::NewOneRenderObj((gbVisNode *)this);
  v2 = (UIRoleDialog *)((char *)v2 + 100);
  v3->Flags = 0;
  v3->Param = 0;
  m_bmodal = (gbRenderEffect *)this->m_bmodal;
  v3->pTexArray = (gbTextureArray *)v2;
  v3->pEffect = m_bmodal;
  Top = (((gbMatrixStack *)gfxMgr->pMatrixStack[1]))->gbMatrixStack::GetTop();
  (((gbMatrix4 *)Top))->gbMatrix4::Transform();
  result = 0;
  v3->Priority = 1;
  v3->Z = 0.0;
  return result;
}

// 0x004BF260
void UIRoleDialog::Render(int nVal)
{
  gbMatrixStack *v2; // edi
  double v4; // st7
  double v5; // st7
  float *p_m_passtime; // ebx
  double v7; // st7
  double v8; // st7
  __int64 v9; // rax
  gbRenderEffect *v10; // ecx
  bool v11; // cc
  float v12; // [esp+0x64] [ebp-0x6C]
  gbRenderEffect *v13; // [esp+0x64] [ebp-0x6C]
  float v14; // [esp+0x64] [ebp-0x6C]
  float v15; // [esp+0x64] [ebp-0x6C]
  int v16; // [esp+0x7C] [ebp-0x54]
  struct gbVec3D v17; // [esp+0x80] [ebp-0x50] BYREF
  struct gbTextureArray v18; // [esp+0x8C] [ebp-0x44] BYREF
  gbTexture **nVala; // [esp+D4h] [ebp+0x4]

  v2 = gfxMgr->pMatrixStack[1];
  (((gbMatrixStack *)v2))->gbMatrixStack::Push();
  (((gbMatrixStack *)v2))->gbMatrixStack::LoadMatrix((gbMatrix4 *)(nVal + 32));
  (((gbVertPoolMgr *)gfxMgr->pVertPoolMgr))->gbVertPoolMgr::GetDynVertBuf(0x15u);
  (((gbRenderEffect *)this->m_bk.m_texs.m_ptex[1]))->gbRenderEffect::Begin();
  (((gbRenderEffect *)this->m_bk.m_texs.m_ptex[1]))->gbRenderEffect::Pass(0);
  (((gbMatrixStack *)v2))->gbMatrixStack::Push();
  v4 = *(float *)&this->m_bk.m_id * -0.2;
  v17.x = 0.0;
  v17.y = 1.0;
  v12 = v4;
  v17.z = 0.0;
  (((gbMatrixStack *)v2))->gbMatrixStack::Rotate(v12,  *v17);
  v18.pTexPt[0] = (gbTexture *)this->m_bk.m_rect.left;
  v13 = (gbRenderEffect *)this->m_bk.m_texs.m_ptex[1];
  v18.nTex = 1;
  (((gbDynVertBuf *)&this[1].m_ani))->gbDynVertBuf::RenderGeomQuad(1, v13, &v18);
  (((gbDynVertBuf *)&this->m_bk.m_texs.m_ptex[3]))->gbDynVertBuf::RenderGeomQuad(6, (gbRenderEffect *)this->m_bk.m_texs.m_ptex[1], (gbTextureArray *)&this->m_bk.m_rect.top);
  (((gbMatrixStack *)v2))->gbMatrixStack::Pop();
  (((gbMatrixStack *)v2))->gbMatrixStack::Push();
  v5 = *(float *)&this->m_bk.m_id * -2.0;
  v17.x = 0.0;
  v17.y = 1.0;
  v14 = v5;
  v17.z = 0.0;
  (((gbMatrixStack *)v2))->gbMatrixStack::Rotate(v14,  *v17);
  (((gbDynVertBuf *)&this->m_face.m_nTextW))->gbDynVertBuf::RenderGeomQuad(6, (gbRenderEffect *)this->m_bk.m_texs.m_ptex[1], (gbTextureArray *)&this->m_bk.m_rect.top);
  (((gbMatrixStack *)v2))->gbMatrixStack::Pop();
  if ( this->m_bk.m_wndcolor.Color == 1 )
  {
    (((gbMatrixStack *)v2))->gbMatrixStack::Scale(0.60000002,   1.0,   0.60000002);
    v16 = 0;
    p_m_passtime = (float *)&this[1].m_ani.m_passtime;
    nVala = (gbTexture **)&this[1].m_ani.m_texarray.m_ptex[6];
    do
    {
      if ( *(p_m_passtime - 1) <= 0.0 )
        break;
      if ( !*nVala )
      {
        (((gbMatrixStack *)v2))->gbMatrixStack::Push();
        v7 = *(float *)&this->m_bk.m_id * -0.5;
        v17.x = 0.0;
        v8 = v7 - *(p_m_passtime - 1);
        v17.y = 1.0;
        v17.z = 0.0;
        v15 = v8;
        (((gbMatrixStack *)v2))->gbMatrixStack::Rotate(v15,  *v17);
        (((gbMatrixStack *)v2))->gbMatrixStack::Translate(0.0,   *p_m_passtime,   0.0);
        v9 = (__int64)(255.0 - *p_m_passtime * 0.016666668 * 255.0);
        v10 = (gbRenderEffect *)this->m_bk.m_texs.m_ptex[1];
        HIDWORD(v9) = this->m_bk.m_rect.left;
        LOBYTE(this[1].m_ani.m_bfocus) = v9;
        BYTE1(this[1].m_ani.m_bfocus) = v9;
        BYTE2(this[1].m_ani.m_bfocus) = v9;
        v18.nTex = 1;
        v18.pTexPt[0] = (gbTexture *)HIDWORD(v9);
        (((gbDynVertBuf *)&this[1].m_ani))->gbDynVertBuf::RenderGeomQuad(1, v10, &v18);
        (((gbMatrixStack *)v2))->gbMatrixStack::Pop();
      }
      p_m_passtime += 2;
      v11 = ++v16 < 4;
      ++nVala;
    }
    while ( v11 );
    this[1].m_ani.m_bfocus = -1;
  }
  (((gbRenderEffect *)this->m_bk.m_texs.m_ptex[1]))->gbRenderEffect::End();
  (((gbMatrixStack *)v2))->gbMatrixStack::Pop();
}
