#include "pal3/ida_defs.h"
#include "globals.h"
#include "pal3/pal3_constants.h"
#include "Misc/UIScenePanel.h"
#include "Role/Actor.h"
#include "Combat/CCBControlWindow.h"
#include "Combat/CCBItemWindow.h"
#include "Combat/CCBMagicWindow.h"
#include "Combat/CCBResultWindow.h"
#include "Combat/CCBRoleState.h"
#include "Combat/CCBUI.h"
#include "Misc/CCBUIPanel.h"
#include "Combat/CCCTData.h"
#include "Data/CGameData.h"
#include "Render/CScreenMode.h"
#include "Combat/CUtil.h"
#include "Misc/ChoseCompose.h"
#include "GameBase/GRPinput.h"
#include "Misc/JusticeBookUI.h"
#include "Role/NPC.h"
#include "Misc/NameSys.h"
#include "Misc/OpenBaseFile.h"
#include "Misc/OpenNULLFile.h"
#include "GameBase/PAL3.h"
#include "Script/PalScript.h"
#include "Script/PalScriptMgr.h"
#include "Misc/Parent_Data.h"
#include "Role/Role.h"
#include "Misc/RoleShadow.h"
#include "Role/RoleSystem.h"
#include "Scene/SceneObj.h"
#include "Misc/SoundMgr.h"
#include "Misc/TaskBookUI.h"
#include "Misc/TextureLibDataBase.h"
#include "Misc/UIBigMap.h"
#include "Misc/UICaption.h"
#include "Misc/UICoverFrm.h"
#include "UI/UICursor.h"
#include "Misc/UIFrameWnd.h"
#include "UI/UIListBox.h"
#include "UI/UIScene.h"
#include "Misc/UIStatic.h"
#include "Misc/UITitle_BBTY.h"
#include "Misc/UITitle_XJTM.h"
#include "UI/UIWnd.h"
#include "Misc/_PlugInfo.h"
#include "Misc/_Texture_Info.h"
#include "Misc/tagCmdData.h"
#include "free_functions.h"

// Forward declarations for unnamed functions
int sub_407790(...);

// 0x0043B570
int UIScenePanel::CreateLabelWidget(
        
        int id,
        void *pRect,
        int parent,
        LPCSTR lpString,
        char a6)
{
  int result; // eax
  const CHAR *v8; // edi
  CHAR *v9; // eax

  result = parent;
  if ( parent )
  {
    v8 = lpString;
    if ( lpString )
    {
      // [AUTO-COMMENTED] (OpenBaseFile *)&lpString->OpenBaseFile();
      this->m_bVisible = 0;
      this->m_hFont = 0;
      this->m_bEnabled = 0;
      *(_DWORD *)&this->m_bOverlayRender = 0;
      if ( a6 )
      {
        this->m_bVisible = ((TextureLibDataBase *)&stru_1894B78)->TextureLibDataBase::CreateParentData(v8);
        v9 = (((_Texture_Info *)&stru_1894B78))->_Texture_Info::_CalculateUV(v8);
        if ( !sub_445ED0((int)v9, 1) )
        {
LABEL_5:
          (((UIWnd *)&this->m_nClipW))->UIWnd::MoveWindow();
LABEL_8:
          // [AUTO-COMMENTED] (OpenNULLFile *)&lpString->OpenNULLFile();
          return result;
        }
      }
      else if ( !sub_445ED0((int)v8, 2) )
      {
        goto LABEL_5;
      }
      (((CCBItemWindow *)this))->CCBItemWindow::Create(id, (tagRECT *)pRect, parent) /* [ROWTABLE] */;
      goto LABEL_8;
    }
  }
  return result;
}

// 0x0043B660
int UIScenePanel::Render()
{
  int result; // eax
  LONG top; // edx
  tagRECT *p_m_rect; // edi
  int v5; // eax
  LONG bottom; // eax
  int v7; // ebx
  UIWnd *m_pChildWnd; // eax
  char *v9; // eax
  Parent_Data *v10; // eax
  void *vftable; // eax
  TextureLibDataBase *v12; // ecx
  LONG v13; // ecx
  LONG v14; // edx
  LONG v15; // edx
  LONG v16; // eax
  int m_benable; // eax
  UIWnd *v18; // eax
  char *left; // [esp-0x20] [ebp-0x124]
  char *v20; // [esp-0x20] [ebp-0x124]
  TextureLibDataBase *v21; // [esp-0x1C] [ebp-0x120]
  TextureLibDataBase *v22; // [esp-0x18] [ebp-0x11C]
  gbColorQuad v23; // [esp-0xC] [ebp-0x110] BYREF
  int p_nTex; // [esp-0x8] [ebp-0x10C]
  unsigned int m_bVisible; // [esp-0x4] [ebp-0x108]
  gbTextureArray *v26; // [esp+0x0] [ebp-0x104]
  _PlugInfo *v27; // [esp+0x4] [ebp-0x100]
  int nW; // [esp+0x10] [ebp-F4h] BYREF
  int v29; // [esp+0x18] [ebp-ECh] BYREF
  int v30; // [esp+0x1C] [ebp-E8h]
  LONG right; // [esp+0x20] [ebp-E4h]
  LONG v32; // [esp+0x24] [ebp-E0h]
  int nY; // [esp+0x28] [ebp-DCh] BYREF
  int v34; // [esp+0x2C] [ebp-D8h]
  LONG v35; // [esp+0x30] [ebp-D4h]
  LONG v36; // [esp+0x34] [ebp-D0h]
  int v37[16]; // [esp+0x38] [ebp-CCh] BYREF
  int v38; // [esp+0x78] [ebp-0x8C]
  int v39; // [esp+0x7C] [ebp-0x88] BYREF
  gbTextureArray v40; // [esp+0x80] [ebp-0x84] BYREF
  int v41; // [esp+0x100] [ebp-0x4]

  result = this->m_bvisible;
  if ( !result )
    return result;
  top = this->m_rect.top;
  p_m_rect = (tagRECT *)&this->m_rect;
  v5 = this->m_rect.left + 2;
  right = this->m_rect.right;
  v29 = v5;
  bottom = this->m_rect.bottom;
  v30 = top + 2;
  v32 = bottom;
  v7 = sub_445F60(0);
  if ( !v7 )
  {
    v15 = this->m_rect.bottom;
    v16 = this->m_rect.right;
    m_bVisible = (unsigned int)&g_fUIColorParam;
    p_nTex = v15;
    v23.Color = v16;
    goto LABEL_17;
  }
  m_pChildWnd = this->m_pChildWnd;
  if ( m_pChildWnd )
  {
    v9 = (char *)&m_pChildWnd[-1].m_bfocus + 3;
    if ( v9 )
    {
      if ( v9 == (char *)1 )
      {
        m_bVisible = (unsigned int)this->m_bVisible;
        p_nTex = (int)&v40.nTex;
        v23.Color = (unsigned int)&this->m_Static_360.m_id;
        v41 = 1;
        v40.nTex = v7;
        (((TextureLibDataBase *)&v29))->TextureLibDataBase::GetTextureInfo((char *)&this->m_rect);
      }
    }
    else
    {
      m_bVisible = (unsigned int)this->m_bVisible;
      p_nTex = 1;
      v23.Color = (unsigned int)&v39;
      v21 = (TextureLibDataBase *)this->m_rect.top;
      left = (char *)p_m_rect->left;
      v40.pTexPt[15] = (gbTexture *)1;
      v39 = v7;
      (((TextureLibDataBase *)v21))->TextureLibDataBase::GetLibInfo(left);
    }
  }
  else
  {
    v10 = this->m_bVisible;
    m_bVisible = 1;
    p_nTex = (int)v10;
    v23.Color = 276;
    v38 = 1;
    v37[0] = v7;
    (((TextureLibDataBase *)v37))->TextureLibDataBase::SetLibFolder((char *)&this->m_rect);
  }
  if ( this->m_benable )
    goto LABEL_18;
  vftable = (*(void **)&(this->m_Static_360));
  if ( vftable )
  {
    if ( vftable == (void *)1 )
    {
      m_bVisible = *(_DWORD *)&this->m_bOverlayRender;
      p_nTex = 1;
      v23.Color = (unsigned int)v37;
      v22 = (TextureLibDataBase *)this->m_rect.right;
      v20 = (char *)p_m_rect->left;
      v38 = 1;
      v37[0] = v7;
      (((TextureLibDataBase *)v22))->TextureLibDataBase::GetLibInfo(v20);
    }
    goto LABEL_18;
  }
  if ( !this->m_pTexture )
  {
    v13 = this->m_rect.bottom;
    v14 = this->m_rect.right;
    m_bVisible = (unsigned int)&g_fUIColorParam;
    p_nTex = v13;
    v23.Color = v14;
LABEL_17:
    crt_sub_00540070();
    goto LABEL_18;
  }
  m_bVisible = *(_DWORD *)&this->m_bOverlayRender;
  p_nTex = 276;
  v23.Color = m_bVisible;
  (((TextureLibDataBase *)v12))->TextureLibDataBase::_CheckItem((char *)&this->m_rect, (char *)&this->m_rect);
LABEL_18:
  if ( *((_BYTE *)&this->m_hTexture + 4) )
  {
    nW = this->m_fontcolor.Color;
    nY = v29;
    v35 = right;
    m_benable = this->m_benable;
    v34 = v30;
    v36 = v32;
    if ( !m_benable || this->m_pChildWnd == (UIWnd *)2 )
    {
      BYTE2(nW) = (BYTE2(nW) - 64) & ((BYTE2(nW) - 64 < 0) - 1);
      BYTE1(nW) = (BYTE1(nW) - 64) & ((BYTE1(nW) - 64 < 0) - 1);
      v18 = this->m_pChildWnd;
      LOBYTE(nW) = (nW - 64) & (((unsigned __int8)nW - 64 < 0) - 1);
      if ( v18 == (UIWnd *)2 )
        v34 = v30 + 6;
    }
    UIRenderPar((int)(&this->m_hTexture + 1), (int)&nY, (int)&nW, 1, (gbColorQuad *)1, v26, v27);
  }
  (((UITitle_BBTY *)this))->UITitle_BBTY::Render() /* [ROWTABLE] */;
  return result;
}

// 0x0043B900

// ---- synthesized vtable stubs (unresolved slots) ----
// [VFTABLE-STUB] original: ((void ( *)(UIWnd *, int, void *, _DWORD))m_pfather->__vftable->OnMessage)( m_pfather, 1003, this->m_id, 0)
static void pal3_vtbl_unk_0(UIWnd *, int, void *, _DWORD);
// [VFTABLE-STUB] original: ((void ( *)(UIWnd *, int, void *, _DWORD))v14->__vftable->OnMessage)(v14, 1002, this->m_id, 0)
static void pal3_vtbl_unk_1(UIWnd *, int, void *, _DWORD);
// [VFTABLE-STUB] original: ((void ( *)(UIWnd *, int, void *, _DWORD))v13->__vftable->OnMessage)(v13, 1001, this->m_id, 0)
static void pal3_vtbl_unk_2(UIWnd *, int, void *, _DWORD);

BOOL UIScenePanel::Update(int nVal, int nVal2)
{
  tagRECT *p_m_rect; // ebp
  BOOL v6; // eax
  LONG left; // edx
  LONG top; // ecx
  int v9; // edi
  int v10; // ebp
  unsigned __int8 ChildWidget; // al
  UIWnd *m_pfather; // ecx
  UIWnd *v13; // ecx
  UIWnd *v14; // ecx
  int v15; // eax
  BOOL v16; // [esp+0xC] [ebp-0xC]
  POINT pt; // [esp+0x10] [ebp-0x8] BYREF

  if ( !this->m_bvisible )
    return 0;
  if ( !this->m_benable )
  {
    this->m_pChildWnd = 0;
    return 0;
  }
  if ( !nVal2 )
  {
    this->m_pChildWnd = 0;
    return (((SceneObj *)this))->SceneObj::Update(nVal, 0) /* [ROWTABLE] */;
  }
  g_Input.GRPinput::GetCursorPos(&pt);
  p_m_rect = (tagRECT *)&this->m_rect;
  v6 = PtInRect(&this->m_rect, pt);
  v16 = v6;
  if ( this->m_pChildWnd != (UIWnd *)2 )
  {
    if ( !v6 )
    {
      this->m_pChildWnd = 0;
      goto LABEL_14;
    }
    this->m_pChildWnd = (UIWnd *)1;
  }
  if ( !v6 )
  {
LABEL_14:
    if ( !this->m_bCursorLeft )
    {
      m_pfather = this->m_pfather;
      this->m_bCursorLeft = 1;
      if ( m_pfather )
        pal3_vtbl_unk_0(m_pfather, 1003, this->m_id, 0) /* [VFTABLE-STUB] */;
    }
    goto LABEL_17;
  }
  left = p_m_rect->left;
  top = this->m_rect.top;
  v9 = pt.x - p_m_rect->left;
  v10 = pt.y - top;
  if ( this->m_bVisible )
  {
    ChildWidget = this->UIScene::GetChildWidget(pt.x - left, pt.y - top, 3);
  }
  else
  {
    if ( v9 >= *(_DWORD *)(sub_445F60(0) + 24) )
      v9 = *(_DWORD *)(sub_445F60(0) + 24) - 1;
    if ( v10 >= *(_DWORD *)(sub_445F60(0) + 28) )
      v10 = *(_DWORD *)(sub_445F60(0) + 28) - 1;
    ChildWidget = (((UIScene *)&this->m_nClipW))->UIScene::GetPixelChannel(0, v9, v10, 3);
  }
  if ( ChildWidget < 6u )
  {
    v16 = 0;
    this->m_pChildWnd = 0;
  }
  else if ( g_Input.KeyInfo[0].PressTime == 1 )
  {
    this->m_pChildWnd = (UIWnd *)2;
    this->m_bCursorLeft = 0;
  }
  else
  {
    v14 = this->m_pfather;
    if ( v14 )
      pal3_vtbl_unk_1(v14, 1002, this->m_id, 0) /* [VFTABLE-STUB] */;
    this->m_bCursorLeft = 0;
  }
LABEL_17:
  if ( this->m_pChildWnd == (UIWnd *)2 && (g_Input.KeyInfo[0].Data & 0xF) != 1 )
  {
    if ( v16 )
    {
      v13 = this->m_pfather;
      this->m_pChildWnd = (UIWnd *)1;
      if ( v13 )
        pal3_vtbl_unk_2(v13, 1001, this->m_id, 0) /* [VFTABLE-STUB] */;
    }
    else
    {
      this->m_pChildWnd = 0;
    }
  }
  v15 = (((SceneObj *)this))->SceneObj::Update(nVal, nVal2) /* [ROWTABLE] */;
  return v16 || v15;
}

static void pal3_vtbl_unk_0(UIWnd *, int, void *, _DWORD)
{
    
}
static void pal3_vtbl_unk_1(UIWnd *, int, void *, _DWORD)
{
    
}
static void pal3_vtbl_unk_2(UIWnd *, int, void *, _DWORD)
{
    
}


// 0x0044BA60
UIScenePanel::UIScenePanel()
{
  sub_4422E0(&this->m_Static_360);
  sub_4422E0(&this->m_Static_10496);
  sub_4422E0(&this->m_Static_10648);
  sub_4422E0(&this->m_Static_10800);
  sub_4422E0(&this->m_Static_10952);
  (((CCBResultWindow *)&this->m_Wnd_11116))->CCBResultWindow::Create();
  (((CCBResultWindow *)&this->m_Wnd_11308))->CCBResultWindow::Create();
  NameSys::GetSys();
  NameSys::GetSys();
  NameSys::GetSys();
  NameSys::GetSys();
  NameSys::GetSys();
  NameSys::GetSys();
  *(&this->m_hSettingsUI + 1) = 0;
  *(_DWORD *)&this->m_bPanelFlagA = 0;
  this->m_nPanelState = 0;
  this->m_nSceneIdx = 0;
  this->m_bFlags0 = 1;
  this->m_bFlags1 = 1;
  *(&this->m_bFlags1 + 1) = 0;
  sub_4422E0(&this->m_Static_13904);
  sub_4422E0(&this->m_Static_14080);
  this->m_fScaleX = 0.0;
  this->m_fScaleY = 0.0;
  *(_DWORD *)&this->m_nTodo_050 = 800;
  this->m_nScrollState = 600;
  *((_BYTE *)&this->m_nObjStore + 4) = 0;
  *((_BYTE *)&this->m_nObjStore + 5) = 0;
  *(&this->m_nObjStore + 2) = 0;
  *(&this->m_nObjStore + 3) = 0;
  this->m_hSettingsUI = 0;
  (int)this;
}

// 0x0044BE80
void UIScenePanel::ctor()
{
  this->UIScenePanel::Destroy();
  (((UIFrameWnd *)&this->m_Static_14080))->UIFrameWnd::_UIFrameWnd();
  (((UIFrameWnd *)&this->m_Static_13904))->UIFrameWnd::_UIFrameWnd();
  if ( this->m_nPanelState )
  {
    operator delete((void *)this->m_nPanelState);
    this->m_nPanelState = 0;
  }
  (((UICaption *)&this->m_SceneF))->UICaption::Destroy2();
  (((UICaption *)&this->m_SceneE))->UICaption::Destroy2();
  (((UICaption *)&this->m_SceneD))->UICaption::Destroy2();
  (((UICaption *)&this->m_SceneC))->UICaption::Destroy2();
  (((UICaption *)&this->m_SceneB))->UICaption::Destroy2();
  (((UICaption *)&this->m_SceneA))->UICaption::Destroy2();
  (((UIFrameWnd *)&this->m_Wnd_11308))->UIFrameWnd::DestroyCallingCtor();
  (((UIFrameWnd *)&this->m_Wnd_11116))->UIFrameWnd::DestroyCallingCtor();
  (((UIFrameWnd *)&this->m_Static_10952))->UIFrameWnd::_UIFrameWnd();
  (((UIFrameWnd *)&this->m_Static_10800))->UIFrameWnd::_UIFrameWnd();
  (((UIFrameWnd *)&this->m_Static_10648))->UIFrameWnd::_UIFrameWnd();
  (((UIFrameWnd *)&this->m_Static_10496))->UIFrameWnd::_UIFrameWnd();
  (((UIFrameWnd *)&this->m_Static_360))->UIFrameWnd::_UIFrameWnd();
  (((UIListBox *)this))->UIListBox::~UIListBox() /* [ROWTABLE] */;
}

// 0x0044C120
void UIScenePanel::CreateSettingsUI()
{
  float *p_m_fScaleY; // ebp
  void *vftable; // edx
  int v4; // ecx
  void *v5; // eax
  int v6; // edx
  void *v7; // edx
  int v8; // ecx
  void *v9; // edx
  void *v10; // eax
  int v11; // edx
  void *v12; // edx
  int v13; // ecx
  void *v14; // eax
  int v15; // edx
  int v16; // eax
  int v17; // eax
  void *v18; // edx
  int v19; // eax
  void *v20; // edx
  int v21; // eax
  void *v22; // edx
  int v23; // eax
  void *v24; // edx
  int v25; // eax
  void *v26; // edx
  int v27; // eax
  void *v28; // edx
  CCBRoleState *v29; // eax
  CCBRoleState *v30; // eax
  CCBUIPanel *v31; // eax
  RoleShadow *v32; // eax
  TaskBookUI *v33; // eax
  int v34; // eax
  CScreenMode *Instance; // eax
  gbAudioManager *AudioManager; // eax
  gbAudioManager *v37; // edi
  CScreenMode *v38; // eax
  UICursor *v39; // ecx
  void *m_nPanelState; // eax
  void *v41; // edi
  unsigned int v42; // edx
  BYTE Data[4]; // [esp+E4h] [ebp-0x68] BYREF
  BYTE v44[4]; // [esp+E8h] [ebp-0x64] BYREF
  BYTE v45[4]; // [esp+ECh] [ebp-0x60] BYREF
  int v46; // [esp+F0h] [ebp-0x5C] BYREF
  int v47; // [esp+F4h] [ebp-0x58]
  int v48; // [esp+F8h] [ebp-0x54]
  int v49; // [esp+FCh] [ebp-0x50]
  int v50; // [esp+0x100] [ebp-0x4C] BYREF
  int v51; // [esp+0x104] [ebp-0x48]
  int v52; // [esp+0x108] [ebp-0x44]
  int v53; // [esp+0x10C] [ebp-0x40]
  int v54; // [esp+0x110] [ebp-0x3C] BYREF
  int v55; // [esp+0x114] [ebp-0x38]
  int v56; // [esp+0x118] [ebp-0x34]
  int v57; // [esp+0x11C] [ebp-0x30]
  _DWORD v58[4]; // [esp+0x120] [ebp-0x2C] BYREF
  _DWORD v59[4]; // [esp+0x130] [ebp-0x1C] BYREF
  int v60; // [esp+0x148] [ebp-0x4]

  p_m_fScaleY = (float *)&this->m_fScaleY;
  (((UIListBox *)this))->UIListBox::SetSelTexture(0, LODWORD(this->m_fScaleY), LODWORD(this->m_fScaleX), *(_DWORD *)&this->m_nTodo_050, this->m_nScrollState) /* [ROWTABLE] */;
  g_nSceneState = 1;
  vftable = (*(void **)&(this->m_Static_360));
  v58[1] = 80;
  v58[0] = 169;
  v58[2] = 611;
  v58[3] = 526;
  ((void ( *)(UIStatic *, _DWORD, _DWORD *, UIScenePanel *))vftable->Create)(
    &this->m_Static_360,
    0,
    v58,
    this);
  LOBYTE(v4) = g_bSceneLoaded;
  (((UIStatic *)&this->m_Static_360))->UIStatic::CreateFromTemplate((void *)off_59DD0C, v4);
  (((RoleSystem *)this))->RoleSystem::InitUICtrlArray() /* [ROWTABLE] */;
  v5 = (*(void **)&(this->m_Static_10496));
  v51 = 192;
  v50 = 79;
  v52 = 409;
  v53 = 424;
  ((void ( *)(UIStatic *, _DWORD, int *, UIScenePanel *))v5->Create)(&this->m_Static_10496, 0, &v50, this);
  LOBYTE(v6) = g_bSceneLoaded;
  (((UIStatic *)&this->m_Static_10496))->UIStatic::CreateFromTemplate((void *)off_59DD10, v6);
  /* [MISATTRIBUTED] UITitle_XJTM on UIScenePanel::this -> fix IDB name of callee */ UITitle_XJTM::CreateSubWidgets((UITitle_XJTM *)this);
  v7 = (*(void **)&(this->m_Static_10648));
  v51 = 203;
  v50 = 556;
  v52 = 610;
  v53 = 318;
  ((void ( *)(UIStatic *, _DWORD, int *, UIScenePanel *))v7->Create)(&this->m_Static_10648, 0, &v50, this);
  LOBYTE(v8) = g_bSceneLoaded;
  (((UIStatic *)&this->m_Static_10648))->UIStatic::CreateFromTemplate((void *)off_59DD14, v8);
  /* [MISATTRIBUTED] Actor on UIScenePanel::this -> fix IDB name of callee */ Actor::InitParticles((Actor *)this);
  v9 = (*(void **)&(this->m_Static_14080));
  this->m_nTodo_36F8 = 1099264164;
  this->m_nTodo_36FC = 1140948992;
  this->m_nTodo_36EC = 518;
  this->m_nTodo_36E8 = 220;
  this->m_nTodo_36F0 = 586;
  this->m_nTodo_36F4 = 1542;
  ((void ( *)(UIStatic *, _DWORD, int *, UIScenePanel *))v9->Create)(
    &this->m_Static_14080,
    0,
    &this->m_nTodo_36E8,
    this);
  (((UIStatic *)&this->m_Static_14080))->UIStatic::CreateFromTemplate((void *)off_59DDDC, 0);
  ((void ( *)(UIStatic *, _DWORD))this->m_Static_14080.__vftable->ShowWindow)(&this->m_Static_14080, 0);
  v10 = (*(void **)&(this->m_Static_10952));
  LOBYTE((*(void **)&(this[1]))) = 0;
  v59[1] = 223;
  v59[0] = 200;
  v59[2] = 581;
  v59[3] = 366;
  ((void ( *)(UIStatic *, _DWORD, _DWORD *, UIScenePanel *))v10->Create)(&this->m_Static_10952, 0, v59, this);
  LOBYTE(v11) = g_bSceneLoaded;
  (((UIStatic *)&this->m_Static_10952))->UIStatic::CreateFromTemplate((void *)off_59DDD4, v11);
  v12 = (*(void **)&(this->m_Wnd_11116));
  v55 = 83;
  v54 = 170;
  v56 = 502;
  v57 = 519;
  ((void ( *)(UIWnd *, _DWORD, int *, UIScenePanel *))v12->Create)(&this->m_Wnd_11116, 0, &v54, this);
  LOBYTE(v13) = g_bSceneLoaded;
  (((UIStatic *)&this->m_Wnd_11116))->UIStatic::CreateFromTemplate((void *)off_59DDCC, v13);
  (((UIBigMap *)&this->m_Wnd_11116))->UIBigMap::SetViewParams(406, 590);
  this->m_nTodo_2C14 = 0;
  this->m_nTodo_2C08 = 1;
  this->m_nTodo_2C0C = 1118044160;
  LOBYTE(this->m_nTodo_2C18) = 0;
  this->m_nTodo_2C10 = 0;
  LOBYTE(this->m_nTodo_2C18) = 1;
  v14 = (*(void **)&(this->m_Wnd_11308));
  v55 = 86;
  v54 = 278;
  v56 = 610;
  v57 = 522;
  ((void ( *)(UIWnd *, _DWORD, int *, UIScenePanel *))v14->Create)(&this->m_Wnd_11308, 0, &v54, this);
  LOBYTE(v15) = g_bSceneLoaded;
  (((UIStatic *)&this->m_Wnd_11308))->UIStatic::CreateFromTemplate((void *)off_59DDD0, v15);
  (((UIBigMap *)&this->m_Wnd_11308))->UIBigMap::SetViewParams(336, 28);
  this->m_nTodo_2CD4 = 0;
  this->m_nTodo_2CC8 = 1;
  this->m_nTodo_2CCC = 1118044160;
  LOBYTE(this->m_nTodo_2CD8) = 0;
  this->m_nTodo_2CD0 = 0;
  LOBYTE(this->m_nTodo_2CD8) = 1;
  v16 = ((int ( *)(UIStatic *, _DWORD, float *, UIScenePanel *))this->m_Static_10800.__vftable->Create)(
          &this->m_Static_10800,
          0,
          p_m_fScaleY,
          this);
  LOBYTE(v16) = g_bSceneLoaded;
  (((UIStatic *)&this->m_Static_10800))->UIStatic::CreateFromTemplate((void *)off_59DD08, v16);
  LOBYTE(v17) = g_bSceneLoaded;
  v18 = (*(void **)&(this->m_SceneA));
  v47 = 0;
  v46 = 152;
  v48 = 388;
  v49 = 156;
  v19 = ((int ( *)(UIScene *, int, int *, UIScenePanel *, int, int))v18[1].Render)(
          &this->m_SceneA,
          161,
          &v46,
          this,
          off_59DDB4,
          v17);
  LOBYTE(v19) = g_bSceneLoaded;
  v20 = (*(void **)&(this->m_SceneB));
  v47 = 175;
  v46 = 59;
  v48 = 187;
  v49 = 431;
  v21 = ((int ( *)(UIScene *, int, int *, UIScenePanel *, int, int))v20[1].Render)(
          &this->m_SceneB,
          162,
          &v46,
          this,
          off_59DDB8,
          v19);
  LOBYTE(v21) = g_bSceneLoaded;
  v22 = (*(void **)&(this->m_SceneC));
  v47 = 446;
  v46 = 142;
  v48 = 378;
  v49 = 602;
  v23 = ((int ( *)(UIScene *, int, int *, UIScenePanel *, int, int))v22[1].Render)(
          &this->m_SceneC,
          163,
          &v46,
          this,
          off_59DDBC,
          v21);
  v47 = 446;
  v46 = 410;
  LOBYTE(v23) = g_bSceneLoaded;
  v24 = (*(void **)&(this->m_SceneD));
  v48 = 646;
  v49 = 602;
  v25 = ((int ( *)(UIScene *, int, int *, UIScenePanel *, int, int))v24[1].Render)(
          &this->m_SceneD,
          164,
          &v46,
          this,
          off_59DDC0,
          v23);
  LOBYTE(v25) = g_bSceneLoaded;
  v26 = (*(void **)&(this->m_SceneE));
  v47 = 179;
  v46 = 585;
  v48 = 713;
  v49 = 435;
  v27 = ((int ( *)(UIScene *, int, int *, UIScenePanel *, int, int))v26[1].Render)(
          &this->m_SceneE,
          165,
          &v46,
          this,
          off_59DDC4,
          v25);
  LOBYTE(v27) = g_bSceneLoaded;
  v28 = (*(void **)&(this->m_SceneF));
  v47 = 0;
  v46 = 416;
  v48 = 652;
  v49 = 156;
  ((void ( *)(UIScene *, int, int *, UIScenePanel *, int, int))v28[1].Render)(
    &this->m_SceneF,
    166,
    &v46,
    this,
    off_59DDC8,
    v27);
  v29 = (CCBRoleState *)operator new(0x5058u);
  *(_DWORD *)v45 = (_DWORD)v29;
  v60 = 0;
  if ( v29 )
    v30 = (CCBRoleState *)(((CCBRoleState *)v29))->CCBRoleState::ctor();
  else
    v30 = 0;
  v60 = -1;
  *(&this->m_nObjStore + 2) = (int)v30;
  (((CCBRoleState *)v30))->CCBRoleState::~CCBRoleState();
  v31 = (CCBUIPanel *)operator new(0x14C4u);
  *(_DWORD *)v45 = (_DWORD)v31;
  v60 = 1;
  if ( v31 )
    v32 = (RoleShadow *)(((CCBUIPanel *)v31))->CCBUIPanel::ctor_3D10();
  else
    v32 = 0;
  v60 = -1;
  *(&this->m_nObjStore + 3) = (int)v32;
  (((RoleShadow *)v32))->RoleShadow::this->InitFromTemplate();
  v33 = (TaskBookUI *)operator new(0x207F0u);
  *(_DWORD *)v45 = (_DWORD)v33;
  v60 = 2;
  if ( v33 )
    (((TaskBookUI *)v33))->TaskBookUI::~TaskBookUI();
  else
    v34 = 0;
  v60 = -1;
  this->m_hSettingsUI = v34;
  this->TaskBookUI_CreateEntry();
  if ( (g_dwGameFlags & 4) != 0 )
  {
    Instance = (CScreenMode *)CScreenMode::GetInstance();
    AudioManager = (gbAudioManager *)(((CScreenMode *)Instance))->CScreenMode::GetAudioManager();
    v37 = (gbAudioManager *)AudioManager;
    if ( AudioManager )
    {
      (((gbAudioManager *)AudioManager))->gbAudioManager::DetachAll3D();
      (((gbAudioManager *)v37))->gbAudioManager::StopSoundStream(0);
      (((gbAudioManager *)v37))->gbAudioManager::StopSoundStream(2);
      v38 = (CScreenMode *)CScreenMode::GetInstance();
      (((SoundMgr *)v38))->SoundMgr::PlayCPKStream();
    }
  }
  *(_DWORD *)Data = 0;
  *(_DWORD *)v44 = 0;
  *(_DWORD *)v45 = 0;
  ReadRegistryString("SOFTWARE\\SOFTSTAR\\PAL3_S_GAME", "S_GAME_A", (char *)Data);
  ReadRegistryString("SOFTWARE\\SOFTSTAR\\PAL3_S_GAME", "S_GAME_B", (char *)v44);
  ReadRegistryString("SOFTWARE\\SOFTSTAR\\PAL3_S_GAME", "S_GAME_C", (char *)v45);
  LOBYTE(g_dwUISettings) = *(_DWORD *)Data != 0;
  BYTE1(g_dwUISettings) = *(_DWORD *)v44 != 0;
  LOBYTE(v39) = *(_DWORD *)v45 != 0;
  BYTE2(g_dwUISettings) = *(_DWORD *)v45 != 0;
  *(&this->m_bFlags1 + 3) = 0;
  *((_BYTE *)&this->m_nObjStore + 5) = 0;
  this->m_nTodo_2B64 = 0;
  LOBYTE(this->m_nTodo_2B60) = 1;
  (((UICursor *)v39))->UICursor::IRender();
  m_nPanelState = (void *)this->m_nPanelState;
  *(_DWORD *)&this->m_bPanelFlagA = 16;
  if ( m_nPanelState )
  {
    operator delete(m_nPanelState);
    this->m_nPanelState = 0;
  }
  v41 = (void *)operator new(4 * *(_DWORD *)&this->m_bPanelFlagA);
  v42 = 4 * *(_DWORD *)&this->m_bPanelFlagA;
  this->m_nPanelState = (int)v41;
  memset(v41, 0, v42);
  this->m_nSceneIdx = 0;
  this->m_bFlags0 = 1;
  this->m_bFlags1 = 0;
  *(&this->m_bFlags1 + 1) = 0;
  if ( (((CGameData *)&g_gamefrm))->CGameData::GetMode() == 8
    || (((CGameData *)&g_gamefrm))->CGameData::GetMode() == 11
    || (_BYTE)g_bGameUpdating )
  {
    /* [MISATTRIBUTED] ChoseCompose on UIScenePanel::this -> fix IDB name of callee */ ChoseCompose::Init((ChoseCompose *)this, 3);
    LOBYTE(g_bGameUpdating) = 0;
  }
}

// 0x0044C910
void UIScenePanel::Destroy()
{
  int v2; // ecx
  int v3; // ecx
  int m_hSettingsUI; // ecx

  this->Destroy();
  v2 = *(&this->m_nObjStore + 2);
  if ( v2 )
    (*(void ( **)(int, int))(*(_DWORD *)v2 + 20))(v2, 1);
  v3 = *(&this->m_nObjStore + 3);
  if ( v3 )
    (*(void ( **)(int, int))(*(_DWORD *)v3 + 20))(v3, 1);
  m_hSettingsUI = this->m_hSettingsUI;
  if ( m_hSettingsUI )
    (*(void ( **)(int, int))(*(_DWORD *)m_hSettingsUI + 20))(m_hSettingsUI, 1);
  *(&this->m_nObjStore + 2) = 0;
  *(&this->m_nObjStore + 3) = 0;
  this->m_hSettingsUI = 0;
}

// 0x0044DAC0
void UIScenePanel::PostRender()
{
  int m_hSettingsUI; // ecx

  switch ( *(&this->m_hSettingsUI + 1) )
  {
    case 0:
      (((CCBControlWindow *)this))->CCBControlWindow::Render((CCBMagicWindow *)this) /* [ROWTABLE] */;
      break;
    case 1:
      m_hSettingsUI = *(&this->m_nObjStore + 2);
      goto LABEL_6;
    case 3:
      (*(void ( **)(_DWORD, UIScenePanel *))(**((_DWORD **)&this->m_nObjStore + 3) + 4))(
        *(&this->m_nObjStore + 3),
        this);
      break;
    case 4:
      m_hSettingsUI = this->m_hSettingsUI;
LABEL_6:
      (*(void ( **)(int, UIScenePanel *))(*(_DWORD *)m_hSettingsUI + 4))(m_hSettingsUI, this);
      break;
    default:
      break;
  }
  crt_sub_00540FD0();
}

// 0x0044DB70
int UIScenePanel::StopAllSounds(float fFade, int nFlags)
{
  CScreenMode *Instance; // eax
  gbAudioManager *AudioManager; // eax
  __int64 v6; // rcx
  int v7; // esi
  int v8; // esi
  CScreenMode *v9; // eax
  gbAudioManager *v10; // eax
  gbAudioManager *v11; // esi
  CScreenMode *v13; // eax
  gbAudioManager *v14; // eax
  gbAudioManager *v15; // esi
  CScreenMode *v16; // eax
  gbAudioManager *v17; // eax
  gbAudioManager *v18; // esi
  PalScriptMgr *v19; // ecx
  char v20; // al
  unsigned int v21; // ecx
  unsigned int v22; // edx
  float *m_nPanelState; // eax
  int v24; // edx
  double v25; // st7
  double v26; // st7
  void *vftable; // edx
  int v28; // ecx
  int m_hSettingsUI; // eax
  CScreenMode *v30; // eax
  gbAudioManager *v31; // eax
  gbAudioManager *v32; // esi
  CScreenMode *v33; // eax
  double v34; // [esp-0x4] [ebp-0x18]

  if ( g_nSceneState != 2 && (g_dwGameFlags & 1) != 0 )
  {
    Instance = (CScreenMode *)CScreenMode::GetInstance();
    AudioManager = (gbAudioManager *)(((CScreenMode *)Instance))->CScreenMode::GetAudioManager();
    (((gbAudioManager *)AudioManager))->gbAudioManager::DetachAll3D();
  }
  HIDWORD(v6) = 0;
  if ( !*(&this->m_bFlags1 + 3) )
  {
    switch ( *(&this->m_hSettingsUI + 1) )
    {
      case 0:
        if ( !*((_BYTE *)&this->m_nObjStore + 4) )
        {
          if ( !this->m_bFlags1 )
          {
            if ( this->m_bFlags0 )
              this->m_bFlags0 = 0;
            *(float *)(this->m_nPanelState + 4 * this->m_nSceneIdx) = fFade;
            v20 = *(&this->m_bFlags1 + 1);
            v21 = this->m_nSceneIdx + 1;
            this->m_nSceneIdx = v21;
            v22 = v21;
            if ( !v20 )
              *(&this->m_bFlags1 + 1) = v21 >= *(_DWORD *)&this->m_bPanelFlagA;
            LODWORD(v6) = *(_DWORD *)&this->m_bPanelFlagA;
            this->m_nTodo_3638 = 0;
            this->m_nSceneIdx = v22 < (unsigned int)v6 ? v22 : 0;
            if ( (_DWORD)v6 )
            {
              m_nPanelState = (float *)this->m_nPanelState;
              v24 = v6;
              do
              {
                v25 = *m_nPanelState++ + *(float *)&this->m_nTodo_3638;
                --v24;
                *(float *)&this->m_nTodo_3638 = v25;
              }
              while ( v24 );
            }
            fFade = *(float *)&this->m_nTodo_3638 / (double)v6;
          }
          if ( !*(&this->m_bFlags1 + 1) )
            return 1;
          /* [MISATTRIBUTED] CCCTData on UIScenePanel::this -> fix IDB name of callee */ CCCTData::InitEntries((CCCTData *)this, fFade);
          if ( LOBYTE((*(void **)&(this[1]))) )
          {
            if ( !(((UICoverFrm *)this))->UICoverFrm::UpdateAnimation(fFade) /* [ROWTABLE] */ )
            {
              v26 = *(float *)&this->m_nTodo_2B64 - fFade * 80.0;
              *(float *)&this->m_nTodo_2B64 = v26;
              if ( v26 <= 0.0 )
                this->m_nTodo_2B64 = 0;
              if ( ((((NPC *)&this->m_Static_10952))->NPC::UpdateAnim(), g_Input.KeyInfo[0].PressTime == 1)
                && (g_Input.KeyInfo[0].Data & 0xF) == 1
                || g_Input.KeyInfo[1].PressTime == 1 && (g_Input.KeyInfo[1].Data & 0xF) == 1 )
              {
                (((UICoverFrm *)this))->UICoverFrm::SetDefaultValues() /* [ROWTABLE] */;
                vftable = (*(void **)&(this->m_Static_14080));
                LOBYTE((*(void **)&(this[1]))) = 0;
                ((void ( *)(UIStatic *, _DWORD))vftable->ShowWindow)(&this->m_Static_14080, 0);
                LOBYTE(this->m_nTodo_2B60) = 1;
                (((SceneObj *)this))->SceneObj::Update(SLODWORD(fFade), nFlags) /* [ROWTABLE] */;
                goto LABEL_43;
              }
            }
          }
          else
          {
            (((JusticeBookUI *)this))->JusticeBookUI::UpdateFadeAnim(fFade) /* [ROWTABLE] */;
          }
          (((SceneObj *)this))->SceneObj::Update(SLODWORD(fFade), nFlags) /* [ROWTABLE] */;
          goto LABEL_43;
        }
        sub_407790();
        g_nSceneState = 2;
        (((PalScriptMgr *)v19))->PalScriptMgr::Destroy();
        (((CGameData *)&g_gamefrm))->CGameData::Load(0);
        g_Input.GRPinput::Reset();
        return 1;
      case 1:
        v28 = *(&this->m_nObjStore + 2);
        goto LABEL_42;
      case 3:
        v28 = *(&this->m_nObjStore + 3);
LABEL_42:
        (*(void ( **)(int, _DWORD, int))(*(_DWORD *)v28 + 8))(v28, LODWORD(fFade), nFlags);
        goto LABEL_43;
      case 4:
        (*(void ( **)(int, _DWORD, int))(*(_DWORD *)this->m_hSettingsUI + 8))(
          this->m_hSettingsUI,
          LODWORD(fFade),
          nFlags);
        m_hSettingsUI = this->m_hSettingsUI;
        if ( !*(_DWORD *)(m_hSettingsUI + 130360) )
          goto LABEL_43;
        LODWORD(v34) = *(_DWORD *)(m_hSettingsUI + 130352);
        (((TaskBookUI *)v34))->TaskBookUI::_todo_456200();
        return 1;
      case 5:
        if ( (g_dwGameFlags & 4) != 0 )
        {
          v30 = (CScreenMode *)CScreenMode::GetInstance();
          v31 = (gbAudioManager *)(((CScreenMode *)v30))->CScreenMode::GetAudioManager();
          v32 = (gbAudioManager *)v31;
          if ( v31 )
          {
            (((gbAudioManager *)v31))->gbAudioManager::StopSoundStream(1);
            (((gbAudioManager *)v32))->gbAudioManager::StopSoundStream(2);
            v33 = (CScreenMode *)CScreenMode::GetInstance();
            (((CScreenMode *)v33))->CScreenMode::AudioStopAll();
          }
        }
        (((CGameData *)&g_gamefrm))->CGameData::Load(0);
        return 1;
      default:
LABEL_43:
        if ( *((_BYTE *)&this->m_nObjStore + 5) && LOBYTE(this->m_nTodo_2C18) && LOBYTE(this->m_nTodo_2CD8) )
          PostQuitMessage(0);
        return 1;
    }
  }
  v7 = this->m_nTodo_364C - 1;
  if ( v7 )
  {
    v8 = v7 - 1;
    if ( v8 )
    {
      if ( v8 == 1 )
      {
        v9 = (CScreenMode *)CScreenMode::GetInstance();
        v10 = (gbAudioManager *)(((CScreenMode *)v9))->CScreenMode::GetAudioManager();
        v11 = (gbAudioManager *)v10;
        if ( v10 )
        {
          (((gbAudioManager *)v10))->gbAudioManager::DetachAll3D();
          (((gbAudioManager *)v11))->gbAudioManager::StopSoundStream(0);
          (((gbAudioManager *)v11))->gbAudioManager::StopSoundStream(2);
          (((gbAudioManager *)v11))->gbAudioManager::StopSoundStream(1);
        }
        (((CGameData *)&g_gamefrm))->CGameData::Load((CUtil *)0xB);
        return 1;
      }
      else
      {
        return 1;
      }
    }
    else
    {
      v13 = (CScreenMode *)CScreenMode::GetInstance();
      v14 = (gbAudioManager *)(((CScreenMode *)v13))->CScreenMode::GetAudioManager();
      v15 = (gbAudioManager *)v14;
      if ( v14 )
      {
        (((gbAudioManager *)v14))->gbAudioManager::DetachAll3D();
        (((gbAudioManager *)v15))->gbAudioManager::StopSoundStream(0);
        (((gbAudioManager *)v15))->gbAudioManager::StopSoundStream(2);
        (((gbAudioManager *)v15))->gbAudioManager::StopSoundStream(1);
      }
      (((CGameData *)&g_gamefrm))->CGameData::Load((CUtil *)8);
      return 1;
    }
  }
  else
  {
    v16 = (CScreenMode *)CScreenMode::GetInstance();
    v17 = (gbAudioManager *)(((CScreenMode *)v16))->CScreenMode::GetAudioManager();
    v18 = (gbAudioManager *)v17;
    if ( v17 )
    {
      (((gbAudioManager *)v17))->gbAudioManager::DetachAll3D();
      (((gbAudioManager *)v18))->gbAudioManager::StopSoundStream(0);
      (((gbAudioManager *)v18))->gbAudioManager::StopSoundStream(2);
      (((gbAudioManager *)v18))->gbAudioManager::StopSoundStream(1);
    }
    PAL3::SnapScreen();
    return 1;
  }
}

// 0x0044DFC0
int UIScenePanel::OnMessage(UICursor *msg, int wparam, int lparam)
{
  int result; // eax
  CScreenMode *Instance; // eax
  Actor *SaveDataManager; // eax
  CScreenMode *v8; // eax
  void *v9; // edx
  int v10; // edi
  int v11; // ebp
  CScreenMode *v12; // eax
  CScreenMode *v13; // eax
  CScreenMode *v14; // eax
  CScreenMode *v15; // eax
  const void *v16; // [esp-0x14] [ebp-0x18]
  const void *v17; // [esp-0xC] [ebp-0x10]
  const void *v18; // [esp-0xC] [ebp-0x10]
  const void *v19; // [esp-0xC] [ebp-0x10]
  const void *v20; // [esp-0xC] [ebp-0x10]
  const void *v21; // [esp-0xC] [ebp-0x10]

  if ( msg == (UICursor *)1000 )
  {
    if ( wparam )
    {
      *((_BYTE *)&this->m_nObjStore + 5) = 0;
      LOBYTE(this->m_nTodo_2C18) = 0;
      this->m_nTodo_2C10 = 1077097267;
      this->m_nTodo_2C20 = 1077097267;
      this->m_nTodo_2CD0 = 1077097267;
      this->m_nTodo_2CE0 = 1077097267;
      LOBYTE(this->m_nTodo_2CD8) = 0;
      this->m_nTodo_2C1C = 1056964608;
      this->m_nTodo_2CDC = 1056964608;
      (((UICursor *)0x3E8))->UICursor::IRender();
    }
    return 1;
  }
  else if ( msg == (UICursor *)1001 )
  {
    switch ( wparam )
    {
      case 161:
        if ( *((_BYTE *)&this->m_nObjStore + 5) || LOBYTE((*(void **)&(this[1]))) )
          goto LABEL_25;
        (((PAL3 *)0))->PAL3::LoadRoleByIndex();
        *((_BYTE *)&this->m_nObjStore + 4) = 1;
        v17 = off_59DC84;
        Instance = (CScreenMode *)CScreenMode::GetInstance();
        (((CScreenMode *)Instance))->CScreenMode::AudioSetPosition(v17, 1);
        SaveDataManager = (Actor *)GetSaveDataManager();
        (((Actor *)SaveDataManager))->Actor::IterateActiveActors();
        return 1;
      case 162:
        if ( *((_BYTE *)&this->m_nObjStore + 5) || LOBYTE((*(void **)&(this[1]))) )
          goto LABEL_17;
        /* [MISATTRIBUTED] ChoseCompose on UIScenePanel::this -> fix IDB name of callee */ ChoseCompose::Init((ChoseCompose *)this, 1);
        v18 = off_59DC84;
        v8 = (CScreenMode *)CScreenMode::GetInstance();
        (((CScreenMode *)v8))->CScreenMode::AudioSetPosition(v18, 1);
        return 1;
      case 163:
        if ( *((_BYTE *)&this->m_nObjStore + 5) || LOBYTE((*(void **)&(this[1]))) )
          goto LABEL_17;
        (((UICoverFrm *)this))->UICoverFrm::SetDefaultValues() /* [ROWTABLE] */;
        v9 = (void *)off_59DC84;
        goto LABEL_26;
      case 164:
        if ( *((_BYTE *)&this->m_nObjStore + 5) || LOBYTE((*(void **)&(this[1]))) )
          goto LABEL_17;
        v10 = BYTE1(g_dwUISettings);
        v11 = BYTE2(g_dwUISettings);
        (((PAL3 *)"SOFTWARE\\SOFTSTAR\\PAL3_S_GAME"))->PAL3::WriteRegistryDword((DWORD)"S_GAME_A", (unsigned __int8)g_dwUISettings);
        (((PAL3 *)"SOFTWARE\\SOFTSTAR\\PAL3_S_GAME"))->PAL3::WriteRegistryDword((DWORD)"S_GAME_B", v10);
        (((PAL3 *)"SOFTWARE\\SOFTSTAR\\PAL3_S_GAME"))->PAL3::WriteRegistryDword((DWORD)"S_GAME_C", v11);
        *((_BYTE *)&this->m_nObjStore + 5) = 1;
        this->m_nTodo_2C14 = 1;
        this->m_nTodo_2C08 = 1;
        this->m_nTodo_2C0C = 0;
        LOBYTE(this->m_nTodo_2C18) = 0;
        this->m_nTodo_2CD4 = 1;
        this->m_nTodo_2CC8 = 1;
        this->m_nTodo_2CCC = 0;
        LOBYTE(this->m_nTodo_2CD8) = 0;
        v16 = off_59DC84;
        v12 = (CScreenMode *)CScreenMode::GetInstance();
        (((CScreenMode *)v12))->CScreenMode::AudioSetPosition(v16, 1);
        return 1;
      case 165:
        if ( *((_BYTE *)&this->m_nObjStore + 5) || LOBYTE((*(void **)&(this[1]))) )
        {
LABEL_17:
          v19 = (const void *)off_59DC90;
          v13 = (CScreenMode *)CScreenMode::GetInstance();
          (((CScreenMode *)v13))->CScreenMode::AudioSetPosition(v19, 1);
          return 1;
        }
        /* [MISATTRIBUTED] ChoseCompose on UIScenePanel::this -> fix IDB name of callee */ ChoseCompose::Init((ChoseCompose *)this, 3);
        v9 = (void *)off_59DC84;
        goto LABEL_26;
      case 166:
        if ( *((_BYTE *)&this->m_nObjStore + 5) || LOBYTE((*(void **)&(this[1]))) )
        {
LABEL_25:
          v9 = (void *)off_59DC90;
LABEL_26:
          v21 = v9;
          v15 = (CScreenMode *)CScreenMode::GetInstance();
          (((CScreenMode *)v15))->CScreenMode::AudioSetPosition(v21, 1);
LABEL_27:
          result = 1;
        }
        else
        {
          v20 = off_59DC84;
          v14 = (CScreenMode *)CScreenMode::GetInstance();
          (((CScreenMode *)v14))->CScreenMode::AudioSetPosition(v20, 1);
          /* [MISATTRIBUTED] ChoseCompose on UIScenePanel::this -> fix IDB name of callee */ ChoseCompose::Init((ChoseCompose *)this, 4);
          result = 1;
        }
        break;
      default:
        goto LABEL_27;
    }
  }
  else
  {
    return (((CGameData *)this))->CGameData::OnMessage((int)msg, wparam, lparam) /* [ROWTABLE] */;
  }
  return result;
}

// 0x0046DF10
char UIScenePanel::ValidateIndex(int nVal)
{
  if ( nVal >= (int)this->m_Static_13904.m_textx )
    return 0;
  if ( nVal >= 0 )
    return *((_BYTE *)&this[1].m_pPanelSlot4 + nVal + 128);
  return 0;
}

// 0x0052CAF0

// ---- synthesized vtable stubs (unresolved slots) ----
// [VFTABLE-STUB] original: ((void ( *)(UIStatic *, _DWORD))v11->__vftable->ShowWindow)(v11, 0)
static void pal3_vtbl_unk_0(UIStatic *, _DWORD);
// [VFTABLE-STUB] original: ((void ( *)(UIStatic *, _DWORD))v12->__vftable->ShowWindow)(v12, 0)
static void pal3_vtbl_unk_1(UIStatic *, _DWORD);

int UIScenePanel::ActivatePanel(int id)
{
  char *v3; // edi
  int v4; // ecx
  int v5; // eax
  int v6; // edx
  const char *v7; // eax
  void (***v8)(_DWORD, _DWORD); // ebx
  int v9; // edx
  int result; // eax
  UIStatic *v11; // [esp+0x70] [ebp-0x3C]
  UIStatic *v12; // [esp+0x74] [ebp-0x38]
  void (***v13)(_DWORD, _DWORD); // [esp+0x78] [ebp-0x34]
  void (***v14)(_DWORD, _DWORD); // [esp+0x7C] [ebp-0x30]
  void (***v15)(_DWORD, _DWORD); // [esp+0x80] [ebp-0x2C]
  void (***v16)(_DWORD, _DWORD); // [esp+0x84] [ebp-0x28]
  void (***v17)(_DWORD, _DWORD); // [esp+0x88] [ebp-0x24]
  _BYTE v18[16]; // [esp+0x8C] [ebp-0x20] BYREF
  _DWORD v19[4]; // [esp+0x9C] [ebp-0x10] BYREF

  v3 = (char *)this + 1552 * id;
  v11 = (UIStatic *)(v3 + 2424);
  (*(void ( **)(const char *, _BYTE *, UIScenePanel *))(*((_DWORD *)v3 + 606) + 16))(
    (&off_5707D0)[id],
    v18,
    this);
  LOBYTE(v4) = *((_BYTE *)&this->m_SceneD.m_hTexture + 69);
  (((UIStatic *)(v3 + 2424)))->UIStatic::CreateFromTemplate("SubGame\\Encampment\\BlanceBk.tga", v4);
  v13 = (void ( ***)(_DWORD, _DWORD))(v3 + 2576);
  (*(void ( **)(const char *, _BYTE *, UIScenePanel *))(*((_DWORD *)v3 + 644) + 16))(
    (&off_5707D0)[id],
    v18,
    this);
  v12 = (UIStatic *)(v3 + 2728);
  v5 = (*(int ( **)(const char *, _BYTE *, UIScenePanel *))(*((_DWORD *)v3 + 682) + 16))(
         (&off_5707D0)[id],
         v18,
         this);
  LOBYTE(v5) = *((_BYTE *)&this->m_SceneD.m_hTexture + 69);
  (((UIStatic *)(v3 + 2728)))->UIStatic::CreateFromTemplate((void *)(0x57081C)[id], v5);
  v6 = *((_DWORD *)v3 + 758);
  v19[1] = 0;
  v19[0] = 0;
  v7 = (&off_5707D0)[id];
  v19[2] = 76;
  v19[3] = 12;
  v15 = (void ( ***)(_DWORD, _DWORD))(v3 + 3032);
  (*(void ( **)(const char *, _DWORD *, UIScenePanel *))(v6 + 16))(v7, v19, this);
  v14 = (void ( ***)(_DWORD, _DWORD))(v3 + 2880);
  (*(void ( **)(const char *, _BYTE *, UIScenePanel *))(*((_DWORD *)v3 + 720) + 16))(
    (&off_5707D0)[id],
    v18,
    this);
  v8 = (void ( ***)(_DWORD, _DWORD))(v3 + 3276);
  (*(void ( **)(char *, const char *, _BYTE *, UIScenePanel *))(*((_DWORD *)v3 + 819) + 16))(
    v3 + 3276,
    (&off_5707D0)[id],
    v18,
    this);
  sub_446010(v3 + 3276);
  v17 = (void ( ***)(_DWORD, _DWORD))(v3 + 3580);
  (*(void ( **)(const char *, _DWORD *, UIScenePanel *))(*((_DWORD *)v3 + 895) + 16))(
    (&off_5707D0)[id],
    v19,
    this);
  v16 = (void ( ***)(_DWORD, _DWORD))(v3 + 3428);
  (*(void ( **)(const char *, _BYTE *, UIScenePanel *))(*((_DWORD *)v3 + 857) + 16))(
    (&off_5707D0)[id],
    v18,
    this);
  v9 = *((_DWORD *)v3 + 956);
  v3 += 3824;
  (*(void ( **)(char *, const char *, _BYTE *, UIScenePanel *))(v9 + 16))(v3, (&off_5707D0)[id], v18, this);
  sub_446010(v3);
  pal3_vtbl_unk_0(v11, 0) /* [VFTABLE-STUB] */;
  (**v13)(v13, 0);
  pal3_vtbl_unk_1(v12, 0) /* [VFTABLE-STUB] */;
  (**v14)(v14, 0);
  (**v15)(v15, 0);
  (**v8)(v8, 0);
  (**v16)(v16, 0);
  (**v17)(v17, 0);
  result = (**(int ( ***)(char *, _DWORD))v3)(v3, 0);
  this->m_bPanelActive = 1;
  return result;
}

static void pal3_vtbl_unk_0(UIStatic *, _DWORD)
{
    
}
static void pal3_vtbl_unk_1(UIStatic *, _DWORD)
{
    
}

