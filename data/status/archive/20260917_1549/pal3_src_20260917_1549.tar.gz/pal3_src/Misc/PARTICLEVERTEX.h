#pragma once
// Auto-generated: PARTICLEVERTEX
#include "pal3/ida_types.h"

class PARTICLEVERTEX {
public:
    DWORD FVF; // +0x0
    char _gap_004[8]; // +0x4
    DWORD color; // +0xC
    float tu; // +0x10
    float tv; // +0x14
    // total size: 0x18 (24)

};
