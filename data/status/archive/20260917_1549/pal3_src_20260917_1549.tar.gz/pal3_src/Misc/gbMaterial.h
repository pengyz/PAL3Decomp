#pragma once
// Auto-generated: gbMaterial
#include "pal3/ida_types.h"

#include "gbengine/gbengine_types.h"

class gbMaterial {
public:
    gbColorFlt diffuse; // +0x0
    gbColorFlt ambient; // +0x10
    gbColorFlt specular; // +0x20
    gbColorFlt emissive; // +0x30
    float power; // +0x40
    // total size: 0x44 (68)

};
