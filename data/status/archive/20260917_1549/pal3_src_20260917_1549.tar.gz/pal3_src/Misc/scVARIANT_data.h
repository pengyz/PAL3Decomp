#pragma once
// Auto-generated: scVARIANT_data
#include "pal3/ida_types.h"

class scVARIANT_data {
public:
    union { // +0x0
    float as_int; // +0x0
    float as_float; // +0x0
    };
    // total size: 0x4 (4)

};
