#pragma once
// Auto-generated: tagRoleTaskData
#include "pal3/ida_types.h"

class tagRoleTaskData {
public:
    int nStatus; // +0x0
    char _gap_004[4]; // +0x4
    int nActionType; // +0x8
    char _gap_00C[4]; // +0xC
    void * pRoleState; // +0x10
    char _gap_014[4]; // +0x14
    char _gap_18[48]; // +0x18
    // total size: 0x48 (72)

};
