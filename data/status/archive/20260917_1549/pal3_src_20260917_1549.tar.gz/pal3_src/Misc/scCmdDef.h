#pragma once
// Auto-generated: scCmdDef
#include "pal3/ida_types.h"

class scCmdDef {
public:
    char * pfun; // +0x0
    BYTE paramlist[8]; // +0x4
    WORD paramnum; // +0xC
    char _tail_00E[2]; // +0xE
    // total size: 0x10 (16)

};
