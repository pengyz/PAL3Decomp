#pragma once
// Auto-generated: tagEntry
#include "pal3/ida_types.h"

class tagEntry {
public:
    int sizeFront; // +0x0
    tagEntry * pEntryNext; // +0x4
    tagEntry * pEntryPrev; // +0x8
    // total size: 0xC (12)

};
