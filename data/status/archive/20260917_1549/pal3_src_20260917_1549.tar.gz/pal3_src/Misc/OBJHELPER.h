#pragma once
// Auto-generated: OBJHELPER
#include "pal3/ida_types.h"

#include "gbengine/gbengine_types.h"

class OBJHELPER {
public:
    BYTE bValid; // +0x0
    char _gap_001[3]; // +0x1
    int nType; // +0x4
    tagRECT rTouchArea; // +0x8
    tagPOINT pGroundPt; // +0x18
    int nEffRunID; // +0x20
    gbVec3D vEffPos; // +0x24
    // total size: 0x30 (48)

};
