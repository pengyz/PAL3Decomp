#pragma once
// Auto-generated: rterrmsgs
#include "pal3/ida_types.h"

class rterrmsgs {
public:
    int rterrno; // +0x0
    char * rterrtxt; // +0x4
    // total size: 0x8 (8)

};
