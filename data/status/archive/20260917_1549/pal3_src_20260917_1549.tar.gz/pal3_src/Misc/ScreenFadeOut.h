#include "Effect/ScreenEffect.h"
#pragma once
// Auto-generated: ScreenFadeOut
#include "pal3/ida_types.h"

class ScreenFadeOut : public ScreenEffect {
public:
    char _tail_000[24]; // +0x0
    // total size: 0x18 (24)

};
