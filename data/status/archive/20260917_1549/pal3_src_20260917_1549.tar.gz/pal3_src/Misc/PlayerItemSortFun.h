#pragma once
// Auto-generated: PlayerItemSortFun
#include "pal3/ida_types.h"

class PlayerItemSortFun {
public:
    int m_by; // +0x0
    // total size: 0x4 (4)

};
