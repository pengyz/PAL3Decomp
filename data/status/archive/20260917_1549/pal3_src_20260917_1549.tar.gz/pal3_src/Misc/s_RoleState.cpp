#include "pal3/ida_defs.h"
#include "globals.h"
#include "pal3/pal3_constants.h"
#include "Misc/s_RoleState.h"
#include "Misc/OpenBaseFile.h"
#include "Misc/OpenNULLFile.h"
#include "Role/RoleSystem.h"
#include "Misc/UICaption.h"
#include "Misc/UICoverFrm.h"
#include "Misc/UIProgressBar.h"
#include "Misc/UIScrollBar.h"
#include "UI/UIWnd.h"
#include "Misc/_PlugInfo.h"
#include "free_functions.h"

// 0x004A3A90
int s_RoleState::LoadAndSetupRole()
{
  int v2; // eax
  int v3; // eax
  int v4; // eax
  int v5; // eax
  int v6; // eax
  int v7; // eax
  int result; // eax
  float fValue; // [esp+0x0] [ebp-0x1C]
  float fValuea; // [esp+0x0] [ebp-0x1C]
  float fValueb; // [esp+0x0] [ebp-0x1C]
  float fValuec; // [esp+0x0] [ebp-0x1C]
  float fValued; // [esp+0x0] [ebp-0x1C]
  float fValuee; // [esp+0x0] [ebp-0x1C]

  *(_DWORD *)this->m_Headbk.m_text = 0;
  do
  {
    v2 = *(_DWORD *)this->m_Headbk.m_text;
    if ( *((_BYTE *)&this->m_Name.m_bvisible + v2 + 1) )
    {
      (((RoleSystem *)((char *)&g_RoleSlotBuf + 1408 * v2)))->RoleSystem::RecalcAggregatedStats(0);
      fValue = (float)*((int *)&g_RoleSlotBuf.m_partyActor.m_nAnimFrame + 352 * *(_DWORD *)this->m_Headbk.m_text);
      (((UIScrollBar *)&this[*(_DWORD *)this->m_Headbk.m_text + 41].m_Name.m_pbk2))->UIScrollBar::SetRange(fValue);
      v3 = *(_DWORD *)this->m_Headbk.m_text;
      fValuea = (float)*((int *)&g_RoleSlotBuf.m_partyActor.m_nAnimFrame + 352 * v3 + 1);
      (((UIScrollBar *)&this[v3 + 41].m_ShenVal.m_pbk2))->UIScrollBar::SetRange(fValuea);
      v4 = *(_DWORD *)this->m_Headbk.m_text;
      fValueb = (float)*((int *)&g_RoleSlotBuf.m_partyActor.m_nAnimFrame + 352 * v4 + 2);
      (((UIScrollBar *)&this[v4 + 41].m_JingVal.m_pbk2))->UIScrollBar::SetRange(fValueb);
      v5 = *(_DWORD *)this->m_Headbk.m_text;
      fValuec = (float)(int)g_RoleSlotBuf.m_partyActor.m_dwMatMsg[352 * v5 + 2];
      (((UIProgressBar *)&this[v5 + 41].m_Name.m_pbk2))->UIProgressBar::FindChildByName(fValuec);
      v6 = *(_DWORD *)this->m_Headbk.m_text;
      fValued = (float)(int)g_RoleSlotBuf.m_partyActor.m_dwMatMsg[352 * v6 + 3];
      (((UIProgressBar *)&this[v6 + 41].m_ShenVal.m_pbk2))->UIProgressBar::FindChildByName(fValued);
      v7 = *(_DWORD *)this->m_Headbk.m_text;
      fValuee = (float)(int)g_RoleSlotBuf.m_partyActor.m_dwMatMsg[352 * v7 + 4];
      (((UIProgressBar *)&this[v7 + 41].m_JingVal.m_pbk2))->UIProgressBar::FindChildByName(fValuee);
      sprintf(
        &this->m_Headbk.m_text[8],
        "%d/%d",
        (int)*(float *)&this[*(_DWORD *)this->m_Headbk.m_text + 41].m_Jing.m_mouseoff,
        *((_DWORD *)&g_RoleSlotBuf.m_partyActor.m_nAnimFrame + 352 * *(_DWORD *)this->m_Headbk.m_text));
      SetEnable((UICaption *)&this[*(_DWORD *)this->m_Headbk.m_text + 41].m_JingBar.m_decorateRc.top);
      sprintf(
        &this->m_Headbk.m_text[8],
        "%d/%d",
        (int)*(float *)&this[*(_DWORD *)this->m_Headbk.m_text + 41].m_Qi.m_mouseoff,
        *((_DWORD *)&g_RoleSlotBuf.m_partyActor.m_nAnimFrame + 352 * *(_DWORD *)this->m_Headbk.m_text + 1));
      SetEnable((UICaption *)&this[*(_DWORD *)this->m_Headbk.m_text + 41].m_QiBar.m_decorateRc.top);
      sprintf(
        &this->m_Headbk.m_text[8],
        "%d/%d",
        (int)*(float *)&this[*(_DWORD *)this->m_Headbk.m_text + 41].m_Shen.m_mouseoff,
        *((_DWORD *)&g_RoleSlotBuf.m_partyActor.m_nAnimFrame + 352 * *(_DWORD *)this->m_Headbk.m_text + 2));
      SetEnable((UICaption *)&this[*(_DWORD *)this->m_Headbk.m_text + 41].m_ShenBar.m_decorateRc.top);
      sprintf(
        &this->m_Headbk.m_text[8],
        &dir[20],
        g_RoleSlotBuf.m_partyActor.m_dwMatMsg[352 * *(_DWORD *)this->m_Headbk.m_text + 9]);
      SetEnable((UICaption *)&this[*(_DWORD *)this->m_Headbk.m_text + 41].m_ExpVal.m_pbk2);
      sprintf(
        &this->m_Headbk.m_text[8],
        &dir[20],
        g_RoleSlotBuf.m_partyActor.m_dwMatMsg[352 * *(_DWORD *)this->m_Headbk.m_text + 10]);
      SetEnable((UICaption *)&this[*(_DWORD *)this->m_Headbk.m_text + 41].m_NextLv.m_pbk2);
      sprintf(
        &this->m_Headbk.m_text[8],
        &dir[20],
        *(_DWORD *)&g_RoleSlotBuf.m_partyActor.m_curact[1408 * *(_DWORD *)this->m_Headbk.m_text + 3]);
      SetEnable((UICaption *)&this[*(_DWORD *)this->m_Headbk.m_text + 41].m_WuLing[1].m_pbk2);
      sprintf(
        &this->m_Headbk.m_text[8],
        &dir[20],
        g_RoleSlotBuf.m_partyActor.m_dwMatMsg[352 * *(_DWORD *)this->m_Headbk.m_text + 11]);
      SetEnable((UICaption *)&this[*(_DWORD *)this->m_Headbk.m_text + 41].m_WuLing[0].m_pbk2);
      sprintf(
        &this->m_Headbk.m_text[8],
        &dir[20],
        *(_DWORD *)&g_RoleSlotBuf.m_partyActor.m_curact[1408 * *(_DWORD *)this->m_Headbk.m_text + 7]);
      SetEnable((UICaption *)&this[*(_DWORD *)this->m_Headbk.m_text + 41].m_WuLing[2].m_pbk2);
    }
    result = *(_DWORD *)this->m_Headbk.m_text + 1;
    *(_DWORD *)this->m_Headbk.m_text = result;
  }
  while ( result < 5 );
  return result;
}

// 0x0052FA50
gbVFileSystem * s_RoleState::LoadSkeletonModel()
{
  gbVFileSystem *result; // eax
  OpenBaseFile v3; // [esp+0x10] [ebp-0x10] BYREF
  int v4; // [esp+0x1C] [ebp-0x4]

  v4 = 0;
  (((gbGeomNode *)&this->m_WuLing[3].m_rect.top))->gbGeomNode::LoadFromFile("SubGame\\Skee\\SkeeScene\\Ball\\Ball.pol", 0, 0);
  (((gbGeomNode *)&this->m_WuLing[3].m_rect.top))->gbGeomNode::GetOBBox((gbOBBox *)&this->m_FWSY.m_pfather);
  (((UICoverFrm *)&this->m_FWSY.m_disablepic))->UICoverFrm::LoadFromFile(aBasedataSkeePa);
  *(_DWORD *)&this->m_FWSY.m_text[12] = 0;
  this->m_FWSY.m_pbkInfo = 0;
  this->m_FWSY.m_ppic = 0;
  this->m_FWSY.m_pbk = (gbTexture *)1093517967;
  *(_DWORD *)&this->m_FWSY.m_mouseoff = 0;
  LOBYTE(this->m_FWSY.m_ppicInfo) = 0;
  v4 = -1;
  // [AUTO-COMMENTED] (OpenNULLFile *)&v3->OpenNULLFile();
  return result;
}

// 0x0052FB00
char s_RoleState::CopyRoleData(int nVal, char pData)
{
  char *v3; // eax
  char result; // al

  v3 = (char *)this->m_FWSY.m_disablepicInfo + 32 * nVal;
  *(_DWORD *)&this->m_FWSY.m_text[12] = *((_DWORD *)v3 + 3);
  this->m_FWSY.m_wndcolor.Color = *(_DWORD *)v3;
  this->m_FWSY.m_id = (void *)*((_DWORD *)v3 + 1);
  this->m_FWSY.m_rect.left = *((_DWORD *)v3 + 2);
  this->m_WuLing[4].m_nTextW = this->m_FWSY.m_wndcolor.Color;
  (*(void **)&(this->m_FWSY)) = (void *)this->m_FWSY.m_id;
  result = (char)pData;
  this->m_FWSY.m_fontcolor.Color = this->m_FWSY.m_rect.left;
  LOBYTE(this->m_FWSY.m_ppicInfo) = pData;
  return result;
}
