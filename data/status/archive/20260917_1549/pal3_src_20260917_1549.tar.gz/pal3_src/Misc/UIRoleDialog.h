#include "Misc/PalScriptWaitObj.h"
#include "UI/UIDialog.h"
#pragma once
// Auto-generated: UIRoleDialog
#include "pal3/ida_types.h"

#include "Misc/UIAnimateCtrl.h"
#include "Misc/UIStaticFlex.h"
#include "Misc/UIStaticFlip.h"
#include "Misc/UITextArea.h"

class UIItem;

class UIRoleDialog : public UIDialog, public PalScriptWaitObj {
public:
    char _gap_000[80]; // +0x0
    UIStaticFlex m_bk; // +0x50
    UIAnimateCtrl m_ani; // +0x110
    UIStaticFlip m_face; // +0x1B4
    UITextArea m_static; // +0x250
    char timeclose[24]; // +0x2B8
    // total size: 0x2D0 (720)

    virtual void * RemoveChild(void *pChild, char bDelete); // 0x004A1A80
    virtual BOOL ProcessFrame(int nVal, int nVal2); // 0x004A1AA0
    UIItem * _sdtor(void *Block, char pData); // 0x004A13F0
    virtual int OnCommand(int nVal, int nVal2, int nVal3); // 0x004A1D10
    ~UIRoleDialog(); // 0x004A1410
    virtual void Create(int nVal); // 0x004BF1C0
    virtual int Destroy(int nVal); // 0x004BF1D0
    virtual void Render(int nVal); // 0x004BF260
};
