#include "pal3/ida_defs.h"
#include "globals.h"
#include "pal3/pal3_constants.h"
#include "Misc/MatrixStack.h"

// 0x0052FC60
void MatrixStack::BeginScene()
{
  gbSceneGraph *pSceneGraph; // esi
  gbMatrixStack *v3; // esi
  MatrixStack *v4; // ebx
  gbVec3D *v5; // ebp
  int v6; // eax
  MatrixStack *v7; // ebx
  gbVec3D *v8; // ebp
  float v9; // edx
  float v10; // [esp+0x1C] [ebp-0x2C]
  float v11; // [esp+0x1C] [ebp-0x2C]
  int v12; // [esp+0x34] [ebp-0x14]
  int v13; // [esp+0x34] [ebp-0x14]
  gbSceneGraph *v14; // [esp+0x38] [ebp-0x10]
  struct gbVec3D v15; // [esp+0x3C] [ebp-0xC] BYREF

  pSceneGraph = gfxMgr->pSceneGraph;
  v14 = (gbSceneGraph *)pSceneGraph;
  (((gbSceneGraph *)pSceneGraph))->gbSceneGraph::Begin(**(gbCamera ***)&this[552]);
  LOBYTE(pSceneGraph->pnodebuf[713]) = 0;
  v3 = gfxMgr->pMatrixStack[1];
  (**(gbCamera ***)&this[552])->gbCamera::SetAsCurrent(3);
  (((gbMatrixStack *)v3))->gbMatrixStack::Push();
v5 = (gbVec3D *)&this[420];
  v12 = 6;
  do
  {
    (((gbMatrixStack *)v3))->gbMatrixStack::Push();
    (((gbMatrixStack *)v3))->gbMatrixStack::Translate(*v5);
    (*(void ( **)(MatrixStack *, _DWORD))(*(_DWORD *)v4 + 16))(v4, 0);
    (((gbMatrixStack *)v3))->gbMatrixStack::Pop();
    ++v5;
    v4 += 70;
    --v12;
  }
  while ( v12 );
  v6 = 0;
  v7 = this + 556;
  v13 = 0;
  v8 = (gbVec3D *)&this[766];
  do
  {
    if ( this[832]._tail_000[v6] )
    {
      (((gbMatrixStack *)v3))->gbMatrixStack::Push();
      (((gbMatrixStack *)v3))->gbMatrixStack::Translate(*v8);
      v10 = *(float *)&this[833];
      v15.x = 0.0;
      v15.y = 1.0;
      v15.z = 0.0;
      (((gbMatrixStack *)v3))->gbMatrixStack::Rotate(v10,  *v15);
      (*(void ( **)(MatrixStack *, _DWORD))(*(_DWORD *)v7 + 16))(v7, 0);
      (((gbMatrixStack *)v3))->gbMatrixStack::Pop();
      v6 = v13;
    }
    ++v6;
    ++v8;
    v7 += 70;
    v13 = v6;
  }
  while ( v6 < 3 );
  if ( this[936]._tail_000[0] )
  {
    (((gbMatrixStack *)v3))->gbMatrixStack::Push();
    (((gbMatrixStack *)v3))->gbMatrixStack::Translate(*(gbVec3D *)&this[907]);
    v9 = *(float *)&this[934];
    v15.x = 0.0;
    v15.y = 1.0;
    v15.z = 0.0;
    (((gbMatrixStack *)v3))->gbMatrixStack::Rotate(v9,  *v15);
    v11 = *(float *)&this[940];
    v15.x = 1.0;
    v15.y = 0.0;
    v15.z = 0.0;
    (((gbMatrixStack *)v3))->gbMatrixStack::Rotate(v11,  *v15);
    (*(void ( **)(MatrixStack *, _DWORD))(*(_DWORD *)&this[834] + 16))(this + 834, 0);
    (((gbMatrixStack *)v3))->gbMatrixStack::Pop();
  }
  (((gbMatrixStack *)v3))->gbMatrixStack::Pop();
  (((gbSceneGraph *)v14))->gbSceneGraph::End();
}

// 0x00530350
void MatrixStack::RenderScenePass()
{
  gbSceneGraph *pSceneGraph; // edi
  gbMatrixStack *v3; // ebx

  pSceneGraph = gfxMgr->pSceneGraph;
  (((gbSceneGraph *)pSceneGraph))->gbSceneGraph::Begin(**(gbCamera ***)&this[1]);
  LOBYTE(pSceneGraph->pnodebuf[713]) = 0;
  v3 = gfxMgr->pMatrixStack[1];
  (**(gbCamera ***)&this[1])->gbCamera::SetAsCurrent(3);
  (((gbMatrixStack *)v3))->gbMatrixStack::Push();
  (*(void ( **)(MatrixStack, _DWORD))(**(_DWORD **)this + 16))(*this, 0);
  (((gbMatrixStack *)v3))->gbMatrixStack::Pop();
  (((gbSceneGraph *)pSceneGraph))->gbSceneGraph::End();
}
