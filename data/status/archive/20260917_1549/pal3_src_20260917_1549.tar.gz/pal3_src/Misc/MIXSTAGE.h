#pragma once
// Auto-generated: MIXSTAGE
#include "pal3/ida_types.h"

class MIXSTAGE {
public:
    char * MSS_mixer_flush; // +0x0
    char * MSS_mixer_merge; // +0x4
    char * MSS_mixer_copy; // +0x8
    // total size: 0xC (12)

};
