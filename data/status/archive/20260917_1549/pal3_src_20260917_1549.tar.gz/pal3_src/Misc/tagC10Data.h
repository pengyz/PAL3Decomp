#pragma once
// Auto-generated: tagC10Data
#include "pal3/ida_types.h"

class tagC10Data {
public:
    int m_nEffParamBase0; // +0x0
    int m_nEffParamBase4; // +0x4
    char _gap_008[4]; // +0x8
    int m_nEffParam0; // +0xC
    int m_nEffParam10; // +0x10
    int m_nEffParam14; // +0x14
    int m_nEffParam1; // +0x18
    int m_nEffParam1C; // +0x1C
    int m_nEffTypeID; // +0x20
    int m_nEffParam24; // +0x24
    int m_nEffTypeCode; // +0x28
    int m_nEffParam2C; // +0x2C
    int m_nEffParam30; // +0x30
    int m_nEffParam34; // +0x34
    int m_nEffParam38; // +0x38
    // total size: 0x3C (60)

};
