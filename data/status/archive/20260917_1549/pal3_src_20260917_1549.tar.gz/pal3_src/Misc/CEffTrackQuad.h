#include "Misc/CEffObj.h"
#include "Effect/CEffQuad.h"
#pragma once
// Auto-generated: CEffTrackQuad
#include "pal3/ida_types.h"

class CEffTrackQuad : public CEffQuad, public CEffObj {
public:
    char _gap_000[4284]; // +0x0
    int m_nCurrTrackPos; // +0x10BC
    float m_fx; // +0x10C0
    float m_fy; // +0x10C4
    float m_fz; // +0x10C8
    // total size: 0x10CC (4300)

};
