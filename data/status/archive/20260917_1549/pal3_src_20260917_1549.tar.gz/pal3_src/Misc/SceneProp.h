#pragma once
// Auto-generated: SceneProp
#include "pal3/ida_types.h"

#include "Misc/ParabolaCalculator.h"
#include "gbengine/gbGeomNode.h"
#include "gbengine/gbengine_types.h"

class SceneProp {
public:
    gbGeomNode * pGeom; // +0x0
    tagRECT rect; // +0x4
    float fCurTime; // +0x14
    float fValidTime; // +0x18
    BYTE bCountTime; // +0x1C
    BYTE bPopFling; // +0x1D
    char _gap_01E[2]; // +0x1E
    gbVec3D vecFling; // +0x20
    gbVec3D lastFling; // +0x2C
    gbVec3D rotFling; // +0x38
    BYTE bCollide; // +0x44
    char _gap_045[3]; // +0x45
    DWORD ID; // +0x48
    BYTE bNeedParabola; // +0x4C
    char _gap_04D[3]; // +0x4D
    int nFlag; // +0x50
    BYTE bValid; // +0x54
    char _gap_055[3]; // +0x55
    ParabolaCalculator parabola; // +0x58
    // total size: 0x88 (136)

    char CalculateWorldPos(float fVal); // 0x005330F0
    char CalcScreenPosition(); // 0x00533BC0
};
