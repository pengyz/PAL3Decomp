#pragma once
// Auto-generated: CEffCamera
#include "pal3/ida_types.h"

class CEffCamera {
public:
    _BYTE _tail_000[4]; // +0x0
    // total size: 0x4 (4)

    // Scalar-wrapper: ctors for IDA (Cls)int casts (no init code)
    CEffCamera() {}
    CEffCamera(int v) { *(int*)this = v; }

};
