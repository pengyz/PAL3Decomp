#pragma once
// Auto-generated: LINEUPINFO
#include "pal3/ida_types.h"

class LINEUPINFO {
public:
    BYTE Info[6]; // +0x0
    // total size: 0x6 (6)

};
