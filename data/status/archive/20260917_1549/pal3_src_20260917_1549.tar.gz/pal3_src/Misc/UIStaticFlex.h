#include "UI/UIWnd.h"
#pragma once
// Auto-generated: UIStaticFlex
#include "pal3/ida_types.h"

#include "Misc/UIStaticFlex_State.h"
#include "Misc/UITextureArray.h"
#include "gbengine/gbPrintFont.h"

class UIStaticFlex : public UIWnd {
public:
    char _gap_000[68]; // +0x0
    tagRECT m_currect; // +0x44
    UITextureArray m_texs; // +0x54
    UIStaticFlex_State m_state; // +0x98
    float m_statetime; // +0x9C
    gbFontType m_fonttype; // +0xA0
    char _gap_0A1[3]; // +0xA1
    int m_tilesize; // +0xA4
    int m_openstyle; // +0xA8
    char _tail_0AC[20]; // +0xAC
    // total size: 0xC0 (192)

};
