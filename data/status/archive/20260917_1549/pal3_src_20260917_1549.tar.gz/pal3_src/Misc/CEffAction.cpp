#include "pal3/ida_defs.h"
#include "globals.h"
#include "pal3/pal3_constants.h"
#include "Misc/CEffAction.h"
#include "Role/Actor.h"
#include "Combat/CCBRoleState.h"
#include "Combat/CCBStage.h"
#include "Combat/CCBStageRole.h"
#include "Combat/CCBSystem.h"
#include "Effect/CEffMgr.h"
#include "Effect/CEffect.h"
#include "Effect/CEffgbParticle.h"
#include "Misc/CTaskTpl_tagEffTaskParam_CEffAction.h"
#include "GameBase/PAL3.h"
#include "Render/RenderTarget2.h"
#include "Role/Role.h"
#include "Misc/tagEffMgrData.h"
#include "Misc/tagEffTaskParam.h"

// Forward declarations for unnamed functions
void __cdecl todo_401800(void);

// 0x004C0500
int CEffAction::OnTest()
{
  int result; // eax

  LOBYTE(result) = 0;
  return result;
}

// 0x004C0520
void CEffAction::AllocRenderTarget()
{
  RenderTarget2 *v1; // eax

  v1 = (RenderTarget2 *)operator new(0x34u);
  if ( v1 )
    (((RenderTarget2 *)v1))->RenderTarget2::ClearTarget();
}

// 0x004C0540
char * CEffAction::ExecutePasses(char a2)
{
  (((RenderTarget2 *)this))->RenderTarget2::ExecutePasses() /* [ROWTABLE] */;
  if ( (a2 & 1) != 0 )
    operator delete(this);
  return (char *)this;
}

// 0x004C0640
void CEffAction::ResetState()
{
  this->m_bIdle = 0;
  this->m_nController = -1;
}

// 0x004C0740

// ---- synthesized vtable stubs (unresolved slots) ----
// [VFTABLE-STUB] original: (*((void ( **)(CTaskTpl_tagEffTaskParam_CEffAction *, _DWORD, _DWORD, _DWORD))v2->__vftable + 1))( v2, *(_DWORD *)(*(_DWORD *)v4 + v6), *(_DWORD *)(*(_DWORD *)v4 + v6 + 4), 0)
static void pal3_vtbl_unk_0(CTaskTpl_tagEffTaskParam_CEffAction *, _DWORD, _DWORD, _DWORD);

void CEffAction::UpdateFrame(float fVal)
{
  CTaskTpl_tagEffTaskParam_CEffAction *v2; // esi
  int v3; // edx
  int v4; // ebp
  int v5; // ebx
  int v6; // edi
  int v7; // ecx
  int v8; // eax
  int v9; // edx
  bool v10; // cc
  int m_nController; // eax
  int v12; // [esp+0x0] [ebp-0x8]
  CEffAction *v13; // [esp+0x4] [ebp-0x4]
  int fVala; // [esp+0xC] [ebp+0x4]

  v2 = ((CTaskTpl_tagEffTaskParam_CEffAction *)this);
*((float *)&this->CTaskTpl_tagEffTaskParam_CEffAction::__vftable + 2) = fVal
                                                                        - *((float *)&this->CTaskTpl_tagEffTaskParam_CEffAction::__vftable
                                                                          + 1);
  *((float *)&this->CTaskTpl_tagEffTaskParam_CEffAction::__vftable + 1) = fVal;
  if ( *((float *)&this->CTaskTpl_tagEffTaskParam_CEffAction::__vftable + 2) > 0.0 )
  {
    v3 = 0;
    fVala = 0;
    if ( *((int *)&this->CTaskTpl_tagEffTaskParam_CEffAction::__vftable + 7) > 0 )
    {
      v12 = 0;
      while ( 1 )
      {
        v4 = v12 + *((_DWORD *)((void **)(v2)) + 3);
        if ( *(_BYTE *)(v4 + 148) )
        {
          if ( *(_DWORD *)(v4 + 12) == 3 )
          {
            v5 = 0;
            if ( *((int *)((void **)(v2)) + 8) > 0 )
              break;
          }
        }
LABEL_29:
        v3 = fVala + 1;
        v10 = ++fVala < *((_DWORD *)((void **)(v2)) + 7);
        v12 += 152;
        if ( !v10 )
        {
          this = v13;
          goto LABEL_31;
        }
      }
      v6 = 0;
      while ( 1 )
      {
        v7 = v6 + *(_DWORD *)v4;
        if ( !*(_BYTE *)(v7 + 64) || v6 > 0 && *(_DWORD *)(v7 - 64) == 2 )
          goto LABEL_29;
        if ( *(_DWORD *)(v7 + 8) == 2 )
          break;
        if ( *(_DWORD *)(v7 + 8) == 3 )
          goto LABEL_22;
        if ( *(_DWORD *)(v7 + 8) == 4 )
        {
          if ( (((CCBStage *)v2))->CCBStage::SetTaskState(v3) )
          {
            v8 = *(_DWORD *)(v4 + 4);
            *(_DWORD *)(v4 + 12) = 4;
            v9 = 9 * v8;
            LOBYTE(v8) = *(_BYTE *)(v4 + 149);
            *(_DWORD *)(v4 + 20) = *(_DWORD *)(*(_DWORD *)v4 + 8 * v9 - 12);
            if ( (_BYTE)v8 == 1 )
            {
              (((CEffgbParticle *)v2))->CEffgbParticle::Init(fVala);
              goto LABEL_29;
            }
          }
        }
LABEL_26:
        ++v5;
        v6 += 72;
        if ( v5 >= *((_DWORD *)((void **)(v2)) + 8) )
          goto LABEL_29;
        v3 = fVala;
      }
      if ( v6 <= 0 )
        goto LABEL_26;
      if ( *(float *)(v7 + 20) >= 0.0 )
      {
        if ( *((float *)((void **)(v2)) + 1) - *(float *)(v7 - 56) <= *(float *)(v7 + 20) )
          goto LABEL_26;
        (((CCBStage *)v2))->CCBStage::GetTaskParam(v3, v5);
        *((_DWORD *)((void **)(v2)) + 4) = fVala;
      }
      else
      {
        if ( *(_DWORD *)(v7 - 64) != 4 )
          goto LABEL_26;
        *(_DWORD *)(*(_DWORD *)(v12 + *((_DWORD *)((void **)(v2)) + 3)) + v6 + 8) = 3;
        *(_DWORD *)(*(_DWORD *)(v12 + *((_DWORD *)((void **)(v2)) + 3)) + v6 + 16) = *((_DWORD *)((void **)(v2)) + 1);
LABEL_22:
        *((_DWORD *)((void **)(v2)) + 4) = v3;
      }
      *((_DWORD *)((void **)(v2)) + 5) = v5;
      pal3_vtbl_unk_0(v2, *(_DWORD *)(*(_DWORD *)v4 + v6), *(_DWORD *)(*(_DWORD *)v4 + v6 + 4), 0) /* [VFTABLE-STUB] */;
      goto LABEL_26;
    }
LABEL_31:
    if ( *((int *)&this->CTaskTpl_tagEffTaskParam_CEffAction::__vftable + 6) <= 0 )
    {
      m_nController = this->m_nController;
      this->m_bIdle = 1;
      if ( m_nController != -1 )
        this->m_pEM->m_pCBSystem->m_pStage->m_pRole[m_nController]->m_bForceFinishThrowingWeapon = 0;
    }
  }
}

static void pal3_vtbl_unk_0(CTaskTpl_tagEffTaskParam_CEffAction *, _DWORD, _DWORD, _DWORD)
{
    
}


// 0x004C0920
void CEffAction::PrepareEffect()
{
  unsigned int v2; // [esp+0x4] [ebp-0x4]
  float *nVal; // [esp+0x10] [ebp+0x8]
  int nVala; // [esp+0x10] [ebp+0x8]

  if ( this->m_pEM->m_pCBSystem )
  {
    if ( (g_bScriptFlag & 1) == 0 )
    {
      g_bScriptFlag |= 1u;
      (((CEffMgr *)&g_pCEffMgrBackup))->CEffMgr::Reset();
      atexit(todo_401800);
    }
    v2 = (int)nVal[21];
    if ( (g_bScriptFlag & 1) == 0 )
    {
      g_bScriptFlag |= 1u;
      (((CEffMgr *)&g_pCEffMgrBackup))->CEffMgr::Reset();
      atexit(todo_401800);
    }
    nVala = (int)*nVal;
    if ( v2 <= 0xA && nVala > 0 )
      (((Actor *)this->m_pEM->m_pCBSystem->m_pStage->m_pRole[v2]))->Actor::GetAnimDurationByIndex(nVala);
  }
}

// 0x004C09E0
void CEffAction::RenderScene()
{
  RenderTarget2 *v1; // ebx
  int v2; // ecx
  int v3; // edx
  int m_SubObj; // esi
  _BYTE *i; // eax
  int v6; // ebp
  unsigned int v7; // eax
  int m_nCurPass; // ecx
  int v9; // eax
  int v10; // edi
  _BYTE *v11; // esi
  int ( **v12)(CEffect *, int); // esi
  unsigned int v13; // eax
  int v14; // ecx
  int v15; // eax
  int v16; // edi
  _BYTE *v17; // esi
  int ( **v18)(CEffect *, int); // esi
  unsigned int v19; // eax
  int *v20; // [esp+0x18] [ebp+0x4]

  v1 = (RenderTarget2 *)((CTaskTpl_tagEffTaskParam_CEffAction *)this);
  v2 = *((_DWORD *)&this->CTaskTpl_tagEffTaskParam_CEffAction::__vftable + 7);
  v3 = 0;
  if ( v2 > 0 )
  {
    m_SubObj = v1->m_SubObj;
    for ( i = (_BYTE *)(m_SubObj + 148); *i; i += 152 )
    {
      if ( ++v3 >= v2 )
        return;
    }
    v6 = 152 * v3;
    *(_DWORD *)(m_SubObj + v6 + 12) = 2;
    *(_BYTE *)(v1->m_SubObj + v6 + 148) = 1;
    *(_BYTE *)(v1->m_SubObj + v6 + 149) = 1;
    v7 = ++g_PAL3.m_nRenderTarget2Count;
    if ( !g_PAL3.m_nRenderTarget2Count || v7 >= 0x7FFFFFFF )
    {
      v7 = 1;
      g_PAL3.m_nRenderTarget2Count = 1;
    }
    *(_DWORD *)(v1->m_SubObj + v6 + 16) = v7;
    *(_DWORD *)(v1->m_SubObj + v6 + 4) = 0;
    *(_DWORD *)(v1->m_SubObj + v6 + 8) = 0;
    *(_DWORD *)(v1->m_SubObj + v6 + 20) = 0;
    if ( v20 )
      qmemcpy((void *)(v1->m_SubObj + v6 + 24), v20, 0x7Cu);
    else
      memset((void *)(v1->m_SubObj + v6 + 24), 0, 0x7Cu);
    ++v1->m_pTargetArray;
    if ( v3 != -1 )
    {
      m_nCurPass = v1->m_nCurPass;
      v9 = 0;
      if ( m_nCurPass > 0 )
      {
        v10 = *(_DWORD *)(v1->m_SubObj + 152 * v3);
        v11 = (_BYTE *)(v10 + 64);
        while ( *v11 )
        {
          ++v9;
          v11 += 72;
          if ( v9 >= m_nCurPass )
            goto LABEL_22;
        }
        v12 = (int ( **)(CEffect *, int))(v10 + 72 * v9);
        memset(v12, 0, 0x48u);
        *v12 = CEffect::SetParam;
        *((_BYTE *)v12 + 64) = 1;
        *((_BYTE *)v12 + 65) = 0;
        v12[1] = 0;
        v12[2] = (int ( *)(CEffect *, int))2;
        v13 = ++g_PAL3.m_nRenderTarget2Count;
        if ( !g_PAL3.m_nRenderTarget2Count || v13 >= 0x7FFFFFFF )
        {
          v13 = 1;
          g_PAL3.m_nRenderTarget2Count = 1;
        }
        v12[3] = (int ( *)(CEffect *, int))v13;
        v12[5] = 0;
        v12[4] = 0;
        v12[6] = 0;
        ++*(_DWORD *)(v1->m_SubObj + v6 + 4);
      }
LABEL_22:
      v14 = v1->m_nCurPass;
      v15 = 0;
      if ( v14 > 0 )
      {
        v16 = *(_DWORD *)(v1->m_SubObj + 152 * v3);
        v17 = (_BYTE *)(v16 + 64);
        while ( *v17 )
        {
          ++v15;
          v17 += 72;
          if ( v15 >= v14 )
            goto LABEL_31;
        }
        v18 = (int ( **)(CEffect *, int))(v16 + 72 * v15);
        memset(v18, 0, 0x48u);
        *v18 = CEffect::SetParam;
        *((_BYTE *)v18 + 64) = 1;
        *((_BYTE *)v18 + 65) = 0;
        v18[1] = 0;
        v18[2] = (int ( *)(CEffect *, int))2;
        v19 = ++g_PAL3.m_nRenderTarget2Count;
        if ( !g_PAL3.m_nRenderTarget2Count || v19 >= 0x7FFFFFFF )
        {
          v19 = 1;
          g_PAL3.m_nRenderTarget2Count = 1;
        }
        v18[3] = (int ( *)(CEffect *, int))v19;
        v18[5] = 0;
        v18[4] = 0;
        v18[6] = 0;
        ++*(_DWORD *)(v1->m_SubObj + v6 + 4);
      }
LABEL_31:
      (((RenderTarget2 *)v1))->RenderTarget2::RenderScene(v3, 0 /* TODO: (int)RenderTarget2::SceneRoleCallback */, 0, 0, v20[18], v20[19]);
      *(_DWORD *)(v1->m_SubObj + v6 + 12) = 3;
      *(_DWORD *)(*(_DWORD *)(v1->m_SubObj + v6) + 8) = 3;
      *(_DWORD *)(*(_DWORD *)(v1->m_SubObj + v6) + 16) = (_DWORD)v1->m_pSurface;
    }
  }
}

// 0x004C1270
int CEffAction::sub_4C1270()
{
  int result; // eax
  int v2; // [esp+0x4] [ebp+0x4]

  switch ( v2 )
  {
    case 0:
      result = (int)(&g_EffMgrData.m_nEffParam9 + 2);
      break;
    case 1:
      result = (int)&g_EffMgrData.m_nEffParam9;
      break;
    case 2:
      result = (int)&g_EffMgrData.m_nEffParam8;
      break;
    case 3:
      result = (int)&g_EffMgrData.m_nEffParam7;
      break;
    case 4:
      result = (int)&g_EffMgrData.m_nEffParam6;
      break;
    case 5:
      result = (int)&g_EffMgrData.m_nEffParam5;
      break;
    case 6:
      result = (int)&g_EffMgrData.m_nEffParam4;
      break;
    case 7:
      result = (int)&g_EffMgrData.m_nEffParam3;
      break;
    case 8:
      result = (int)&g_EffMgrData.m_nEffParam2;
      break;
    case 9:
      result = (int)(&g_EffMgrData.m_nEffTypeCode + 8);
      break;
    case 10:
      result = (int)(&g_EffMgrData.m_nEffTypeCode + 5);
      break;
    case 11:
      result = (int)(&g_EffMgrData.m_nEffTypeCode + 2);
      break;
    case 12:
      result = (int)&g_EffMgrData.m_nEffTypeCode;
      break;
    case 13:
      result = (int)&g_EffMgrData.m_nEffTypeID;
      break;
    case 14:
      result = (int)&g_EffMgrData.m_nEffParam1;
      break;
    case 15:
      result = (int)&g_EffMgrData.m_nEffParam0;
      break;
    case 16:
      result = (int)&g_EffMgrData;
      break;
    case 17:
      result = (int)dword_5D4DA0;
      break;
    case 18:
      result = (int)dword_5D4D94;
      break;
    case 19:
      result = (int)dword_5D4D88;
      break;
    case 20:
      result = (int)&g_pszEditorDesc;
      break;
    case 21:
      result = (int)dword_5D4D70;
      break;
    case 22:
      result = (int)dword_5D4D58;
      break;
    case 23:
      result = (int)dword_5D4D44;
      break;
    default:
      result = (int)g_EffCylinderEditorData;
      break;
  }
  return result;
}
