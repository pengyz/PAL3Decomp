#pragma once
// Auto-generated: UIScenePanel
#include "pal3/ida_types.h"

#include "UI/UIScene.h"
#include "Misc/UIStatic.h"
#include "UI/UIWnd.h"

class UICursor;

class UIScenePanel : public UIScene {
public:
    char _gap_000[344]; // +0x0
    int m_SlotData; // +0x158
    int m_nTodo_15C; // +0x15C
    int m_nTodo_160; // +0x160
    int m_nCategoryIdx; // +0x164
    UIStatic m_Static_360; // +0x168
    int m_pSubPanel; // +0x200
    int m_nTodo_204; // +0x204
    char _gap_208[638]; // +0x208
    BYTE m_bPanelActive; // +0x486
    char _gap_487[1265]; // +0x487
    int m_pPanelSlot0; // +0x978
    char _gap_97C[148]; // +0x97C
    int m_pPanelSlot1; // +0xA10
    char _gap_A14[148]; // +0xA14
    int m_pPanelSlot2; // +0xAA8
    char _gap_AAC[148]; // +0xAAC
    int m_pPanelSlot3; // +0xB40
    char _gap_B44[148]; // +0xB44
    int m_pPanelSlot4; // +0xBD8
    char _gap_BDC[240]; // +0xBDC
    int m_pPanelSlot5; // +0xCCC
    char _gap_CD0[148]; // +0xCD0
    int m_pPanelSlot6; // +0xD64
    char _gap_D68[148]; // +0xD68
    int m_pPanelSlot7; // +0xDFC
    char _gap_E00[240]; // +0xE00
    int m_pPanelSlot8; // +0xEF0
    char _gap_EF4[1260]; // +0xEF4
    void * m_nTodo_13E0; // +0x13E0
    char _gap_13E4[3324]; // +0x13E4
    void * m_nTodo_20E0; // +0x20E0
    char _gap_20E4[2076]; // +0x20E4
    UIStatic m_Static_10496; // +0x2900
    UIStatic m_Static_10648; // +0x2998
    UIStatic m_Static_10800; // +0x2A30
    UIStatic m_Static_10952; // +0x2AC8
    int m_nTodo_2B60; // +0x2B60
    int m_nTodo_2B64; // +0x2B64
    char _gap_2B68[4]; // +0x2B68
    UIWnd m_Wnd_11116; // +0x2B6C
    char _gap_2BB0[88]; // +0x2BB0
    int m_nTodo_2C08; // +0x2C08
    int m_nTodo_2C0C; // +0x2C0C
    int m_nTodo_2C10; // +0x2C10
    int m_nTodo_2C14; // +0x2C14
    int m_nTodo_2C18; // +0x2C18
    int m_nTodo_2C1C; // +0x2C1C
    int m_nTodo_2C20; // +0x2C20
    char _gap_2C24[8]; // +0x2C24
    UIWnd m_Wnd_11308; // +0x2C2C
    char _gap_2C70[88]; // +0x2C70
    int m_nTodo_2CC8; // +0x2CC8
    int m_nTodo_2CCC; // +0x2CCC
    int m_nTodo_2CD0; // +0x2CD0
    int m_nTodo_2CD4; // +0x2CD4
    int m_nTodo_2CD8; // +0x2CD8
    int m_nTodo_2CDC; // +0x2CDC
    int m_nTodo_2CE0; // +0x2CE0
    char _gap_2CE4[8]; // +0x2CE4
    UIScene m_SceneA; // +0x2CEC
    char _gap_2E44[48]; // +0x2E44
    UIScene m_SceneB; // +0x2E74
    char _gap_2FCC[48]; // +0x2FCC
    UIScene m_SceneC; // +0x2FFC
    char _gap_3154[48]; // +0x3154
    UIScene m_SceneD; // +0x3184
    char _gap_32DC[48]; // +0x32DC
    UIScene m_SceneE; // +0x330C
    char _gap_3464[48]; // +0x3464
    UIScene m_SceneF; // +0x3494
    char _gap_35EC[28]; // +0x35EC
    BYTE m_nTodo_3608; // +0x3608
    BYTE m_nTodo_3609; // +0x3609
    char _gap_360A[2]; // +0x360A
    int m_nTodo_360C; // +0x360C
    int m_nTodo_3610; // +0x3610
    int m_nTodo_3614; // +0x3614
    int m_nObjStore; // +0x3618
    char _gap_361C[12]; // +0x361C
    int m_hSettingsUI; // +0x3628
    char _gap_362C[4]; // +0x362C
    BYTE m_bPanelFlagA; // +0x3630
    BYTE m_nTodo_3631; // +0x3631
    BYTE m_nTodo_3632; // +0x3632
    char _gap_3633[1]; // +0x3633
    int m_nPanelState; // +0x3634
    int m_nTodo_3638; // +0x3638
    int m_nSceneIdx; // +0x363C
    char _gap_3640[4]; // +0x3640
    BYTE m_bFlags0; // +0x3644
    BYTE m_bFlags1; // +0x3645
    char _gap_3646[6]; // +0x3646
    int m_nTodo_364C; // +0x364C
    UIStatic m_Static_13904; // +0x3650
    int m_nTodo_36E8; // +0x36E8
    int m_nTodo_36EC; // +0x36EC
    int m_nTodo_36F0; // +0x36F0
    int m_nTodo_36F4; // +0x36F4
    int m_nTodo_36F8; // +0x36F8
    int m_nTodo_36FC; // +0x36FC
    UIStatic m_Static_14080; // +0x3700
    // total size: 0x3798 (14232)

    virtual int Render(); // 0x0043B660
    virtual BOOL Update(int nVal, int nVal2); // 0x0043B900
    virtual int CreateLabelWidget(int id, void *pRect, int parent, LPCSTR lpString, char a6); // 0x0043B570
    virtual void PostRender(); // 0x0044DAC0
    virtual int StopAllSounds(float fFade, int nFlags); // 0x0044DB70
    virtual void Destroy(); // 0x0044C910
    virtual int OnMessage(UICursor *msg, int wparam, int lparam); // 0x0044DFC0
    void _UIScenePanel(); // 0x0043B3E0
    UIScenePanel(); // 0x0044BA60
    void ctor(); // 0x0044BE80
    void CreateSettingsUI(); // 0x0044C120
    char ValidateIndex(int nVal); // 0x0046DF10
    int ActivatePanel(int id); // 0x0052CAF0
    int LayoutSlot(int arg0, int nVal, int nVal2, int nVal3, int nVal4); // 0x0052CD40
};
