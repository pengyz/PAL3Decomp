#pragma once
// Auto-generated: FontPrint3DInfo
#include "pal3/ida_types.h"

#include "gbengine/gbengine_types.h"
#include "gbengine/gbPrintFont.h"

class FontPrint3DInfo {
public:
    gbFontType font; // +0x0
    char _gap_001[3]; // +0x1
    float x; // +0x4
    float y; // +0x8
    float z; // +0xC
    int strloc; // +0x10
    int strlen; // +0x14
    float scalex; // +0x18
    float scaley; // +0x1C
    gbColorQuad color; // +0x20
    // total size: 0x24 (36)

};
