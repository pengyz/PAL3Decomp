#pragma once
// Auto-generated: UIPosMaker
#include "pal3/ida_types.h"

class _UIPOS;

class UIPosMaker {
public:
    BYTE m_bIsLoaded; // +0x0
    char _gap_001[3]; // +0x1
    _UIPOS * m_pUIPos; // +0x4
    int m_nPosNum; // +0x8
    // total size: 0xC (12)

};
