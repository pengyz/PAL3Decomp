#pragma once
// Auto-generated: UIParabolaCtrl
#include "pal3/ida_types.h"

class UIParabolaCtrl {
public:
    _BYTE _tail_000[4]; // +0x0
    // total size: 0x4 (4)

    int GetState(); // 0x004A1CF0
    // Scalar-wrapper: ctors for IDA (Cls)int casts (no init code)
    UIParabolaCtrl() {}
    UIParabolaCtrl(int v) { *(int*)this = v; }

};
