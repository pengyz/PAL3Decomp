#pragma once
// Auto-generated: Comp_Donate_Detail
#include "pal3/ida_types.h"

class Comp_Donate_Detail {
public:
    DWORD m_KeyId; // +0x0
    BYTE m_bDonated; // +0x4
    BYTE m_bHasKey; // +0x5
    char _gap_006[2]; // +0x6
    DWORD m_SourceId; // +0x8
    BYTE m_bHasSource; // +0xC
    char _gap_00D[3]; // +0xD
    DWORD m_Intimacy; // +0x10
    DWORD m_CompId; // +0x14
    BYTE m_bComposed; // +0x18
    BYTE m_bCanRepeat; // +0x19
    char _tail_01A[2]; // +0x1A
    // total size: 0x1C (28)

};
