#include "pal3/ida_defs.h"
#include "globals.h"
#include "pal3/pal3_constants.h"
#include "Role/Actor.h"
#include "Misc/ArcSceneMonster.h"
#include "Misc/Array.h"
#include "Misc/CCBFiveNimbusWindow.h"
#include "Combat/CCBRoleState.h"
#include "Combat/CCBStage.h"
#include "Combat/CCBStageRole.h"
#include "Combat/CCBSystem.h"
#include "Render/CScreenMode.h"
#include "Scene/CameraCtrl.h"
#include "Misc/ECBStageTaskState.h"
#include "GameBase/GRPinput.h"
#include "Misc/GlowObj.h"
#include "Misc/MiniGame2Scene.h"
#include "Role/Object3D.h"
#include "Misc/OpenBaseFile.h"
#include "Misc/OpenNULLFile.h"
#include "GameBase/PAL3.h"
#include "Data/PAL_GDB.h"
#include "Script/PalScript.h"
#include "Script/PalScriptMgr.h"
#include "Render/RenderTarget2.h"
#include "Render/RenderTarget3.h"
#include "Role/Role.h"
#include "Misc/RoleAtt.h"
#include "Misc/RoleCamera.h"
#include "Misc/RoleCameraCtrl.h"
#include "Role/RoleSystem.h"
#include "Scene/SceneMgr.h"
#include "Scene/SceneObj.h"
#include "Effect/ScreenEffect.h"
#include "Effect/ScreenEffectMgr.h"
#include "Misc/ScriptSystemData.h"
#include "Misc/TxtFile.h"
#include "Misc/UIBigMap.h"
#include "Misc/UIButton.h"
#include "Misc/UIFrameWnd.h"
#include "UI/UIListBox.h"
#include "Misc/UIRoleDialog.h"
#include "UI/UIScene.h"
#include "Misc/UIStatic.h"
#include "UI/UIWnd.h"
#include "Misc/VideoPlayer.h"
#include "Misc/gbActorMgr.h"
#include "Misc/s_RoleState.h"
#include "Misc/scAsmDecoder.h"
#include "Misc/tagActionCommand.h"
#include "Misc/tagCmdData.h"
#include "free_functions.h"

// Forward declarations for unnamed functions
int sub_407790(...);
int sub_538260(...);

// Unnamed globals (extern)
void __cdecl nullsub_2(...);
void __cdecl nullsub_71(void);
void __cdecl nullsub_72(void);

// 0x00419690
void Actor::UpdatePhysics(float fVal)
{
  void **p_m_InnerActor; // edi
  double v4; // st7
  char v6; // c0
  long double v7; // st7

  p_m_InnerActor = (void **)&this->m_InnerActor;
  (((Actor *)&this->m_InnerActor))->Actor::QueryState();
  v4 = fVal + *(float *)&this[1].m_pEquipAtt0;
  *(float *)&this[1].m_pEquipAtt0 = v4;
  if ( v6 )
  {
    v7 = (1.0 - cos(v4 / *(float *)&this[1].m_nRoleState1 * 3.1415927)) * 0.5;
    this->m_vecTargetPos.x = *(float *)&this[1].m_dwMatMsg[1] * (1.0 - v7)
                           + *((float *)&this[1].m_pParticleData + 3) * v7;
    this->m_vecTargetPos.y = *(float *)&this[1].m_dwMatMsg[2] * (1.0 - v7)
                           + *((float *)&this[1].m_pParticleData + 4) * v7;
    this->m_vecTargetPos.z = *(float *)&this[1].m_dwMatMsg[3] * (1.0 - v7)
                           + *((float *)&this[1].m_pParticleData + 5) * v7;
  }
  else
  {
    this->m_vecTargetPos.x = *((float *)&this[1].m_pParticleData + 3);
    this->m_vecTargetPos.y = *((float *)&this[1].m_pParticleData + 4);
    this->m_vecTargetPos.z = *((float *)&this[1].m_pParticleData + 5);
    this[1].m_pEquipAtt1[0] = 0;
    (((Actor *)p_m_InnerActor))->Actor::CompareActionName(0, 0);
  }
}

// 0x0041B9F0
unsigned int Actor::GetInnerAnimDuration(int animId)
{
  return (((Actor *)&this->m_InnerActor))->Actor::GetAnimDuration(animId);
}

// 0x0041BCA0
int Actor::ExecuteAction(tagActionCommand *pCmd)
{
  int result; // eax
  Actor *pTargetActor; // edx

  LODWORD(this->m_fDirX) = (unsigned long)pCmd->cmdType;
  result = (int)this[1].m_pEquipAtt1[0];
  if ( result != 3 )
  {
    (((RoleSystem *)this))->RoleSystem::NotifySceneChange() /* [ROWTABLE] */;
    if ( this[1].m_pEquipAtt1[0] == (RoleAtt *)3 )
    {
      pTargetActor = (Actor *)pCmd->pTargetActor;
      LODWORD(this->m_vecTargetPos.x) = (unsigned long)pTargetActor;
      this->m_vecTargetPos.y = pCmd->targetY;
      this->m_vecTargetPos.z = pCmd->targetZ;
      this->m_actarray_begin = pTargetActor;
      this->m_actarray_end = (Actor *)LODWORD(this->m_vecTargetPos.y);
      this->m_actarray_capacity_end = (Actor *)LODWORD(this->m_vecTargetPos.z);
      this->m_actarray_end = 0;
    }
    else
    {
      (((RoleSystem *)this))->RoleSystem::SetTargetRotation((gbVec3D *)&pCmd->pTargetActor) /* [ROWTABLE] */;
    }
    result = (((RoleSystem *)this))->RoleSystem::UpdateMovement(pCmd->fSpeed, 1) /* [ROWTABLE] */;
    this->m_nCmdParam = pCmd->nCmdParam;
  }
  return result;
}

// 0x0044CB30
int Actor::InitParticles()
{
  int *v2; // ebp
  void **p_m_pParticleData; // esi
  int v4; // eax
  unsigned int v5; // eax
  unsigned int v6; // edx
  unsigned int v7; // edi
  int v8; // edx
  int v9; // eax
  int v10; // ecx
  _DWORD *v11; // edx
  int v12; // eax
  int v13; // ecx
  int v15; // [esp+0x0] [ebp-0x24]
  int v16; // [esp+0x10] [ebp-0x14]
  int v17; // [esp+0x14] [ebp-0x10] BYREF
  int v18; // [esp+0x18] [ebp-0xC]
  int v19; // [esp+0x1C] [ebp-0x8]
  int v20; // [esp+0x20] [ebp-0x4]

  v17 = 0;
  v18 = 0;
  v19 = 128;
  v20 = 128;
  RoleSystem_InitDefaultPositions(v15);
  v2 = (int *)&off_59DD18;
  p_m_pParticleData = (void **)&this->m_pParticleData;
  do
  {
    v4 = (*((int ( **)(void **, _DWORD, int *, Actor *))*p_m_pParticleData + 4))(
           p_m_pParticleData,
           0,
           &v17,
           this);
    if ( (int)v2 < (int)&off_59DD60 )
    {
      LOBYTE(v4) = g_bSceneLoaded;
      (((UIStatic *)p_m_pParticleData))->UIStatic::CreateFromTemplate((void *)*v2, v4);
    }
    else
    {
      v5 = rand();
      v6 = v5 % 0x12;
      v7 = v5 % 0x12;
      LOBYTE(v6) = g_bSceneLoaded;
      (((UIStatic *)p_m_pParticleData))->UIStatic::CreateFromTemplate((void *)*(&off_59DD18 + v5 % 0x12), v6);
      p_m_pParticleData[43] = (void *)*((_DWORD *)&this->m_bDirFlag + 52 * v7);
      p_m_pParticleData[44] = (void *)*((_DWORD *)&this->m_bDirFlag + 52 * v7 + 1);
    }
    *((float *)p_m_pParticleData + 46) = (float)(rand() % 255);
    ++v2;
    v8 = rand() % 10;
    v9 = v17;
    v10 = v18;
    v16 = v8 + 10;
    v11 = (_DWORD *)(p_m_pParticleData + 38);
    p_m_pParticleData += 52;
    *((float *)p_m_pParticleData - 5) = (double)v16 * 0.1;
    *((_BYTE *)p_m_pParticleData - 16) = 1;
    *v11 = v9;
    v12 = v19;
    v11[1] = v10;
    v13 = v20;
    v11[2] = v12;
    v11[3] = v13;
  }
  while ( (int)v2 < (int)&off_59DD70 );
  return /* [MISATTRIBUTED] RoleCamera on Actor::this -> fix IDB name of callee */ RoleCamera::InitParticles((RoleCamera *)this);
}

// 0x00456EE0
int Actor::ApplyStateArray()
{
  int v2; // esi
  void **p_m_pParticleData; // edi
  int result; // eax

  this->Actor::SaveState();
  v2 = 0;
  p_m_pParticleData = (void **)&this->m_pParticleData;
  do
  {
    result = (*(int ( **)(void **, _DWORD))*p_m_pParticleData)(p_m_pParticleData, g_bStateFlags[v2++]);
    p_m_pParticleData += 94;
  }
  while ( v2 < 52 );
  return result;
}

// 0x00456F10
char * Actor::SaveState()
{
  char *result; // eax
  int v2; // eax
  int i; // ecx
  int v4; // esi
  int v5; // eax
  int v6; // ecx
  BYTE Data[4]; // [esp+0x8] [ebp-0x8] BYREF
  BYTE v8[4]; // [esp+0xC] [ebp-0x4] BYREF

  memset(g_bStateFlags, 0, 0x34u);
  *(_DWORD *)Data = 0;
  *(_DWORD *)v8 = 0;
  result = (char *)ReadRegistryString(szSubKey, szValueName, (char *)Data);
  if ( (_BYTE)result )
  {
    result = (char *)ReadRegistryString(szSubKey, "MOVIE_B", (char *)v8);
    if ( (_BYTE)result )
    {
      v2 = *(_DWORD *)Data;
      for ( i = 0; i < 32; ++i )
        g_bStateFlags[i] = ((1 << i) & v2) != 0;
      v4 = *(_DWORD *)v8;
      v5 = i;
      v6 = 0;
      result = (char *)&g_bStateFlags[v5];
      do
      {
        *result++ = ((1 << v6) & v4) != 0;
        if ( (int)result >= (int)&g_bListNeedsRefresh )
          break;
        ++v6;
      }
      while ( v6 < 32 );
    }
  }
  return result;
}

// 0x0050ACF0
unsigned int Actor::GetAnimDurationByIndex(int nVal)
{
  unsigned int result; // eax

  result = nVal;
  if ( nVal > 0 )
  {
    sprintf(byte_17AB808, "z%02d", nVal);
    return (*(Actor **)&this->m_szTexture[12])->Actor::GetAnimDuration((int)byte_17AB808);
  }
  return result;
}

// 0x005309A0
int Actor::ResetTransformState()
{
  int v2; // eax
  int v3; // ecx
  float v4; // edx
  double v5; // st7
  double v6; // st7
  int v7; // eax
  int result; // eax
  int v9; // et2
  int v10; // [esp+0xC] [ebp-0x8]
  float v11; // [esp+0x10] [ebp-0x4]

  v2 = (((ArcSceneMonster *)&this->m_dwMatMsg[6]))->ArcSceneMonster::CheckDistance(0.0);
  v10 = *(_DWORD *)(v2 + 4);
  v3 = *(_DWORD *)(v2 + 8);
  *(_DWORD *)&this->m_curact[11] = *(_DWORD *)v2;
  *(_DWORD *)&this->m_curact[15] = v10;
  *(_DWORD *)&this->m_curact[19] = v3;
  *(_DWORD *)&this->m_bChangedMat = *(_DWORD *)&this->m_curact[11];
  *(_DWORD *)&this->m_curact[3] = *(_DWORD *)&this->m_curact[15];
  *(_DWORD *)&this->m_curact[7] = *(_DWORD *)&this->m_curact[19];
  *(_DWORD *)&this->m_curact[23] = 0;
  *(_DWORD *)&this->m_curact[27] = 0;
  *(_DWORD *)&this->m_curact[31] = 0;
  *(_DWORD *)&this->m_curact[35] = 0;
  *(_DWORD *)&this->m_curact[39] = *(_DWORD *)&this->m_curact[27];
  this->_overlap_RoleSystem_m_partyActor_m_nState = *(_DWORD *)&this->m_curact[31];
  v4 = *(float *)(v2 + 4);
  v11 = *(float *)(v2 + 8);
  this->m_fDirX = *(float *)v2;
  this->m_fDirY = v4;
  this->m_fDirZ = v11;
  this->m_fNormX = 0.0;
  this->m_fNormY = 0.0;
  this->m_fNormZ = -0.001;
  this->m_fDistAccum = 0.0;
  *((_DWORD *)&this->m_fSpeed + 2) = 1093517967;
  *((_DWORD *)&this->m_fSpeed + 3) = 1105649992;
  this->m_fSpeed = 10.86;
  *((_DWORD *)&this->m_fSpeed + 1) = 1093517967;
  this->m_fAngleDeg = 0.0;
  this->m_InnerActor = 0;
  this->m_nUpdateMode = 0;
  *(&this->m_nUpdateMode + 1) = 0;
  (*(Actor **)&this->m_actarray_type)->Actor::SetMaterialName((void *)lpString2, 0);
  lstrcpyA((LPSTR)&this->m_fMatrixC, lpString2);
  v5 = this->m_fBlendWeight * 0.33333334;
  *(&this->m_bDirFlag + 21) = 0;
  *(&this->m_bDirFlag + 22) = 0;
  this->m_bDirFlag = 0;
  *((_DWORD *)&this->m_bDirFlag + 1) = 0;
  *(&this->m_bDirFlag + 1) = 1;
  *((_BYTE *)&this->m_nAnimCounter + 46) = 0;
  *((_DWORD *)&this->m_bDirFlag + 6) = 1145241600;
  *((_DWORD *)&this->m_bDirFlag + 7) = 1119092736;
  *((_DWORD *)&this->m_bDirFlag + 8) = -1033895936;
  *((_DWORD *)&this->m_bDirFlag + 9) = 1104150528;
  v6 = v5 + this->m_fBlendWeight;
  *(&this->m_nUpdateMode + 5) = 0;
  *(&this->m_nUpdateMode + 6) = 1086324736;
  *(&this->m_nUpdateMode + 7) = 1086324736;
  *(&this->m_nUpdateMode + 8) = 1022739087;
  *(_DWORD *)&this[1].m_actarray_type = 0;
  *((float *)&this->m_nUpdateMode + 4) = v6;
  *((_BYTE *)&this->m_nUpdateMode + 14) = 1;
  *((_BYTE *)&this->m_nUpdateMode + 15) = 1;
  *(&this->m_nUpdateMode + 2) = 1039516303;
  *((_BYTE *)&this->m_nUpdateMode + 13) = 1;
  *((_BYTE *)&this->m_nAnimCounter + 44) = 0;
  v7 = rand();
  this->m_bStateFlag = 0;
  v9 = v7 % 2600;
  result = v7 / 2600;
  *((_BYTE *)&this->m_nAnimCounter + 45) = 0;
  *(&this->m_nAnimCounter + 4) = v9;
  return result;
}

// 0x00530C00
bool Actor::UpdateAnimState(char pData)
{
  unsigned int v3; // ecx
  RoleSystem *v4; // ecx
  bool result; // al

  UIAnimateCtrlEX_SwapBuffer(3);
  (*(Actor **)&this->m_actarray_type)->Actor::SetMaterialName((void *)lpString2, 0);
  v3 = this->m_dwMatMsg[10];
  *((_BYTE *)&this->m_nAnimCounter + 45) = pData;
  (*(ScreenEffectMgr **)(v3 + 1312))->ScreenEffectMgr::ProcessInstance();
  v4 = (RoleSystem *)this->m_dwMatMsg[10];
  *(&this->m_bDirFlag + 21) = 1;
  (((RoleSystem *)v4))->RoleSystem::StopBlinkUI();
  result = (bool)pData == 0;
  *(_BYTE *)(this->m_dwMatMsg[10] + 4524) = 1;
  *((_BYTE *)&this->m_nAnimCounter + 46) = pData == 0;
  return result;
}

// 0x00530F20
bool Actor::GetBoundRadius()
{
  char *m_pRoleState; // ecx
  gbOBBox *OBBox; // eax
  long double v5; // [esp+0x0] [ebp-0x8]

  m_pRoleState = (char *)this->m_pRoleState;
  v5 = fabs(this->m_fDistAccum - *((float *)m_pRoleState + 932));
  OBBox = (((MiniGame2Scene *)m_pRoleState))->MiniGame2Scene::GetOBBox();
  return (((gbOBBox *)OBBox))->gbOBBox::GetRadius() > v5;
}

// 0x00530F70
void Actor::BlendAnimation(float fVal)
{
  double v3; // st7
  double v4; // st7
  Actor *v5; // ecx
  double v6; // st7
  float v7; // edx

  if ( !*((_BYTE *)&this->m_nUpdateMode + 13) )
  {
    v3 = fVal * *((float *)&this->m_nUpdateMode + 2);
    if ( *((_BYTE *)&this->m_nUpdateMode + 12) )
    {
      v4 = this->m_fSpeed - v3;
      this->m_fSpeed = v4;
      if ( v4 <= 0.0 )
      {
        v5 = *(Actor **)&this->m_actarray_type;
        *((_BYTE *)&this->m_nUpdateMode + 12) = 0;
        (((Actor *)v5))->Actor::SetMaterialName((void *)off_5F50B4, 0);
        UIAnimateCtrlEX_SwapBuffer(0);
      }
    }
    else
    {
      v6 = v3 + this->m_fSpeed;
      this->m_fSpeed = v6;
      if ( v6 >= *(&this->m_fSpeed + 2) )
      {
        v7 = *(&this->m_fSpeed + 2);
        *((_BYTE *)&this->m_nUpdateMode + 12) = 1;
        this->m_fSpeed = v7;
        *((_BYTE *)&this->m_nUpdateMode + 13) = 1;
      }
      *((_BYTE *)&this->m_nUpdateMode + 15) = 1;
    }
  }
}

// 0x00531260
void Actor::UpdateFrame(float arg0)
{
  unsigned int m_nAnimCounter; // eax
  float *v4; // eax
  double v5; // st7
  float *p_m_fDirX; // ebx
  double v7; // st6
  float v8; // ecx
  double v9; // st7
  double v10; // st7
  float m_fDirZ; // ecx
  double v12; // st7
  float v13; // ecx
  double v14; // st7
  float v15; // edx
  float v16; // ecx
  double v17; // st7
  double v18; // st7
  long double v19; // st7
  int v20; // esi
  int m_nUpdateMode; // eax
  float v22; // eax
  unsigned int v23; // edi
  DWORD TickCount; // eax
  DWORD v25; // eax
  unsigned int v26; // edx
  int v27; // edx
  int v28; // edx
  CHAR *v29; // edx
  double v30; // st7
  gbOBBox *SlotA; // eax
  double v32; // st7
  int v33; // ecx
  bool v34; // zf
  double v35; // st7
  gbOBBox *v36; // eax
  Actor *v37; // ecx
  int v38; // esi
  gbOBBox *SlotB; // eax
  int v40; // eax
  unsigned int v41; // eax
  DWORD v42; // eax
  DWORD v43; // eax
  unsigned int v44; // ecx
  int v45; // eax
  int msg; // [esp+0x0] [ebp-0x9C]
  float v47; // [esp+0x4] [ebp-0x98]
  int nVal; // [esp+0x1C] [ebp-0x80]
  gbVec3D v49; // [esp+0x20] [ebp-0x7C] BYREF
  gbVec3D v50; // [esp+0x2C] [ebp-0x70] BYREF
  int p_DWORD; // [esp+0x38] [ebp-0x64] BYREF
  float v52; // [esp+0x3C] [ebp-0x60]
  float v53; // [esp+0x40] [ebp-0x5C]
  float m_fDirX; // [esp+0x44] [ebp-0x58]
  float m_fDirY; // [esp+0x48] [ebp-0x54]
  float v56; // [esp+0x4C] [ebp-0x50]
  float v57[19]; // [esp+0x50] [ebp-0x4C] BYREF

  m_nAnimCounter = this->m_nAnimCounter;
  if ( m_nAnimCounter <= 2 )
  {
    this->m_nAnimCounter = m_nAnimCounter + 1;
  }
  else if ( !*(_BYTE *)(this->m_dwMatMsg[10] + 7276) )
  {
    return;
  }
  switch ( this->m_nUpdateMode )
  {
    case 1:
      this->Actor::BlendAnimation(arg0);
      break;
    case 2:
      (((RoleAtt *)this))->RoleAtt::ApplySpeedFactor(arg0) /* [ROWTABLE] */;
      break;
    case 3:
      (((RoleAtt *)this))->RoleAtt::UpdateTimedBuff(arg0) /* [ROWTABLE] */;
      break;
  }
  if ( this->m_bStateFlag )
  {
    Actor::QueryState(*(Actor **)&this->m_actarray_type);
    return;
  }
  v4 = (float *)(((ArcSceneMonster *)&this->m_dwMatMsg[6]))->ArcSceneMonster::CheckDistance(this->m_fDistAccum);
  if ( !v4 )
  {
    this->m_bDirFlag = 0;
    (((s_RoleState *)this->m_pRoleState))->s_RoleState::CopyRoleData(0, 0);
    this->m_bStateFlag = 1;
    this->Actor::UpdateAnimState(0);
    return;
  }
  v5 = *v4 - this->m_fDirX;
  p_m_fDirX = (float *)&this->m_fDirX;
  m_fDirY = v4[1] - this->m_fDirY;
  v7 = v4[2] - this->m_fDirZ;
  this->m_fNormY = m_fDirY;
  v56 = v7;
  v8 = v56;
  this->m_fNormX = v5;
  this->m_fNormZ = v8;
  (((gbVec3D *)&this->m_fNormX))->gbVec3D::Normalize();
  v9 = arg0 * this->m_fSpeed;
  *(_DWORD *)&this->m_bChangedMat = *(_DWORD *)&this->m_curact[11];
  *(_DWORD *)&this->m_curact[3] = *(_DWORD *)&this->m_curact[15];
  v10 = v9 * this->m_fNormX;
  *(_DWORD *)&this->m_curact[7] = *(_DWORD *)&this->m_curact[19];
  *(float *)&this->m_curact[11] = this->m_fDirX;
  m_fDirZ = this->m_fDirZ;
  *(float *)&this->m_curact[15] = this->m_fDirY;
  *(float *)&this->m_curact[19] = m_fDirZ;
  v12 = v10 + this->m_fDirX;
  p_DWORD = *(int *)&this->m_curact[11];
  v13 = *(float *)&this->m_curact[15];
  this->m_fDirX = v12;
  v14 = this->m_fNormY * this->m_fSpeed;
  v15 = *(float *)&this->m_curact[19];
  v52 = v13;
  v53 = v15;
  this->m_fDirY = v14 * arg0 + this->m_fDirY;
  this->m_fDirZ = this->m_fNormZ * this->m_fSpeed * arg0 + this->m_fDirZ;
  m_fDirX = this->m_fDirX;
  v16 = this->m_fDirZ;
  m_fDirY = this->m_fDirY;
  v56 = v16;
  this->m_fDistAccum = sqrt(
                         (v52 - m_fDirY) * (v52 - m_fDirY)
                       + (v53 - v16) * (v53 - v16)
                       + (*(float *)&p_DWORD - m_fDirX) * (*(float *)&p_DWORD - m_fDirX))
                     + this->m_fDistAccum;
  m_fDirX = this->m_fDirX - *(float *)&this->m_curact[11];
  v17 = this->m_fDirY - *(float *)&this->m_curact[15];
  v50.x = m_fDirX;
  m_fDirY = v17;
  v18 = this->m_fDirZ - *(float *)&this->m_curact[19];
  v50.y = m_fDirY;
  v56 = v18;
  v50.z = v56;
  (((gbVec3D *)&v50))->gbVec3D::Normalize();
  v49 = v50;
  (((gbVec3D *)&v49))->gbVec3D::Normalize();
  if ( (byte_17AFB04 & 1) == 0 )
  {
    dword_17AFAF8 = 0;
    LOBYTE(byte_17AFB04) = byte_17AFB04 | 1;
    dword_17AFAFC = 0;
    dword_17AFB00 = 1065353216;
    atexit(nullsub_72);
  }
  v19 = acos(v49.z * *(float *)&dword_17AFB00 + v49.y * *(float *)&dword_17AFAFC + *(float *)&dword_17AFAF8 * v49.x);
  this->m_fAngleDeg = v19;
  if ( v49.x < 0.0 )
    this->m_fAngleDeg = 6.2831855 - v19;
  this->m_fAngleDeg = this->m_fAngleDeg * 57.29578;
  if ( (byte_17AFB04 & 2) == 0 )
  {
    dword_17AFAE8 = 0;
    LOBYTE(byte_17AFB04) = byte_17AFB04 | 2;
    dword_17AFAEC = 1065353216;
    dword_17AFAF0 = 0;
    atexit(nullsub_71);
  }
  *(float *)&this->m_InnerActor = acos(
                                    v49.z * *(float *)&dword_17AFAF0
                                  + v49.y * *(float *)&dword_17AFAEC
                                  + *(float *)&dword_17AFAE8 * v49.x)
                                * 57.29578;
  m_fDirX = *p_m_fDirX;
  m_fDirY = this->m_fDirY + 200.0;
  v56 = this->m_fDirZ;
  (((RoleCameraCtrl *)this->m_dwMatMsg[9]))->RoleCameraCtrl::ComputeViewVector(SLODWORD(m_fDirX), SLODWORD(m_fDirY), SLODWORD(v56));
  m_fDirX = *p_m_fDirX;
  v20 = 0;
  m_fDirY = this->m_fDirY + 200.0;
  v56 = this->m_fDirZ;
  (((RoleCameraCtrl *)this->m_dwMatMsg[9]))->RoleCameraCtrl::SetViewPosition(SLODWORD(m_fDirX), SLODWORD(m_fDirY), SLODWORD(v56), 0);
  (((UIScene *)this->m_dwMatMsg[9]))->UIScene::LoadMapData(*((_DWORD *)&this->m_bDirFlag + 6));
  *(float *)&msg = *((float *)&this->m_bDirFlag + 7) - (this->m_fAngleDeg - 90.0);
  (((UIBigMap *)this->m_dwMatMsg[9]))->UIBigMap::SetBounds(msg, *((_DWORD *)&this->m_bDirFlag + 8), 0);
  m_nUpdateMode = this->m_nUpdateMode;
  if ( m_nUpdateMode != 1 && m_nUpdateMode != 3 && m_nUpdateMode != 2 && (g_Input.KeyInfo[1].Data & 0xF) == 1 )
  {
    v22 = this->m_fDirY;
    *(&this->m_nUpdateMode + 6) = *(&this->m_nUpdateMode + 7);
    *((_BYTE *)&this->m_nUpdateMode + 15) = 0;
    *(float *)&this[1].m_actarray_type = v22;
    *((_BYTE *)&this->m_nUpdateMode + 14) = 1;
    *(&this->m_nUpdateMode + 5) = 0;
    UIAnimateCtrlEX_SwapBuffer(2);
    (*(Actor **)&this->m_actarray_type)->Actor::SetMaterialName((void *)off_5F50C0, 0);
  }
  if ( *(&this->m_nUpdateMode + 1) == 2 )
  {
    if ( (*(Object3D **)&this->m_actarray_type)->Object3D::GetVisNode() )
    {
      (*(Actor **)&this->m_actarray_type)->Actor::SetMaterialName((void *)off_5F50C4, 0);
      *(&this->m_nUpdateMode + 1) = 0;
    }
    if ( *(&this->m_nUpdateMode + 1) == 2 && (*(Object3D **)&this->m_actarray_type)->Object3D::GetVisNode() )
    {
      *(&this->m_nUpdateMode + 1) = 0;
      (*(Actor **)&this->m_actarray_type)->Actor::SetMaterialName((void *)lpString2, 0);
    }
  }
  if ( !*(&this->m_nUpdateMode + 1) && (*(Object3D **)&this->m_actarray_type)->Object3D::GetVisNode() )
  {
    v23 = *(&this->m_nAnimCounter + 4);
    if ( !*((_BYTE *)&this->m_nAnimCounter + 28) )
    {
      TickCount = GetTickCount();
      *(&this->m_nAnimCounter + 5) = TickCount;
      *(&this->m_nAnimCounter + 6) = TickCount;
      *((_BYTE *)&this->m_nAnimCounter + 28) = 1;
    }
    v25 = GetTickCount();
    v26 = v25 - *(&this->m_nAnimCounter + 6);
    *(&this->m_nAnimCounter + 5) = v25;
    if ( v26 <= v23 )
    {
      v29 = (CHAR *)lpString2;
    }
    else
    {
      *(&this->m_nAnimCounter + 6) = v25;
      *((_BYTE *)&this->m_nAnimCounter + 28) = 0;
      *(&this->m_nAnimCounter + 4) = rand() % 2600 + 1000;
      v27 = rand() % 300 / 10 / 10;
      if ( !v27 )
      {
        (*(Actor **)&this->m_actarray_type)->Actor::SetMaterialName((void *)lpString2, 0);
        goto LABEL_45;
      }
      v28 = v27 - 1;
      if ( !v28 )
      {
        (*(Actor **)&this->m_actarray_type)->Actor::SetMaterialName((void *)off_5F50BC, 0);
        goto LABEL_45;
      }
      if ( v28 != 1 )
        goto LABEL_45;
      v29 = (CHAR *)off_5F50C4;
    }
    (*(Actor **)&this->m_actarray_type)->Actor::SetMaterialName(v29, 0);
  }
LABEL_45:
  if ( !this->m_nUpdateMode )
  {
    if ( this->m_bDirFlag )
    {
      if ( g_Input.KeyInfo[0].PressTime == 1 )
      {
        v30 = this->m_fSpeed + 0.2;
        this->m_fSpeed = v30;
        if ( v30 >= *(&this->m_fSpeed + 3) )
          this->m_fSpeed = *(&this->m_fSpeed + 3);
      }
    }
  }
  if ( *(&this->m_nUpdateMode + 1) == 1 )
  {
    if ( (*(Object3D **)&this->m_actarray_type)->Object3D::GetVisNode() )
    {
      *(&this->m_nUpdateMode + 1) = 0;
      (*(Actor **)&this->m_actarray_type)->Actor::SetMaterialName((void *)lpString2, 0);
    }
    (*(Actor **)&this->m_actarray_type)->Actor::PlayAction((int)&this->m_obbox);
    this->m_fAnimDelta = this->m_fAnimDelta + *p_m_fDirX;
    *(float *)this->m_dwMatMsg = this->m_fDirY + *(float *)this->m_dwMatMsg;
    *(float *)&this->m_dwMatMsg[1] = this->m_fDirZ + *(float *)&this->m_dwMatMsg[1];
    while ( 1 )
    {
      SlotA = (gbOBBox *)(((CCBFiveNimbusWindow *)this->m_pRoleState))->CCBFiveNimbusWindow::GetSlotA(v20);
      if ( (((gbOBBox *)&this->m_obbox))->gbOBBox::IsColOBB(*SlotA) )
        break;
      if ( ++v20 >= 6 )
        goto LABEL_62;
    }
    qmemcpy(
      v57,
      (const void *)(((CCBFiveNimbusWindow *)this->m_pRoleState))->CCBFiveNimbusWindow::GetSlotA(v20),
      sizeof(v57));
    v32 = v57[16];
    if ( v57[17] > (double)v57[16] )
      v32 = v57[17];
    if ( v57[18] > v32 )
      v32 = v57[18];
    *(float *)&nVal = v32 + v32 + this->m_fDistAccum;
    this->m_fDistAccum = *(float *)&nVal;
    (((RoleAtt *)this))->RoleAtt::InterpolateStats(nVal) /* [ROWTABLE] */;
LABEL_62:
    v20 = 0;
  }
  v33 = this->m_nUpdateMode;
  if ( v33 != 1 )
  {
    if ( v33 != 3 && this->m_fSpeed < (double)*(&this->m_fSpeed + 2) )
      this->m_fSpeed = *((float *)&this->m_nUpdateMode + 2) + this->m_fSpeed;
    if ( v33 != 3 )
    {
      (*(Actor **)&this->m_actarray_type)->Actor::PlayAction((int)&this->m_obbox);
      v34 = this->m_nUpdateMode == 2;
      this->m_fAnimDelta = this->m_fAnimDelta + *p_m_fDirX;
      if ( v34 )
        v35 = *(float *)&this[1].m_actarray_type;
      else
        v35 = this->m_fDirY;
      *(float *)this->m_dwMatMsg = v35 + *(float *)this->m_dwMatMsg;
      *(float *)&this->m_dwMatMsg[1] = this->m_fDirZ + *(float *)&this->m_dwMatMsg[1];
      while ( 1 )
      {
        v36 = (gbOBBox *)(((CCBFiveNimbusWindow *)this->m_pRoleState))->CCBFiveNimbusWindow::GetSlotA(v20);
        if ( (((gbOBBox *)&this->m_obbox))->gbOBBox::IsColOBB(*v36) )
          break;
        if ( ++v20 >= 6 )
          goto LABEL_76;
      }
      UIAnimateCtrlEX_SwapBuffer(1);
      v37 = *(Actor **)&this->m_actarray_type;
      *((_BYTE *)&this->m_nUpdateMode + 13) = 0;
      *((_BYTE *)&this->m_nUpdateMode + 12) = 1;
      (((Actor *)v37))->Actor::SetMaterialName((void *)off_5F50C8, 1);
LABEL_76:
      v38 = 0;
      while ( 1 )
      {
        SlotB = (gbOBBox *)(((CCBFiveNimbusWindow *)this->m_pRoleState))->CCBFiveNimbusWindow::GetSlotB(v38);
        if ( (((gbOBBox *)&this->m_obbox))->gbOBBox::IsColOBB(*SlotB) )
          break;
        if ( ++v38 >= 3 )
          goto LABEL_82;
      }
      p_DWORD = 0xFFFF;
      v52 = 0.0;
      v53 = 0.0;
      *(float *)&p_DWORD = _pal3_coerce_f32(sub_52FC50(v38));
      v53 = _pal3_coerce_f32((((PAL_GDB *)&g_pGDB))->PAL_GDB::GDB_GetSkillNum(p_DWORD));
      LODWORD(v52) = 1;
      if ( !(((CCBStage *)&((RoleSystem *)&stru_C059A0)->m_fAnimSpeed))->CCBStage::GetByIndex(&p_DWORD) )
      {
        this->m_pRoleState[v38 + 3328] = 0;
        v40 = sub_52FC50(v38);
        (((CCBFiveNimbusWindow *)this))->CCBFiveNimbusWindow::ApplySelection(v40) /* [ROWTABLE] */;
      }
    }
  }
LABEL_82:
  if ( this->Actor::GetBoundRadius() && this->m_bDirFlag )
  {
    this->m_bStateFlag = 1;
    this->Actor::UpdateAnimState(1);
  }
  Actor::QueryState(*(Actor **)&this->m_actarray_type);
  if ( this->m_bDirFlag )
  {
    if ( *(&this->m_bDirFlag + 1) )
    {
      if ( !*(&this->m_bDirFlag + 16) )
      {
        v42 = GetTickCount();
        *((_DWORD *)&this->m_bDirFlag + 2) = v42;
        *((_DWORD *)&this->m_bDirFlag + 3) = v42;
        *(&this->m_bDirFlag + 16) = 1;
      }
      v43 = GetTickCount();
      v44 = v43 - *((_DWORD *)&this->m_bDirFlag + 3);
      *((_DWORD *)&this->m_bDirFlag + 2) = v43;
      if ( v44 > 0x12C )
      {
        *((_DWORD *)&this->m_bDirFlag + 3) = v43;
        *(&this->m_bDirFlag + 16) = 0;
        v47 = *((float *)&this->m_bDirFlag + 1);
        *(&this->m_bDirFlag + 1) = 0;
        v45 = (((ArcSceneMonster *)&this->m_dwMatMsg[6]))->ArcSceneMonster::ValidateRange(v47);
        (((s_RoleState *)this->m_pRoleState))->s_RoleState::CopyRoleData(v45, 1);
      }
    }
  }
  else if ( *(float *)&this->m_dwMatMsg[8] * 0.5 <= this->m_fDistAccum )
  {
    this->m_bDirFlag = 1;
    *((_DWORD *)&this->m_bDirFlag + 1) = LODWORD(this->m_fDistAccum);
    v41 = this->m_dwMatMsg[9];
    *(_DWORD *)(v41 + 168) = 1117782016;
    *(_DWORD *)(v41 + 172) = 0;
    *(_DWORD *)(v41 + 176) = 0;
    *(_DWORD *)(v41 + 180) = 0;
    *(_DWORD *)(v41 + 220) = 2600;
    *(_DWORD *)(v41 + 196) = 0;
    *(_DWORD *)(v41 + 192) = 0;
    *(_DWORD *)(v41 + 188) = 0;
    *(_DWORD *)(v41 + 184) = 0;
    *(_BYTE *)(v41 + 216) = 1;
    *(_BYTE *)(v41 + 217) = 0;
    *(_BYTE *)(v41 + 224) = 0;
    (((RoleSystem *)this->m_dwMatMsg[10]))->RoleSystem::StartBlinkUI();
  }
}

// 0x00536160
int Actor::SetParam(int nVal)
{
  int v3; // eax
  int result; // eax
  Actor *m_actarray_begin; // ecx
  Actor *m_actarray_end; // ecx
  int v7[17]; // [esp+0x4] [ebp-0x44] BYREF

  if ( this->m_fScale )
  {
    v3 = rand();
    Actor_SetActorAction(-83 - v3 % 34);
    this->m_bParamFlag = 1;
  }
  (*(gbGeomNode **)&this->m_actarray_type)->gbGeomNode::GetTotalOBBox((gbOBBox *)&this->m_actarray_capacity_end);
  ArcLocaleRole_TransformPoint((int)v7);
  result = (*(int ( **)(_DWORD))(**(_DWORD **)&this->m_actarray_type + 20))(*(_DWORD *)&this->m_actarray_type);
  m_actarray_begin = (Actor *)this->m_actarray_begin;
  if ( m_actarray_begin )
    result = (*(int ( **)(Actor *))(*(_DWORD *)&m_actarray_begin->m_actarray_type + 20))(m_actarray_begin);
  m_actarray_end = (Actor *)this->m_actarray_end;
  if ( m_actarray_end )
    return (*(int ( **)(Actor *))(*(_DWORD *)&m_actarray_end->m_actarray_type + 20))(m_actarray_end);
  return result;
}

// 0x00536220
// attributes: thunk
int Actor::GetDefaultFOV_thunk()
{
  return this->Actor::SetDefaultFOV();
}

// 0x00536230
int Actor::SetDefaultFOV()
{
  int result; // eax

  result = 1094713344;
  dword_17B129C = 1094713344;
  return result;
}

// 0x00536240
// attributes: thunk
int Actor::GetDefaultDist_thunk()
{
  int result; // eax

  this->Actor::SetDefaultDist();
  return result;
}

// 0x00536250
void Actor::SetDefaultDist()
{
  flt_17B1298 = 12.0 + 12.0;
}

// 0x00536310
void Actor::DestroyInternalData()
{
  (((UIFrameWnd *)&this[4].m_fRoleParam2))->UIFrameWnd::_UIFrameWnd();
  (((UIButton *)&this[3].m_fDirY))->UIButton::~UIButton();
  (((UIRoleDialog *)&this[2].m_nRoleState0))->UIRoleDialog::~UIRoleDialog();
  (((UIRoleDialog *)&this->m_nHandleEvent))->UIRoleDialog::~UIRoleDialog();
  (((UIListBox *)this))->UIListBox::~UIListBox() /* [ROWTABLE] */;
}

// 0x005363A0
int Actor::ResetDefaultState()
{
  int result; // eax

  result = 0;
  this->m_nActionState = 0;
  this->m_nActionType = 0;
  this->m_bActionFlag1 = 0;
  return result;
}

// 0x00536A40
// attributes: thunk
int Actor::GetDefaultFOV2_thunk()
{
  return this->Actor::SetDefaultFOV2();
}

// 0x00536A50
int Actor::SetDefaultFOV2()
{
  int result; // eax

  result = 1094713344;
  dword_17B154C = 1094713344;
  return result;
}

// 0x00536A60
// attributes: thunk
int Actor::GetDefaultDist2_thunk()
{
  int result; // eax

  this->Actor::SetDefaultDist2();
  return result;
}

// 0x00536A70
void Actor::SetDefaultDist2()
{
  flt_17B1548 = 12.0 + 12.0;
}

// 0x00536A80
void Actor::FastInit()
{
  this->m_actarray_type = HIBYTE(this);
  this->m_actarray_begin = 0;
  this->m_actarray_end = 0;
  this->m_actarray_capacity_end = 0;
  this->m_dwMatMsg[0] = 0;
  this->m_dwMatMsg[1] = 0;
  memset(this->m_name, 0, 0x104u);
  memset(this->m_szTexture, 0, 0x104u);
}

// 0x00536AC0

// ---- synthesized vtable stubs (unresolved slots) ----
// [VFTABLE-STUB] original: (*((void ( **)(gbActorDef *, char *))v16->pBody->__vftable + 15))(v16->pBody, m_szTexture)
static void pal3_vtbl_unk_0(gbActorDef *, char *);

int Actor::SetMaterialName(void *name, int a2)
{
  unsigned int *m_dwMatMsg; // ebx
  char *v6; // edi
  unsigned int v7; // kr04_4
  Actor *m_actarray_begin; // eax
  unsigned int v9; // esi
  int v10; // edi
  Actor *v11; // eax
  int v12; // eax
  int v13; // eax
  gbActor *v14; // ecx
  char *m_szTexture; // esi
  gbActor *v16; // ebp
  gbActor *m_pact; // [esp-0x4] [ebp-0x30]
  struct gbNodeMsgObj v18; // [esp+0x10] [ebp-0x1C] BYREF
  int v19; // [esp+0x28] [ebp-0x4]

  m_dwMatMsg = this->m_dwMatMsg;
  if ( !strcmp((const char *)name, (const char *)this->m_dwMatMsg) )
    return 1;
  v7 = strlen((const char *)name) + 1;
  v6 = (char *)name + v7;
  qmemcpy(m_dwMatMsg, name, 4 * (v7 >> 2));
  qmemcpy(&m_dwMatMsg[v7 >> 2], &v6[4 * (v7 >> 2) - v7], v7 & 3);
  _strlwr((char *)m_dwMatMsg);
  m_actarray_begin = (Actor *)this->m_actarray_begin;
  v9 = 0;
  if ( m_actarray_begin && (unsigned int)(((char *)this->m_actarray_end - (char *)m_actarray_begin) >> 2) > 1 )
  {
    this->m_pact = 0;
    v10 = gbCrc32Compute((const char *)m_dwMatMsg);
    while ( 1 )
    {
      v11 = (Actor *)this->m_actarray_begin;
      if ( !v11 || v9 >= ((char *)this->m_actarray_end - (char *)v11) >> 2 )
        break;
      if ( this->Actor::ValidateInput(v10, *((_DWORD *)&v11->m_actarray_type + v9)) )
      {
        this->m_pact = (gbActor *)*((_DWORD *)&this->m_actarray_begin->m_actarray_type + v9);
        break;
      }
      ++v9;
    }
  }
  m_pact = (gbActor *)this->m_pact;
  v12 = gbCrc32Compute((const char *)m_dwMatMsg);
  v13 = this->Actor::ValidateInput(v12, (int)m_pact);
  v14 = (gbActor *)this->m_pact;
  if ( !v14 || !v13 )
    return 0;
  (((gbActor *)v14))->gbActor::GotoAction((char *)m_dwMatMsg, 0);
  while ( (((gbVisNode *)this->m_pact))->gbVisNode::PopMessage(*v18) )
    ;
  m_szTexture = this->m_szTexture;
  if ( this->m_szTexture[0] )
  {
    // [AUTO-COMMENTED] (OpenBaseFile *)&name->OpenBaseFile();
    v16 = (gbActor *)this->m_pact;
    v19 = 0;
    pal3_vtbl_unk_0(v16->pBody, m_szTexture) /* [VFTABLE-STUB] */;
    v19 = -1;
    // [AUTO-COMMENTED] (OpenNULLFile *)&name->OpenNULLFile();
  }
  return 1;
}

static void pal3_vtbl_unk_0(gbActorDef *, char *)
{
    
}


// 0x00536C50
int Actor::CompareActionName(int actionIdx, int nVal)
{
  if ( !strcmp((&off_570904)[actionIdx], (const char *)this->m_dwMatMsg) )
    return 1;
  else
    return this->Actor::SetMaterialName((void *)(&off_570904)[actionIdx], nVal);
}

// 0x00536CC0
unsigned int Actor::GetAnimDuration(int animId)
{
  return (((gbActor *)this->m_pact))->gbActor::GetActionDuration((char *)animId);
}

// 0x00536CE0
void Actor::EnableTransition(int nVal, int nVal2)
{
  (((gbActor *)this->m_pact))->gbActor::EnableActionTransMtl((char *)nVal, nVal2);
}

// 0x00536D00
void Actor::SetTimeScale(float scale)
{
  (((gbVisNode *)this->m_pact))->gbVisNode::SetTimeScale(scale);
}

// 0x00536D20
void Actor::sub_536D20(const char *a2, int a3)
{
  int v4; // esi
  gbActor *ActorFile; // eax
  Actor *m_actarray_end; // eax
  gbVec3D *v7; // esi
  Actor *m_actarray_begin; // edx
  unsigned int v9; // ecx
  int v10; // eax
  int v11; // eax
  gbVec3D *v12; // edi
  gbVec3D *v13; // ebp
  int ArrayCount; // eax
  Actor *v15; // ecx
  gbActor **v16; // eax
  int p_DWORD2; // [esp+0x10] [ebp-0x11C] BYREF
  OpenBaseFile v18; // [esp+0x14] [ebp-0x118] BYREF
  Actor *v19; // [esp+0x18] [ebp-0x114]
  char Buffer[260]; // [esp+0x1C] [ebp-0x110] BYREF
  int v21; // [esp+0x128] [ebp-0x4]

  this->Actor::UpdateAllActions();
  strcpy(this->m_name, a2);
  v4 = 0;
  v21 = 0;
  sprintf(Buffer, "role\\%s\\%s.ini", this->m_name, this->m_name);
  if ( (int)(((gbVFileSystem *)g_pVFileSys))->gbVFileSystem::FileExistNum(Buffer) > 0 )
  {
    ActorFile = (((gbActorMgr *)g_pActorMgr))->gbActorMgr::LoadActorFile(Buffer);
    this->m_pact = ActorFile;
    if ( ActorFile )
    {
      m_actarray_end = (Actor *)this->m_actarray_end;
      v7 = (gbVec3D *)m_actarray_end;
      if ( ((char *)this->m_actarray_capacity_end - (char *)m_actarray_end) >> 2 )
      {
        Vec3CopyStruct(
          (gbVec3D *)m_actarray_end,
          (gbVec3D *)m_actarray_end,
          (gbVec3D *)&m_actarray_end->m_actarray_begin);
        this->Actor::StoreParam((int)this->m_actarray_end, 1 - (((char *)this->m_actarray_end - (char *)v7) >> 2));
        v15 = (Actor *)this->m_actarray_end;
        v16 = (gbActor **)v7;
        if ( v7 != (gbVec3D *)v15 )
        {
          do
            *v16++ = this->m_pact;
          while ( v16 != (gbActor **)v15 );
        }
        this->m_actarray_end = (Actor *)((char *)this->m_actarray_end + 4);
      }
      else
      {
        m_actarray_begin = (Actor *)this->m_actarray_begin;
        if ( !m_actarray_begin || (v9 = ((char *)m_actarray_end - (char *)m_actarray_begin) >> 2, v9 <= 1) )
          v9 = 1;
        if ( m_actarray_begin )
          v10 = ((char *)m_actarray_end - (char *)m_actarray_begin) >> 2;
        else
          v10 = 0;
        v11 = v9 + v10;
        p_DWORD2 = v11;
        if ( v11 < 0 )
          v11 = 0;
        v12 = (gbVec3D *)operator new(4 * v11);
        v13 = (gbVec3D *)Vec3CopyStruct((gbVec3D *)this->m_actarray_begin, v7, v12);
        this->Actor::StoreParam((int)v13, 1);
        Vec3CopyStruct(v7, (gbVec3D *)this->m_actarray_end, (gbVec3D *)&v13->y);
        v19 = (Actor *)this->m_actarray_begin;
        operator delete(v19);
        this->m_actarray_capacity_end = (Actor *)(&v12->x + p_DWORD2);
        ArrayCount = this->Actor::GetArrayCount();
        this->m_actarray_begin = (Actor *)v12;
        this->m_actarray_end = (Actor *)(&v12->y + ArrayCount);
      }
    }
  }
  else
  {
    do
    {
      sprintf(Buffer, "role\\%s\\%02d.ini", this->m_name, v4);
      p_DWORD2 = 0;
      if ( (((gbVFileSystem *)g_pVFileSys))->gbVFileSystem::FileExistNum(Buffer) )
      {
        p_DWORD2 = (int)(((gbActorMgr *)g_pActorMgr))->gbActorMgr::LoadActorFile(Buffer);
        if ( !p_DWORD2 )
          goto LABEL_21;
        this->Actor::LoadActionSequence((int *)this->m_actarray_end, 1u, &p_DWORD2);
      }
      ++v4;
    }
    while ( v4 < 10 );
    this->m_pact = *(gbActor **)this->m_actarray_begin;
  }
LABEL_21:
  v21 = -1;
  // [AUTO-COMMENTED] (OpenNULLFile *)&v18->OpenNULLFile();
}

// 0x00536FB0
int Actor::QueryState()
{
  return (*(int ( **)(gbActor *))(*(_DWORD *)((gbChain1DNode *)this->m_pact) + 20))(this->m_pact);
}

// 0x00536FC0
int Actor::DispatchAction(int actionId)
{
  return (*(int ( **)(gbActor *, int))(*(_DWORD *)((gbChain1DNode *)this->m_pact) + 16))(this->m_pact, actionId);
}

// 0x00536FD0

// ---- synthesized vtable stubs (unresolved slots) ----
// [VFTABLE-STUB] original: (*((int ( **)(gbActorDef *, int, gbActor *))this->m_pact->pBody->__vftable + 7))( this->m_pact->pBody, actionId, this->m_pact)
static int pal3_vtbl_unk_0(gbActorDef *, int, gbActor *);

int Actor::PlayAction(int actionId)
{
  return pal3_vtbl_unk_0(this->m_pact->pBody, actionId, this->m_pact) /* [VFTABLE-STUB] */;
}

static int pal3_vtbl_unk_0(gbActorDef *, int, gbActor *)
{
    return 0;
}


// 0x00536FF0
int Actor::UpdateAllActions()
{
  unsigned int i; // edi
  Actor *m_actarray_begin; // eax
  int result; // eax
  unsigned int *m_dwMatMsg; // esi

  for ( i = 0; ; ++i )
  {
    m_actarray_begin = (Actor *)this->m_actarray_begin;
    if ( !m_actarray_begin || i >= ((char *)this->m_actarray_end - (char *)m_actarray_begin) >> 2 )
      break;
    (((gbActorMgr *)g_pActorMgr))->gbActorMgr::DestroyActor(*((gbActor **)&m_actarray_begin->m_actarray_type + i));
  }
  result = (int)this->m_actarray_end;
  this->m_actarray_end = this->m_actarray_begin;
  this->m_pact = 0;
  m_dwMatMsg = this->m_dwMatMsg;
  *m_dwMatMsg = 0;
  m_dwMatMsg[1] = 0;
  return result;
}

// 0x005370E0
int Actor::ValidateInput(int nVal, int nVal2)
{
  int v3; // ecx
  int v4; // eax
  _DWORD *i; // edx

  if ( !nVal2 )
    return 0;
  v3 = *(_DWORD *)(nVal2 + 100);
  v4 = 0;
  if ( v3 <= 0 )
    return 0;
  for ( i = (_DWORD *)(*(_DWORD *)(nVal2 + 96) + 4); *i != nVal; i += 9 )
  {
    if ( ++v4 >= v3 )
      return 0;
  }
  return 1;
}

// 0x00537120

// ---- synthesized vtable stubs (unresolved slots) ----
// [VFTABLE-STUB] original: (*((void ( **)(gbActorDef *, char *))this->m_pact->pBody->__vftable + 15))( this->m_pact->pBody, this->m_szTexture)
static void pal3_vtbl_unk_0(gbActorDef *, char *);

void Actor::SetTextureName(const char *pszName)
{
  if ( pszName )
  {
    strcpy(this->m_szTexture, pszName);
    if ( this->m_szTexture[0] )
    {
      // [AUTO-COMMENTED] (OpenBaseFile *)&pszName->OpenBaseFile();
      pal3_vtbl_unk_0(this->m_pact->pBody, this->m_szTexture) /* [VFTABLE-STUB] */;
      // [AUTO-COMMENTED] (OpenNULLFile *)&pszName->OpenNULLFile();
    }
  }
}

static void pal3_vtbl_unk_0(gbActorDef *, char *)
{
    
}


// 0x005371B0

// ---- synthesized vtable stubs (unresolved slots) ----
// [VFTABLE-STUB] original: (*((void ( **)(gbActorDef *, char *))v7->pBody->__vftable + 15))(v7->pBody, m_szTexture)
static void pal3_vtbl_unk_0(gbActorDef *, char *);

void Actor::SetVisible(int bVisible)
{
  int v3; // eax
  int v4; // eax
  gbActor *v5; // ecx
  char *m_szTexture; // esi
  gbActor *v7; // ebx
  gbActor *m_pact; // [esp+0x0] [ebp-0x2C]
  struct gbNodeMsgObj v9; // [esp+0x10] [ebp-0x1C] BYREF
  int v10; // [esp+0x28] [ebp-0x4]
  char *v11; // [esp+0x34] [ebp+0x8]
  char *v12; // [esp+0x38] [ebp+0xC]

  if ( bVisible )
  {
    strcpy((char *)this->m_dwMatMsg, (const char *)bVisible);
    _strlwr((char *)this->m_dwMatMsg);
  }
  m_pact = (gbActor *)this->m_pact;
  v3 = gbCrc32Compute((const char *)this->m_dwMatMsg);
  v4 = this->Actor::ValidateInput(v3, (int)m_pact);
  v5 = (gbActor *)this->m_pact;
  if ( v5 && v4 )
  {
    (((gbActor *)v5))->gbActor::GotoAction((char *)this->m_dwMatMsg, v11, v12);
    while ( (((gbVisNode *)this->m_pact))->gbVisNode::PopMessage(*v9) )
      ;
    m_szTexture = this->m_szTexture;
    if ( this->m_szTexture[0] )
    {
      // [AUTO-COMMENTED] (OpenBaseFile *)&bVisible->OpenBaseFile();
      v7 = (gbActor *)this->m_pact;
      v10 = 0;
      pal3_vtbl_unk_0(v7->pBody, m_szTexture) /* [VFTABLE-STUB] */;
      v10 = -1;
      // [AUTO-COMMENTED] (OpenNULLFile *)&bVisible->OpenNULLFile();
    }
  }
}

static void pal3_vtbl_unk_0(gbActorDef *, char *)
{
    
}


// 0x005372B0
int Actor::GetArrayCount()
{
  Actor *m_actarray_begin; // edx

  m_actarray_begin = (Actor *)this->m_actarray_begin;
  if ( m_actarray_begin )
    return ((char *)this->m_actarray_end - (char *)m_actarray_begin) >> 2;
  else
    return 0;
}

// 0x005372D0
int * Actor::LoadActionSequence(int *p_DWORD, unsigned int dwVal, int *p_DWORD2)
{
  Actor *v5; // edi
  int *result; // eax
  Actor *m_actarray_begin; // edx
  unsigned int v8; // ecx
  int v9; // eax
  int v10; // eax
  int *v11; // ecx
  int *n; // eax
  int *v13; // eax
  unsigned int v14; // edx
  int *v15; // edi
  int *v16; // edx
  int *v17; // eax
  Actor *v18; // ecx
  Actor *v19; // eax
  unsigned int v20; // ebx
  int *v21; // esi
  int *v22; // ecx
  Actor *v23; // eax
  unsigned int k; // ebp
  int *v25; // ecx
  int *m; // eax
  unsigned int v27; // ebp
  Actor *m_actarray_end; // esi
  int *i; // ecx
  Actor *v30; // ecx
  int *j; // eax
  int v32; // esi
  int v34; // [esp+0x14] [ebp-0x4]
  Actor *dwVala; // [esp+0x20] [ebp+0x8]
result = (int *)this->m_actarray_end;
  if ( ((char *)this->m_actarray_capacity_end - (char *)result) >> 2 >= dwVal )
  {
    if ( result - p_DWORD >= dwVal )
    {
      if ( dwVal )
      {
        v27 = 4 * dwVal;
        m_actarray_end = (Actor *)this->m_actarray_end;
        for ( i = &result[-dwVal]; i != result; m_actarray_end = (Actor *)((char *)m_actarray_end + 4) )
        {
          if ( m_actarray_end )
            *(_DWORD *)&m_actarray_end->m_actarray_type = (unsigned long)*i;
          ++i;
        }
        v30 = (Actor *)this->m_actarray_end;
        for ( j = (int *)((char *)v30 - v27); j != p_DWORD; *(_DWORD *)&v30->m_actarray_type = v32 )
        {
          v32 = *--j;
          v30 = (Actor *)((char *)v30 - 4);
        }
        for ( result = p_DWORD; result != &p_DWORD[v27 / 4]; ++result )
          *result = *p_DWORD2;
        this->m_actarray_end = (Actor *)((char *)this->m_actarray_end + v27);
      }
    }
    else
    {
      v20 = 4 * dwVal;
      v21 = (int *)&p_DWORD[dwVal];
      if ( p_DWORD != result )
      {
        v22 = (int *)&v21[v20 / 0xFFFFFFFC];
        do
        {
          if ( v21 )
          {
            *v21 = *v22;
}
          ++v22;
          ++v21;
        }
        while ( v22 != result );
      }
      v23 = (Actor *)this->m_actarray_end;
      for ( k = dwVal - (((char *)v23 - (char *)p_DWORD) >> 2); k; --k )
      {
        if ( v23 )
          *(_DWORD *)&v23->m_actarray_type = (unsigned long)*p_DWORD2;
        v23 = (Actor *)((char *)v23 + 4);
      }
      v25 = (int *)this->m_actarray_end;
      for ( m = p_DWORD; m != v25; ++m )
        *m = *p_DWORD2;
      result = (int *)(&this->m_actarray_end->m_actarray_type + v20);
      this->m_actarray_end = (Actor *)result;
    }
  }
  else
  {
    m_actarray_begin = (Actor *)this->m_actarray_begin;
    if ( !m_actarray_begin || (v8 = ((char *)result - (char *)m_actarray_begin) >> 2, dwVal >= v8) )
      v8 = dwVal;
    if ( m_actarray_begin )
      v9 = ((char *)result - (char *)m_actarray_begin) >> 2;
    else
      v9 = 0;
    v10 = v8 + v9;
    v34 = v10;
    if ( v10 < 0 )
      v10 = 0;
    dwVala = (Actor *)operator new(4 * v10);
    v11 = (int *)dwVala;
    for ( n = (int *)this->m_actarray_begin; n != p_DWORD; ++v11 )
    {
      if ( v11 )
        *v11 = *n;
      ++n;
    }
    v13 = (int *)v11;
    if ( dwVal )
    {
      v14 = dwVal;
      do
      {
        if ( v13 )
        {
          *v13 = *p_DWORD2;
}
        ++v13;
        --v14;
      }
      while ( v14 );
    }
    v15 = (int *)this->m_actarray_end;
    v16 = (int *)&v11[dwVal];
    if ( p_DWORD != v15 )
    {
      v17 = (int *)p_DWORD;
      do
      {
        if ( v16 )
          *v16 = *v17;
        ++v17;
        ++v16;
      }
      while ( v17 != v15 );
    }
    operator delete(this->m_actarray_begin);
    this->m_actarray_capacity_end = (Actor *)((char *)dwVala + 4 * v34);
    v18 = (Actor *)this->m_actarray_begin;
    if ( v18 )
    {
      v19 = (Actor *)this->m_actarray_end;
      this->m_actarray_begin = dwVala;
      result = (int *)((char *)dwVala + 4 * dwVal + 4 * (((char *)v19 - (char *)v18) >> 2));
    }
    else
    {
      this->m_actarray_begin = dwVala;
      result = (int *)((char *)dwVala + 4 * dwVal);
    }
    this->m_actarray_end = (Actor *)result;
  }
  return result;
}

// 0x00537510
int Actor::StoreParam(int nVal, int nVal2)
{
  int result; // eax
  int v4; // ecx
  _DWORD *v5; // [esp+0xC] [ebp+0xC]

  result = nVal2;
  if ( nVal2 )
  {
    v4 = nVal2;
    result = nVal;
    do
    {
      if ( result )
        *(_DWORD *)result = (unsigned long)*v5;
      result += 4;
      --v4;
    }
    while ( v4 );
  }
  return result;
}

// 0x005375B0
int Actor::ClearArrayEntry(int nVal)
{
  int result; // eax

  result = nVal;
  *(_BYTE *)nVal = HIBYTE(nVal);
  *(_DWORD *)(nVal + 4) = 0;
  *(_DWORD *)(nVal + 8) = 0;
  *(_DWORD *)(nVal + 12) = 0;
  *(_BYTE *)(nVal + 16) = HIBYTE(nVal);
  *(_DWORD *)(nVal + 20) = 0;
  *(_DWORD *)(nVal + 24) = 0;
  *(_DWORD *)(nVal + 28) = 0;
  *(_BYTE *)(nVal + 32) = HIBYTE(nVal);
  *(_DWORD *)(nVal + 36) = 0;
  *(_DWORD *)(nVal + 40) = 0;
  *(_DWORD *)(nVal + 44) = 0;
  return result;
}

// 0x005375F0
void Actor::ClearPathBuffer()
{
  Actor *m_actarray_begin; // edi
  Actor *i; // [esp+0x10] [ebp-0x10]

  operator delete(this->m_pAllocBuf);
  this->m_pAllocBuf = 0;
  this->m_fTransitionSpeed = 0.0;
  this->m_fTransitionPos = 0.0;
  operator delete(*(void **)this->m_name);
  *(_DWORD *)this->m_name = 0;
  *(_DWORD *)&this->m_name[4] = 0;
  this->m_fMoveSpeed = 0.0;
  m_actarray_begin = (Actor *)this->m_actarray_begin;
  for ( i = this->m_actarray_end; m_actarray_begin != i; m_actarray_begin = (Actor *)((char *)m_actarray_begin + 164) )
  {
    nullsub_2(m_actarray_begin->m_nAnimBuffer, m_actarray_begin->m_nParticleBuffer);
    operator delete((void *)m_actarray_begin->m_nAnimBuffer);
    m_actarray_begin->m_nAnimBuffer = 0;
    m_actarray_begin->m_nParticleBuffer = 0;
    m_actarray_begin->m_vecTargetPos.x = 0.0;
    (((Array *)&m_actarray_begin->m_nAnimParam1))->Array::Free();
  }
  operator delete(this->m_actarray_begin);
  this->m_actarray_begin = 0;
  this->m_actarray_end = 0;
  this->m_actarray_capacity_end = 0;
}

// 0x005376E0
int Actor::LoadSaveData(char *pszSlotIdx)
{
  int result; // eax
  FILE *v3; // ebx
  _BYTE v4[72]; // [esp+0x4] [ebp-0x1E0] BYREF
  char v5[80]; // [esp+0x4C] [ebp-0x198] BYREF
  char Buffer[260]; // [esp+E0h] [ebp-0x104] BYREF
  char *v7; // [esp+0x1EC] [ebp+0x8]

  sprintf(Buffer, "save\\pal%02d.arc", pszSlotIdx);
  result = (int)fopen(Buffer, "rb");
  v3 = (FILE *)result;
  if ( result )
  {
    fread(v4, 0xDCu, 1u, (FILE *)result);
    qmemcpy(v7, v5, 0x50u);
    fclose(v3);
    return 1;
  }
  return result;
}

// 0x00537770
int Actor::LoadActions(FILE *Stream, int *pnVal)
{
  int v4; // ebx
  char **v5; // ebx
  char *v6; // eax
  Actor *m_actarray_begin; // ebx
  int v8; // edx
  Actor *p_m_pact; // ebx
  int result; // eax
  int v11; // esi
  char **v12; // [esp-0x1C] [ebp-0x130]
  Actor *m_actarray_end; // [esp-0xC] [ebp-0x120]
  FILE *v14; // [esp+0x0] [ebp-0x114]
  int v15; // [esp+0x10] [ebp-0x104]
  int v16; // [esp+0x10] [ebp-0x104]
  int v17; // [esp+0x10] [ebp-0x104]
  char pActionType; // [esp+0x17] [ebp-FDh] BYREF
  int v19; // [esp+0x18] [ebp-FCh] BYREF
  char *a4; // [esp+0x1C] [ebp-F8h] BYREF
  int Buffer; // [esp+0x20] [ebp-F4h] BYREF
  char nY[132]; // [esp+0x24] [ebp-F0h] BYREF
  Array v23; // [esp+A8h] [ebp-0x6C] BYREF
  char v24; // [esp+B8h] [ebp-0x5C] BYREF
  void *Block; // [esp+BCh] [ebp-0x58]
  int v26; // [esp+C0h] [ebp-0x54]
  int v27; // [esp+C4h] [ebp-0x50]
  _BYTE pData[64]; // [esp+C8h] [ebp-0x4C] BYREF
  int v29; // [esp+0x110] [ebp-0x4]

  fseek(Stream, pnVal[40], 0);
  fread(&Buffer, 4u, 1u, Stream);
  v4 = 0;
  if ( Buffer > 0 )
  {
    v15 = 0;
    do
    {
      fread((void *)(((GRPinput *)&stru_D8C2B8)->KeyInfo[148].Data + v15), 0x18u, 1u, Stream);
      ++v4;
      v15 += 24;
    }
    while ( v4 < Buffer );
  }
  fseek(Stream, pnVal[41], 0);
  a4 = 0;
  fread(&a4, 4u, 1u, Stream);
  v5 = ActVecUninitCopy(
         (int)this->m_actarray_end,
         (unsigned int *)this->m_actarray_end,
         (unsigned int *)this->m_actarray_begin,
         v12);
  this->Actor::DestroyActionRange((int)v5, (int)this->m_actarray_end);
  v6 = (char *)a4;
  this->m_actarray_end = (Actor *)v5;
  v16 = 0;
  if ( (int)v6 > 0 )
  {
    do
    {
      memset(&v23.m_nSize, 0, 12);
      LOBYTE(v23.m_pDataStart) = pActionType;
      v29 = 0;
      (((Actor *)&v24))->Actor::InitAction(&pActionType);
      m_actarray_end = (Actor *)this->m_actarray_end;
      v29 = 1;
      this->Actor::ActVec_InsertN(&m_actarray_end->m_actarray_type, 1u, nY);
      m_actarray_begin = (Actor *)this->m_actarray_begin;
      if ( m_actarray_begin )
        v8 = ((char *)this->m_actarray_end - (char *)m_actarray_begin) / 164;
      else
        v8 = 0;
      (((UIBigMap *)((char *)m_actarray_begin + 164 * v8 - 164)))->UIBigMap::SetElementVisible(Stream, v14);
      v29 = 2;
      nullsub_2(Block, v26);
      operator delete(Block);
      Block = 0;
      v26 = 0;
      v27 = 0;
      v29 = -1;
      (((Array *)&v23))->Array::Free();
      ++v16;
    }
    while ( v16 < (int)a4 );
  }
  fseek(Stream, pnVal[46], 0);
  v19 = 0;
  fread(&v19, 4u, 1u, Stream);
  p_m_pact = (Actor *)&this->m_pact;
  v17 = *(_DWORD *)this->m_name;
  nullsub_2(v17, *(_DWORD *)&this->m_name[4]);
  result = v19;
  *(_DWORD *)&this->m_name[4] = v17;
  v11 = 0;
  if ( result > 0 )
  {
    do
    {
      memset(pData, 0, sizeof(pData));
      fread(pData, 0x40u, 1u, Stream);
      (((Actor *)p_m_pact))->Actor::ActVec_InsertRange(&p_m_pact->m_actarray_end->m_actarray_type, 1u, pData, (unsigned int)v14);
      result = v19;
      ++v11;
    }
    while ( v11 < v19 );
  }
  return result;
}

// 0x00537A30
void Actor::ClearAllocBuffers()
{
  operator delete((void *)this->m_nAnimBuffer);
  this->m_nAnimBuffer = 0;
  this->m_nParticleBuffer = 0;
  this->m_vecTargetPos.x = 0.0;
  operator delete((void *)LODWORD(this->m_vecBonePos.x));
  this->m_vecBonePos.x = 0.0;
  this->m_vecBonePos.y = 0.0;
  this->m_vecBonePos.z = 0.0;
}

// 0x00537A90
FILE * Actor::DoSceneTransition(double pData, int nVal)
{
  char v3; // di
  char v4; // si
  FILE *result; // eax
  FILE *v6; // ebp
  Actor **p_pTargetActor; // esi
  int v8; // edi
  _BYTE *v9; // edx
  int v10; // esi
  void *v11; // edi
  int v12; // ecx
  unsigned __int8 **v13; // eax
  unsigned __int8 *v14; // edx
  int v15; // esi
  SceneObj *p_m_nScreenFlags; // ebx
  Actor *v17; // esi
  gbImage2D *m_needscriptdel; // ecx
  CScreenMode *Instance; // eax
  gbVec3D *p_m_lastFrom; // ebx
  float m_fCtrlYaw; // edi
  float m_yaw; // ecx
  float y; // eax
  float *p_m_fCachePosY; // esi
  tagActionCommand *p_pCmd; // edi
  scAsmDecoder *v26; // ecx
  PAL3 *v27; // ecx
  RenderTarget3 *v28; // eax
  PAL3 *v29; // ecx
  ScreenEffectMgr *Instance_fd20; // eax
  CScreenMode *v31; // eax
  gbAudioManager *AudioManager; // eax
  int *v33; // edi
  int v34; // esi
  int *v35; // ebx
  RoleSystem *RoleDataOffset; // eax
  int v37; // esi
  int v38; // eax
  Actor *v39; // edi
  double v40; // [esp-0x10] [ebp-0x280B0]
  char v41; // [esp+0x0] [ebp-0x280A0]
  int v42; // [esp+0x0] [ebp-0x280A0]
  char v43; // [esp+0x4] [ebp-0x2809C]
  Actor *v44; // [esp+0x10] [ebp-0x28090] BYREF
  float v45; // [esp+0x14] [ebp-0x2808C] BYREF
  float v46; // [esp+0x18] [ebp-0x28088]
  float v47; // [esp+0x1C] [ebp-0x28084]
  tagActionCommand v48; // [esp+0x20] [ebp-0x28080] BYREF
  double sceneNames[4]; // [esp+0x3C] [ebp-0x28064] BYREF
  char v50; // [esp+0x5C] [ebp-0x28044] BYREF
  _DWORD pSrc[7]; // [esp+C0h] [ebp-0x27FE0] BYREF
  tagActionCommand pCmd; // [esp+DCh] [ebp-0x27FC4] BYREF
  unsigned __int8 v53; // [esp+0x168] [ebp-0x27F38]
  char String2[35]; // [esp+0x169] [ebp-0x27F37] BYREF
  int v55; // [esp+0x18C] [ebp-0x27F14]
  float v56; // [esp+0x190] [ebp-0x27F10]
  int v57; // [esp+0x194] [ebp-0x27F0C]
  int v58; // [esp+0x198] [ebp-0x27F08]
  int v59; // [esp+0x19C] [ebp-0x27F04]
  unsigned int v60; // [esp+0x1A0] [ebp-0x27F00]
  int v61; // [esp+0x1A4] [ebp-0x27EFC]
  int v62; // [esp+0x1A8] [ebp-0x27EF8]
  char v63; // [esp+0x1AC] [ebp-0x27EF4]
  int v64; // [esp+0x1B0] [ebp-0x27EF0]
  char v65; // [esp+0x1B4] [ebp-0x27EEC]
  unsigned __int8 v66; // [esp+0x1B5] [ebp-0x27EEB]
  char v67[20]; // [esp+0x1B6] [ebp-0x27EEA] BYREF
  int v68; // [esp+0x1CA] [ebp-0x27ED6]
  int pnVal[44]; // [esp+0x20C] [ebp-0x27E94] BYREF
  char v70; // [esp+0x2BC] [ebp-0x27DE4] BYREF
  int v71; // [esp+0x2C8] [ebp-0x27DD8]
  char Buffer[260]; // [esp+0x2E8] [ebp-0x27DB8] BYREF
  int v73; // [esp+0x3EC] [ebp-0x27CB4] BYREF
  int v74; // [esp+0x3F0] [ebp-0x27CB0]
  _DWORD v75[3]; // [esp+0x3F4] [ebp-0x27CAC]
  __int16 v76; // [esp+0x400] [ebp-0x27CA0]
  int v77; // [esp+0x402] [ebp-0x27C9E]
  char v78; // [esp+0x406] [ebp-0x27C9A]
  int v79; // [esp+0x408] [ebp-0x27C98]
  unsigned __int8 v80; // [esp+0x40C] [ebp-0x27C94]
  _BYTE v81[41]; // [esp+0x40D] [ebp-0x27C93] BYREF
  __int16 v82; // [esp+0x436] [ebp-0x27C6A]
  int v83; // [esp+0x438] [ebp-0x27C68]
  int v84; // [esp+0x43C] [ebp-0x27C64]
  int v85; // [esp+0x440] [ebp-0x27C60]
  _BYTE v86[40]; // [esp+0x444] [ebp-0x27C5C]
  int v87; // [esp+0x46C] [ebp-0x27C34]
  _BYTE v88[160]; // [esp+0x470] [ebp-0x27C30] BYREF
  int v89; // [esp+0x510] [ebp-0x27B90]
  _DWORD v90[40466]; // [esp+0x514] [ebp-0x27B8C] BYREF
  char v91; // [esp+0x27D5C] [ebp-0x344]
  int v92; // [esp+0x27D60] [ebp-0x340]
  _BYTE v93[828]; // [esp+0x27D64] [ebp-0x33C] BYREF
sub_407790();
  sprintf(Buffer, "save\\pal%02d.arc", LODWORD(pData));
  result = fopen(Buffer, "rb");
  v6 = (FILE *)result;
  if ( result )
  {
    v43 = v4;
    v41 = v3;
    fread(pnVal, 0xDCu, 1u, result);
    memset(&pSrc[4], 0, 12);
    p_pTargetActor = (Actor **)&pCmd.pTargetActor;
    v8 = 5;
    do
    {
      p_pTargetActor += 7;
      --v8;
    }
    while ( v8 );
    v57 = 0;
    v58 = 0;
    v59 = 0;
    fseek(v6, pnVal[38], 0);
    fread(sceneNames, 0x1D0u, 1u, v6);
    fseek(v6, pnVal[39], 0);
    LoadGameState(v6);
    (((Actor *)v44))->Actor::LoadActions(v6, pnVal);
    fseek(v6, pnVal[42], 0);
    v45 = 1.0;
    v46 = 1.0;
    v47 = 1.0;
    fread(&v45, 0xCu, 1u, v6);
    fseek(v6, pnVal[43], 0);
    v73 = 0;
    v74 = 0;
    memset(v90, 0, 12);
    v75[0] = 1;
    (((Actor *)&v90[3]))->Actor::InitAnimSequence();
    ArraySort((int)&v90[58], 808, 200, (int)sub_538260);
    v90[40465] = 0;
    v90[40462] = 1;
    v90[40463] = 1;
    v90[40464] = 1;
    v9 = v93;
    v10 = 11;
    do
    {
      v11 = (void *)v9;
      v9 += 52;
      --v10;
      memset(v11, 0, 0x2Cu);
    }
    while ( v10 );
    fread(&v73, 0x27CB4u, 1u, v6);
    g_ScriptSystemData.m_nScriptFlag = v75[0];
    g_ScriptSystemData.m_nScriptCounter1 = v74;
    g_nRoleParam = v75[1];
    LOBYTE(g_nActor_DE5F9C) = v78;
    dword_C10CC4 = v79;
    g_ScriptSystemData.m_nScriptCounter0 = v73;
    LOWORD(g_nActor_DE5FA8) = v76;
    g_nActorState = v77;
    LOBYTE(g_dwUISettings) = v81[40];
    g_nRoleState = v75[2];
    qmemcpy(g_SaveSlotFlags, v81, sizeof(g_SaveSlotFlags));
    g_bUIWnd_DE625A = v80;
    *(_WORD *)((char *)&g_dwUISettings + 1) = v82;
    g_nUpdateInterval = v85;
    g_bRoleFlag1 = v83 == 1;
    g_bRoleFlag2 = v84 == 1;
    v12 = 0;
    v13 = (unsigned __int8 **)&g_pSceneTransitionBegin;
    do
    {
      ++v13;
      v14 = (unsigned __int8 *)(unsigned __int8)v86[v12++];
      *(v13 - 1) = v14;
    }
    while ( (int)v13 < (int)&g_pSceneTransitionEnd );
    qmemcpy(g_fCamRoleParams, v88, sizeof(g_fCamRoleParams));
    g_nFiveNimbusCount = v89;
    qmemcpy(&g_SceneTransitionBuffer, v90, 0x27848u);
    g_nWolfIndex = v87;
    LOBYTE(byte_D92785) = v91;
    dword_C10CD4 = v92;
    qmemcpy(g_pCBSystem->m_Player, v93, sizeof(g_pCBSystem->m_Player));
    g_fGameTimer = *(float *)&pnVal[18];
    CScreenMode::GetInstance()->m_bRenderAlt = v65;
    v15 = v66;
    CScreenMode::GetInstance()->m_nFadeState = v15;
    p_m_nScreenFlags = (SceneObj *)&CScreenMode::GetInstance()->m_nScreenFlags;
    v17 = (Actor *)strlen(v67);
    v44 = (Actor *)v17;
    if ( (((SceneObj *)p_m_nScreenFlags))->SceneObj::UpdateAutoDelete((unsigned int)v17) )
    {
      qmemcpy(p_m_nScreenFlags->m_needscriptdel, v67, (unsigned int)v17);
      m_needscriptdel = (gbImage2D *)p_m_nScreenFlags->m_needscriptdel;
      p_m_nScreenFlags->GlowObj::__vftable = v17;
      *(&v17->m_actarray_type + (_DWORD)m_needscriptdel) = 0;
    }
    if ( CScreenMode::GetInstance()->m_bRenderAlt )
    {
      Instance = (CScreenMode *)CScreenMode::GetInstance();
      (((CScreenMode *)Instance))->CScreenMode::AudioFadeOut();
    }
    HIDWORD(v40) = (unsigned long)&v50;
    LODWORD(v40) = sceneNames;
    LoadScene(v40, (char *)1, 0, v41, v43);
    p_m_lastFrom = (gbVec3D *)&g_pCameraCtrl->m_lastFrom;
    if ( !LODWORD(g_pCameraCtrl->m_nextYAW)
      || (m_fCtrlYaw = g_pCameraCtrl->m_fCtrlYaw, m_yaw = g_pCameraCtrl->m_yaw, LODWORD(m_fCtrlYaw) == LODWORD(m_yaw)) )
    {
      (((CameraCtrl *)&g_pCameraCtrl->m_lastFrom))->CameraCtrl::UpdateFOVLerp();
      y = p_m_lastFrom[2].y;
      LODWORD(p_m_lastFrom[2].y) = LODWORD(y) + 28;
      (((Actor *)LODWORD(y)))->Actor::CopyConstruct_1C(pSrc);
    }
    else
    {
      LODWORD(g_pCameraCtrl->m_fCtrlYaw) = LODWORD(m_fCtrlYaw) + 28;
      if ( LODWORD(m_fCtrlYaw) + 28 == LODWORD(m_yaw) )
      {
        (((Actor *)LODWORD(m_fCtrlYaw)))->Actor::CopyConstruct_1C(pSrc);
        (((CameraCtrl *)p_m_lastFrom))->CameraCtrl::UpdateFOVLerp();
      }
      else if ( m_fCtrlYaw != 0.0 )
      {
        qmemcpy((void *)LODWORD(m_fCtrlYaw), pSrc, 0x1Cu);
      }
    }
    ++LODWORD(p_m_lastFrom[3].z);
    RoleCamera_PushState(v42);
    p_m_fCachePosY = (float *)&((RoleSystem *)&stru_C059A0)->m_fCachePosY;
    p_pCmd = (tagActionCommand *)&pCmd;
    do
    {
      (((Actor *)p_m_fCachePosY))->Actor::ExecuteAction(p_pCmd);
      p_m_fCachePosY += 2176;
      ++p_pCmd;
    }
    while ( (int)p_m_fCachePosY < (int)&unk_C10960 );
    if ( _strcmpi(&((RoleSystem *)&stru_C0A360)->m_nAnimState, String2) )
    {
      (((Actor *)&((RoleSystem *)&stru_C0A360)->m_partyActor.m_Actor))->Actor::sub_536D20(String2, 0);
      strcpy(&((RoleSystem *)&stru_C0A360)->m_nAnimState, String2);
      ((RoleSystem *)&stru_C0A360)->RoleSystem::UpdateTransform();
    }
    (((scAsmDecoder *)v26))->scAsmDecoder::Execute(v53, 0);
    g_nScriptEventParam = v55;
    g_fScriptEventParam2 = v56;
    g_nScriptRolePosX = v57;
    g_nScriptRolePosY = v58;
    v27 = (PAL3 *)v61;
    g_nScriptRolePosZ = v59;
    g_nCurrentEventId = v60;
    g_nActor_BFDBA8 = v61;
    LOBYTE(v27) = v63;
    g_nActor_BFDBAC = v62;
    g_SceneMgr.m_fFadeTimer = v64;
    g_SceneMgr.m_nSceneTransitionParam2 = v63;
    v28 = (((PAL3 *)v27))->PAL3::GetInstance();
    LOBYTE((*(void **)(v28))) = v67[16];
    Instance_fd20 = (((PAL3 *)v29))->PAL3::GetInstance_fd20();
    LOBYTE(Instance_fd20->m_pVtable) = v67[17];
    LOBYTE(byte_BFDA40) = v67[19];
    LOBYTE(byte_BFDA41) = v67[18];
    (((PalScript *)(unsigned __int8)v68))->PalScript::InitParticleSlht((PalScript *)(unsigned __int8)v68);
    v31 = (CScreenMode *)CScreenMode::GetInstance();
    AudioManager = (gbAudioManager *)(((CScreenMode *)v31))->CScreenMode::GetAudioManager();
    if ( AudioManager )
    {
      AudioManager->S_2DMasterVol = v45;
      AudioManager->S_3DMasterVol = v46;
      (((gbAudioManager *)AudioManager))->gbAudioManager::SetMusicMasterVolume(v47);
    }
    v33 = (int *)(UISceneUpdate() + 492772);
    v34 = 0;
    if ( *v33 > 0 )
    {
      v35 = (int *)&v70;
      do
      {
        if ( *v35 )
        {
          fseek(v6, *v35, 0);
          RoleDataOffset = (RoleSystem *)GetRoleDataOffset(v34);
          (((RoleSystem *)RoleDataOffset))->RoleSystem::ClearPathData(v6);
        }
        ++v34;
        ++v35;
      }
      while ( v34 < *v33 );
    }
    v37 = 0;
    if ( v71 )
    {
      fseek(v6, v71, 0);
      v44 = 0;
      fread(&v44, 4u, 1u, v6);
      v38 = UISceneUpdate();
      memset(&v48.pTargetActor, 0, 12);
      if ( (int)v44 > 0 )
      {
        v39 = (Actor *)(v38 + 57572);
        do
        {
          fread(&v48, 0x1Cu, 1u, v6);
          (((Actor *)v39))->Actor::ExecuteAction(&v48);
          ++v37;
          v39 = (Actor *)((char *)v39 + 8704);
        }
        while ( v37 < (int)v44 );
      }
    }
    fclose(v6);
    return (FILE *)1;
  }
  return result;
}

// 0x005381D0
char * Actor::InitAnimSequence()
{
  char *v1; // esi
  int v2; // ebx
  float *p_m_fRoleParam2; // eax
  float *v4; // ebp
  float *v5; // ebp
  float *v6; // ebp

  v1 = (char *)&this->m_name[4];
  v2 = 4;
  p_m_fRoleParam2 = (float *)&this->m_fRoleParam2;
  do
  {
    v4 = (float *)(p_m_fRoleParam2 - 6);
    *(_DWORD *)v1 = 0;
    *(p_m_fRoleParam2 - 8) = 0.0;
    *(p_m_fRoleParam2 - 7) = 0.0;
    *v4 = 0.0;
    v1 += 48;
    v4[1] = 0.0;
    v4[2] = 0.0;
    v5 = (float *)(p_m_fRoleParam2 - 3);
    *(p_m_fRoleParam2 - 3) = 0.0;
    v5[1] = 0.0;
    v5[2] = 0.0;
    v6 = (float *)p_m_fRoleParam2;
    p_m_fRoleParam2 += 12;
    --v2;
    *v6 = 0.0;
    v6[1] = 0.0;
    v6[2] = 0.0;
  }
  while ( v2 );
  this->m_actarray_type = 0;
  *(&this->m_actarray_type + 1) = 0;
  *(&this->m_actarray_type + 2) = 0;
  *(&this->m_actarray_type + 3) = 0;
  LOBYTE(this->m_actarray_begin) = 0;
  BYTE1(this->m_actarray_begin) = 0;
  BYTE2(this->m_actarray_begin) = 0;
  this->m_actarray_capacity_end = 0;
  this->m_pact = 0;
  *(_DWORD *)this->m_name = 0;
  *(_DWORD *)&this->m_fScale = 0;
  this->m_actarray_end = (Actor *)1065353216;
  memset(&this->m_name[4], 0, 0xC0u);
  return &this->m_actarray_type;
}

// 0x00538320
BOOL Actor::EnsureDirectory()
{
  return CheckDirectoryExists(PathName) || CreateDirectoryA(PathName, 0);
}

// 0x00538500
BOOL Actor::LoadActorModel(int nVal)
{
  int v2; // edi
  _EXCEPTION_REGISTRATION_RECORD *ExceptionList; // eax
  void *v4; // esp
  BOOL result; // eax
  int v6; // ebx
  FILE *v7; // ebp
  _DWORD *v8; // eax
  int v9; // ecx
  float *p_m_fCachePosY; // esi
  float *v11; // edi
  float v12; // edx
  gbVec3D *p_m_lastFrom; // esi
  float z; // eax
  float v15; // eax
  const char *m_nField0C; // eax
  PAL3 *v17; // ecx
  PAL3 *v18; // ecx
  int v19; // eax
  CHAR *v20; // esi
  int v21; // edi
  _BYTE *v22; // edx
  int v23; // esi
  void *v24; // edi
  int v25; // ecx
  unsigned __int8 **v26; // eax
  char v27; // dl
  int v28; // esi
  int *v29; // edi
  RoleSystem *RoleDataOffset; // eax
  int v31; // esi
  RoleSystem *v32; // edi
  int v33; // [esp-0x10] [ebp-0x282C0]
  int v34; // [esp+0x0] [ebp-0x282B0] BYREF
  Actor *v35; // [esp+0x4] [ebp-0x282AC]
  _DWORD Buffer[2]; // [esp+0x8] [ebp-0x282A8] BYREF
  float Buffer_8; // [esp+0x10] [ebp-0x282A0]
  int Buffer_12; // [esp+0x14] [ebp-0x2829C]
  float Buffer_16[7]; // [esp+0x18] [ebp-0x28298] BYREF
  _DWORD Buffer_44[116]; // [esp+0x34] [ebp-0x2827C] BYREF
  int Buffer_508[55]; // [esp+0x204] [ebp-0x280AC] BYREF
  TxtFile Buffer_728; // [esp+0x2E0] [ebp-0x27FD0] BYREF
  char Buffer_1252[260]; // [esp+0x4EC] [ebp-0x27DC4] BYREF
  int Buffer_1512; // [esp+0x5F0] [ebp-0x27CC0] BYREF
  int Buffer_1516; // [esp+0x5F4] [ebp-0x27CBC]
  int Buffer_1520; // [esp+0x5F8] [ebp-0x27CB8]
  int Buffer_1524; // [esp+0x5FC] [ebp-0x27CB4]
  int Buffer_1528; // [esp+0x600] [ebp-0x27CB0]
  __int16 Buffer_1532; // [esp+0x604] [ebp-0x27CAC]
  int Buffer_1534; // [esp+0x606] [ebp-0x27CAA]
  char Buffer_1538; // [esp+0x60A] [ebp-0x27CA6]
  int Buffer_1540; // [esp+0x60C] [ebp-0x27CA4]
  unsigned __int8 Buffer_1544; // [esp+0x610] [ebp-0x27CA0]
  _BYTE Buffer_1545[41]; // [esp+0x611] [ebp-0x27C9F] BYREF
  __int16 Buffer_1586; // [esp+0x63A] [ebp-0x27C76]
  int Buffer_1588; // [esp+0x63C] [ebp-0x27C74]
  int Buffer_1592; // [esp+0x640] [ebp-0x27C70]
  int Buffer_1596; // [esp+0x644] [ebp-0x27C6C]
  _BYTE Buffer_1600[40]; // [esp+0x648] [ebp-0x27C68]
  int Buffer_1640; // [esp+0x670] [ebp-0x27C40]
  _BYTE Buffer_1644[160]; // [esp+0x674] [ebp-0x27C3C] BYREF
  int Buffer_1804; // [esp+0x714] [ebp-0x27B9C]
  _DWORD Buffer_1808[40466]; // [esp+0x718] [ebp-0x27B98] BYREF
  char v64; // [esp+0x27F60] [ebp-0x350]
  int v65; // [esp+0x27F64] [ebp-0x34C]
  _BYTE v66[828]; // [esp+0x27F68] [ebp-0x348] BYREF
  _EXCEPTION_REGISTRATION_RECORD *v67; // [esp+0x282A4] [ebp-0xC]
  void *v68; // [esp+0x282A8] [ebp-0x8]
  int v69; // [esp+0x282AC] [ebp-0x4]

  v69 = -1;
  ExceptionList = NtCurrentTeb()->NtTib.ExceptionList;
  v68 = ((void*)0);
  v67 = (_EXCEPTION_REGISTRATION_RECORD *)ExceptionList;
  v4 = alloca(164516);
result = this->Actor::EnsureDirectory();
  if ( result )
  {
    v6 = UISceneUpdate();
    memset(Buffer_508, 0, sizeof(Buffer_508));
    *(float *)&Buffer_508[18] = g_fGameTimer;
    Buffer_508[19] = ((RoleSystem *)&stru_C059A0)->m_nRetryCount;
    LOBYTE(Buffer_508[20]) = LOBYTE(((RoleSystem *)&stru_C059A0)->m_fCachePosX);
    Buffer_508[37] = ((RoleSystem *)&stru_C059A0)->m_nMoveRole;
    v69 = 0;
    (((PalScript *)&Buffer_728))->PalScript::LoadFromFile("datascript\\SceneName.txt");
    (((PalScript *)&Buffer_728))->PalScript::SetDirectory((char *)v6);
    if ( !(((PalScript *)&Buffer_728))->PalScript::FindSaveStateString((PalScript *)(v6 + 32), (char *)&Buffer_508[20] + 1, (char *)0x40, v2) )
      (((PalScript *)&Buffer_728))->PalScript::FindSaveStateString((PalScript *)&dir[12], (char *)&Buffer_508[20] + 1, (char *)0x40, v33);
    sprintf(Buffer_1252, "save\\pal%02d.arc", nVal);
    v7 = fopen(Buffer_1252, Mode);
    if ( v7 )
    {
      memset(&Buffer_44[37], 0, 12);
      v8 = (_DWORD *)&Buffer_44[43];
      v9 = 5;
      do
      {
        *(v8 - 2) = 0;
        *(v8 - 1) = 0;
        *v8 = 0;
        v8 += 7;
        --v9;
      }
      while ( v9 );
      memset(Buffer_44, 0, sizeof(Buffer_44));
      qmemcpy(Buffer_44, (const void *)v6, 0x84u);
      p_m_fCachePosY = (float *)&((RoleSystem *)&stru_C059A0)->m_fCachePosY;
      v11 = (float *)&Buffer_44[40];
      do
      {
        (((RoleSystem *)p_m_fCachePosY))->RoleSystem::ExportRoleData(v11);
        p_m_fCachePosY += 2176;
        v11 += 7;
      }
      while ( (int)p_m_fCachePosY < (int)&unk_C10960 );
      LOBYTE(Buffer_44[75]) = (_BYTE)g_SceneMgr.m_nCurrentRoleSlot;
      v12 = g_fScriptEventParam2;
      strcpy((char *)&Buffer_44[75] + 1, &((RoleSystem *)&stru_C0A360)->m_nAnimState);
      *(float *)&Buffer_44[85] = v12;
      Buffer_44[84] = g_nScriptEventParam;
      Buffer_44[86] = g_nScriptRolePosX;
      Buffer_44[87] = g_nScriptRolePosY;
      Buffer_44[88] = g_nScriptRolePosZ;
      Buffer_44[90] = g_nActor_BFDBA8;
      Buffer_44[89] = g_nCurrentEventId;
      LOBYTE(Buffer_44[92]) = g_SceneMgr.m_nSceneTransitionParam2;
      Buffer_44[91] = g_nActor_BFDBAC;
      Buffer_44[93] = g_SceneMgr.m_fFadeTimer;
      (((RoleSystem *)g_pCameraCtrl))->RoleSystem::AddCameraKeyframe();
      Buffer[0] = LODWORD(g_pCameraCtrl->m_fromVec.z);
      Buffer[1] = LODWORD(g_pCameraCtrl->m_yaw);
      Buffer_8 = g_pCameraCtrl->m_fCtrlYaw;
      Buffer_12 = g_pCameraCtrl->m_dist;
      (((CameraCtrl *)Buffer))->CameraCtrl::SetupCameraArray(-1);
      Buffer_44[33] = *(_DWORD *)LODWORD(Buffer_8);
      Buffer_44[34] = *(_DWORD *)(LODWORD(Buffer_8) + 4);
      Buffer_44[35] = *(_DWORD *)(LODWORD(Buffer_8) + 8);
      Buffer_44[36] = *(_DWORD *)(LODWORD(Buffer_8) + 12);
      Buffer_44[37] = *(_DWORD *)(LODWORD(Buffer_8) + 16);
      Buffer_44[38] = *(_DWORD *)(LODWORD(Buffer_8) + 20);
      Buffer_44[39] = *(_DWORD *)(LODWORD(Buffer_8) + 24);
      p_m_lastFrom = (gbVec3D *)&g_pCameraCtrl->m_lastFrom;
      if ( LODWORD(g_pCameraCtrl->m_fCtrlYaw) == LODWORD(g_pCameraCtrl->m_fromVec.z) )
        (((CameraCtrl *)&g_pCameraCtrl->m_lastFrom))->CameraCtrl::PopState();
      z = p_m_lastFrom[3].z;
      if ( z != 0.0 )
        LODWORD(p_m_lastFrom[2].y) -= 28;
      LODWORD(v15) = LODWORD(z) - 1;
      p_m_lastFrom[3].z = v15;
      if ( v15 == 0.0 )
        (((CameraCtrl *)p_m_lastFrom))->CameraCtrl::PopState();
      LOBYTE(Buffer_44[94]) = (unsigned long)CScreenMode::GetInstance()->m_bRenderAlt;
      BYTE1(Buffer_44[94]) = (unsigned long)CScreenMode::GetInstance()->m_nFadeState;
      m_nField0C = (const char *)CScreenMode::GetInstance()->m_nField0C;
      if ( !m_nField0C )
        m_nField0C = (const char *)&g_bActorFlag;
      strncpy((char *)&Buffer_44[94] + 2, m_nField0C, 0x10u);
      BYTE2(Buffer_44[98]) = (*(void **)((((PAL3 *)v17))->PAL3::GetInstance()));
      HIBYTE(Buffer_44[98]) = (unsigned long)(((PAL3 *)v18))->PAL3::GetInstance_fd20()->m_pVtable;
      BYTE1(Buffer_44[99]) = (unsigned long)byte_BFDA40;
      LOBYTE(Buffer_44[99]) = (unsigned long)byte_BFDA41;
      BYTE2(Buffer_44[99]) = g_SceneMgr.m_pCurrentScript != 0;
      (((Actor *)v35))->Actor::BuildCollisionMesh((int *)v6);
      fwrite(Buffer_508, 0xDCu, 1u, v7);
      Buffer_508[38] = ftell(v7);
      fwrite(Buffer_44, 0x1D0u, 1u, v7);
      Buffer_508[39] = ftell(v7);
      SaveGameState(v7);
      (((CScreenMode *)v35))->CScreenMode::LoadAudioFromFile(v7, Buffer_508);
      v19 = ftell(v7);
      Buffer_1512 = 0;
      Buffer_1516 = 0;
      Buffer_1520 = 1;
      Buffer_508[43] = v19;
      memset(Buffer_1808, 0, 12);
      ArraySort((int)&Buffer_1808[9], 48, 4, 0 /* TODO: (int)CCBStage::ClearRoleState */);
      (((Actor *)&Buffer_1808[3]))->Actor::ClearActionFlags();
      v20 = (CHAR *)&Buffer_1808[58];
      v21 = 200;
      do
      {
        sub_538260(v20);
        v20 += 808;
        --v21;
      }
      while ( v21 );
      Buffer_1808[40465] = 0;
      Buffer_1808[40462] = 1;
      Buffer_1808[40463] = 1;
      Buffer_1808[40464] = 1;
      v22 = v66;
      v23 = 11;
      do
      {
        v24 = (void *)v22;
        v22 += 52;
        --v23;
        memset(v24, 0, 0x2Cu);
      }
      while ( v23 );
      Buffer_1512 = g_ScriptSystemData.m_nScriptCounter0;
      Buffer_1516 = g_ScriptSystemData.m_nScriptCounter1;
      Buffer_1520 = g_ScriptSystemData.m_nScriptFlag;
      Buffer_1534 = g_nActorState;
      Buffer_1538 = g_nActor_DE5F9C;
      Buffer_1524 = g_nRoleParam;
      Buffer_1528 = g_nRoleState;
      Buffer_1532 = g_nActor_DE5FA8;
      Buffer_1540 = dword_C10CC4;
      Buffer_1596 = g_nUpdateInterval;
      qmemcpy(Buffer_1545, g_SaveSlotFlags, 0x28u);
      Buffer_1586 = *(_WORD *)((char *)&g_dwUISettings + 1);
      Buffer_1545[40] = g_dwUISettings;
      Buffer_1544 = g_bUIWnd_DE625A;
      Buffer_1592 = g_bRoleFlag2;
      Buffer_1588 = g_bRoleFlag1;
      v25 = 0;
      v26 = (unsigned __int8 **)&g_pSceneTransitionBegin;
      do
      {
        v27 = *(_BYTE *)v26++;
        Buffer_1600[v25++] = v27;
      }
      while ( (int)v26 < (int)&g_pSceneTransitionEnd );
      Buffer_1640 = g_nWolfIndex;
      qmemcpy(Buffer_1644, g_fCamRoleParams, sizeof(Buffer_1644));
      Buffer_1804 = g_nFiveNimbusCount;
      qmemcpy(Buffer_1808, &g_SceneTransitionBuffer, sizeof(Buffer_1808));
      v64 = byte_D92785;
      v65 = dword_C10CD4;
      qmemcpy(v66, g_pCBSystem->m_Player, 0x23Cu);
      fwrite(&Buffer_1512, 0x27CB4u, 1u, v7);
      if ( *(_DWORD *)(v6 + 96) == 2 )
      {
        v28 = 0;
        if ( *(int *)(v6 + 492772) > 0 )
        {
          v29 = (int *)&Buffer_508[44];
          do
          {
            *v29 = ftell(v7);
            RoleDataOffset = (RoleSystem *)GetRoleDataOffset(v28);
            (((RoleSystem *)RoleDataOffset))->RoleSystem::GetFontColor(v7);
            ++v28;
            ++v29;
          }
          while ( v28 < *(_DWORD *)(v6 + 492772) );
        }
      }
      Buffer_508[47] = ftell(v7);
      v34 = *(_DWORD *)(v6 + 57568);
      fwrite(&v34, 4u, 1u, v7);
      v31 = 0;
      memset(&Buffer_16[1], 0, 12);
      if ( v34 > 0 )
      {
        v32 = (RoleSystem *)(v6 + 57572);
        do
        {
          (((RoleSystem *)v32))->RoleSystem::ExportRoleData(Buffer_16);
          fwrite(Buffer_16, 0x1Cu, 1u, v7);
          ++v31;
          v32 = (RoleSystem *)((char *)v32 + 8704);
        }
        while ( v31 < v34 );
      }
      fseek(v7, 0, 0);
      strcpy((char *)Buffer_508, "PAL");
      LOBYTE(Buffer_508[1]) = 1;
      fwrite(Buffer_508, 0xDCu, 1u, v7);
      fclose(v7);
      v69 = -1;
      (((PalScript *)&Buffer_728))->PalScript::Cleanup();
      return 1;
    }
    else
    {
      v69 = -1;
      (((PalScript *)&Buffer_728))->PalScript::Cleanup();
      return 0;
    }
  }
  return result;
}

// 0x00538CE0
int Actor::ClearActionFlags()
{
  int result; // eax

  result = 0;
  this->m_actarray_type = 0;
  *(&this->m_actarray_type + 1) = 0;
  *(&this->m_actarray_type + 2) = 0;
  *(&this->m_actarray_type + 3) = 0;
  LOBYTE(this->m_actarray_begin) = 0;
  BYTE1(this->m_actarray_begin) = 0;
  BYTE2(this->m_actarray_begin) = 0;
  this->m_actarray_end = (Actor *)1065353216;
  this->m_actarray_capacity_end = 0;
  this->m_pact = 0;
  *(_DWORD *)this->m_name = 0;
  *(_DWORD *)&this->m_fScale = 0;
  memset(&this->m_name[4], 0, 0xC0u);
  return result;
}

// 0x00538D20
BOOL Actor::CompareModelName(char *String1, char *String2)
{
  return !_strcmpi(String1, String2) && !_strcmpi(String1 + 32, String2 + 32);
}

// 0x00538FA0
void Actor::BuildCollisionMesh(int *pOut)
{
  Actor *m_actarray_end; // esi
  Actor *m_actarray_begin; // edi
  int *v5; // eax
  Actor *v6; // ecx
  int v7; // edx
  Actor *p_m_nAnimParam1; // ebp
  char *v9; // esi
  int *p_m_nPathBuffer; // ebx
  int *v11; // eax
  int v12; // edi
  int *v13; // esi
  int v14; // eax
  int v15; // edx
  int v16; // eax
  char v17; // al
  int v18; // ecx
  int v19; // edi
  _BYTE *v20; // esi
  char v21; // dl
  char *v22; // [esp+0x0] [ebp-0x3FC]
  int v23; // [esp+0x4] [ebp-0x3F8]
  char pActionType; // [esp+0x13] [ebp-0x3E9] BYREF
  __int16 p_WORD2; // [esp+0x14] [ebp-0x3E8] BYREF
  char v26; // [esp+0x16] [ebp-0x3E6] BYREF
  char v27; // [esp+0x17] [ebp-0x3E5] BYREF
  char String2[132]; // [esp+0x18] [ebp-0x3E4] BYREF
  Array v29; // [esp+0x9C] [ebp-0x360] BYREF
  Actor v30; // [esp+ACh] [ebp-0x350] BYREF
  char v31; // [esp+0x3E8] [ebp-0x14]
  char v32; // [esp+0x3E9] [ebp-0x13]
  int v33; // [esp+0x3EC] [ebp-0x10]
  int v34; // [esp+0x3F8] [ebp-0x4]

  LOBYTE(v29.m_pDataStart) = pActionType;
  memset(&v29.m_nSize, 0, 12);
  v34 = 0;
  (((Actor *)&v30))->Actor::InitAction(&pActionType);
  qmemcpy(String2, pOut, sizeof(String2));
  v34 = 1;
  (((Actor *)&v30.m_nPathBuffer))->Actor::InitAction(&v27);
  LOBYTE(v34) = 2;
  (((Actor *)&v30.m_vecTargetPos.y))->Actor::InitAction(&v26);
  m_actarray_end = (Actor *)this->m_actarray_end;
  m_actarray_begin = (Actor *)this->m_actarray_begin;
  for ( LOBYTE(v34) = 3; m_actarray_begin != m_actarray_end; m_actarray_begin = (Actor *)((char *)m_actarray_begin + 164) )
  {
    if ( Actor::CompareModelName(&m_actarray_begin->m_actarray_type, String2) )
      break;
  }
  v5 = (int *)this->m_actarray_end;
  if ( m_actarray_begin == (Actor *)v5 )
  {
    this->Actor::InsertAction(v5, (char **)&v30.m_pact);
    v6 = (Actor *)this->m_actarray_begin;
    if ( v6 )
      v7 = ((char *)this->m_actarray_end - (char *)v6) / 164;
    else
      v7 = 0;
    m_actarray_begin = (Actor *)((char *)v6 + 164 * v7 - 164);
  }
  p_m_nAnimParam1 = (Actor *)&m_actarray_begin->m_nAnimParam1;
  v9 = ActVecReallocate(
         LODWORD(m_actarray_begin->m_vecBonePos.y),
         (char *)LODWORD(m_actarray_begin->m_vecBonePos.y),
         (char *)LODWORD(m_actarray_begin->m_vecBonePos.x),
         v22,
         v23);
  nullsub_2(v9, LODWORD(m_actarray_begin->m_vecBonePos.y));
  p_m_nPathBuffer = (int *)&m_actarray_begin->m_nPathBuffer;
  LODWORD(m_actarray_begin->m_vecBonePos.y) = (unsigned long)v9;
  (((Actor *)&m_actarray_begin->m_nPathBuffer))->Actor::GetActionArrayEnd((_WORD *)m_actarray_begin->m_nAnimBuffer, (__int16 *)m_actarray_begin->m_nParticleBuffer);
  qmemcpy(m_actarray_begin, pOut, 0x84u);
  // [AUTO-COMMENTED] (gbVec3D *)&v30.m_fMatrixA->gbVec3D(0.0, 0.0, 0.0);
  // [AUTO-COMMENTED] (gbAABBox *)&v30.m_dwMatMsg[1]->gbAABBox();
  (((Actor *)(&v30.m_nUpdateMode + 4)))->Actor::ClearActionArrays();
  v11 = (int *)pOut;
  v12 = 0;
  if ( pOut[55] > 0 )
  {
    v13 = (int *)(pOut + 72);
    do
    {
      if ( (((PalScriptMgr *)(v13 - 16)))->PalScriptMgr::IsInputBlocked() )
      {
        (((Actor *)&v30.m_nInterpFrames))->Actor::ActionEntry_Assign((int)(v13 + 27));
        v14 = *(v13 - 3);
        v15 = *(v13 - 1);
        *(&v30.m_nUpdateMode + 5) = *(v13 - 2);
        *(&v30.m_nUpdateMode + 4) = v14;
        v16 = (unsigned long)*v13;
        *(&v30.m_nUpdateMode + 6) = v15;
        *(&v30.m_nUpdateMode + 7) = v16;
        ((gbVec3D *)(&v30.m_nUpdateMode + 8))->gbVec3D::operator=(v13 + 1);
        v17 = *((_BYTE *)v13 + 17);
        v18 = (unsigned long)v13[5];
        v31 = *((_BYTE *)v13 + 16);
        v32 = v17;
        v33 = v18;
        (((Actor *)p_m_nAnimParam1))->Actor::ActVec_Insert_char(&p_m_nAnimParam1->m_actarray_end->m_actarray_type, 1u, (char *)&v30.m_nInterpFrames);
      }
      v11 = (int *)pOut;
      ++v12;
      v13 += 224;
    }
    while ( v12 < pOut[55] );
  }
  v19 = 0;
  if ( v11[14392] > 0 )
  {
    v20 = (char *)v11 + 57873;
    do
    {
      if ( *(v20 - 128) == 2 && !*v20 )
      {
        v21 = v20[331];
        LOBYTE(p_WORD2) = *(v20 - 129);
        HIBYTE(p_WORD2) = v21;
        (((Actor *)p_m_nPathBuffer))->Actor::ActVec_Insert_word((_WORD *)p_m_nPathBuffer[2], 1u, &p_WORD2);
        v11 = (int *)pOut;
      }
      ++v19;
      v20 += 8704;
    }
    while ( v19 < v11[14392] );
  }
  LOBYTE(v34) = 1;
  (((Array *)&v30.m_vecTargetPos.y))->Array::Free();
  (((Array *)&v30.m_nPathBuffer))->Array::Free();
  v34 = -1;
  (((Array *)&v30))->Array::Free();
  (((Array *)&v29))->Array::Free();
}

// 0x005392C0
char * Actor::ActionEntry_Assign(int nVal)
{
  char *result; // eax
  int v4; // ebp
  char *v5; // esi
  char *v6; // edx
  int v7; // esi
  char *v8; // esi
  int *v9; // esi
  char *v10; // edx
  int v11; // ebx
  char *v12; // esi
  char *v13; // esi
  char *v14; // ecx
  int v15; // edx
  int nVala; // [esp+0x10] [ebp+0x4]

  result = (char *)&this->m_actarray_type;
  v4 = nVal - (_DWORD)result;
  *(_DWORD *)result = *(_DWORD *)nVal;
  v5 = (char *)(result + 4);
  do
  {
    *v5 = v5[v4];
    ++v5;
  }
  while ( (unsigned int)&v5[-4 - (_DWORD)result] < 0x20 );
  result[36] = *(_BYTE *)(nVal + 36);
  result[37] = *(_BYTE *)(nVal + 37);
  *((_DWORD *)result + 10) = *(_DWORD *)(nVal + 40);
  *((_DWORD *)result + 11) = *(_DWORD *)(nVal + 44);
  *((_DWORD *)result + 12) = *(_DWORD *)(nVal + 48);
  *((_DWORD *)result + 13) = *(_DWORD *)(nVal + 52);
  *((_DWORD *)result + 14) = *(_DWORD *)(nVal + 56);
  *((_DWORD *)result + 15) = *(_DWORD *)(nVal + 60);
  *((_DWORD *)result + 16) = *(_DWORD *)(nVal + 64);
  *((_DWORD *)result + 17) = *(_DWORD *)(nVal + 68);
  result[72] = *(_BYTE *)(nVal + 72);
  result[73] = *(_BYTE *)(nVal + 73);
  result[74] = *(_BYTE *)(nVal + 74);
  result[75] = *(_BYTE *)(nVal + 75);
  v6 = (char *)(result + 76);
  v7 = 6;
  do
  {
    *(_DWORD *)v6 = *(_DWORD *)&v6[v4];
    v6 += 4;
    --v7;
  }
  while ( v7 );
  result[100] = *(_BYTE *)(nVal + 100);
  *((_WORD *)result + 51) = *(_WORD *)(nVal + 102);
  *((_WORD *)result + 52) = *(_WORD *)(nVal + 104);
  *((_WORD *)result + 53) = *(_WORD *)(nVal + 106);
  *((_WORD *)result + 54) = *(_WORD *)(nVal + 108);
  result[110] = *(_BYTE *)(nVal + 110);
  v8 = (char *)(result + 111);
  do
  {
    *v8 = v8[v4];
    ++v8;
  }
  while ( (unsigned int)&v8[-111 - (_DWORD)result] < 0x10 );
  *((_DWORD *)result + 32) = *(_DWORD *)(nVal + 128);
  v9 = (int *)(nVal + 136);
  *((_DWORD *)result + 33) = *(_DWORD *)(nVal + 132);
  v10 = (char *)(result + 140);
  nVala = 16;
  do
  {
    v11 = (unsigned long)*v9;
    v9 += 3;
    *((_DWORD *)v10 - 1) = v11;
    *(_DWORD *)v10 = *(_DWORD *)&v10[nVal - (_DWORD)result];
    *((_DWORD *)v10 + 1) = *(v9 - 1);
    v10 += 12;
    --nVala;
  }
  while ( nVala );
  *((_WORD *)result + 164) = *(_WORD *)(nVal + 328);
  v12 = (char *)(result + 330);
  do
  {
    *v12 = v12[v4];
    ++v12;
  }
  while ( (unsigned int)&v12[-330 - (_DWORD)result] < 0x20 );
  result[362] = *(_BYTE *)(nVal + 362);
  *((_DWORD *)result + 91) = *(_DWORD *)(nVal + 364);
  *((_DWORD *)result + 92) = *(_DWORD *)(nVal + 368);
  *((_DWORD *)result + 93) = *(_DWORD *)(nVal + 372);
  *((_DWORD *)result + 94) = *(_DWORD *)(nVal + 376);
  *((_DWORD *)result + 95) = *(_DWORD *)(nVal + 380);
  *((_DWORD *)result + 96) = *(_DWORD *)(nVal + 384);
  *((_DWORD *)result + 97) = *(_DWORD *)(nVal + 388);
  v13 = (char *)(result + 392);
  do
  {
    *v13 = v13[v4];
    ++v13;
  }
  while ( (unsigned int)&v13[-392 - (_DWORD)result] < 8 );
  *((_DWORD *)result + 100) = *(_DWORD *)(nVal + 400);
  *((_DWORD *)result + 101) = *(_DWORD *)(nVal + 404);
  *((_DWORD *)result + 102) = *(_DWORD *)(nVal + 408);
  v14 = (char *)(result + 412);
  v15 = 52;
  do
  {
    *(_DWORD *)v14 = *(_DWORD *)&v14[v4];
    v14 += 4;
    --v15;
  }
  while ( v15 );
  return result;
}

// 0x005394D0
int * Actor::ClearActionArrays()
{
  int *result; // eax

  result = (int *)this;
  this->m_actarray_begin = 0;
  this->m_actarray_end = 0;
  this->m_actarray_capacity_end = 0;
  this->m_pact = 0;
  *(_DWORD *)this->m_name = 0;
  *(_DWORD *)&this->m_name[4] = 0;
  return result;
}

// 0x00539540
int Actor::AddActionByName(const char *pszName, const char *pszName2, int nVal)
{
  int v4; // ebp
  Actor *m_actarray_end; // edi
  Actor *i; // esi
  float x; // ebx
  unsigned int j; // edi
  int v10; // edi
  char pActionType; // [esp+0x13] [ebp-B1h] BYREF
  char String2[32]; // [esp+0x14] [ebp-B0h] BYREF
  char v14[104]; // [esp+0x34] [ebp-0x90] BYREF
  void *v15; // [esp+0x9C] [ebp-0x28]
  int v16; // [esp+A0h] [ebp-0x24]
  int v17; // [esp+A4h] [ebp-0x20]
  char v18; // [esp+A8h] [ebp-0x1C] BYREF
  void *Block; // [esp+ACh] [ebp-0x18]
  int v20; // [esp+B0h] [ebp-0x14]
  int v21; // [esp+B4h] [ebp-0x10]
  int v22; // [esp+C0h] [ebp-0x4]

  v4 = 0;
  v14[100] = pActionType;
  v15 = 0;
  v16 = 0;
  v17 = 0;
  v22 = 0;
  (((Actor *)&v18))->Actor::InitAction(&pActionType);
  strcpy(String2, pszName);
  strcpy(v14, pszName2);
  m_actarray_end = (Actor *)this->m_actarray_end;
  for ( i = this->m_actarray_begin; i != m_actarray_end; i = (Actor *)((char *)i + 164) )
  {
    if ( Actor::CompareModelName(&i->m_actarray_type, String2) )
      break;
  }
  if ( i != this->m_actarray_end )
  {
    x = i->m_vecBonePos.x;
    for ( j = 0; x != 0.0 && j < (LODWORD(i->m_vecBonePos.y) - LODWORD(x)) / 656; ++j )
    {
      if ( *(unsigned __int8 *)(LODWORD(i->m_vecBonePos.x) + v4) == nVal )
      {
        v10 = LODWORD(i->m_vecBonePos.x) + 656 * j;
        operator delete(Block);
        Block = 0;
        v20 = 0;
        v21 = 0;
        operator delete(v15);
        return v10;
      }
      v4 += 656;
    }
  }
  operator delete(Block);
  Block = 0;
  v20 = 0;
  v21 = 0;
  operator delete(v15);
  return 0;
}

// 0x00539700
void Actor::GetAnimDataBuffer(void **Buffer, int Stream)
{
  FILE *v3; // ebx
  float x; // eax
  float i; // edi
  int m_nAnimBuffer; // eax
  char *j; // edi
  int Buffera; // [esp+0xC] [ebp-0x4] BYREF

  v3 = (FILE *)Buffer;
  if ( Buffer )
  {
    fwrite(this, 0x84u, 1u, (FILE *)Buffer);
    x = this->m_vecBonePos.x;
    if ( x == 0.0 )
      Buffer = 0;
    else
      Buffer = (void **)((LODWORD(this->m_vecBonePos.y) - LODWORD(x)) / 656);
    fwrite(&Buffer, 4u, 1u, v3);
    if ( (int)Buffer > 0 )
    {
      for ( i = this->m_vecBonePos.x; LODWORD(i) != LODWORD(this->m_vecBonePos.y); LODWORD(i) += 656 )
        fwrite((const void *)LODWORD(i), 0x290u, 1u, v3);
    }
    m_nAnimBuffer = this->m_nAnimBuffer;
    if ( m_nAnimBuffer )
      Buffera = (this->m_nParticleBuffer - m_nAnimBuffer) >> 1;
    else
      Buffera = 0;
    fwrite(&Buffera, 4u, 1u, v3);
    if ( Buffera > 0 )
    {
      for ( j = (char *)this->m_nAnimBuffer; j != (char *)this->m_nParticleBuffer; j += 2 )
        fwrite(j, 2u, 1u, v3);
    }
  }
}

// 0x005399E0
void Actor::IterateActiveActors()
{
  Actor *m_actarray_begin; // ebp
  Actor *m_actarray_end; // ebx
  Actor *i; // esi

  m_actarray_begin = (Actor *)this->m_actarray_begin;
  m_actarray_end = (Actor *)this->m_actarray_end;
  for ( i = m_actarray_begin; i != m_actarray_end; i = (Actor *)((char *)i + 164) )
    (((Actor *)i))->Actor::ClearAllocBuffers();
  this->m_actarray_end = m_actarray_begin;
}

// 0x00539A90
char Actor::SearchAnimByIndex(char *String1, char *pszBuf)
{
  unsigned int v3; // ebp
  int i; // ebx
  int v6; // eax
  int v7; // esi

  v3 = 0;
  for ( i = 0; ; i += 64 )
  {
    v6 = *(_DWORD *)this->m_name;
    if ( !v6 || v3 >= (*(_DWORD *)&this->m_name[4] - v6) >> 6 )
      break;
    v7 = i + v6;
    if ( !_strcmpi(String1, (const char *)(i + v6)) && !_strcmpi(pszBuf, (const char *)(v7 + 32)) )
      return 1;
    ++v3;
  }
  return 0;
}

// 0x00539AF0
void Actor::RegisterAnim(char *pszName, char *pszBuf)
{
  Actor *p_m_pact; // ebx
  char *p_m_actarray_type; // eax
  char *v6; // ebp
  Actor *m_actarray_begin; // edx
  unsigned int v8; // ecx
  int v9; // eax
  unsigned int v10; // esi
  int v11; // eax
  char *v12; // edi
  Actor *v13; // eax
  Actor *v14; // eax
  int v15; // ecx
  Actor *m_actarray_end; // eax
  char *v17; // edi
  int v18; // [esp+0x0] [ebp-0x50]
  char pData[64]; // [esp+0x10] [ebp-0x40] BYREF
  char *String1; // [esp+0x54] [ebp+0x4]
  char *pszBufa; // [esp+0x58] [ebp+0x8]

  if ( pszName && pszBuf && strlen(pszName) && strlen(pszBuf) && !this->Actor::SearchAnimByIndex(pszName, pszBuf) )
  {
    memset(pData, 0, sizeof(pData));
    p_m_pact = (Actor *)&this->m_pact;
    strcpy(pData, pszName);
    strcpy(&pData[32], pszBuf);
    p_m_actarray_type = (char *)&p_m_pact->m_actarray_end->m_actarray_type;
    v6 = (char *)p_m_actarray_type;
    if ( ((char *)p_m_pact->m_actarray_capacity_end - p_m_actarray_type) >> 6 )
    {
      (((Actor *)p_m_pact))->Actor::CopyBufferBlocks(p_m_actarray_type, p_m_actarray_type, p_m_actarray_type + 64);
      (((Actor *)p_m_pact))->Actor::CopyIfValid(&p_m_pact->m_actarray_end->m_actarray_type, (char *)(1 - (((char *)p_m_pact->m_actarray_end - v6) >> 6)), pData);
      m_actarray_end = (Actor *)p_m_pact->m_actarray_end;
      if ( v6 == (char *)m_actarray_end )
      {
        p_m_pact->m_actarray_end = (Actor *)((char *)p_m_pact->m_actarray_end + 64);
      }
      else
      {
        do
        {
          v17 = (char *)v6;
          v6 += 64;
          qmemcpy(v17, pData, 0x40u);
        }
        while ( v6 != (char *)m_actarray_end );
        p_m_pact->m_actarray_end = (Actor *)((char *)p_m_pact->m_actarray_end + 64);
      }
    }
    else
    {
      m_actarray_begin = (Actor *)p_m_pact->m_actarray_begin;
      if ( !m_actarray_begin || (v8 = (p_m_actarray_type - (char *)m_actarray_begin) >> 6, v8 <= 1) )
        v8 = 1;
      if ( m_actarray_begin )
        v9 = (p_m_actarray_type - (char *)m_actarray_begin) >> 6;
      else
        v9 = 0;
      v10 = v9 + v8;
      v11 = v9 + v8;
      if ( v11 < 0 )
        v11 = 0;
      pszBufa = (char *)operator new(v11 << 6);
      v12 = (char *)pszBufa;
      v13 = (Actor *)p_m_pact->m_actarray_begin;
      String1 = (char *)&v13->m_actarray_type;
      if ( v13 != (Actor *)v6 )
      {
        while ( 1 )
        {
          (((Actor *)v12))->Actor::CopyConstruct_40(v13, v18);
          v12 += 64;
          String1 += 64;
          if ( String1 == v6 )
            break;
          v13 = (Actor *)String1;
        }
      }
      (((Actor *)p_m_pact))->Actor::CopyIfValid(v12, (char *)1, pData);
      (((Actor *)p_m_pact))->Actor::CopyBufferBlocks(v6, &p_m_pact->m_actarray_end->m_actarray_type, v12 + 64);
      nullsub_2(p_m_pact->m_actarray_begin, p_m_pact->m_actarray_end);
      operator delete(p_m_pact->m_actarray_begin);
      v14 = (Actor *)p_m_pact->m_actarray_begin;
      p_m_pact->m_actarray_capacity_end = (Actor *)&pszBufa[64 * v10];
      if ( v14 )
      {
        v15 = (((char *)p_m_pact->m_actarray_end - (char *)v14) >> 6) + 1;
        p_m_pact->m_actarray_begin = (Actor *)pszBufa;
        p_m_pact->m_actarray_end = (Actor *)&pszBufa[64 * v15];
      }
      else
      {
        p_m_pact->m_actarray_begin = (Actor *)pszBufa;
        p_m_pact->m_actarray_end = (Actor *)(pszBufa + 64);
      }
    }
  }
}

// 0x00539D60
int * Actor::ClearAllActions()
{
  int *result; // eax
  Actor *m_actarray_begin; // ebp
  Actor *m_actarray_end; // edi
  Actor *v4; // esi

  result = (int *)this;
  *(_DWORD *)&this->m_name[4] = *(_DWORD *)this->m_name;
  m_actarray_begin = (Actor *)this->m_actarray_begin;
  m_actarray_end = (Actor *)this->m_actarray_end;
  v4 = (Actor *)m_actarray_begin;
  if ( m_actarray_begin != m_actarray_end )
  {
    do
    {
      (((Actor *)v4))->Actor::ClearAllocBuffers();
      v4 = (Actor *)((char *)v4 + 164);
    }
    while ( v4 != m_actarray_end );
    result = (int *)this;
  }
  result[2] = (int)m_actarray_begin;
  result[10] = (unsigned long)result[9];
  return result;
}

// 0x00539E70
char * Actor::InsertAnimFrame(float fVal)
{
  float m_fTransitionSpeed; // eax
  float *p_m_fMoveRange; // esi
  gbVec3D *v4; // edi
  char *m_pAllocBuf; // edx
  unsigned int v6; // ecx
  int v7; // eax
  int v8; // eax
  char *v9; // eax
  int *v10; // ebp
  int i; // ebx
  int v12; // eax
  char *result; // eax
  int v14; // ecx
  gbVec3D *v15; // eax
  char *v16; // [esp+0x8] [ebp-0x8]
  int v17; // [esp+0xC] [ebp-0x4]

  m_fTransitionSpeed = this->m_fTransitionSpeed;
  p_m_fMoveRange = (float *)&this->m_fMoveRange;
  v4 = (gbVec3D *)LODWORD(m_fTransitionSpeed);
  if ( (LODWORD(this->m_fTransitionPos) - LODWORD(m_fTransitionSpeed)) >> 2 )
  {
    Vec3CopyStruct(
      (gbVec3D *)LODWORD(m_fTransitionSpeed),
      (gbVec3D *)LODWORD(m_fTransitionSpeed),
      (gbVec3D *)(LODWORD(m_fTransitionSpeed) + 4));
    (((Actor *)p_m_fMoveRange))->Actor::StoreParam(*((_DWORD *)p_m_fMoveRange + 2), 1 - ((*((_DWORD *)p_m_fMoveRange + 2) - (int)v4) >> 2));
    v15 = (gbVec3D *)*((_DWORD *)p_m_fMoveRange + 2);
    if ( v4 == v15 )
    {
      result = (char *)(*((_DWORD *)p_m_fMoveRange + 2) + 4);
      *((_DWORD *)p_m_fMoveRange + 2) = (unsigned long)result;
    }
    else
    {
      do
      {
        v4->x = fVal;
        v4 = (gbVec3D *)((char *)v4 + 4);
      }
      while ( v4 != v15 );
      result = (char *)(*((_DWORD *)p_m_fMoveRange + 2) + 4);
      *((_DWORD *)p_m_fMoveRange + 2) = (unsigned long)result;
    }
  }
  else
  {
    m_pAllocBuf = (char *)this->m_pAllocBuf;
    if ( !m_pAllocBuf || (v6 = (LODWORD(m_fTransitionSpeed) - (int)m_pAllocBuf) >> 2, v6 <= 1) )
      v6 = 1;
    if ( m_pAllocBuf )
      v7 = (LODWORD(m_fTransitionSpeed) - (int)m_pAllocBuf) >> 2;
    else
      v7 = 0;
    v8 = v6 + v7;
    v17 = v8;
    if ( v8 < 0 )
      v8 = 0;
    v9 = (char *)operator new(4 * v8);
    v10 = (int *)*((_DWORD *)p_m_fMoveRange + 1);
    v16 = (char *)v9;
    for ( i = (int)v9; v10 != (int *)v4; i += 4 )
      AssignInt((int *)i, v10++);
    (((Actor *)p_m_fMoveRange))->Actor::StoreParam(i, 1);
    Vec3CopyStruct(v4, *((gbVec3D **)p_m_fMoveRange + 2), (gbVec3D *)(i + 4));
    nullsub_2(*((_DWORD *)p_m_fMoveRange + 1), *((_DWORD *)p_m_fMoveRange + 2));
    operator delete(*((void **)p_m_fMoveRange + 1));
    v12 = *((_DWORD *)p_m_fMoveRange + 1);
    *((_DWORD *)p_m_fMoveRange + 3) = (unsigned long)&v16[4 * v17];
    if ( v12 )
    {
      v14 = *((_DWORD *)p_m_fMoveRange + 2);
      *((_DWORD *)p_m_fMoveRange + 1) = (unsigned long)v16;
      result = (char *)&v16[4 * ((v14 - v12) >> 2) + 4];
      *((_DWORD *)p_m_fMoveRange + 2) = (unsigned long)result;
    }
    else
    {
      *((_DWORD *)p_m_fMoveRange + 1) = (unsigned long)v16;
      result = (char *)(v16 + 4);
      *((_DWORD *)p_m_fMoveRange + 2) = (unsigned long)(v16 + 4);
    }
  }
  return result;
}

// 0x0053A020
char Actor::IterateAllocBuffer(int nVal)
{
  char *m_pAllocBuf; // edx
  unsigned int i; // eax

  m_pAllocBuf = (char *)this->m_pAllocBuf;
  for ( i = 0; m_pAllocBuf && i < (LODWORD(this->m_fTransitionSpeed) - (int)m_pAllocBuf) >> 2; ++i )
  {
    if ( *(_DWORD *)&this->m_pAllocBuf[4 * i] == nVal )
      return 1;
  }
  return 0;
}

// 0x0053A060
int * Actor::InitAction(_BYTE *pActionType)
{
  int *result; // eax

  result = (int *)this;
  this->m_actarray_type = *pActionType;
  this->m_actarray_begin = 0;
  this->m_actarray_end = 0;
  this->m_actarray_capacity_end = 0;
  return result;
}

// 0x0053A080
_WORD * Actor::GetActionArrayEnd(_WORD *p_WORD, __int16 *pnVal)
{
  __int16 *v3; // edx
  _WORD *result; // eax
  __int16 *m_actarray_end; // edi
  Actor *v6; // esi
  __int16 v7; // bx

  v3 = (__int16 *)pnVal;
  result = (_WORD *)p_WORD;
  m_actarray_end = (__int16 *)this->m_actarray_end;
  v6 = (Actor *)p_WORD;
  if ( pnVal != m_actarray_end )
  {
    do
    {
      v7 = *v3++;
      *(_WORD *)&v6->m_actarray_type = v7;
      v6 = (Actor *)((char *)v6 + 2);
    }
    while ( v3 != m_actarray_end );
  }
  this->m_actarray_end = v6;
  return result;
}

// 0x0053A0C0
int Actor::InsertAction(int *p_DWORD, char **nY)
{
  Actor *m_actarray_begin; // ebx
  Actor *m_actarray_end; // ecx
  int v7; // ebp
  unsigned int v8; // ebp
  int v9; // edx
  unsigned int v10; // eax
  Actor *v11; // eax
  int *v12; // ebx
  int i; // ebp
  int ActionCount; // eax
  char **v16; // [esp-0xC] [ebp-0x24]
  char **v17; // [esp+0x0] [ebp-0x18]
  unsigned int v18; // [esp+0x10] [ebp-0x8]
  Actor *v19; // [esp+0x14] [ebp-0x4]
  int *p_DWORDa; // [esp+0x1C] [ebp+0x4]

  m_actarray_begin = (Actor *)this->m_actarray_begin;
  m_actarray_end = (Actor *)this->m_actarray_end;
  v7 = ((char *)p_DWORD - (char *)m_actarray_begin) / 164;
  p_DWORDa = (int *)v7;
  if ( ((char *)this->m_actarray_capacity_end - (char *)m_actarray_end) / 164 )
  {
    if ( ((char *)m_actarray_end - (char *)p_DWORD) / 164 )
    {
      this->Actor::FindMatchingEntry((int)&m_actarray_end[-1].m_fDistAccum, (int)m_actarray_end, (int)m_actarray_end);
      ActVecUninitFill((int)p_DWORD, (int)&this->m_actarray_end[-1].m_fDistAccum, (int)this->m_actarray_end, v17);
      ActVecUninitCopy2((int)p_DWORD, p_DWORD + 41, (int *)nY, v16);
    }
    else
    {
      this->Actor::FindMatchingEntry((int)p_DWORD, (int)m_actarray_end, (int)(p_DWORD + 41));
      this->Actor::SetVideoRegions((int)this->m_actarray_end, 1 - ((char *)this->m_actarray_end - (char *)p_DWORD) / 164, (int)nY);
      ActVecUninitCopy2((int)p_DWORD, (int *)this->m_actarray_end, (int *)nY, v17);
    }
    this->m_actarray_end = (Actor *)((char *)this->m_actarray_end + 164);
  }
  else
  {
    if ( !m_actarray_begin || (v8 = ((char *)m_actarray_end - (char *)m_actarray_begin) / 164, v8 <= 1) )
      v8 = 1;
    if ( m_actarray_begin )
      v9 = ((char *)m_actarray_end - (char *)m_actarray_begin) / 164;
    else
      v9 = 0;
    v10 = v9 + v8;
    v18 = v9 + v8;
    if ( (int)(v9 + v8) < 0 )
      v10 = 0;
    v11 = (Actor *)operator new(164 * v10);
    v12 = (int *)this->m_actarray_begin;
    v19 = (Actor *)v11;
    for ( i = (int)v11; v12 != p_DWORD; i += 164 )
    {
      (((VideoPlayer *)i))->VideoPlayer::SetRegion((int)v12);
      v12 += 41;
    }
    (((VideoPlayer *)i))->VideoPlayer::SetRegion((int)nY);
    this->Actor::FindMatchingEntry((int)p_DWORD, (int)this->m_actarray_end, i + 164);
    this->Actor::DestroyActionRange((int)this->m_actarray_begin, (int)this->m_actarray_end);
    operator delete(this->m_actarray_begin);
    this->m_actarray_capacity_end = (Actor *)((char *)v19 + 164 * v18);
    ActionCount = this->Actor::GetActionCount();
    v7 = (int)p_DWORDa;
    this->m_actarray_begin = v19;
    this->m_actarray_end = (Actor *)(&v19->m_vecTargetPos.y + 41 * ActionCount);
  }
  return (int)this->m_actarray_begin + 164 * v7;
}

// 0x0053A2E0
int Actor::GetActionCount()
{
  int result; // eax

  result = (int)this->m_actarray_begin;
  if ( result )
    return ((int)this->m_actarray_end - result) / 164;
  return result;
}

// 0x0053A310
void Actor::DestroyActionRange(int nVal, int nVal2)
{
  Actor *i; // esi

  for ( i = (Actor *)nVal; i != (Actor *)nVal2; i = (Actor *)((char *)i + 164) )
    (((Actor *)i))->Actor::ClearAllocBuffers();
}

// 0x0053A340
void Actor::ActVec_Insert_char(char *pszBuf, unsigned int dwVal, char *pszBuf2)
{
  Actor *m_actarray_end; // ebx
  Actor *m_actarray_begin; // esi
  unsigned int v7; // ecx
  int v8; // edx
  unsigned int v9; // eax
  Actor *v10; // esi
  Actor *v11; // edx
  Actor *j; // eax
  Actor *v13; // eax
  unsigned int v14; // ebx
  char *p_m_actarray_type; // edi
  char *v16; // ebx
  char *v17; // eax
  Actor *v18; // eax
  int v19; // edx
  Actor *v20; // edi
  unsigned int v21; // esi
  char *v22; // eax
  Actor *v23; // edx
  Actor *v24; // eax
  unsigned int i; // edx
  Actor *v26; // ebx
  Actor *v27; // esi
  unsigned int v28; // ebp
  Actor *v29; // esi
  Actor *v30; // ebx
  int v31; // esi
  Actor *v32; // esi
  int v33; // [esp+0x0] [ebp-0x18]
  Actor *v34; // [esp+0x10] [ebp-0x8]
  Actor *v35; // [esp+0x14] [ebp-0x4]
  Actor *pszBufa; // [esp+0x1C] [ebp+0x4]
  unsigned int dwVala; // [esp+0x20] [ebp+0x8]
  unsigned int dwValb; // [esp+0x20] [ebp+0x8]
  char *pszBuf2a; // [esp+0x24] [ebp+0xC]

  m_actarray_end = (Actor *)this->m_actarray_end;
if ( ((char *)this->m_actarray_capacity_end - (char *)m_actarray_end) / 656 >= dwVal )
  {
    v20 = (Actor *)pszBuf;
    if ( ((char *)m_actarray_end - pszBuf) / 656 >= dwVal )
    {
      if ( dwVal )
      {
        pszBufa = (Actor *)this->m_actarray_end;
        v28 = 656 * dwVal;
        v29 = (Actor *)((char *)m_actarray_end - 656 * dwVal);
        if ( v29 != m_actarray_end )
        {
          do
          {
            (((Actor *)pszBufa))->Actor::CopyConstruct_290(v29, v33);
            v29 = (Actor *)((char *)v29 + 656);
            pszBufa = (Actor *)((char *)pszBufa + 656);
          }
          while ( v29 != m_actarray_end );
          this = v34;
        }
        v30 = (Actor *)this->m_actarray_end;
        v31 = (int)v30 - v28;
        if ( v20 != (Actor *)((char *)v30 - v28) )
        {
          do
          {
            v31 -= 656;
            v30 = (Actor *)((char *)v30 - 656);
            (((Actor *)v30))->Actor::SetCurrentAction(v31);
          }
          while ( (Actor *)v31 != v20 );
          this = v34;
        }
        v32 = (Actor *)((char *)v20 + v28);
        if ( v20 != (Actor *)((char *)v20 + v28) )
        {
          do
          {
            (((Actor *)v20))->Actor::SetCurrentAction((int)pszBuf2);
            v20 = (Actor *)((char *)v20 + 656);
          }
          while ( v20 != v32 );
          this = v34;
        }
        this->m_actarray_end = (Actor *)((char *)this->m_actarray_end + v28);
      }
    }
    else
    {
      v21 = 656 * dwVal;
      dwValb = 656 * dwVal;
      v22 = (char *)&pszBuf[656 * dwVal];
      if ( pszBuf != (char *)m_actarray_end )
      {
        v23 = (Actor *)&v22[-v21];
        do
        {
          if ( v22 )
          {
            qmemcpy(v22, v23, 0x290u);
            v20 = (Actor *)pszBuf;
            this = v34;
          }
          v23 = (Actor *)((char *)v23 + 656);
          v22 += 656;
        }
        while ( v23 != m_actarray_end );
      }
      v24 = (Actor *)this->m_actarray_end;
      for ( i = dwVal - ((char *)v24 - (char *)v20) / 656; i; --i )
      {
        if ( v24 )
        {
          qmemcpy(v24, pszBuf2, 0x290u);
          v20 = (Actor *)pszBuf;
          this = v34;
        }
        v24 = (Actor *)((char *)v24 + 656);
      }
      v26 = (Actor *)this->m_actarray_end;
      v27 = (Actor *)v20;
      if ( v20 != v26 )
      {
        do
        {
          (((Actor *)v27))->Actor::ActionEntry_Assign((int)pszBuf2);
          (((Actor *)&v27->m_curact[35]))->Actor::CopyActionData((int)(pszBuf2 + 620));
          v27 = (Actor *)((char *)v27 + 656);
        }
        while ( v27 != v26 );
        this = v34;
      }
      this->m_actarray_end = (Actor *)((char *)this->m_actarray_end + dwValb);
    }
  }
  else
  {
    m_actarray_begin = (Actor *)this->m_actarray_begin;
    if ( !m_actarray_begin || (v7 = ((char *)m_actarray_end - (char *)m_actarray_begin) / 656, dwVal >= v7) )
      v7 = dwVal;
    if ( m_actarray_begin )
      v8 = ((char *)m_actarray_end - (char *)m_actarray_begin) / 656;
    else
      v8 = 0;
    v9 = v8 + v7;
    dwVala = v8 + v7;
    if ( (int)(v8 + v7) < 0 )
      v9 = 0;
    v10 = (Actor *)v34;
    v35 = (Actor *)operator new(656 * v9);
    v11 = (Actor *)v35;
    for ( j = this->m_actarray_begin; j != (Actor *)pszBuf; v11 = (Actor *)((char *)v11 + 656) )
    {
      if ( v11 )
      {
        qmemcpy(v11, j, 0x290u);
        v10 = (Actor *)v34;
      }
      j = (Actor *)((char *)j + 656);
    }
    v13 = (Actor *)v11;
    if ( dwVal )
    {
      v14 = dwVal;
      do
      {
        if ( v13 )
        {
          qmemcpy(v13, pszBuf2, 0x290u);
          v10 = (Actor *)v34;
        }
        v13 = (Actor *)((char *)v13 + 656);
        --v14;
      }
      while ( v14 );
    }
    p_m_actarray_type = (char *)&v10->m_actarray_end->m_actarray_type;
    pszBuf2a = (char *)p_m_actarray_type;
    v16 = (char *)(&v11->m_actarray_type + 656 * dwVal);
    if ( pszBuf != p_m_actarray_type )
    {
      v17 = (char *)pszBuf;
      do
      {
        if ( v16 )
        {
          qmemcpy(v16, v17, 0x290u);
          v10 = (Actor *)v34;
          p_m_actarray_type = (char *)pszBuf2a;
        }
        v17 += 656;
        v16 += 656;
      }
      while ( v17 != p_m_actarray_type );
    }
    operator delete(v10->m_actarray_begin);
    v18 = (Actor *)v10->m_actarray_begin;
    v10->m_actarray_capacity_end = (Actor *)((char *)v35 + 656 * dwVala);
    if ( v18 )
      v19 = ((char *)v10->m_actarray_end - (char *)v18) / 656;
    else
      v19 = 0;
    v10->m_actarray_begin = v35;
    v10->m_actarray_end = (Actor *)((char *)v35 + 656 * v19 + 656 * dwVal);
  }
}

// 0x0053A670
int * Actor::CopyActionData(int nVal)
{
  int *result; // eax

  result = (int *)this;
  *(_DWORD *)&this->m_actarray_type = *(_DWORD *)nVal;
  this->m_actarray_begin = *(Actor **)(nVal + 4);
  this->m_actarray_end = *(Actor **)(nVal + 8);
  this->m_actarray_capacity_end = *(Actor **)(nVal + 12);
  this->m_pact = *(gbActor **)(nVal + 16);
  *(_QWORD *)this->m_name = *(_QWORD *)(nVal + 20);
  LOBYTE(this->m_fMoveSpeed) = *(_BYTE *)(nVal + 28);
  BYTE1(this->m_fMoveSpeed) = *(_BYTE *)(nVal + 29);
  this->m_fMoveRange = *(float *)(nVal + 32);
  return result;
}

// 0x0053A6C0
_WORD * Actor::ActVec_Insert_word(_WORD *p_WORD, unsigned int dwVal, _WORD *p_WORD2)
{
  Actor *v5; // edi
  _WORD *result; // eax
  Actor *m_actarray_begin; // edx
  unsigned int v8; // ecx
  int v9; // eax
  int v10; // eax
  Actor *v11; // ecx
  Actor *k; // eax
  _WORD *p_m_actarray_type; // eax
  unsigned int v14; // edx
  Actor *v15; // edi
  _WORD *v16; // edx
  Actor *v17; // eax
  Actor *v18; // ecx
  Actor *v19; // eax
  unsigned int v20; // ebx
  _WORD *v21; // esi
  _WORD *v22; // ecx
  Actor *v23; // eax
  unsigned int j; // ebp
  Actor *v25; // ecx
  Actor *v26; // eax
  unsigned int v27; // ebp
  _WORD *v28; // ecx
  _WORD *i; // esi
  Actor *m_actarray_end; // ecx
  _WORD *v31; // eax
  __int16 v32; // si
  int v34; // [esp+0x14] [ebp-0x4]
  Actor *dwVala; // [esp+0x20] [ebp+0x8]
result = (_WORD *)&this->m_actarray_end->m_actarray_type;
  if ( ((char *)this->m_actarray_capacity_end - (char *)result) >> 1 >= dwVal )
  {
    if ( result - p_WORD >= dwVal )
    {
      if ( dwVal )
      {
        v27 = 2 * dwVal;
        v28 = (_WORD *)&result[-dwVal];
        for ( i = result; v28 != result; ++i )
        {
          if ( i )
            *i = *v28;
          ++v28;
        }
        m_actarray_end = (Actor *)this->m_actarray_end;
        v31 = (_WORD *)(&m_actarray_end->m_actarray_type - v27);
        if ( p_WORD != (_WORD *)((char *)m_actarray_end - v27) )
        {
          do
          {
            v32 = *--v31;
            m_actarray_end = (Actor *)((char *)m_actarray_end - 2);
            *(_WORD *)&m_actarray_end->m_actarray_type = v32;
          }
          while ( v31 != p_WORD );
        }
        for ( result = p_WORD; result != &p_WORD[v27 / 2]; ++result )
          *result = *p_WORD2;
        this->m_actarray_end = (Actor *)((char *)this->m_actarray_end + v27);
      }
    }
    else
    {
      v20 = 2 * dwVal;
      v21 = (_WORD *)&p_WORD[dwVal];
      if ( p_WORD != result )
      {
        v22 = (_WORD *)&v21[v20 / 0xFFFFFFFE];
        do
        {
          if ( v21 )
          {
            *v21 = *v22;
}
          ++v22;
          ++v21;
        }
        while ( v22 != result );
      }
      v23 = (Actor *)this->m_actarray_end;
      for ( j = dwVal - (((char *)v23 - (char *)p_WORD) >> 1); j; --j )
      {
        if ( v23 )
          *(_WORD *)&v23->m_actarray_type = *p_WORD2;
        v23 = (Actor *)((char *)v23 + 2);
      }
      v25 = (Actor *)this->m_actarray_end;
      v26 = (Actor *)p_WORD;
      if ( p_WORD != (_WORD *)v25 )
      {
        do
        {
          *(_WORD *)&v26->m_actarray_type = *p_WORD2;
          v26 = (Actor *)((char *)v26 + 2);
        }
        while ( v26 != v25 );
      }
      result = (_WORD *)(&this->m_actarray_end->m_actarray_type + v20);
      this->m_actarray_end = (Actor *)result;
    }
  }
  else
  {
    m_actarray_begin = (Actor *)this->m_actarray_begin;
    if ( !m_actarray_begin || (v8 = ((char *)result - (char *)m_actarray_begin) >> 1, dwVal >= v8) )
      v8 = dwVal;
    if ( m_actarray_begin )
      v9 = ((char *)result - (char *)m_actarray_begin) >> 1;
    else
      v9 = 0;
    v10 = v8 + v9;
    v34 = v10;
    if ( v10 < 0 )
      v10 = 0;
    dwVala = (Actor *)operator new(2 * v10);
    v11 = (Actor *)dwVala;
    for ( k = this->m_actarray_begin; k != (Actor *)p_WORD; v11 = (Actor *)((char *)v11 + 2) )
    {
      if ( v11 )
        *(_WORD *)&v11->m_actarray_type = *(_WORD *)&k->m_actarray_type;
      k = (Actor *)((char *)k + 2);
    }
    p_m_actarray_type = (_WORD *)&v11->m_actarray_type;
    if ( dwVal )
    {
      v14 = dwVal;
      do
      {
        if ( p_m_actarray_type )
        {
          *p_m_actarray_type = *p_WORD2;
}
        ++p_m_actarray_type;
        --v14;
      }
      while ( v14 );
    }
    v15 = (Actor *)this->m_actarray_end;
    v16 = (_WORD *)(&v11->m_actarray_type + 2 * dwVal);
    if ( p_WORD != (_WORD *)v15 )
    {
      v17 = (Actor *)p_WORD;
      do
      {
        if ( v16 )
          *v16 = *(_WORD *)&v17->m_actarray_type;
        v17 = (Actor *)((char *)v17 + 2);
        ++v16;
      }
      while ( v17 != v15 );
    }
    operator delete(this->m_actarray_begin);
    this->m_actarray_capacity_end = (Actor *)((char *)dwVala + 2 * v34);
    v18 = (Actor *)this->m_actarray_begin;
    if ( v18 )
    {
      v19 = (Actor *)this->m_actarray_end;
      this->m_actarray_begin = dwVala;
      result = (_WORD *)(&dwVala->m_actarray_type + 2 * dwVal + 2 * (((char *)v19 - (char *)v18) >> 1));
    }
    else
    {
      this->m_actarray_begin = dwVala;
      result = (_WORD *)(&dwVala->m_actarray_type + 2 * dwVal);
    }
    this->m_actarray_end = (Actor *)result;
  }
  return result;
}

// 0x0053A8D0
unsigned int Actor::ActVec_InsertN(char *pszBuf, unsigned int nX, char *nY)
{
  Actor *m_actarray_end; // edi
  unsigned int v5; // esi
  Actor *m_actarray_begin; // ecx
  unsigned int v7; // ebx
  int v8; // edx
  unsigned int v9; // eax
  int v10; // ebp
  char *i; // edi
  int j; // edi
  char *v13; // edi
  char *v14; // eax
  char *p_m_actarray_type; // ebp
  Actor *v16; // ebp
  Actor *k; // edi
  Actor *v18; // eax
  int v19; // edx
  unsigned int v20; // esi
  unsigned int result; // eax
  char *v23; // ebx
  Actor *v24; // edi
  unsigned int v25; // esi
  char *v26; // ebx
  Actor *v27; // ebx
  int v28; // esi
  Actor *v29; // edi
  int *v30; // ebx
  char *p_m_nPathBuffer; // edx
  int *v32; // eax
  char *v33; // ebx
  Actor *v34; // [esp+0x10] [ebp-0xC]
  Actor *v35; // [esp+0x14] [ebp-0x8]
  Actor *v36; // [esp+0x14] [ebp-0x8]
  Actor *v37; // [esp+0x18] [ebp-0x4]
  char *pszBufa; // [esp+0x20] [ebp+0x4]
  unsigned int pszBufb; // [esp+0x20] [ebp+0x4]
  char *nXa; // [esp+0x24] [ebp+0x8]
  Actor *nXb; // [esp+0x24] [ebp+0x8]
  int *nXc; // [esp+0x24] [ebp+0x8]
  char *nXd; // [esp+0x24] [ebp+0x8]
  char *nYa; // [esp+0x28] [ebp+0xC]

  m_actarray_end = (Actor *)this->m_actarray_end;
  v5 = nX;
if ( ((char *)this->m_actarray_capacity_end - (char *)m_actarray_end) / 164 >= nX )
  {
    result = (unsigned int)((unsigned __int64)(1676084799i64 * ((char *)m_actarray_end - pszBuf)) >> 32) >> 31;
    if ( ((char *)m_actarray_end - pszBuf) / 164 >= nX )
    {
      if ( nX )
      {
        v27 = (Actor *)this->m_actarray_end;
        result = 164 * nX;
        v28 = (int)m_actarray_end - 164 * nX;
        pszBufb = 164 * nX;
        if ( (Actor *)v28 != m_actarray_end )
        {
          do
          {
            (((VideoPlayer *)v27))->VideoPlayer::SetRegion(v28);
            v28 += 164;
            v27 = (Actor *)((char *)v27 + 164);
          }
          while ( (Actor *)v28 != m_actarray_end );
          this = v34;
          result = 164 * nX;
        }
        v29 = (Actor *)this->m_actarray_end;
        v30 = (int *)((char *)v29 - result);
        if ( pszBuf != (char *)v29 - result )
        {
          p_m_nPathBuffer = (char *)&v29->m_nPathBuffer;
          v32 = (int *)(v30 + 37);
          while ( 1 )
          {
            v30 -= 41;
            nXc = (int *)(v32 - 41);
            qmemcpy(&v29[-1].m_fDistAccum, v30, 0x84u);
            v36 = (Actor *)(p_m_nPathBuffer - 164);
            (((Actor *)(p_m_nPathBuffer - 180)))->Actor::ActArray_Assign(v32 - 45);
            (((Actor *)v36))->Actor::BoneIndexVec_Assign(nXc);
            if ( v30 == (int *)pszBuf )
              break;
            v32 = (int *)nXc;
            p_m_nPathBuffer = (char *)&v36->m_actarray_type;
            v29 = (Actor *)((char *)v29 - 164);
          }
          this = v34;
          result = pszBufb;
        }
        v33 = (char *)pszBuf;
        nXd = (char *)&pszBuf[result];
        if ( pszBuf != &pszBuf[result] )
        {
          do
          {
            qmemcpy(v33, nY, 0x84u);
            (((Actor *)(v33 + 132)))->Actor::ActArray_Assign((int *)nY + 33);
            (((Actor *)(v33 + 148)))->Actor::BoneIndexVec_Assign((int *)nY + 37);
            v33 += 164;
          }
          while ( v33 != nXd );
          this = v34;
          result = pszBufb;
        }
        this->m_actarray_end = (Actor *)((char *)this->m_actarray_end + result);
      }
    }
    else
    {
      v23 = (char *)pszBuf;
      pszBufa = (char *)(164 * nX);
      if ( pszBuf != (char *)m_actarray_end )
      {
        nXa = (char *)&pszBuf[164 * nX];
        do
        {
          (((VideoPlayer *)nXa))->VideoPlayer::SetRegion((int)v23);
          v23 += 164;
          nXa += 164;
        }
        while ( v23 != (char *)m_actarray_end );
        this = v34;
      }
      v24 = (Actor *)this->m_actarray_end;
      v25 = v5 - ((char *)v24 - pszBuf) / 164;
      if ( v25 )
      {
        do
        {
          (((VideoPlayer *)v24))->VideoPlayer::SetRegion((int)nY);
          v24 = (Actor *)((char *)v24 + 164);
          --v25;
        }
        while ( v25 );
        this = v34;
      }
      v26 = (char *)pszBuf;
      nXb = (Actor *)this->m_actarray_end;
      if ( pszBuf != (char *)nXb )
      {
        do
        {
          qmemcpy(v26, nY, 0x84u);
          (((Actor *)(v26 + 132)))->Actor::ActArray_Assign((int *)nY + 33);
          (((Actor *)(v26 + 148)))->Actor::BoneIndexVec_Assign((int *)nY + 37);
          v26 += 164;
        }
        while ( v26 != (char *)nXb );
        this = v34;
      }
      result = (unsigned int)&pszBufa[(unsigned int)this->m_actarray_end];
      this->m_actarray_end = (Actor *)result;
    }
  }
  else
  {
    m_actarray_begin = (Actor *)this->m_actarray_begin;
    if ( !m_actarray_begin || (v7 = ((char *)m_actarray_end - (char *)m_actarray_begin) / 164, nX >= v7) )
      v7 = nX;
    if ( m_actarray_begin )
      v8 = ((char *)m_actarray_end - (char *)m_actarray_begin) / 164;
    else
      v8 = 0;
    v9 = v8 + v7;
    v35 = (Actor *)(v8 + v7);
    if ( (int)(v8 + v7) < 0 )
      v9 = 0;
    v37 = (Actor *)operator new(164 * v9);
    v10 = (int)v37;
    for ( i = (char *)&this->m_actarray_begin->m_actarray_type; i != pszBuf; v10 += 164 )
    {
      (((VideoPlayer *)v10))->VideoPlayer::SetRegion((int)i);
      i += 164;
    }
    for ( j = v10; nX; --nX )
    {
      (((VideoPlayer *)j))->VideoPlayer::SetRegion((int)nY);
      j += 164;
    }
    v13 = (char *)pszBuf;
    v14 = (char *)(v10 + 164 * v5);
    p_m_actarray_type = (char *)&this->m_actarray_end->m_actarray_type;
    if ( pszBuf != p_m_actarray_type )
    {
      nYa = (char *)v14;
      do
      {
        (((VideoPlayer *)nYa))->VideoPlayer::SetRegion((int)v13);
        v13 += 164;
        nYa += 164;
      }
      while ( v13 != p_m_actarray_type );
    }
    v16 = (Actor *)this->m_actarray_end;
    for ( k = this->m_actarray_begin; k != v16; k = (Actor *)((char *)k + 164) )
      (((Actor *)k))->Actor::ClearAllocBuffers();
    operator delete(this->m_actarray_begin);
    this->m_actarray_capacity_end = (Actor *)((char *)v37 + 164 * (_DWORD)v35);
    v18 = (Actor *)this->m_actarray_begin;
    if ( v18 )
      v19 = ((char *)this->m_actarray_end - (char *)v18) / 164;
    else
      v19 = 0;
    v20 = v19 + v5;
    this->m_actarray_begin = v37;
    result = 41 * v20;
    this->m_actarray_end = (Actor *)((char *)v37 + 164 * v20);
  }
  return result;
}

// 0x0053ACA0
char * Actor::ActVec_InsertRange(
        
        char *pszBuf,
        unsigned int dwVal,
        const void *pData,
        unsigned int nSize)
{
  unsigned int v5; // esi
  Actor *v6; // edi
  char *result; // eax
  Actor *m_actarray_begin; // edx
  unsigned int v9; // ecx
  int v10; // eax
  int v11; // eax
  Actor *v12; // edx
  Actor *i; // eax
  Actor *v14; // eax
  unsigned int v15; // ebx
  char *v16; // ebp
  char *v17; // ebx
  char *v18; // eax
  Actor *v19; // ecx
  Actor *v20; // eax
  char *v22; // edx
  char *v23; // ebx
  Actor *v24; // eax
  unsigned int v25; // esi
  unsigned int v26; // edx
  char *p_m_actarray_type; // edx
  char *v28; // eax
  char *v29; // edi
  unsigned int v30; // esi
  Actor *m_actarray_end; // ebx
  char *v32; // edx
  Actor *v33; // edx
  char *v34; // eax
  char *v35; // eax
  char *v36; // edi
  int v38; // [esp+0x14] [ebp-0x8]
  Actor *v39; // [esp+0x18] [ebp-0x4]
  char *pszBufa; // [esp+0x20] [ebp+0x4]

  v5 = dwVal;
result = (char *)&this->m_actarray_end->m_actarray_type;
  if ( ((char *)this->m_actarray_capacity_end - result) >> 6 >= dwVal )
  {
    if ( (result - pszBuf) >> 6 >= dwVal )
    {
      if ( !dwVal )
        return result;
      v30 = dwVal << 6;
      m_actarray_end = (Actor *)this->m_actarray_end;
      v32 = (char *)&result[-64 * dwVal];
      pszBufa = (char *)(dwVal << 6);
      if ( v32 != result )
      {
        do
        {
          if ( m_actarray_end )
          {
            qmemcpy(m_actarray_end, v32, 0x40u);
}
          v32 += 64;
          m_actarray_end = (Actor *)((char *)m_actarray_end + 64);
        }
        while ( v32 != result );
        v30 = dwVal << 6;
      }
      v33 = (Actor *)this->m_actarray_end;
      v34 = (char *)(&v33->m_actarray_type - v30);
      if ( pszBuf != (char *)v33 - v30 )
      {
        do
        {
          v34 -= 64;
          v33 = (Actor *)((char *)v33 - 64);
          qmemcpy(v33, v34, 0x40u);
        }
        while ( v34 != pszBuf );
}
      v35 = (char *)pszBuf;
      if ( pszBuf == &pszBuf[(_DWORD)pszBufa] )
        goto LABEL_54;
      do
      {
        v36 = (char *)v35;
        v35 += 64;
        qmemcpy(v36, pData, 0x40u);
      }
      while ( v35 != &pszBuf[(_DWORD)pszBufa] );
    }
    else
    {
      pszBufa = (char *)(dwVal << 6);
      v22 = (char *)&pszBuf[64 * dwVal];
      if ( pszBuf != result )
      {
        v23 = (char *)pszBuf;
        do
        {
          if ( v22 )
          {
            qmemcpy(v22, v23, 0x40u);
v5 = dwVal;
          }
          v23 += 64;
          v22 += 64;
        }
        while ( v23 != result );
      }
      v24 = (Actor *)this->m_actarray_end;
      v25 = v5 - (((char *)v24 - pszBuf) >> 6);
      if ( v25 )
      {
        v26 = v25;
        do
        {
          if ( v24 )
          {
            qmemcpy(v24, pData, 0x40u);
}
          v24 = (Actor *)((char *)v24 + 64);
          --v26;
        }
        while ( v26 );
      }
      p_m_actarray_type = (char *)&this->m_actarray_end->m_actarray_type;
      v28 = (char *)pszBuf;
      if ( pszBuf == p_m_actarray_type )
        goto LABEL_54;
      do
      {
        v29 = (char *)v28;
        v28 += 64;
        qmemcpy(v29, pData, 0x40u);
      }
      while ( v28 != p_m_actarray_type );
    }
LABEL_54:
    result = (char *)&pszBufa[(unsigned int)this->m_actarray_end];
    this->m_actarray_end = (Actor *)result;
    return result;
  }
  m_actarray_begin = (Actor *)this->m_actarray_begin;
  if ( !m_actarray_begin || (v9 = (result - (char *)m_actarray_begin) >> 6, dwVal >= v9) )
    v9 = dwVal;
  if ( m_actarray_begin )
    v10 = (result - (char *)m_actarray_begin) >> 6;
  else
    v10 = 0;
  v11 = v9 + v10;
  v38 = v11;
  if ( v11 < 0 )
    v11 = 0;
  v39 = (Actor *)operator new(v11 << 6);
  v12 = (Actor *)v39;
  for ( i = this->m_actarray_begin; i != (Actor *)pszBuf; v12 = (Actor *)((char *)v12 + 64) )
  {
    if ( v12 )
    {
      qmemcpy(v12, i, 0x40u);
v5 = dwVal;
    }
    i = (Actor *)((char *)i + 64);
  }
  v14 = (Actor *)v12;
  if ( v5 )
  {
    v15 = v5;
    do
    {
      if ( v14 )
      {
        qmemcpy(v14, pData, 0x40u);
v5 = dwVal;
      }
      v14 = (Actor *)((char *)v14 + 64);
      --v15;
    }
    while ( v15 );
  }
  v16 = (char *)&this->m_actarray_end->m_actarray_type;
  v17 = (char *)(&v12->m_actarray_type + 64 * v5);
  if ( pszBuf != v16 )
  {
    v18 = (char *)pszBuf;
    do
    {
      if ( v17 )
      {
        qmemcpy(v17, v18, 0x40u);
v5 = dwVal;
      }
      v18 += 64;
      v17 += 64;
    }
    while ( v18 != v16 );
  }
  operator delete(this->m_actarray_begin);
  v19 = (Actor *)this->m_actarray_begin;
  this->m_actarray_capacity_end = (Actor *)((char *)v39 + 64 * v38);
  if ( v19 )
  {
    v20 = (Actor *)this->m_actarray_end;
    this->m_actarray_begin = v39;
    result = (char *)(&v39->m_actarray_type + 64 * (v5 + (((char *)v20 - (char *)v19) >> 6)));
  }
  else
  {
    this->m_actarray_begin = v39;
    result = (char *)(&v39->m_actarray_type + 64 * v5);
  }
  this->m_actarray_end = (Actor *)result;
  return result;
}

// 0x0053AF30
int Actor::FindMatchingEntry(int nY, int nVal, int nX)
{
  int v4; // esi
  int v5; // edi

  v4 = nY;
  if ( nY == nVal )
    return nX;
  v5 = nX;
  do
  {
    (((VideoPlayer *)v5))->VideoPlayer::SetRegion(v4);
    v4 += 164;
    v5 += 164;
  }
  while ( v4 != nVal );
  return v5;
}

// 0x0053AF70
void Actor::SetVideoRegions(int nX, int nVal, int nY)
{
  int i; // edi

  for ( i = nVal; i; --i )
  {
    (((VideoPlayer *)nX))->VideoPlayer::SetRegion(nY);
    nX += 164;
  }
}

// 0x0053AFA0
char * Actor::CopyBufferBlocks(char *pszDst, char *pszSrc, char *pszBuf3)
{
  char *v4; // edx
  char *result; // eax

  v4 = (char *)pszDst;
  if ( pszDst == pszSrc )
    return pszBuf3;
  result = (char *)pszBuf3;
  do
  {
    if ( result )
      qmemcpy(result, v4, 0x40u);
    v4 += 64;
    result += 64;
  }
  while ( v4 != pszSrc );
  return result;
}

// 0x0053AFE0
char * Actor::CopyIfValid(char *pszBuf, char *pszBuf2, const void *pData)
{
  char *result; // eax
  char *v5; // edx

  result = (char *)pszBuf2;
  if ( pszBuf2 )
  {
    v5 = (char *)pszBuf2;
    result = (char *)pszBuf;
    do
    {
      if ( result )
        qmemcpy(result, pData, 0x40u);
      result += 64;
      --v5;
    }
    while ( v5 );
  }
  return result;
}

// 0x0053B230
int Actor::GetCount()
{
  int result; // eax

  result = (int)this->m_actarray_begin;
  if ( result )
    return ((int)this->m_actarray_end - result) / 656;
  return result;
}

// 0x0053B260
char * Actor::CompareBuffers(char *pszBuf, char *pszBuf2, char *pszBuf3)
{
  char *v4; // edx
  char *result; // eax

  v4 = (char *)pszBuf;
  if ( pszBuf == pszBuf2 )
    return pszBuf3;
  result = (char *)pszBuf3;
  do
  {
    if ( result )
      qmemcpy(result, v4, 0x290u);
    v4 += 656;
    result += 656;
  }
  while ( v4 != pszBuf2 );
  return result;
}

// 0x0053B2A0
int * Actor::SelectPointer(int *pnVal, int *pnVal2, int *pnVal3)
{
  int *v3; // ecx
  int *result; // eax
  int v5; // esi

  v3 = (int *)pnVal;
  if ( pnVal == pnVal2 )
    return pnVal3;
  result = (int *)pnVal3;
  do
  {
    v5 = (unsigned long)(*v3++);
    *result++ = v5;
  }
  while ( v3 != pnVal2 );
  return result;
}

// 0x0053B6E0
void Actor::CopyConstruct_1C(void *pDst, const void *pSrc)
{
  if ( pDst )
    qmemcpy(pDst, pSrc, 0x1Cu);
}

// 0x0053B700
void Actor::CopyConstruct_290(void *pDst, const void *pSrc, int nVal)
{
  if ( pDst )
    qmemcpy(pDst, pSrc, 0x290u);
}

// 0x0053B870
void Actor::CopyConstruct_40(void *pDst, const void *pSrc, int nVal)
{
  if ( pDst )
    qmemcpy(pDst, pSrc, 0x40u);
}

// 0x0053B890
char * Actor::SetCurrentAction(int nVal)
{
  int v4; // ebx
  Actor **p_m_actarray_begin; // eax
  int *p_m_nCachedA; // eax
  int v7; // ecx
  _BYTE *v8; // eax
  int v9; // ecx
  gbVec3D *p_m_vecBonePos; // ebp
  signed __int16 *v11; // eax
  float *p_m_fActionAssignParam; // eax
  float *p_m_fFacingAngle; // eax
  int v14; // ecx
  int v16; // [esp+0x10] [ebp-0x4]
  int nVala; // [esp+0x18] [ebp+0x4]

  v4 = nVal - (_DWORD)this;
  *(_DWORD *)&this->m_actarray_type = *(_DWORD *)nVal;
  p_m_actarray_begin = (Actor **)&this->m_actarray_begin;
  do
  {
    *(_BYTE *)p_m_actarray_begin = *((_BYTE *)p_m_actarray_begin + v4);
    p_m_actarray_begin = (Actor **)((char *)p_m_actarray_begin + 1);
  }
  while ( (unsigned int)p_m_actarray_begin - 4 - (unsigned int)this < 0x20 );
  LOBYTE(this->m_pAllocBuf) = *(_BYTE *)(nVal + 36);
  BYTE1(this->m_pAllocBuf) = *(_BYTE *)(nVal + 37);
  this->m_fTransitionSpeed = *(float *)(nVal + 40);
  this->m_fTransitionPos = *(float *)(nVal + 44);
  this->m_nRoleParam0 = *(_DWORD *)(nVal + 48);
  this->m_fRoleParam1 = *(float *)(nVal + 52);
  this->m_fRoleParam = *(float *)(nVal + 56);
  this->m_fRoleParam2 = *(float *)(nVal + 60);
  this->m_fRoleParam3 = *(float *)(nVal + 64);
  this->m_nRoleParam2 = *(_DWORD *)(nVal + 68);
  this->m_pRoleParam3 = *(char **)(nVal + 72);
  p_m_nCachedA = (int *)&this->m_nCachedA;
  v7 = 6;
  do
  {
    *p_m_nCachedA = *(int *)((char *)p_m_nCachedA + v4);
    ++p_m_nCachedA;
    --v7;
  }
  while ( v7 );
  LOBYTE(this->m_szText) = *(_BYTE *)(nVal + 100);
  HIWORD(this->m_szText) = *(_WORD *)(nVal + 102);
  *((_WORD *)&this->m_szText + 2) = *(_WORD *)(nVal + 104);
  *((_WORD *)&this->m_szText + 3) = *(_WORD *)(nVal + 106);
  *((_WORD *)&this->m_szText + 4) = *(_WORD *)(nVal + 108);
  *((_BYTE *)&this->m_szText + 10) = *(_BYTE *)(nVal + 110);
  v8 = (char *)&this->m_szText + 11;
  do
  {
    *v8 = v8[v4];
    ++v8;
  }
  while ( (unsigned int)&v8[-111 - (_DWORD)this] < 0x10 );
  this->m_nAnimParam0 = *(_DWORD *)(nVal + 128);
  v9 = nVal - (_DWORD)this;
  this->m_nAnimParam1 = *(_DWORD *)(nVal + 132);
  p_m_vecBonePos = (gbVec3D *)&this->m_vecBonePos;
  v16 = nVal - (_DWORD)this;
  nVala = 16;
  while ( 1 )
  {
    (((gbVec3D *)p_m_vecBonePos))->gbVec3D::operator=((char *)p_m_vecBonePos + v9);
    ++p_m_vecBonePos;
    if ( !--nVala )
      break;
    v9 = v16;
  }
  this->m_nAnimState = *(_WORD *)(nVal + 328);
  v11 = (signed __int16 *)(&this->m_nAnimState + 1);
  do
  {
    *(_BYTE *)v11 = *((_BYTE *)v11 + v4);
    v11 = (signed __int16 *)((char *)v11 + 1);
  }
  while ( (unsigned int)v11 - 330 - (unsigned int)this < 0x20 );
  BYTE2(this->m_nHandleEvent) = *(_BYTE *)(nVal + 362);
  gbVec3D::operator=(&this->m_vecPos, nVal + 364);
  gbVec3D::operator=(&this->m_vecRot, nVal + 376);
  this->m_nCloneParam = *(_DWORD *)(nVal + 388);
  p_m_fActionAssignParam = (float *)&this->m_fActionAssignParam;
  do
  {
    *(_BYTE *)p_m_fActionAssignParam = *((_BYTE *)p_m_fActionAssignParam + v4);
    p_m_fActionAssignParam = (float *)((char *)p_m_fActionAssignParam + 1);
  }
  while ( (unsigned int)p_m_fActionAssignParam - 392 - (unsigned int)this < 8 );
  this->m_nCloneState = *(_DWORD *)(nVal + 400);
  this->m_nCloneFlag1 = *(_DWORD *)(nVal + 404);
  this->m_nCloneFlag2 = *(_DWORD *)(nVal + 408);
  p_m_fFacingAngle = (float *)&this->m_fFacingAngle;
  v14 = 52;
  do
  {
    *p_m_fFacingAngle = *(float *)((char *)p_m_fFacingAngle + v4);
    ++p_m_fFacingAngle;
    --v14;
  }
  while ( v14 );
  *(_DWORD *)&this->m_curact[35] = *(_DWORD *)(nVal + 620);
  *(_DWORD *)&this->m_curact[39] = *(_DWORD *)(nVal + 624);
  this->_overlap_RoleSystem_m_partyActor_m_nState = *(_DWORD *)(nVal + 628);
  this->m_fDirX = *(float *)(nVal + 632);
  gbVec3D::operator=(&this->m_fDirY, nVal + 636);
  LOBYTE(this->m_fNormY) = *(_BYTE *)(nVal + 648);
  BYTE1(this->m_fNormY) = *(_BYTE *)(nVal + 649);
  this->m_fNormZ = *(float *)(nVal + 652);
  return &this->m_actarray_type;
}

// 0x0053BAE0
int * Actor::ActArray_Assign(int *p_DWORD)
{
  Actor *v3; // esi
  int v4; // edi
  unsigned int v5; // ebp
  Actor *m_actarray_begin; // ecx
  unsigned int v7; // edx
  int v8; // esi
  Actor *v9; // ebp
  int v10; // eax
  int v11; // edx
  int *result; // eax
  unsigned int v13; // ebp
  unsigned int v14; // edx
  int v15; // edx
  Actor *v16; // ebp
  char *j; // esi
  int v18; // ebp
  int *v19; // ecx
  char *v20; // eax
  Actor *k; // edx
  int v22; // eax
  int v23; // edx
  int v24; // eax
  int v25; // edx
  int v26; // eax
  Actor *v27; // eax
  int v28; // ebp
  Actor *v29; // edx
  char *i; // eax
  int *p_DWORDa; // [esp+0x18] [ebp+0x4]
if ( this == (Actor *)p_DWORD )
    return (int *)v3;
  v4 = (unsigned long)p_DWORD[1];
  if ( v4 )
    v5 = (p_DWORD[2] - v4) / 656;
  else
    v5 = 0;
  m_actarray_begin = (Actor *)this->m_actarray_begin;
  if ( m_actarray_begin )
    v7 = ((char *)this->m_actarray_end - (char *)m_actarray_begin) / 656;
  else
    v7 = 0;
  if ( v5 <= v7 )
  {
    v8 = (unsigned long)p_DWORD[1];
    p_DWORDa = (int *)p_DWORD[2];
    v9 = (Actor *)m_actarray_begin;
    if ( (int *)v4 != p_DWORDa )
    {
      do
      {
        (((Actor *)v9))->Actor::SetCurrentAction(v8);
        v8 += 656;
        v9 = (Actor *)((char *)v9 + 656);
      }
      while ( (int *)v8 != p_DWORDa );
    }
    v10 = (unsigned long)p_DWORD[1];
    if ( v10 )
      v11 = (p_DWORD[2] - v10) / 656;
    else
      v11 = 0;
    result = (int *)this;
    this->m_actarray_end = (Actor *)((char *)this->m_actarray_begin + 656 * v11);
    return result;
  }
  if ( v4 )
    v13 = (p_DWORD[2] - v4) / 656;
  else
    v13 = 0;
  if ( m_actarray_begin )
    v14 = ((char *)this->m_actarray_capacity_end - (char *)m_actarray_begin) / 656;
  else
    v14 = 0;
  if ( v13 > v14 )
  {
    operator delete(this->m_actarray_begin);
    v24 = (unsigned long)p_DWORD[1];
    if ( v24 )
      v25 = (p_DWORD[2] - v24) / 656;
    else
      v25 = 0;
    v26 = v25;
    if ( v25 < 0 )
      v26 = 0;
    v27 = (Actor *)operator new(656 * v26);
    this->m_actarray_begin = v27;
    v28 = (unsigned long)p_DWORD[2];
    v29 = (Actor *)v27;
    for ( i = (char *)p_DWORD[1]; i != (char *)v28; v29 = (Actor *)((char *)v29 + 656) )
    {
      if ( v29 )
      {
        qmemcpy(v29, i, 0x290u);
}
      i += 656;
    }
    this->m_actarray_end = v29;
    this->m_actarray_capacity_end = v29;
    return (int *)v3;
  }
  if ( m_actarray_begin )
    v15 = ((char *)this->m_actarray_end - (char *)m_actarray_begin) / 656;
  else
    v15 = 0;
  v16 = (Actor *)this->m_actarray_begin;
  for ( j = (char *)(v4 + 656 * v15); (char *)v4 != j; v16 = (Actor *)((char *)v16 + 656) )
  {
    (((Actor *)v16))->Actor::SetCurrentAction(v4);
    v4 += 656;
  }
  v18 = (unsigned long)p_DWORD[2];
  v19 = (int *)this;
  v20 = (char *)j;
  for ( k = this->m_actarray_end; v20 != (char *)v18; k = (Actor *)((char *)k + 656) )
  {
    if ( k )
    {
      qmemcpy(k, v20, 0x290u);
      v19 = (int *)this;
    }
    v20 += 656;
  }
  v22 = (unsigned long)p_DWORD[1];
  if ( v22 )
    v23 = (p_DWORD[2] - v22) / 656;
  else
    v23 = 0;
  result = (int *)v19;
  v19[2] = (unsigned long)(v19[1] + 656 * v23);
  return result;
}

// 0x0053BD30
int * Actor::BoneIndexVec_Assign(int *pnVal)
{
  __int16 *v3; // eax
  unsigned int v4; // edi
  Actor *m_actarray_begin; // edx
  unsigned int v6; // ecx
  int i; // ecx
  __int16 v8; // di
  int v9; // eax
  Actor *v10; // ecx
  int *result; // eax
  unsigned int v12; // edi
  unsigned int v13; // ecx
  int v14; // ecx
  __int16 *k; // ecx
  __int16 v16; // di
  int v17; // edi
  Actor *m_actarray_end; // edx
  __int16 *m; // eax
  int v20; // eax
  int v21; // ecx
  int v22; // eax
  Actor *v23; // eax
  int v24; // edx
  Actor *v25; // ecx
  _WORD *j; // eax

  if ( this == (Actor *)pnVal )
    return (int *)this;
  v3 = (__int16 *)pnVal[1];
  if ( v3 )
    v4 = (pnVal[2] - (int)v3) >> 1;
  else
    v4 = 0;
  m_actarray_begin = (Actor *)this->m_actarray_begin;
  if ( m_actarray_begin )
    v6 = ((char *)this->m_actarray_end - (char *)m_actarray_begin) >> 1;
  else
    v6 = 0;
  if ( v4 <= v6 )
  {
    for ( i = pnVal[2]; v3 != (__int16 *)i; m_actarray_begin = (Actor *)((char *)m_actarray_begin + 2) )
    {
      v8 = *v3++;
      *(_WORD *)&m_actarray_begin->m_actarray_type = v8;
    }
    v9 = (unsigned long)pnVal[1];
    if ( v9 )
      v10 = (Actor *)((char *)this->m_actarray_begin + 2 * ((pnVal[2] - v9) >> 1));
    else
      v10 = (Actor *)this->m_actarray_begin;
    result = (int *)this;
    this->m_actarray_end = v10;
    return result;
  }
  if ( v3 )
    v12 = (pnVal[2] - (int)v3) >> 1;
  else
    v12 = 0;
  if ( m_actarray_begin )
    v13 = ((char *)this->m_actarray_capacity_end - (char *)m_actarray_begin) >> 1;
  else
    v13 = 0;
  if ( v12 > v13 )
  {
    operator delete(this->m_actarray_begin);
    v21 = (unsigned long)pnVal[1];
    if ( v21 )
      v22 = (pnVal[2] - v21) >> 1;
    else
      v22 = 0;
    if ( v22 < 0 )
      v22 = 0;
    v23 = (Actor *)operator new(2 * v22);
    this->m_actarray_begin = v23;
    v24 = (unsigned long)pnVal[2];
    v25 = (Actor *)v23;
    for ( j = (_WORD *)pnVal[1]; j != (_WORD *)v24; v25 = (Actor *)((char *)v25 + 2) )
    {
      if ( v25 )
        *(_WORD *)&v25->m_actarray_type = *j;
      ++j;
    }
    this->m_actarray_end = v25;
    this->m_actarray_capacity_end = v25;
    return (int *)this;
  }
  if ( m_actarray_begin )
    v14 = ((char *)this->m_actarray_end - (char *)m_actarray_begin) >> 1;
  else
    v14 = 0;
  for ( k = &v3[v14]; v3 != k; m_actarray_begin = (Actor *)((char *)m_actarray_begin + 2) )
  {
    v16 = *v3++;
    *(_WORD *)&m_actarray_begin->m_actarray_type = v16;
  }
  v17 = (unsigned long)pnVal[2];
  m_actarray_end = (Actor *)this->m_actarray_end;
  for ( m = k; m != (__int16 *)v17; m_actarray_end = (Actor *)((char *)m_actarray_end + 2) )
  {
    if ( m_actarray_end )
      *(_WORD *)&m_actarray_end->m_actarray_type = *m;
    ++m;
  }
  v20 = (unsigned long)pnVal[1];
  if ( v20 )
    this->m_actarray_end = (Actor *)((char *)this->m_actarray_begin + 2 * ((pnVal[2] - v20) >> 1));
  else
    this->m_actarray_end = this->m_actarray_begin;
  return (int *)this;
}

// 0x0053BEB0
int Actor::GetActionCountEx()
{
  int result; // eax

  result = (int)this->m_actarray_begin;
  if ( result )
    return ((int)this->m_actarray_capacity_end - result) / 656;
  return result;
}
