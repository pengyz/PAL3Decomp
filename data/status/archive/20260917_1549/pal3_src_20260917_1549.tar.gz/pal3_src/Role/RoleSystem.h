#pragma once
// Auto-generated: RoleSystem
#include "pal3/ida_types.h"

#include "Role/Actor.h"
#include "Misc/UIFrameWnd.h"
#include "UI/UIItem.h"
#include "UI/UIWnd.h"
#include "gbengine/gbGeomNode.h"
#include "gbengine/gbengine_internal.h"
#include "gbengine/gbengine_types.h"
#include "gbengine/gbengine_types.h"

#include "Misc/tagTeamSlotsBOverlay.h"
class Object3D;

class RoleSystem : public UIWnd {
public:
    char _gap_000[68]; // +0x0
    char * m_pVtable; // +0x44
    float m_fStateX; // +0x48
    float m_fStateY; // +0x4C
    BYTE m_nStateMode; // +0x50
    char _gap_051[3]; // +0x51
    int m_nTimerDuration; // +0x54
    float m_fDirX; // +0x58
    float m_fDirY; // +0x5C
    float m_fDirZ; // +0x60
    char * m_pPathPoints; // +0x64
    int m_nPathCount; // +0x68
    char * m_pPathCurrent; // +0x6C
    char * m_pPathNext; // +0x70
    int m_nTodo_074; // +0x74
    int m_nPathFlag; // +0x78
    int m_nPathField7C; // +0x7C
    float m_fMoveX; // +0x80
    int m_nPathState; // +0x84
    float m_fMoveZ; // +0x88
    char * m_pPathListHead; // +0x8C
    int m_nActionResult; // +0x90
    int m_nDispFontColor; // +0x94
    int m_nDispWndColor; // +0x98
    int m_nField9C; // +0x9C
    float m_fPosX; // +0xA0
    float m_fPosY; // +0xA4
    float m_fPosZ; // +0xA8
    char m_nFacing; // +0xAC
    char m_nActionState; // +0xAD
    char m_nAnimState; // +0xAE
    BYTE m_bActionPause; // +0xAF
    int m_szModelName; // +0xB0
    int m_mapData; // +0xB4
    float m_fScale; // +0xB8
    int m_nImageIdx; // +0xBC
    float m_fMoveSpd; // +0xC0
    char _gap_0C4[10]; // +0xC4
    BYTE m_byStateArray; // +0xCE
    char _gap_0CF[1]; // +0xCF
    char m_bFlags; // +0xD0
    BYTE m_bActionState; // +0xD1
    char _gap_0D2[6]; // +0xD2
    float m_fAngle; // +0xD8
    float m_fTileHeight; // +0xDC
    int m_nSpawnData; // +0xE0
    int m_nActionType; // +0xE4
    int m_nActionStep; // +0xE8
    float m_fActionParam; // +0xEC
    BYTE m_nSpawnFlags; // +0xF0
    char _gap_0F1[3]; // +0xF1
    BYTE m_nRoleAction; // +0xF4
    char _gap_0F5[1]; // +0xF5
    BYTE m_nRoleSlot; // +0xF6
    char _gap_0F7[1]; // +0xF7
    float m_fWaypointX; // +0xF8
    float m_fWaypointZ; // +0xFC
    BYTE m_nActionParam; // +0x100
    char _gap_101[3]; // +0x101
    BYTE m_nInitMoveMode; // +0x104
    char _gap_105[3]; // +0x105
    int m_nSpawnExtra; // +0x108
    int m_nSpawnParam2; // +0x10C
    int m_szModelPath; // +0x110
    UIWnd * m_pWaypointWnd; // +0x114
    char _gap_118[8]; // +0x118
    int m_nParamArray; // +0x120
    char _gap_124[8]; // +0x124
    BYTE m_bSpawnByteA; // +0x12C
    BYTE m_bSpawnByteB; // +0x12D
    char _gap_12E[2]; // +0x12E
    int m_nSpawnParam; // +0x130
    int m_nActionTimer; // +0x134
    gbVec3D m_vecPosArray; // +0x138
    char _gap_144[4]; // +0x144
    int m_nMoveSrc; // +0x148
    int m_nMoveDst; // +0x14C
    int m_nMoveStep; // +0x150
    char _gap_154[12]; // +0x154
    int m_nSavedState; // +0x160
    int m_nVisState; // +0x164
    BYTE m_bVisFlag; // +0x168
    BYTE _gap_169[3]; // +0x169
    char * m_pWndFrame; // +0x16C
    int m_nTodo_170; // +0x170
    char _gap_174[8]; // +0x174
    int m_nActive; // +0x17C
    float m_fInactiveTime; // +0x180
    char _gap_184[12]; // +0x184
    void * m_pCmdQueue; // +0x190
    void * m_pCmdQueueEnd; // +0x194
    float m_fCmdInterval; // +0x198
    float m_fCmdTimer; // +0x19C
    char * m_pPathNodeIter; // +0x1A0
    int m_nCmdQueuePos; // +0x1A4
    Actor m_partyActor; // +0x1A8
    float m_fPathTargetY; // +0x4DC
    float m_fPathTargetZ; // +0x4E0
    float m_fPathAngle; // +0x4E4
    float m_fPathSpeed; // +0x4E8
    int m_nPrevMoveMode; // +0x4EC
    int m_nMoveMode; // +0x4F0
    int m_nMoveSubMode; // +0x4F4
    int m_nCollisionState; // +0x4F8
    int m_nCollisionParam; // +0x4FC
    BYTE m_bPathActive; // +0x500
    char _gap_501[3]; // +0x501
    int m_nCoreState; // +0x504
    int m_nTransformState; // +0x508
    float m_fMovement; // +0x50C
    float m_fRotAxisX; // +0x510
    float m_fRotAxisY; // +0x514
    float m_fRotAxisZ; // +0x518
    int m_nMovement; // +0x51C
    float m_fSavedRotX; // +0x520
    UIFrameWnd m_FrameA; // +0x524
    int m_nActiveRole; // +0x56C
    int m_nRoleCount; // +0x570
    int m_nAnimation; // +0x574
    int m_nAnimCopy1; // +0x578
    int m_nAnimCopy2; // +0x57C
    int m_nAnimCopy3; // +0x580
    Object3D * m_pLinkedRole; // +0x584
    int m_nTransformMode; // +0x588
    char * m_pLinkedSystem; // +0x58C
    float m_fAnimSpeed; // +0x590
    float m_fMoveRadius; // +0x594
    float m_fMoveSpeed; // +0x598
    int m_nMoveReset; // +0x59C
    gbGeomNode * m_pRenderObj; // +0x5A0
    int m_bRenderFlag1; // +0x5A4
    char m_bRenderFlag2; // +0x5A8
    char _gap_5A9[3]; // +0x5A9
    int m_nTodo_5AC; // +0x5AC
    char * m_pCtrlPoint; // +0x5B0
    int m_nMoveRole; // +0x5B4
    int m_nRetryCount; // +0x5B8
    float m_fCachePosX; // +0x5BC
    float m_fCachePosY; // +0x5C0
    float m_fCachePosZ; // +0x5C4
    float m_fMoveTargetX; // +0x5C8
    int m_fMoveTargetY; // +0x5CC
    float m_fMoveTargetZ; // +0x5D0
    float m_fMoveRole; // +0x5D4
    float m_fMoveParamY; // +0x5D8
    float m_fMoveParamZ; // +0x5DC
    char _gap_5E0[60]; // +0x5E0
    int m_nTodo_61C; // +0x61C
    char _gap_620[4]; // +0x620
    UIWnd _embed_UIWnd_624; // +0x624
    char _gap_668[36]; // +0x668
    int m_nTodo_68C; // +0x68C
    float m_nTodo_690; // +0x690
    union { // +0x694
        int m_teamSlots[307]; // +0x694
        struct {
            char _gap_694[4];
            float m_fCBTimer; // +0x698
            int m_nTodo_69C; // +0x69C
            char _gap_6A0[72];
            float m_nTodo_6E8; // +0x6E8
            float m_nTodo_6EC; // +0x6EC
            float m_nTodo_6F0; // +0x6F0
            char _gap_6F4[8];
            float m_nTodo_6FC; // +0x6FC
            float m_nTodo_700; // +0x700
            float m_nTodo_704; // +0x704
            char _gap_708[752];
            float pfVal; // +0x9F8
            char m_CCBStageCamBuffer; // +0x9FC
        } m_state;
    } m_teamSlotOverlay;
    char _gap_B60[48]; // +0xB60
    int m_nTodo_B90; // +0xB90
    char _gap_B94[4]; // +0xB94
    int m_wndPanel; // +0xB98
    char _gap_B9C[16]; // +0xB9C
    UIWnd m_StaticSlotArray; // +0xBAC
    union { // +0xC00
        tagTeamSlotsBOverlay combat; // +0xC00
    } m_teamSlotsB;
    char _gap_F20[156]; // +0xF20
    int m_pScriptBuf; // +0xFBC
    char _gap_FC0[36]; // +0xFC0
    int m_nField_FE4; // +0xFE4
    char _gap_FE8[16]; // +0xFE8
    void * m_nTodo_FF8; // +0xFF8
    char _gap_FFC[4]; // +0xFFC
    int m_configData[96]; // +0x1000
    char _gap_1180[4]; // +0x1180
    int m_nTodo_1184; // +0x1184
    int m_nTodo_1188; // +0x1188
    int m_nMoveState1; // +0x118C
    int m_nMoveState2; // +0x1190
    int m_nMoveState3; // +0x1194
    BYTE m_bMoveFlag1; // +0x1198
    char _gap_1199[3]; // +0x1199
    int m_nMoveParam1; // +0x119C
    int m_nMoveParam2; // +0x11A0
    BYTE m_bMoveFlag2; // +0x11A4
    char _gap_11A5[3]; // +0x11A5
    UIItem m_partyUI3; // +0x11A8
    int m_teamData3[29]; // +0x1290
    // total size: 0x1304 (4868)

    virtual ~RoleSystem() {}

    virtual BOOL UpdateTimer(int nVal, int nVal2); // 0x00532710
    void * _scalar_dtor(UIWnd *Block, char pData); // 0x00531E50
    virtual int HandleMsgDLL(HINSTANCE hinstDLL, DWORD fdwReason, LPVOID lpvReserved); // 0x005329A0
    virtual void * AllocSlotData(int nVal); // 0x004202A0
    virtual void Reset(); // 0x004208A0
    virtual void ResetState(); // 0x004209E0
    BOOL CheckSceneCollision(int *nFlag, int nVal); // 0x004083E0
    int BindRoleToScene(int index, float *pfVal, float *pfVal2, int nVal, char pData); // 0x00408460
    int * Init(); // 0x0040BE50
    int RecalcAggregatedStats(char pData); // 0x0040BE80
    static int ForceStopRole(int nVal); // 0x0040C9A0
    static void RenderMainRole(void *pMatrixStack); // 0x00410430
    static int CheckVisible(); // 0x00410E40
    void ApplyMoveStep(double fInput, int nVal, float fVal, char bCollide); // 0x00411E00
    void SetMoveSpeed(float fSpeed, int nRoleIndex, int nFlag); // 0x00412230
    void UpdatePosition(); // 0x004122C0
    void RenderRole(gbMatrixStack *pStack, int nVal); // 0x00412400
    int NotifySceneChange(); // 0x004125B0
    static int GetAnimOffset(int nType, unsigned __int8 nMode); // 0x004126D0
    int UpdateTransform(); // 0x00412710
    int UpdatePath(int nVal); // 0x00412940
    int StartHalfSpeedMovement(); // 0x00412A50
    void MoveToTile(__int64 tileXY, int nMode); // 0x00412A90
    void SetMoveTarget(float *pTargetPos, int nFlags); // 0x00412B60
    int SetPathWaypoint(float fVal); // 0x00412C30
    char BindPartyToScene(float *pfVal, int nVal); // 0x00412D90
    int MoveRole(float *pPos, int nVal, int nVal2, int nVal3); // 0x00412E60
    char UpdateRole(float *pfVal, int nVal, int nVal2); // 0x00413010
    char MoveToTileCheck(int nTileX, int nTileY, int nMode); // 0x004132B0
    void InterpolateMoveFrame(float fVal); // 0x00413390
    int StepAlongPath(double fStepSize, float fVal); // 0x00413420
    double AdvanceToTarget(double fDelta); // 0x00413850
    int PlaceAtRegion(int nSceneIdx, int nRegion); // 0x00413C00
    void PathFollowUpdate(); // 0x00413CD0
    void NormalizeDirection(float *pfDir); // 0x00414250
    int NotifyMoveComplete(); // 0x004142E0
    double UpdateMovement(double result, gbVec3D *pB); // 0x00414350
    float * UpdateMoveInterpolation(float *pfVal, float *pfVal2); // 0x004148C0
    void GetPosition(float *pOut, int nVal); // 0x00414980
    void UpdateMoveTimer(); // 0x00414A10
    int PathFind(float *pTarget); // 0x00414A30
    int GetActionByIndex(int nParam); // 0x00414E30
    int PlayAction(char *pszAction, int nMode); // 0x00414F90
    void UpdateActionState(float fVal); // 0x004150C0
    static void ScaleVector(float *pVec, float fScale); // 0x004161E0
    void CheckMoveCollisionDist(int thisa, float *pfVal); // 0x00416220
    int CalcTileDistance(int nTileX, int nTileY); // 0x004163B0
    void SetTargetRotation(gbVec3D *pTarget); // 0x00416490
    BOOL IsPathMoving(); // 0x004164E0
    int IsActionBlocked(); // 0x00416500
    void IsPathComplete(float *pTargetPos, int nMode); // 0x00416550
    int UpdateMovement(float fDeltaTime, int nMode); // 0x00416620
    void UpdateAnimation(float *pfVal); // 0x00416790
    void ProcessInteraction(); // 0x00416BC0
    int GetActiveRole(); // 0x00416F10
    void InitPathTracking(float *nFlags); // 0x00416FA0
    void RestoreMoveMode(float *nFlags); // 0x00416FE0
    void SetupMoveState(float *pfVal); // 0x00417040
    void UpdateTransform(float arg0); // 0x00417420
    int EnterSubMode6(); // 0x00417850
    BOOL CheckVisibility(); // 0x004178A0
    void SetState(int state); // 0x00417AC0
    void StopAndResetPath(); // 0x00417BC0
    double UpdateMoveSubMode(double result, float result_4); // 0x00417C50
    int CheckWidgetReady(gbRay *pRay); // 0x004180B0
    int GetMoveState(); // 0x00418130
    int Notify(); // 0x004181E0
    void AddVec3ToTarget(int nVal, int nVal2); // 0x00418970
    int StartPathMove(char *pszBuf, int nVal, char *pszBuf2, int nVal2, float fVal, int nVal3); // 0x004189C0
    BOOL IsInBounds(int nVal, int nVal2); // 0x00418D90
    char TryMoveToTarget(__int16 pData, int nVal); // 0x00418DC0
    int ResetPathParams(int nVal); // 0x00419030
    int ProcessMoveCommand(int *p_DWORD); // 0x00419790
    void StartLinearMove(int *pTargetPos, int nMode); // 0x004198C0
    void GetActorState(double thisa, int nVal, int nVal2, int nVal3); // 0x00419A20
    int GetDirection(float *pOut); // 0x00419A80
    int NotifyAndSetMode6(); // 0x00419AE0
    __int64 SetCollisionRadius(); // 0x00419B10
    void UpdateFollowBehavior(float fDelta); // 0x00419B30
    BOOL AdvancePathStep(float *pfVal); // 0x00419EF0
    void SetActorTexture(const char *pszName); // 0x0041A150
    void ScanMoveDirections(float fRadius); // 0x0041A1A0
    void UpdateFollowerMovement(float fVal); // 0x0041A450
    void UpdateFollowVelocity(); // 0x0041ABE0
    void UpdateFollowVelocityEx(); // 0x0041AD40
    void SetBlendMode(float fAlpha); // 0x0041AEA0
    int SetTransform(int *p_DWORD); // 0x0041AEE0
    int AllocPathPage(int nVal, int nVal2); // 0x0041AF50
    int StopPathMovement(int nVal); // 0x0041B120
    int GetCurrentTile(); // 0x0041B300
    void LoadWeaponModel(char *pszRoleName); // 0x0041B420
    char ApproachTarget(int nVal); // 0x0041B6C0
    BOOL InterpolateHeight(float *pfVal); // 0x0041BA10
    int InitDefaultState(); // 0x0041BAD0
    int GetCount(); // 0x0041BBE0
    int ExportRoleData(float *pfVal); // 0x0041BC30
    int * ClearColors(_BYTE *p_BYTE); // 0x0041BD40
    const char * GetRoleName(unsigned int nRoleIndex); // 0x0041BD70
    int FlushCommandQueue(); // 0x0041C090
    int SetInactive(int nVal); // 0x0041C190
    int AddCameraKeyframe(); // 0x0041D220
    RoleSystem(); // 0x00420290
    virtual int sub_4202F0(); // 0x004202F0
    int GetCurrentID(int *pnVal, char pData); // 0x00420320
    void InitRoleImage(); // 0x004203C0
    unsigned __int8 * LoadRoleImage(int nIndex, const char *pszPath); // 0x004207D0
    virtual RoleSystem * sub_420910(char a2); // 0x00420910
    void InitInternal(); // 0x00420930
    int CopyRoleToSlot(RoleSystem *pRoleSystem, int index); // 0x00420940
    char GetTile(int nX, int nY); // 0x004209F0
    int * IsTileInBounds(int nVal, int nY, int nVal2); // 0x00420A10
    void SetRoleGridPosition(float fVal, int nVal, float fVal2, int nVal2); // 0x00420A90
    int GetRolePtr(int index); // 0x00420F30
    char * GetMapNodePtr(int nIndex); // 0x00420F50
    BOOL IsRoleInRange(int index, int *pnVal, int nVal); // 0x00420F70
    BOOL CheckMoveCollision(int *index, float *pfVal, int nVal); // 0x00420FB0
    BOOL CheckCollision(int *pResult, int nFlag); // 0x00421020
    BOOL IsTilePassable(char nTileType, int nSceneIdx, int nX, int nY); // 0x00421150
    void SetRoleParam(int index, float *pfVal, int *pnVal, int *p_DWORD); // 0x00421440
    BOOL ValidatePathIndex(int index, int nY, int nVal); // 0x004214B0
    int AdvanceOnPath(int *pResult, char *nFlag, int nVal, char *pszBuf, int nVal2); // 0x004215B0
    int ValidatePath(int *pResult, int *nFlag, int *pnVal, int nVal, int nVal2, int **a7); // 0x00421710
    BOOL GetPathTarget(int *pResult, int *nFlag, int *pnVal, char *pszBuf, int nVal, int **a7); // 0x004218B0
    int UpdatePathProgress(char arg0, int index, char *pszBuf, int nVal, char *pszBuf2, int nVal2); // 0x00421A90
    char * NotifyPathEnd(int nVal); // 0x00421BF0
    int * BuildPathSegment(int *pnVal, char pData); // 0x00421D10
    int ClearWaypointBuffer(int nVal, int nVal2, int nVal3, char pData); // 0x00421DD0
    void ResetTransition(); // 0x00421EA0
    size_t GetFontColor(FILE *Stream); // 0x00421F20
    char ClearPathData(FILE *Buffer); // 0x00421F70
    BOOL BuildModelPath(const char *pszName); // 0x00422000
    int * ResetModelPaths(); // 0x00422140
    static char SetAnimBlend(int nVal); // 0x00422430
    void SetAnimFrame(); // 0x00422540
    void ResetGlobalPos(); // 0x00422740
    static int SetCameraMode(int nVal); // 0x004234A0
    void ProcessAction(); // 0x0042A010
    BOOL CheckScriptTrigger(struct gbVec3D *p); // 0x0042A950
    int SetActionState(int nVal, char pData); // 0x0042AD40
    void UpdateStateMode(); // 0x0042B510
    int * SetTileTypeVisible(int nTileType, int bVisible); // 0x0042C0C0
    int ExecScriptDataCmd(int *p_DWORD); // 0x0042D9F0
    int ExecScriptDataA(); // 0x0042DBD0
    int ExecScriptDataB(); // 0x0042DD80
    int ExecScriptDataIdx(int nVal); // 0x0042E870
    int ExecScriptDataC(); // 0x0042EA30
    int ProcessWaypoint(); // 0x0044B470
    int InitUICtrlArray(); // 0x0044CD90
    int InitDefaultPositions(); // 0x0044CEC0
    int InitRandomParticles(); // 0x0044D380
    int ctor_1D20(); // 0x00531D20
    void ctor(); // 0x00531E70
    int InitAllSystems(); // 0x00531F50
    int ApplyRotationAxis(int nVal, char pData); // 0x00532360
    int ShowHideUI(char pData); // 0x00532410
    int StartBlinkUI(); // 0x005326A0
    int StopBlinkUI(); // 0x005326E0
    static int ScaleValue(int nVal, int *pnVal, int *p_DWORD); // 0x00532960
    void AdjustHeight(int nVal); // 0x00532C80
    int GetStateMode(); // 0x00532D30
    void NegateStateMode(); // 0x00532D40
    char ResetPathState(); // 0x00532E10
};
