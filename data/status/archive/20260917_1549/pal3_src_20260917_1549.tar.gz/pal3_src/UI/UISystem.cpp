#include "pal3/ida_defs.h"
#include "globals.h"
#include "pal3/pal3_constants.h"
#include "UI/UISystem.h"
#include "Script/PalScriptMgr.h"
#include "Role/RoleSystem.h"
#include "Misc/ScriptSystemData.h"
#include "free_functions.h"

// Forward declarations for unnamed functions
int sub_41F8C0(...);

// 0x00422DF0
void UISystem::Destroy()
{
  _DWORD *v1; // eax
  PalScriptMgr *v2; // esi
  RoleSystem *v3; // esi

  v1 = (_DWORD *)UISceneUpdate();
  sub_421870(v1);
  v2 = (PalScriptMgr *)&pOut;
  do
  {
    sub_41F8C0(v2);
    v2 = (PalScriptMgr *)((char *)v2 + 493156);
  }
  while ( (int)v2 < (int)&byte_D8B314 );
  v3 = (RoleSystem *)&g_ScriptSystemData;
  do
  {
    (((RoleSystem *)v3))->RoleSystem::Reset();
    v3 = (RoleSystem *)((char *)v3 + 392);
  }
  while ( (int)v3 < (int)&stru_D8B938 );
}
