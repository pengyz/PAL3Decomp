#pragma once
// Auto-generated: UIRenderObj
#include "pal3/ida_types.h"

class UIRenderObj {
public:
    _BYTE _tail_000[4]; // +0x0
    // total size: 0x4 (4)

    UIRenderObj(); // 0x00541640
    ~UIRenderObj(); // 0x00541710
    UIRenderObj(int v) { *(int*)this = v; }

};
