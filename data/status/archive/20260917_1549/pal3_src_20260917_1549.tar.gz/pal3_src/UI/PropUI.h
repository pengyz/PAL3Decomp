#include "Misc/UIFrameWnd.h"
#pragma once
// Auto-generated: PropUI
#include "pal3/ida_types.h"

#include "Misc/BtnGroup.h"
#include "Misc/MUIDialog.h"
#include "Misc/UI3DCtrl.h"
#include "Misc/UIAnimateCtrl.h"
#include "Misc/UIButton.h"
#include "Misc/UIFlexBar.h"
#include "UI/UIListBox.h"
#include "Misc/UIStatic.h"
#include "Misc/st_Manager.h"

class PlayerItem;

class PropUI : public UIFrameWnd {
public:
    char _gap_000[72]; // +0x0
    int bkWndX; // +0x48
    int bkWndY; // +0x4C
    int m_ListWidth; // +0x50
    int m_ListHeight; // +0x54
    st_Manager m_PropData; // +0x58
    char _gap_14C[24]; // +0x14C
    int m_nTodo_164; // +0x164
    int m_nTodo_168; // +0x168
    char _gap_16C[12]; // +0x16C
    int m_nTodo_178; // +0x178
    char _gap_17C[20]; // +0x17C
    int m_nTodo_190; // +0x190
    char _gap_194[96]; // +0x194
    int m_nTodo_1F4; // +0x1F4
    int m_nTodo_1F8; // +0x1F8
    char _gap_1FC[48]; // +0x1FC
    int m_nTodo_22C; // +0x22C
    char _gap_230[40]; // +0x230
    int m_nTodo_258; // +0x258
    char _gap_25C[4]; // +0x25C
    int m_nTodo_260; // +0x260
    int m_nTodo_264; // +0x264
    char _gap_268[104]; // +0x268
    int m_nTodo_2D0; // +0x2D0
    int m_nTodo_2D4; // +0x2D4
    int m_nTodo_2D8; // +0x2D8
    int m_nTodo_2DC; // +0x2DC
    int m_nTodo_2E0; // +0x2E0
    char _gap_2E4[60]; // +0x2E4
    int m_nTodo_320; // +0x320
    char _gap_324[280]; // +0x324
    int m_nTodo_43C; // +0x43C
    char _gap_440[76]; // +0x440
    int m_nTodo_48C; // +0x48C
    int m_nTodo_490; // +0x490
    char _gap_494[208]; // +0x494
    int m_nTodo_564; // +0x564
    char _gap_568[764]; // +0x568
    int m_nTodo_864; // +0x864
    char _gap_868[2224]; // +0x868
    int m_nTodo_1118; // +0x1118
    char _gap_111C[9516]; // +0x111C
    int m_nTodo_3648; // +0x3648
    char _gap_364C[4]; // +0x364C
    int m_nTodo_3650; // +0x3650
    char _gap_3654[80]; // +0x3654
    int m_nTodo_36A4; // +0x36A4
    char _gap_36A8[1512]; // +0x36A8
    int m_nTodo_3C90; // +0x3C90
    char _gap_3C94[884]; // +0x3C94
    int m_nTodo_4008; // +0x4008
    char _gap_400C[708]; // +0x400C
    int m_nTodo_42D0; // +0x42D0
    char _gap_42D4[484]; // +0x42D4
    PlayerItem * p_DealData; // +0x44B8
    char buf[256]; // +0x44BC
    char remarkbuf[256]; // +0x45BC
    int m_SelNum; // +0x46BC
    int * m_ListSelNum; // +0x46C0
    int * m_MaxNum; // +0x46C4
    int m_x; // +0x46C8
    int m_y; // +0x46CC
    int m_Sum; // +0x46D0
    int i; // +0x46D4
    int j; // +0x46D8
    BYTE _isCreatable; // +0x46DC
    char _gap_46DD[3]; // +0x46DD
    UIStatic m_Frame; // +0x46E0
    int m_EmbedUI3DCtrl; // +0x4778
    char _gap_477C[4]; // +0x477C
    UIFlexBar m_FrameBar; // +0x4780
    UIStatic m_Flag; // +0x47D4
    int m_nTodo_486C; // +0x486C
    int m_nTodo_4870; // +0x4870
    UIStatic m_OutFrameT; // +0x4874
    char _gap_490C[8]; // +0x490C
    UIStatic m_OutFrameR; // +0x4914
    char _gap_49AC[8]; // +0x49AC
    UIStatic m_OutFrameL; // +0x49B4
    char _gap_4A4C[8]; // +0x4A4C
    UIStatic m_OutFrameB; // +0x4A54
    char _gap_4AEC[8]; // +0x4AEC
    tagRECT mb_ExitRc; // +0x4AF4
    UIButton mb_Exit; // +0x4B04
    UIAnimateCtrl m_ani; // +0x4C5C
    UIStatic m_Role[5]; // +0x4D00
    char _gap_4FF8[40]; // +0x4FF8
    tagRECT m_RoleRc[5]; // +0x5020
    int RoleX; // +0x5070
    int RoleY; // +0x5074
    int HeadW; // +0x5078
    int HeadH; // +0x507C
    BYTE m_Is[5]; // +0x5080
    char _gap_5085[3]; // +0x5085
    MUIDialog m_Msg; // +0x5088
    char _gap_5590[12]; // +0x5590
    int m_EmbedSubPanel; // +0x559C
    char _gap_55A0[80]; // +0x55A0
    UI3DCtrl m_3DObj; // +0x55F0
    UIStatic m_Dlg; // +0x5724
    char _gap_57BC[8]; // +0x57BC
    tagRECT m_DlgRc; // +0x57C4
    UIStatic m_TalkFrame; // +0x57D4
    char _gap_586C[8]; // +0x586C
    UIStatic m_Ready; // +0x5874
    char _gap_590C[8]; // +0x590C
    tagRECT m_ReadyRc; // +0x5914
    UIStatic m_ListFrame; // +0x5924
    char _gap_59BC[8]; // +0x59BC
    UIStatic m_ListGrid[14]; // +0x59C4
    char _gap_6214[112]; // +0x6214
    UIStatic m_ScrollHB; // +0x6284
    char _gap_631C[8]; // +0x631C
    UIStatic m_EquipFlag; // +0x6324
    char _gap_63BC[8]; // +0x63BC
    UIStatic m_ListPropTitle; // +0x63C4
    char _gap_645C[8]; // +0x645C
    tagRECT m_ListPropTitleRc; // +0x6464
    UIListBox ml_ListProp; // +0x6474
    char _gap_692C[36]; // +0x692C
    int m_nCaptionOverlay; // +0x6950
    char _gap_6954[40]; // +0x6954
    tagRECT ml_ListPropRc; // +0x697C
    BtnGroup m_btnGroup; // +0x698C
    float m_ctrlTime; // +0x6C70
    BYTE m_bCanUpdate1; // +0x6C74
    BYTE m_bCanUpdate2; // +0x6C75
    char _gap_6C76[2]; // +0x6C76
    UIStatic m_PropRemarkBk; // +0x6C78
    char _gap_6D10[8]; // +0x6D10
    UIStatic m_PropRemark; // +0x6D18
    char _gap_6DB0[8]; // +0x6DB0
    UIStatic m_PropAtt; // +0x6DB8
    char _gap_6E50[8]; // +0x6E50
    UIStatic m_MoneyRemark; // +0x6E58
    char _gap_6EF0[8]; // +0x6EF0
    tagRECT m_MoneyRc; // +0x6EF8
    UIStatic m_SumProp; // +0x6F08
    char _gap_6FA0[8]; // +0x6FA0
    tagRECT m_SumRc; // +0x6FA8
    UIButton mb_OK; // +0x6FB8
    tagRECT mb_OKRc; // +0x7110
    char _tail_7120[96]; // +0x7120
    // total size: 0x7180 (29056)

    virtual ~PropUI() {}

    virtual int HandleInput(int nVal, int nVal2); // 0x0046F620
    int _scalar_dtor(void *Block, char); // 0x0046D4C0
    virtual int InitListUI(int arg0, int nVal, unsigned int dwVal); // 0x0046F650
    void Init(); // 0x00452670
    int ShowCategory0(unsigned __int8 pData); // 0x0045B200
    int ShowCategory1(unsigned __int8 pData); // 0x0045B320
    int ShowCategory2(unsigned __int8 pData); // 0x0045B440
    int ShowCategory3(unsigned __int8 pData); // 0x0045B560
    int ShowCategory4(unsigned __int8 pData); // 0x0045B680
    int InitUI(); // 0x0046D140
    void ctor(); // 0x0046D4E0
    int UpdateItemList(const void *arg0); // 0x0046DD10
    int InitPlayerList(int nVal); // 0x0046DF40
    int SetSlotLock(int nVal); // 0x0046EC30
    bool CheckMode(unsigned int dwVal); // 0x0046EC50
    int SetSceneStates(unsigned __int8 pData); // 0x0046EC70
    int DisplayItemInfo(); // 0x0046ECC0
    int UpdateCaptions(); // 0x0046F160
    void UpdateItemDetail(int nItemIdx); // 0x0046F300
    int SetPendingMessage(char msg, int wparam, int lparam); // 0x00521A50
};
