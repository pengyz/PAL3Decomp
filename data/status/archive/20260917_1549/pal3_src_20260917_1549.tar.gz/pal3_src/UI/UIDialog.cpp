#include "pal3/ida_defs.h"
#include "globals.h"
#include "pal3/pal3_constants.h"
#include "UI/UIDialog.h"
#include "Combat/CCBItemWindow.h"
#include "Scene/CameraCtrl.h"
#include "Misc/RoleCameraCtrl.h"
#include "UI/UINote.h"
#include "free_functions.h"

// Forward declarations for unnamed functions

// 0x004503D0
void UIDialog::Create(int id, int x, int y, int parent, char *tex)
{
  gbTexture *v7; // eax
  tagRECT pRect; // [esp+0x4] [ebp-0x10] BYREF

  pRect.right = x;
  this[1].m_id = (void *)x;
  this[1].m_rect.left = y;
  pRect.bottom = y;
  pRect.top = 0;
  pRect.left = 0;
  (((CCBItemWindow *)this))->CCBItemWindow::Create(id, &pRect, parent) /* [ROWTABLE] */;
  this[1].m_rect.top = (LONG)v7;
  if ( v7 )
    (((gbTexture *)v7))->gbTexture::LoadTexture(1);
}

// 0x00450550
void UIDialog::Show()
{
  unsigned int v1; // [esp+0x4] [ebp+0x4]

  this[1].m_wndcolor.Color = v1;
}

// 0x00450B30

// ---- synthesized vtable stubs (unresolved slots) ----
// [VFTABLE-STUB] original: ((int ( *)(UIDialog *, _DWORD))this->__vftable->ShowWindow)(this, 0)
static int pal3_vtbl_unk_0(UIDialog *, _DWORD);

int UIDialog::Init()
{
  tagRECT pRect; // [esp+0x8] [ebp-0x10] BYREF
  int parent; // [esp+0x1C] [ebp+0x4]

  pRect.left = (g_DrvInfo.width - 274) / 2;
  pRect.top = 10;
  pRect.bottom = 87;
  pRect.right = pRect.left + 274;
  (((CCBItemWindow *)this))->CCBItemWindow::Create(0, &pRect, parent) /* [ROWTABLE] */;
  (((UINote *)&this[1]))->UINote::Create(1, (int)&pRect, (int)this, "ui\\flex\\note");
  sub_445FA0(&this[1]);
  (((RoleCameraCtrl *)&this[1]))->RoleCameraCtrl::SetTargetDistance(2);
  return pal3_vtbl_unk_0(this, 0) /* [VFTABLE-STUB] */;
}

static int pal3_vtbl_unk_0(UIDialog *, _DWORD)
{
    return 0;
}

