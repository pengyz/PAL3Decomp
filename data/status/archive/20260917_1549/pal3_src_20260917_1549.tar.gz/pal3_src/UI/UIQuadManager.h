#pragma once
// Auto-generated: UIQuadManager
#include "pal3/ida_types.h"

class UIQuadManager {
public:
    _BYTE _tail_000[4]; // +0x0
    // total size: 0x4 (4)

    static UIQuadManager * GetInstance(); // 0x005415F0
    // Scalar-wrapper: ctors for IDA (Cls)int casts (no init code)
    UIQuadManager() {}
    UIQuadManager(int v) { *(int*)this = v; }

};
