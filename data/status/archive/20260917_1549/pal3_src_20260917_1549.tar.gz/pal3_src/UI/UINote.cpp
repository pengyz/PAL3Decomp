#include "pal3/ida_defs.h"
#include "globals.h"
#include "pal3/pal3_constants.h"
#include "UI/UINote.h"
#include "Combat/CCBItemWindow.h"
#include "Misc/OpenBaseFile.h"
#include "Misc/OpenNULLFile.h"
#include "Misc/UIStatic.h"
#include "free_functions.h"

// Forward declarations for unnamed functions

// 0x004450A0
void * UINote::Create(int id, int nVal, int nVal2, char *tex)
{
  int v6; // esi
  void *result; // eax
  OpenBaseFile v8; // [esp+0x10] [ebp-0x110] BYREF
  char Buffer[256]; // [esp+0x14] [ebp-0x10C] BYREF
  int v10; // [esp+0x11C] [ebp-0x4]

  (((CCBItemWindow *)this))->CCBItemWindow::Create(id, (tagRECT *)nVal, nVal2) /* [ROWTABLE] */;
  v6 = 0;
  v10 = 0;
  do
  {
    sprintf(Buffer, "%s%d.tga", tex, v6);
    sub_445ED0((int)Buffer, 1);
    ++v6;
  }
  while ( v6 < 9 );
  this->m_static.m_texs.m_ptex[7] = *(gbTexture **)(sub_445F60(0) + 24);
  this->m_static.m_texs.m_ptex[4] = 0;
  this->m_bvisible = 0;
  v10 = -1;
  // [AUTO-COMMENTED] (OpenNULLFile *)&v8->OpenNULLFile();
  return result;
}

// 0x00528D30
int UINote::GetEntryPtr(int nIndex)
{
  return (int)&this[12].m_static.m_texs.m_ptex[64 * nIndex + 13];
}

// 0x0052AFF0
void UINote::RenderWithStack(gbMatrixStack *pStack)
{
  (((gbMatrixStack *)pStack))->gbMatrixStack::Push();
  (((gbMatrixStack *)pStack))->gbMatrixStack::Translate(*(gbVec3D *)&this[1]);
  (*(void ( **)(_DWORD, _DWORD))(*(_DWORD *)LODWORD(this->time) + 16))(LODWORD(this->time), 0);
  (((gbMatrixStack *)pStack))->gbMatrixStack::Pop();
}

// 0x0052B030
int UINote::CallVtableMethod(double pData)
{
  float v3; // [esp+0x0] [ebp-0x4]

  v3 = pData;
  return (*(int ( **)(_DWORD))(*(_DWORD *)LODWORD(this->time) + 48))(LODWORD(v3));
}
