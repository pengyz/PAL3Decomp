#include "pal3/ida_defs.h"
#include "globals.h"
#include "pal3/pal3_constants.h"
#include "UI/UIItem.h"
#include "free_functions.h"

// Forward declarations for unnamed functions

// 0x004A14D0
void * UIItem::SetData(char pData)
{
  return sub_446010(&this[1].m_nTodo_05C + 33);
}
