#include "Misc/UIFrameWnd.h"
#pragma once
// Auto-generated: StateUI
#include "pal3/ida_types.h"

#include "Misc/MUIDialog.h"
#include "Misc/UI3DCtrl.h"
#include "Misc/UIButton.h"
#include "Misc/UIFlexBar.h"
#include "Misc/UIParticle.h"
#include "Misc/UIStatic.h"
#include "gbengine/gbTexture.h"
#include "Misc/s_RoleState.h"
#include "Misc/s_SpecialPropItem.h"

class JusticeBookUI;
class LineupUI;
class MagicUI;
class MainEquipUI;
class MainPropUI;
class SwordUI;
class SystemUI;
class TaskBookUI;
class UIWnd;

class StateUI : public UIFrameWnd {
public:
    char _gap_000[72]; // +0x0
    BYTE m_isJusticeBook; // +0x48
    char _gap_049[207]; // +0x49
    BYTE m_IsMsg; // +0x118
    BYTE m_Is[5]; // +0x119
    char _gap_11E[2]; // +0x11E
    int m_CtrlRole; // +0x120
    BYTE m_IsActive; // +0x124
    BYTE m_IsCreateable; // +0x125
    char _gap_126[2]; // +0x126
    UIStatic m_Frame; // +0x128
    UIStatic m_TimeMoney; // +0x1C0
    UIStatic m_OutFrameT; // +0x258
    UIStatic m_OutFrameR; // +0x2F0
    UIStatic m_OutFrameL; // +0x388
    UIStatic m_OutFrameB; // +0x420
    UIStatic stp_BarL; // +0x4B8
    UIFlexBar stp_BarM; // +0x550
    UIStatic stp_BarR; // +0x5A4
    UIButton stp_State; // +0x63C
    UIButton stp_Magic; // +0x794
    UIButton stp_Equip; // +0x8EC
    UIButton stp_Prop; // +0xA44
    UIButton stp_BattleArray; // +0xB9C
    UIButton stp_TaskBook; // +0xCF4
    UIButton stp_System; // +0xE4C
    UIButton stp_Exit; // +0xFA4
    UIStatic stp_Effect; // +0x10FC
    tagRECT stp_Rect; // +0x1194
    UIStatic m_GameTime; // +0x11A4
    UIStatic m_GameMoney; // +0x123C
    UIParticle m_par[16][7]; // +0x12D4
    char _gap_11254[896]; // +0x11254
    UIParticle m_par2[16][7]; // +0x115D4
    char _gap_21554[896]; // +0x21554
    tagRECT m_parRc[7]; // +0x218D4
    BYTE _isParBtn[7]; // +0x21944
    char _gap_2194B[1]; // +0x2194B
    int _curParEffect; // +0x2194C
    tagRECT m_PortraitRc; // +0x21950
    UIStatic m_Portrait; // +0x21960
    UIStatic m_TeamState; // +0x219F8
    UIStatic m_Time; // +0x21A90
    UIStatic m_Money; // +0x21B28
    tagRECT m_TeamStateRc; // +0x21BC0
    s_RoleState m_RoleState[5]; // +0x21BD0
    char _gap_265CC[800]; // +0x265CC
    UIStatic m_State[4]; // +0x268EC
    UIStatic m_Alignment; // +0x26B4C
    tagRECT m_AlignmentRc; // +0x26BE4
    UIStatic m_Head[5]; // +0x26BF4
    tagRECT m_HeadRc[5]; // +0x26EEC
    UIStatic m_TopFrame; // +0x26F3C
    UIButton m_LeaveHere; // +0x26FD4
    tagRECT m_LeaveRc; // +0x2712C
    UI3DCtrl m_3DObj; // +0x2713C
    MUIDialog m_DlgEx; // +0x27270
    char _gap_27778[96]; // +0x27778
    LineupUI * p_LineupUI; // +0x277D8
    MagicUI * p_MagicUI; // +0x277DC
    MainEquipUI * p_mEquipUI; // +0x277E0
    MainPropUI * p_mPropUI; // +0x277E4
    SwordUI * p_SwordUI; // +0x277E8
    JusticeBookUI * p_JusticeBookUI; // +0x277EC
    TaskBookUI * p_TaskBookUI; // +0x277F0
    SystemUI * p_SystemUI; // +0x277F4
    int m_curRender; // +0x277F8
    BYTE m_saveflag_note; // +0x277FC
    BYTE m_isSeekSAVELOAD; // +0x277FD
    char _gap_277FE[2]; // +0x277FE
    UIStatic m_test; // +0x27800
    gbTexture * pInterceptTex; // +0x27898
    float sv; // +0x2789C
    float ev; // +0x278A0
    BYTE m_isExit; // +0x278A4
    char _gap_278A5[3]; // +0x278A5
    s_SpecialPropItem m_SpecialPropItem[5]; // +0x278A8
    // total size: 0x278D0 (162000)

    virtual ~StateUI() {}

    StateUI * _scalar_dtor(char a2); // 0x00483260
    virtual int OnRender(); // 0x00485DF0
    int LoadRoleList(); // 0x0047F390
    int ReleaseResource(); // 0x0047F410
    int CategorizeRoles(); // 0x0047F450
    int ShowPanels(int nVal, unsigned __int8 pData, UIWnd *bFlag); // 0x00480070
    int DispatchCmd(BOOL bFlag); // 0x00480450
    int AutoScrollParticles(int nVal); // 0x00482C90
    void ctor(); // 0x00483380
    int IteratePlayerAtts(); // 0x004845F0
    int UpdateVisibility(); // 0x00484660
    int SelectTab1(unsigned __int8 nTab); // 0x00484E90
    int SelectTab2(unsigned __int8 nTab); // 0x00484EB0
    virtual int sub_4850E0(); // 0x004850E0
    virtual int sub_485230(); // 0x00485230
    int RefreshStatsDisplay(); // 0x00485980
    char * RefreshFromAtts(); // 0x00485CD0
    int SelectSubTab1(unsigned __int8 nTab); // 0x0048A310
    int SelectSubTab2(unsigned __int8 nTab); // 0x0048A330
    void UpdateRoleTooltip(int nVal); // 0x00492850
    void UpdateAttributeDisplay(int arg0, char *pszBuf, float id); // 0x00493420
    void UpdateScrollBars(); // 0x004940F0
    int ForwardToBigMap(char pData); // 0x004945E0
    int SelectBigMapTab2(char nTab); // 0x00494600
    int ShowPage(); // 0x004998E0
    void DisplayCaption(int nVal); // 0x0049A360
    int UpdateScrollValues(); // 0x0049AC70
    int SelectXJTMTab1(unsigned __int8 nTab); // 0x0049E860
    int SelectXJTMTab2(unsigned __int8 nTab); // 0x0049E880
    UIWnd * GetChildPtr(int index); // 0x004A2BD0
    UIWnd * FindChild(int id); // 0x004A2F90
    int SaveData(); // 0x004B2470
};
