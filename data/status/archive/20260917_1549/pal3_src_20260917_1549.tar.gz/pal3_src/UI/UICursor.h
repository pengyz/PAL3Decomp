#pragma once
// Auto-generated: UICursor
#include "pal3/ida_types.h"

#include "gbengine/gbengine_types.h"
#include "gbengine/gbTexture.h"
#include "gbengine/gbTexture.h"

class CameraCtrl;
class _PlugInfo;

class UICursor {
public:
    UINT m_dwID[3]; // +0x0
    CameraCtrl * m_active; // +0xC
    gbTexture * m_tex[3]; // +0x10
    char _gap_014[8]; // +0x14
    BYTE m_bShow; // +0x1C
    BYTE m_bSoftMode; // +0x1D
    char _gap_01E[14]; // +0x1E
    DWORD m_pData; // +0x2C
    char _tail_030[16]; // +0x30
    // total size: 0x40 (64)

    void Update(double fDelta); // 0x00535120
    static int IRender(int nX, int nY, int nW, int nH, gbColorQuad *pColor, gbTextureArray *pTex, _PlugInfo *pInfo); // 0x00541160
    void IRender(); // 0x00541CC0
};
