#include "Misc/UIFrameWnd.h"
#pragma once
// Auto-generated: EquipUI
#include "pal3/ida_types.h"

#include "Misc/BtnGroup.h"
#include "Misc/MUIDialog.h"
#include "Misc/PlayerAtt.h"
#include "Misc/UI3DCtrl.h"
#include "Misc/UIAnimate.h"
#include "Misc/UIAnimateCtrl.h"
#include "Misc/UIButton.h"
#include "Misc/UIFlexBar.h"
#include "UI/UIListBox.h"
#include "Misc/UIStatic.h"
#include "Misc/UIStaticRM.h"
#include "Misc/UITabBtn.h"
#include "Misc/st_Manager.h"

class PlayerItem;
class UIWnd;

class EquipUI : public UIFrameWnd {
public:
    char _gap_000[72]; // +0x0
    int bkWndX; // +0x48
    int bkWndY; // +0x4C
    char buf[256]; // +0x50
    int m_SelNum; // +0x150
    int * m_ListNum; // +0x154
    int m_x; // +0x158
    int m_y; // +0x15C
    int m_Sum; // +0x160
    int i; // +0x164
    int j; // +0x168
    int k; // +0x16C
    BYTE _isCreatable; // +0x170
    char _gap_171[3]; // +0x171
    float _flashSpeed; // +0x174
    st_Manager m_EquipData; // +0x178
    char _gap_26C[17260]; // +0x26C
    PlayerItem * p_DealData; // +0x45D8
    PlayerAtt m_TempData[5]; // +0x45DC
    tagRECT rc; // +0x63A0
    UIStatic m_Frame; // +0x63B0
    char _gap_6448[8]; // +0x6448
    UIFlexBar m_FrameBar; // +0x6450
    UIStatic m_Flag; // +0x64A4
    char _gap_653C[8]; // +0x653C
    UIStatic m_OutFrameT; // +0x6544
    char _gap_65DC[8]; // +0x65DC
    UIStatic m_OutFrameR; // +0x65E4
    char _gap_667C[8]; // +0x667C
    UIStatic m_OutFrameL; // +0x6684
    char _gap_671C[8]; // +0x671C
    UIStatic m_OutFrameB; // +0x6724
    char _gap_67BC[8]; // +0x67BC
    UIAnimateCtrl m_ani; // +0x67C4
    UIStatic m_Role[5]; // +0x6868
    char _gap_6B60[40]; // +0x6B60
    tagRECT m_RoleRc[5]; // +0x6B88
    int RoleX; // +0x6BD8
    int RoleY; // +0x6BDC
    int HeadW; // +0x6BE0
    int HeadH; // +0x6BE4
    BYTE m_Is[5]; // +0x6BE8
    char _gap_6BED[3]; // +0x6BED
    UIStatic m_Arrow[8][6][5]; // +0x6BF0
    char _gap_FA70[1920]; // +0xFA70
    UIStatic m_ArrowNum[8][2][5]; // +0x101F0
    char _gap_13170[640]; // +0x13170
    tagRECT m_ArrowRc[8][6][5]; // +0x133F0
    BYTE m_IsArrow[8][6][5]; // +0x142F0
    int m_OldSelect; // +0x143E0
    BYTE m_IsMove[8][6][5]; // +0x143E4
    tagRECT m_AnimateRc[8][6][5]; // +0x144D4
    UIAnimate m_ArrowMove[8][6][5]; // +0x153D4
    UIStaticRM m_Icon[6][5]; // +0x18494
    char _gap_199AC[240]; // +0x199AC
    UIStatic m_Select[6][5]; // +0x19A9C
    char _gap_1AC6C[240]; // +0x1AC6C
    BYTE m_IsControlEquip; // +0x1AD5C
    BYTE m_IsEquip[6][5]; // +0x1AD5D
    BYTE m_IsMsg; // +0x1AD7B
    int * m_EquipingNum; // +0x1AD7C
    int m_Equiping[6][5]; // +0x1AD80
    int * m_UnEquipingNum; // +0x1ADF8
    int * m_MaxNum; // +0x1ADFC
    BYTE m_Adorn[2][5]; // +0x1AE00
    char _gap_1AE0A[2]; // +0x1AE0A
    UI3DCtrl m_3DObj; // +0x1AE0C
    MUIDialog m_Msg; // +0x1AF40
    char _gap_1B448[96]; // +0x1B448
    UIStatic m_TalkFrame; // +0x1B4A8
    char _gap_1B540[8]; // +0x1B540
    UIStatic m_Ready; // +0x1B548
    char _gap_1B5E0[8]; // +0x1B5E0
    tagRECT m_ReadyRc; // +0x1B5E8
    UIButton mb_EquipYes; // +0x1B5F8
    UIButton mb_EquipNo; // +0x1B750
    UIStatic m_EquipTalk; // +0x1B8A8
    char _gap_1B940[8]; // +0x1B940
    tagRECT m_EquipRc; // +0x1B948
    UIStatic m_ListFrame; // +0x1B958
    char _gap_1B9F0[8]; // +0x1B9F0
    UIStatic m_ListGrid[14]; // +0x1B9F8
    char _gap_1C248[112]; // +0x1C248
    UIStatic m_ScrollHB; // +0x1C2B8
    char _gap_1C350[8]; // +0x1C350
    UIStatic m_EquipFlag; // +0x1C358
    char _gap_1C3F0[8]; // +0x1C3F0
    UIStatic m_ListEquipTitle; // +0x1C3F8
    char _gap_1C490[8]; // +0x1C490
    UIListBox ml_ListEquip; // +0x1C498
    char _gap_1C950[80]; // +0x1C950
    tagRECT ml_ListEquipRc; // +0x1C9A0
    BtnGroup m_btnGroup; // +0x1C9B0
    float m_ctrlTime; // +0x1CC94
    BYTE m_bCanUpdate1; // +0x1CC98
    BYTE m_bCanUpdate2; // +0x1CC99
    char _gap_1CC9A[2]; // +0x1CC9A
    UIStatic m_EquipRemarkBk; // +0x1CC9C
    char _gap_1CD34[8]; // +0x1CD34
    UIStatic m_EquipRemark; // +0x1CD3C
    char _gap_1CDD4[8]; // +0x1CDD4
    tagRECT m_EquipRemarkRc; // +0x1CDDC
    UIStatic m_EquipAtt; // +0x1CDEC
    char _gap_1CE84[8]; // +0x1CE84
    tagRECT m_EquipAttRc; // +0x1CE8C
    UIStatic m_MoneyRemark; // +0x1CE9C
    char _gap_1CF34[8]; // +0x1CF34
    tagRECT m_MoneyRc; // +0x1CF3C
    UIStatic m_SumEquip; // +0x1CF4C
    char _gap_1CFE4[8]; // +0x1CFE4
    tagRECT m_SumRc; // +0x1CFEC
    UIButton mb_OK; // +0x1CFFC
    tagRECT mb_OKRc; // +0x1D154
    BYTE m_IsDicker; // +0x1D164
    char _gap_1D165[3]; // +0x1D165
    UIButton mb_Cancel; // +0x1D168
    tagRECT mb_CancelRc; // +0x1D2C0
    UIButton mb_Exit; // +0x1D2D0
    tagRECT mb_ExitRc; // +0x1D428
    UITabBtn m_TabBtn; // +0x1D438
    tagRECT mb_DKRc; // +0x1D450
    tagRECT haveRc; // +0x1D460
    BYTE m_isCancelTalk; // +0x1D470
    char _tail_1D471[195]; // +0x1D471
    // total size: 0x1D534 (120116)

    virtual ~EquipUI() {}

    static int EquipUI_RenderEffects(int nVal); // 0x0049FE00
    virtual BOOL Update(int nVal, int nVal2); // 0x004A00B0
    void * _scalar_dtor(UIWnd *Block, char pData); // 0x00498C70
    virtual void HandleEquipEvent(int nVal, char *pszBuf, int nVal2); // 0x004A0370
    int ShowPage(); // 0x00484D20
    int SelectTab0(unsigned __int8 nTab); // 0x00484E70
    int SetSubTab(unsigned __int8 nTab); // 0x0048A2F0
    void UpdateSlot(int nSlotIdx, int nItemID, int nCount); // 0x00494040
    int SelectBigMapTab0(char nTab); // 0x004945C0
    void HandleInput(int nInputID, int nParam); // 0x00494D70
    int ctor(); // 0x00498820
    EquipUI(); // 0x00499030
    int SetSubTab2(unsigned __int8 nTab); // 0x0049E840
    int SetGroupVisible(unsigned __int8 bVisible); // 0x0049F9B0
    int InitParticleEffects(int nVal); // 0x0049FA10
    BOOL UpdateDisplay(int nPage, int nSlot); // 0x0049FBE0
    int FindNextSlot(int *pCounter); // 0x0049FF30
    int FindPrevSlot(int *pCounter); // 0x0049FF60
    char HandleInput(); // 0x0049FF90
    void Init(); // 0x004A4220
    int InitEquipUI(int nVal); // 0x004AB6B0
    static void ControlDealBTWnd(uchar); // 0x005137EF
};
