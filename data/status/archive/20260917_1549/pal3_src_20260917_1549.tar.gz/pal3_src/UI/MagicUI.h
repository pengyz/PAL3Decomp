#include "Misc/UIFrameWnd.h"
#pragma once
// Auto-generated: MagicUI
#include "pal3/ida_types.h"

#include "Misc/DLG_MSG.h"
#include "Misc/MUIDialog.h"
#include "Misc/SkillData.h"
#include "Misc/UIAnimate.h"
#include "Misc/UIButton.h"
#include "Misc/UIFlexBar.h"
#include "UI/UIListBox.h"
#include "Misc/UIParticle.h"
#include "Misc/UIStatic.h"
#include "Misc/m_RoleState.h"

class StateUI;

class MagicUI : public UIFrameWnd {
public:
    char _gap_000[72]; // +0x0
    BYTE m_ComSkill[8][5]; // +0x48
    char _gap_070[168]; // +0x70
    char remarkbuf[256]; // +0x118
    int s_x; // +0x218
    BYTE m_IsMsg; // +0x21C
    BYTE m_Is[5]; // +0x21D
    char _gap_222[2]; // +0x222
    int m_CtrlRole; // +0x224
    BYTE m_IsActive; // +0x228
    BYTE m_IsCreateable; // +0x229
    char _gap_22A[2]; // +0x22A
    int curPage; // +0x22C
    int m_SelNum; // +0x230
    int m_CurType; // +0x234
    int m_usemagicRole; // +0x238
    BYTE m_isuseMagic; // +0x23C
    BYTE m_LockUse; // +0x23D
    BYTE m_IsUsed; // +0x23E
    BYTE m_IsCanUse; // +0x23F
    BYTE m_IsAllUse; // +0x240
    char _gap_241[3]; // +0x241
    tagPOINT pt; // +0x244
    SkillData m_RoleSkill[7][5]; // +0x24C
    char _gap_25D8[32620]; // +0x25D8
    StateUI * pStateUI; // +0xA544
    UIStatic m_Frame; // +0xA548
    UIStatic m_TimeMoney; // +0xA5E0
    UIStatic m_OutFrameT; // +0xA678
    UIStatic m_OutFrameR; // +0xA710
    UIStatic m_OutFrameL; // +0xA7A8
    UIStatic m_OutFrameB; // +0xA840
    UIStatic stp_BarL; // +0xA8D8
    UIFlexBar stp_BarM; // +0xA970
    UIStatic stp_BarR; // +0xA9C4
    UIButton stp_State; // +0xAA5C
    UIButton stp_Magic; // +0xABB4
    UIButton stp_Equip; // +0xAD0C
    UIButton stp_Prop; // +0xAE64
    UIButton stp_BattleArray; // +0xAFBC
    UIButton stp_TaskBook; // +0xB114
    UIButton stp_System; // +0xB26C
    UIButton stp_Exit; // +0xB3C4
    UIStatic stp_Effect; // +0xB51C
    tagRECT stp_Rect; // +0xB5B4
    tagRECT titleRc; // +0xB5C4
    UIStatic m_title[4]; // +0xB5D4
    UIStatic m_GameTime; // +0xB834
    UIStatic m_GameMoney; // +0xB8CC
    MUIDialog m_DlgEx; // +0xB964
    char _gap_BE6C[96]; // +0xBE6C
    UIParticle m_btnPar[16][7]; // +0xBECC
    char _gap_1BE4C[896]; // +0x1BE4C
    UIParticle m_btnPar2[16][7]; // +0x1C1CC
    char _gap_2C14C[896]; // +0x2C14C
    tagRECT m_btnParRc[7]; // +0x2C4CC
    BYTE _isParBtn[7]; // +0x2C53C
    char _gap_2C543[1]; // +0x2C543
    int _curParEffect; // +0x2C544
    int m_CurSelRole; // +0x2C548
    int m_CurNeedRole; // +0x2C54C
    MUIDialog m_Dlg; // +0x2C550
    char _gap_2CA58[96]; // +0x2CA58
    MUIDialog m_Msg; // +0x2CAB8
    char _gap_2CFC0[96]; // +0x2CFC0
    DLG_MSG m_DlgMsg; // +0x2D020
    char _gap_2D021[3]; // +0x2D021
    UIAnimate m_Animate[5]; // +0x2D024
    tagRECT m_AnimateRc[5]; // +0x2D128
    UIStatic m_ListFrame; // +0x2D178
    UIStatic m_ListGrid[8]; // +0x2D210
    UIStatic m_RemarkBk; // +0x2D6D0
    UIStatic m_Remark; // +0x2D768
    UIStatic m_RemarkVal; // +0x2D800
    UIStatic m_UnCom; // +0x2D898
    m_RoleState m_Role[5]; // +0x2D930
    char _gap_329E4[800]; // +0x329E4
    UIButton m_Ctrlbtn[7]; // +0x32D04
    UIListBox ml_SpeList; // +0x3366C
    char _gap_33B24[80]; // +0x33B24
    UIListBox ml_FengList; // +0x33B74
    char _gap_3402C[80]; // +0x3402C
    UIListBox ml_LeiList; // +0x3407C
    char _gap_34534[80]; // +0x34534
    UIListBox ml_ShuiList; // +0x34584
    char _gap_34A3C[80]; // +0x34A3C
    UIListBox ml_HuoList; // +0x34A8C
    char _gap_34F44[80]; // +0x34F44
    UIListBox ml_TuList; // +0x34F94
    char _gap_3544C[80]; // +0x3544C
    UIListBox ml_SuangList; // +0x3549C
    char _gap_35954[80]; // +0x35954
    UIStatic m_TopFrame; // +0x359A4
    UIStatic m_TopFrameXS; // +0x35A3C
    UIParticle m_parRainbow[8][5]; // +0x35AD4
    char _gap_3B614[320]; // +0x3B614
    UIParticle m_parRise[8][5]; // +0x3B754
    char _gap_41294[320]; // +0x41294
    tagRECT m_parRc[5]; // +0x413D4
    // total size: 0x41424 (267300)

    int SelectTab3(unsigned __int8 nTab); // 0x00484ED0
    int SelectTab4(unsigned __int8 nTab); // 0x00484EF0
    int RefreshAndLayout(); // 0x0048A010
    int SelectSubTab3(unsigned __int8 nTab); // 0x0048A350
    int SelectSubTab4(unsigned __int8 nTab); // 0x0048A370
    int InitUILayout(); // 0x0048A390
    int UpdateViewListItems(); // 0x0048B8F0
    int SelectBigMapTab3(char nTab); // 0x00494620
    int SelectBigMapTab4(char nTab); // 0x00494640
    void ProcessInput(); // 0x00494660
    int SelectXJTMTab3(unsigned __int8 nTab); // 0x0049E8A0
    int SelectXJTMTab4(unsigned __int8 nTab); // 0x0049E8C0
    static void InitComItem(); // 0x00551C66
    static int NextRole(int *); // 0x0055CCE4
};
