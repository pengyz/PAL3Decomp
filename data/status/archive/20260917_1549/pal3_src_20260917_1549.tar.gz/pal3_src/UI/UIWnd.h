#pragma once
// Auto-generated: UIWnd
#include "pal3/ida_types.h"

#include "Misc/PtrArray.h"
#include "gbengine/gbengine_types.h"

class UIWnd {
public:
    // vtable (6 methods, order matches binary layout)

    char _gap_000[4]; // +0x0
    gbColorQuad m_fontcolor; // +0x4
    gbColorQuad m_wndcolor; // +0x8
    void * m_id; // +0xC
    tagRECT m_rect; // +0x10
    UIWnd * m_pfather; // +0x20
    PtrArray m_childs; // +0x24
    int m_bcreateok; // +0x34
    int m_bvisible; // +0x38
    int m_benable; // +0x3C
    int m_bfocus; // +0x40
    // total size: 0x44 (68)

    virtual ~UIWnd() {}

    virtual int ShowWindow(int nFlags); // 0x00445E70
    virtual void RenderText(); // 0x0044A870
    virtual int GetUIElements(float fVal, int nVal); // 0x0044A820
    void * _sdtor_14(void *Block, char a2); // 0x0044A7D0
    static int _scalar_dtor(); // 0x0043BB90
    void Destroy(); // 0x0043BBB0
    void GetWidth(int nWidth); // 0x0043FDC0
    void GetHeight(int nHeight); // 0x0043FDD0
    void GetPosition(int pPos); // 0x0043FDE0
    virtual int LayoutAndRender(); // 0x004433D0
    void _UIWnd(); // 0x00445B40
    int OnMessage(int nMsg, int wParam, int lParam); // 0x00445D10
    int MoveWindow(); // 0x00445F20
    void DelegateRender(); // 0x00450390
    void RenderContent(); // 0x00450440
    UIWnd * _sdtor_27(char a2); // 0x00450E90
    int _todo_451730(); // 0x00451730
    UIWnd * _sdtor_28(char a2); // 0x004518E0
    void CleanupScript(); // 0x00457340
    static void SetRect(tagRECT *); // 0x004D589C
    static void BringWindowToTop(); // 0x004D5950
    int _todo_525080(); // 0x00525080
};
