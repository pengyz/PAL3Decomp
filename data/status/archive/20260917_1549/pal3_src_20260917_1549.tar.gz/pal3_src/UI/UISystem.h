#pragma once
// Auto-generated: UISystem
#include "pal3/ida_types.h"

class UISystem {
public:
    _BYTE _tail_000[4]; // +0x0
    // total size: 0x4 (4)

    void Destroy(); // 0x00422DF0
    // Scalar-wrapper: ctors for IDA (Cls)int casts (no init code)
    UISystem() {}
    UISystem(int v) { *(int*)this = v; }

};
