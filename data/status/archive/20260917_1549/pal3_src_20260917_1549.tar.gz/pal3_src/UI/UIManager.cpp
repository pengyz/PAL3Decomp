#include "pal3/ida_defs.h"
#include "globals.h"
#include "pal3/pal3_constants.h"
#include "UI/UIManager.h"
#include "Misc/OpenBaseFile.h"
#include "Misc/OpenNULLFile.h"
#include "Role/Role.h"
#include "Role/RoleSystem.h"
#include "Scene/SceneMgr.h"
#include "Misc/UIBigMap.h"
#include "UI/UIWnd.h"
#include "free_functions.h"

// Forward declarations for unnamed functions

// 0x0041F370
void UIManager::Render()
{
  gbTexture *v2; // eax
  int v3; // eax
  int v4; // edi
  UIManager *v5; // esi
  _DWORD *v6; // ebp
  int *p_m_nSize; // ebp
  UIManager *v8; // esi
  gbMatrix4 *Top; // esi
  const gbMatrix4 *v10; // edi
  UIManager v11; // ecx
  float *v12; // [esp+0x1C] [ebp-0x12C]
  int v13; // [esp+0x2C] [ebp-0x11C]
  int v14; // [esp+0x2C] [ebp-0x11C]
  _DWORD v15[4]; // [esp+0x34] [ebp-0x114] BYREF
  gbMatrix4 v16; // [esp+0x44] [ebp-0x104] BYREF
  gbMatrix4 v17; // [esp+0x84] [ebp-C4h] BYREF
  struct gbTextureArray v18; // [esp+C4h] [ebp-0x84] BYREF
  gbMatrix4 v19; // [esp+0x108] [ebp-0x40] BYREF

  v2 = (gbTexture *)this[1];
  v18.nTex = 1;
  v18.pTexPt[0] = v2;
  v3 = UISceneUpdate();
  v4 = 0;
  v13 = 0;
  if ( *(int *)(v3 + 57568) > 0 )
  {
    v5 = this + 16;
    v6 = (_DWORD *)(v3 + 57716);
    v14 = *(_DWORD *)(v3 + 57568);
    do
    {
      if ( v6[122] )
      {
        if ( *v6 )
        {
          v5[1] = 0;
          *v5 = 0;
          v5[3] = (UIManager)1065353216;
          v5[2] = (UIManager)1065353216;
          if ( (((UIBigMap *)(v6 - 36)))->UIBigMap::Update((int)&v5[-12], v12) )
          {
            ++v4;
            v5 += 17;
          }
        }
      }
      v6 += 2176;
      --v14;
    }
    while ( v14 );
    v13 = v4;
  }
  if ( g_nSceneState != 9 )
  {
    p_m_nSize = (int *)&((RoleSystem *)&stru_C059A0)->_embed_UIWnd_624.m_childs.m_nSize;
    v8 = (UIManager *)&this[17 * v4 + 16];
    do
    {
      if ( p_m_nSize[122] )
      {
        if ( *p_m_nSize )
        {
          v8[1] = 0;
          *v8 = 0;
          v8[3] = (UIManager)1065353216;
          v8[2] = (UIManager)1065353216;
          if ( (((UIBigMap *)(p_m_nSize - 36)))->UIBigMap::Update((int)&v8[-12], v12) )
          {
            ++v4;
            v8 += 17;
          }
        }
      }
      p_m_nSize += 2176;
    }
    while ( (int)p_m_nSize < (int)g_SceneMgr.m_nTodo_C660 );
    v13 = v4;
  }
  if ( v4 > 0 )
  {
    (((gbVertPoolMgr *)gfxMgr->pVertPoolMgr))->gbVertPoolMgr::GetDynVertBuf(0x15u);
    if ( gfxMgr->FogParam.type == 1 )
    {
      Top = (((gbMatrixStack *)gfxMgr->pMatrixStack[1]))->gbMatrixStack::GetTop();
      v10 = (((gbMatrixStack *)gfxMgr->pMatrixStack[0]))->gbMatrixStack::GetTop();
      (((gbMatrix4 *)&v17))->gbMatrix4::LoadIdentity();
      v17.zz = -1.0;
      gbMatrix4::operator=(&v16, Top);
      gbMatrix4::RightMultiply(v16,  &v17);
      gbMatrix4::RightMultiply(v16,  v10);
      gbRenderEffect::SetVariant(*(_DWORD *)&this[3], 0, &v16);
      v15[0] = LODWORD(gfxMgr->FogParam.start);
      v15[1] = LODWORD(gfxMgr->FogParam.end);
      v11 = this[3];
      v15[2] = LODWORD(gfxMgr->FogParam.density);
      v15[3] = 1065353216;
      ((void ( *)(_DWORD, _DWORD, _DWORD))gbRenderEffect::SetVariant)(v11, 2, v15);
      qmemcpy(&v19, Top, sizeof(v19));
      gbMatrix4::RightMultiply(v19,  &v17);
      gbRenderEffect::SetVariant(*(gbRenderEffect **)&this[3], "viewm", &v19);
      (((gbDynVertBuf *)&this[4]))->gbDynVertBuf::RenderGeomQuad(v13, *(gbRenderEffect **)&this[3], &v18);
    }
    else
    {
      (((gbDynVertBuf *)&this[4]))->gbDynVertBuf::RenderGeomQuad(v4, *(gbRenderEffect **)&this[2], &v18);
    }
  }
}

// 0x0041F5E0
void * UIManager::LoadShadowTexture()
{
  gbTexture *v2; // eax
  void *result; // eax
  OpenBaseFile v4; // [esp+0x18] [ebp-0x10] BYREF
  int v5; // [esp+0x24] [ebp-0x4]

  v5 = 0;
  this[1] = (UIManager)v2;
  (((gbTexture *)v2))->gbTexture::LoadTexture(1);
  this[2] = (UIManager)(((gbEffectMgr *)gfxMgr->pEffectMgr))->gbEffectMgr::NewRenderEffect("gfxscript\\shadow.gbf", 0);
  this[3] = (UIManager)(((gbEffectMgr *)gfxMgr->pEffectMgr))->gbEffectMgr::NewRenderEffect("gfxscript\\shadow_F2.gbf", 0);
  v5 = -1;
  // [AUTO-COMMENTED] (OpenNULLFile *)&v4->OpenNULLFile();
  return result;
}
