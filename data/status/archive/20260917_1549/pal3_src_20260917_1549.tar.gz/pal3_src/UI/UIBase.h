#pragma once
// Auto-generated: UIBase
#include "pal3/ida_types.h"

class UIBase {
public:
    _BYTE _tail_000[4]; // +0x0
    // total size: 0x4 (4)

    // Scalar-wrapper: ctors for IDA (Cls)int casts (no init code)
    UIBase() {}
    UIBase(int v) { *(int*)this = v; }

};
