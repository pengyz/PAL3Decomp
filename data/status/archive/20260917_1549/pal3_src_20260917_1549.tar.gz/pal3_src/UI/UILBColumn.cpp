#include "pal3/ida_defs.h"
#include "globals.h"
#include "pal3/pal3_constants.h"
#include "UI/UILBColumn.h"

// 0x0043DCB0
// attributes: thunk
UILBColumn::~UILBColumn()
{
  this->UILBColumn::Destroy();
}

// 0x0043DCC0
void UILBColumn::Destroy()
{
  flt_D90060 = 12.0 + 12.0;
}
