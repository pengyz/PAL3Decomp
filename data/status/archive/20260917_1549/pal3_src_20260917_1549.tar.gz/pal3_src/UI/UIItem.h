#include "UI/UIWnd.h"
#pragma once
// Auto-generated: UIItem
#include "pal3/ida_types.h"

class UIItem : public UIWnd {
public:
    char _gap_000[68]; // +0x0
    int m_fTimerLimit; // +0x44
    int m_fTimerAccum; // +0x48
    int m_nTodo_04C; // +0x4C
    int m_nTodo_050; // +0x50
    int m_nTodo_054; // +0x54
    int m_nTodo_058; // +0x58
    int m_nTodo_05C; // +0x5C
    char _tail_060[136]; // +0x60
    // total size: 0xE8 (232)

    void * SetData(char pData); // 0x004A14D0
};
