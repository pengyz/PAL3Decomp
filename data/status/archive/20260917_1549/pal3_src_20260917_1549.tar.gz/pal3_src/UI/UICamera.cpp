#include "pal3/ida_defs.h"
#include "globals.h"
#include "pal3/pal3_constants.h"
#include "UI/UICamera.h"
#include "Scene/CameraCtrl.h"
#include "Role/Object3D.h"
#include "Role/Role.h"
#include "Role/RoleSystem.h"
#include "Scene/SceneMgr.h"
#include "Misc/ScriptSystemData.h"
#include "UI/UIWnd.h"
#include "Misc/scAsmDecoder.h"

// Forward declarations for unnamed functions
int sub_429A90(...);

// 0x0041A070
BOOL UICamera::IsPointVisible(float *pfTargetPos, char bNearVisible)
{
  double v4; // st7
  double v5; // st6
  gbVec3D v7; // [esp+0x4] [ebp-0x18] BYREF
  float v8; // [esp+0x14] [ebp-0x8]
  float v9; // [esp+0x18] [ebp-0x4]
  float pfTargetPosa; // [esp+0x20] [ebp+0x4]

  v4 = *pfTargetPos - *((float *)this + 1);
  v8 = pfTargetPos[1] - *((float *)this + 2);
  v5 = pfTargetPos[2] - *((float *)this + 3);
  v7.y = v8;
  v9 = v5;
  v7.x = v4;
  v7.z = v9;
  pfTargetPosa = (((gbVec3D *)&v7))->gbVec3D::Length();
  if ( 0.87 * 500.0 < pfTargetPosa )
    return 0;
  if ( bNearVisible && 12.0 * 8.0 > pfTargetPosa )
    return 1;
  return v7.z / pfTargetPosa * *((float *)this + 7)
       + v7.y / pfTargetPosa * *((float *)this + 6)
       + v7.x / pfTargetPosa * *((float *)this + 5) > 0.87;
}

// 0x00420CD0
int UICamera::GetViewMode(int nVal)
{
  int v1; // ecx
  int v2; // ebp
  int v3; // ebx
  int v4; // edi
  int v5; // eax
  UICamera *v6; // ecx
  int v7; // esi
  float v8; // eax
  float v9; // eax
  double v10; // st7
  double v11; // st7
  double v12; // st7
  float v14; // [esp+0xC] [ebp-0x14]
  float v15; // [esp+0x10] [ebp-0x10]
  float pfTargetPos; // [esp+0x14] [ebp-0xC] BYREF
  float v17; // [esp+0x18] [ebp-0x8]
  float v18; // [esp+0x1C] [ebp-0x4]

  v2 = v1;
  v3 = -1;
  v4 = 0;
  v5 = *(_DWORD *)(v1 + 220);
  pfTargetPos = 0.0;
  v17 = 0.0;
  v18 = 0.0;
  v15 = 3.4028235e38;
  if ( v5 <= 0 )
    return 0;
  v6 = (UICamera *)((RoleSystem *)&stru_C10DF0)->m_teamSlotOverlay.m_teamSlots[154];
  v7 = v2 + 272;
  do
  {
    if ( *(_BYTE *)(v7 + 125)
      && (*(_BYTE *)(v7 + 160) & 2) != 0
      && *(_BYTE *)(v7 + 126)
      && *(unsigned __int8 *)(v7 + 198) == v6->m_hCameraHandle )
    {
      v8 = *(float *)v7;
      pfTargetPos = *(float *)(v7 - 8);
      v18 = v8;
      v17 = 0.0;
      if ( (((UICamera *)v6))->UICamera::IsPointVisible(&pfTargetPos, 1) )
      {
        v9 = *(float *)(v7 - 8);
        v18 = *(float *)v7;
        v6 = (UICamera *)((RoleSystem *)&stru_C10DF0)->m_teamSlotOverlay.m_teamSlots[154];
        pfTargetPos = v9;
        v17 = 0.0;
        pfTargetPos = v9 - *(float *)(((RoleSystem *)&stru_C10DF0)->m_teamSlotOverlay.m_teamSlots[154] + 4);
        v17 = -*(float *)(((RoleSystem *)&stru_C10DF0)->m_teamSlotOverlay.m_teamSlots[154] + 8);
        v10 = v18 - *(float *)(((RoleSystem *)&stru_C10DF0)->m_teamSlotOverlay.m_teamSlots[154] + 12);
        v18 = v10;
        v11 = v10 * v18 + pfTargetPos * pfTargetPos + v17 * v17;
        v14 = v11;
        if ( v11 < v15 )
        {
          v3 = v4;
          v15 = v11;
        }
      }
      else
      {
        v6 = (UICamera *)((RoleSystem *)&stru_C10DF0)->m_teamSlotOverlay.m_teamSlots[154];
      }
    }
    ++v4;
    v7 += 896;
  }
  while ( v4 < *(_DWORD *)(v2 + 220) );
  if ( v3 < 0 )
    return 0;
  v12 = *(float *)(896 * v3 + v2 + 1104);
  if ( v14 - v12 * v12 >= 10000.0 )
    return 0;
  else
    return 896 * v3 + v2 + 224;
}

// 0x00420E50
float * UICamera::CalcPosition(float *pMat)
{
  int v1; // ecx
  int v2; // ebp
  int v3; // ebx
  int v4; // edi
  int v5; // esi
  double v6; // st6
  double v7; // st5
  double v8; // st3
  double v9; // st4
  float v11; // [esp+0xC] [ebp-0x4]

  v2 = v1;
  v3 = -1;
  v4 = 0;
  v11 = 3.4028235e38;
  if ( *(int *)(v1 + 220) <= 0 )
    return 0;
  v5 = v1 + 272;
  do
  {
    if ( *(_BYTE *)(v5 + 125)
      && (*(_BYTE *)(v5 + 160) & 2) != 0
      && *(_BYTE *)(v5 + 126)
      && sub_429A90((Object3D *)(v5 - 48), pMat) )
    {
      v6 = g_pCameraCtrl->m_vecLookAt.y - *(float *)(v5 - 4);
      v7 = g_pCameraCtrl->m_vecLookAt.z - *(float *)v5;
      v8 = g_pCameraCtrl->m_vecLookAt.x - *(float *)(v5 - 8);
      v9 = v7 * v7 + v8 * v8 + v6 * v6;
      if ( v9 < v11 )
      {
        v11 = v9;
        v3 = v4;
      }
    }
    ++v4;
    v5 += 896;
  }
  while ( v4 < *(_DWORD *)(v2 + 220) );
  if ( v3 >= 0 )
    return (float *)(896 * v3 + v2 + 224);
  else
    return 0;
}

// 0x004230D0
int UICamera::GetState()
{
  int p_m_childs; // ebp
  int v2; // ebx
  int v3; // edi
  int v4; // esi
  double v5; // st7
  double v6; // st7
  double v7; // st7
  scAsmDecoder *v8; // edi
  UIWnd *v9; // esi
  double v10; // st7
  double v11; // st7
  double v12; // st7
  float v14; // [esp+0x4] [ebp-0x1C]
  float v15; // [esp+0x8] [ebp-0x18]
  float v16; // [esp+0x8] [ebp-0x18]
  float v17; // [esp+0xC] [ebp-0x14]
  float v18; // [esp+0xC] [ebp-0x14]
  float v19; // [esp+0x10] [ebp-0x10]
  float v20; // [esp+0x10] [ebp-0x10]
  gbVec3D v21; // [esp+0x14] [ebp-0xC] BYREF

  p_m_childs = 0;
  v14 = 3.4028235e38;
  v2 = 0;
  v3 = 493156 * (g_ScriptSystemData.m_nGameMode == 1) + 12722152;
  if ( *(&dword_C300C8 + 123289 * (g_ScriptSystemData.m_nGameMode == 1)) > 0 )
  {
    v4 = 493156 * (g_ScriptSystemData.m_nGameMode == 1) + 12779892;
    do
    {
      if ( *(_DWORD *)(v4 + 464) )
      {
        if ( *(_DWORD *)(v4 - 24) )
        {
          if ( *(_DWORD *)(((RoleSystem *)&stru_C10DF0)->m_teamSlotOverlay.m_teamSlots[154] + 628) == *(_DWORD *)(v4 + 460) )
          {
            if ( (((RoleSystem *)((RoleSystem *)&stru_C10DF0)->m_teamSlotOverlay.m_teamSlots[154]))->RoleSystem::AdvancePathStep((float *)(v4 - 164)) )
            {
              v15 = *(float *)(((RoleSystem *)&stru_C10DF0)->m_teamSlotOverlay.m_teamSlots[154] + 160) - *(float *)(v4 - 8);
              v5 = *(float *)(((RoleSystem *)&stru_C10DF0)->m_teamSlotOverlay.m_teamSlots[154] + 164) - *(float *)(v4 - 4);
              v21.x = v15;
              v17 = v5;
              v6 = *(float *)(((RoleSystem *)&stru_C10DF0)->m_teamSlotOverlay.m_teamSlots[154] + 168) - *(float *)v4;
              v21.y = v17;
              v19 = v6;
              v21.z = v19;
              v7 = (((gbVec3D *)&v21))->gbVec3D::Length();
              if ( v7 < v14 )
              {
                v14 = v7;
                p_m_childs = v4 - 168;
              }
            }
          }
        }
      }
      ++v2;
      v4 += 8704;
    }
    while ( v2 < *(_DWORD *)(v3 + 57568) );
  }
  v8 = 0;
  v9 = (UIWnd *)(&((RoleSystem *)&stru_C059A0)->_embed_UIWnd_624 + 1);
  do
  {
    if ( v8 != g_SceneMgr.m_nCurrentRoleSlot )
    {
      if ( v9[6].m_bvisible )
      {
        if ( (((UICamera *)((RoleSystem *)&stru_C10DF0)->m_teamSlotOverlay.m_teamSlots[154]))->UICamera::IsPointVisible((float *)&v9[-3].m_childs.capacity, 1) )
        {
          v16 = *(float *)(((RoleSystem *)&stru_C10DF0)->m_teamSlotOverlay.m_teamSlots[154] + 160) - *(float *)&v9[-1].m_benable;
          v10 = *(float *)(((RoleSystem *)&stru_C10DF0)->m_teamSlotOverlay.m_teamSlots[154] + 164) - *(float *)&v9[-1].m_bfocus;
          v21.x = v16;
          v18 = v10;
          v11 = *(float *)(((RoleSystem *)&stru_C10DF0)->m_teamSlotOverlay.m_teamSlots[154] + 168) - *(float *)((void **)(v9));
          v21.y = v18;
          v20 = v11;
          v21.z = v20;
          v12 = (((gbVec3D *)&v21))->gbVec3D::Length();
          if ( v12 < v14 )
          {
            v14 = v12;
            p_m_childs = (int)&v9[-3].m_childs;
          }
        }
      }
    }
    v9 += 128;
    v8 = (scAsmDecoder *)((char *)v8 + 1);
  }
  while ( (int)v9 < (int)&unk_C10968.m_nAnimState );
  if ( p_m_childs && 12.0 * 4.5 < v14 - *(float *)(p_m_childs + 16) )
    return 0;
  else
    return p_m_childs;
}

// 0x004232D0
int UICamera::GetTarget()
{
  int v0; // edi
  char v1; // bl
  int v2; // ebp
  int v3; // esi
  double v4; // st6
  double v5; // st5
  double v6; // st3
  double v7; // st4
  scAsmDecoder *v8; // edi
  UIWnd *v9; // esi
  double v10; // st6
  double v11; // st5
  double v12; // st3
  double v13; // st4
  float v15; // [esp+0x0] [ebp-0x8]
  int v16; // [esp+0x4] [ebp-0x4]
  gbRay *pRay; // [esp+0xC] [ebp+0x4]

  v15 = 3.4028235e38;
  v16 = -1;
  v0 = 0;
  v1 = 1;
  v2 = 493156 * (g_ScriptSystemData.m_nGameMode == 1) + 12722152;
  if ( *(&dword_C300C8 + 123289 * (g_ScriptSystemData.m_nGameMode == 1)) > 0 )
  {
    v3 = 493156 * (g_ScriptSystemData.m_nGameMode == 1) + 12779892;
    do
    {
      if ( *(_DWORD *)(v3 + 464) )
      {
        if ( *(_DWORD *)(v3 - 24) )
        {
          if ( (((RoleSystem *)(v3 - 168)))->RoleSystem::CheckWidgetReady(pRay) )
          {
            v4 = g_pCameraCtrl->m_vecLookAt.y - *(float *)(v3 - 4);
            v5 = g_pCameraCtrl->m_vecLookAt.z - *(float *)v3;
            v6 = g_pCameraCtrl->m_vecLookAt.x - *(float *)(v3 - 8);
            v7 = v5 * v5 + v4 * v4 + v6 * v6;
            if ( v7 < v15 )
            {
              v15 = v7;
              v16 = v0;
              v1 = 1;
            }
          }
        }
      }
      ++v0;
      v3 += 8704;
    }
    while ( v0 < *(_DWORD *)(v2 + 57568) );
  }
  v8 = 0;
  v9 = (UIWnd *)(&((RoleSystem *)&stru_C059A0)->_embed_UIWnd_624 + 1);
  do
  {
    if ( v8 != g_SceneMgr.m_nCurrentRoleSlot )
    {
      if ( v9[6].m_bvisible )
      {
        if ( (((RoleSystem *)&v9[-3].m_childs))->RoleSystem::CheckWidgetReady(pRay) )
        {
          v10 = g_pCameraCtrl->m_vecLookAt.y - *(float *)&v9[-1].m_bfocus;
          v11 = g_pCameraCtrl->m_vecLookAt.z - *(float *)((void **)(v9));
          v12 = g_pCameraCtrl->m_vecLookAt.x - *(float *)&v9[-1].m_benable;
          v13 = v11 * v11 + v10 * v10 + v12 * v12;
          if ( v13 < v15 )
          {
            v15 = v13;
            v16 = (int)v8;
            v1 = 0;
          }
        }
      }
    }
    v9 += 128;
    v8 = (scAsmDecoder *)((char *)v8 + 1);
  }
  while ( (int)v9 < (int)&unk_C10968.m_nAnimState );
  if ( v16 < 0 )
    return 0;
  if ( v1 )
    return 8704 * v16 + v2 + 57572;
  return (int)(&((RoleSystem *)&stru_C059A0)->m_fCachePosY + 2176 * v16);
}
