#pragma once
// Auto-generated: UIManager
#include "pal3/ida_types.h"

class UIManager {
public:
    _BYTE _tail_000[4]; // +0x0
    // total size: 0x4 (4)

    void Render(); // 0x0041F370
    void * LoadShadowTexture(); // 0x0041F5E0
    // Scalar-wrapper: ctors for IDA (Cls)int casts (no init code)
    UIManager() {}
    UIManager(int v) { *(int*)this = v; }

};
