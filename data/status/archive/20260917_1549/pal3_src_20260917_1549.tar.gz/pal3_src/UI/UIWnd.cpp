#include "pal3/ida_defs.h"
#include "globals.h"
#include "pal3/pal3_constants.h"
#include "UI/UIWnd.h"
#include "Render/RenderTarget2.h"
#include "Scene/SceneObj.h"
#include "Misc/TextureLibDataBase.h"
#include "UI/UIListBox.h"
#include "Misc/UIStatic.h"
#include "Misc/UITitle_BBTY.h"
#include "free_functions.h"

// Forward declarations for unnamed functions

// 0x0043BBB0
void UIWnd::Destroy()
{
}

// 0x0043FDC0
void UIWnd::GetWidth(int nWidth)
{
  *(float *)&this[2].m_fontcolor.Color = (float)nWidth;
}

// 0x0043FDD0
void UIWnd::GetHeight(int nHeight)
{
  *(float *)&this[2].m_wndcolor.Color = (float)nHeight;
}

// 0x0043FDE0
void UIWnd::GetPosition(int pPos)
{
  *(float *)&this[2].m_id = (float)pPos;
}

// 0x004433D0
int UIWnd::LayoutAndRender()
{
  int result; // eax

  result = this->m_bvisible;
  if ( result )
  {
    if ( this[1].m_childs.m_nSize && this[2].m_rect.left <= 1u )
      UIInitSystem();
    if ( !this->m_benable && this[1].m_benable && this[2].m_rect.left <= 1u )
      UIInitSystem();
    (((UITitle_BBTY *)this))->UITitle_BBTY::Render() /* [ROWTABLE] */;
  }
  return result;
}

// 0x00445B40
void UIWnd::_UIWnd()
{
  (((SceneObj *)this))->SceneObj::HideAll() /* [ROWTABLE] */;
  (((UIListBox *)&this->m_childs))->UIListBox::ReleaseVtable();
}

// 0x00445E70
int UIWnd::ShowWindow(int nFlags)
{
  int result; // eax
  void *vftable; // edx

  result = this->m_bcreateok;
  if ( result )
  {
    result = nFlags;
    if ( this->m_bvisible != nFlags )
    {
      vftable = (*(void **)(this));
      this->m_bvisible = nFlags;
      return ((int ( *)(int, int, _DWORD))vftable->OnMessage)(1000, nFlags, 0);
    }
  }
  return result;
}

// 0x00445F20
int UIWnd::MoveWindow()
{
  int v2; // esi
  gbRefObject **v3; // ebx
  int result; // eax

  v2 = 0;
  if ( this->m_bfocus > 0 )
  {
    v3 = (gbRefObject **)this;
    do
    {
      (*v3)->gbRefObject::Release();
      ++v2;
      ++v3;
    }
    while ( v2 < this->m_bfocus );
  }
  result = 0;
  memset(this, 0, sizeof(UIWnd));
  return result;
}

// 0x0044A820
int UIWnd::GetUIElements(float fVal, int nVal)
{
  double v4; // st7
  LONG top; // edx
  void *m_id; // eax

  if ( !this->m_bvisible )
    return 0;
  v4 = fVal + *(float *)&this[1].m_rect.right;
  top = this[1].m_rect.top;
  m_id = (void *)this[1].m_id;
  *(float *)&this[1].m_rect.right = v4;
  if ( top > (int)m_id || v4 <= 2.0 )
    return 1;
  this[1].m_rect.right = 0;
  this[1].m_rect.top = top + 1;
  return 1;
}

// 0x0044A870

// ---- synthesized vtable stubs (unresolved slots) ----
// [VFTABLE-STUB] original: ((void ( *)(UIWnd *))this->__vftable->Destroy)(this)
static void pal3_vtbl_unk_0(UIWnd *);

void UIWnd::RenderText()
{
  void *m_id; // ebp
  LONG top; // eax
  LONG v4; // edi
  double v5; // st7
  double v6; // st7
  int v7; // edi

  if ( this->m_bvisible )
  {
    if ( this[1].m_wndcolor.Color )
    {
      m_id = (void *)this[1].m_id;
      if ( (int)m_id > 0 )
      {
        top = this[1].m_rect.top;
        if ( top > (int)m_id )
        {
          v5 = *(float *)&this[1].m_rect.right - 5.0;
          if ( v5 <= 0.0 )
            v5 = 0.0;
          v6 = 1.0 - v5 * 0.33333334;
          if ( v6 < 0.0 )
            v6 = 0.0;
          v7 = 0;
          do
            (((UIStatic *)this))->UIStatic::RenderTile(v7++, (__int64)(v6 * 255.0)) /* [ROWTABLE] */;
          while ( v7 <= (int)this[1].m_id );
          if ( !(unsigned __int8)(__int64)(v6 * 255.0) )
          {
            pal3_vtbl_unk_0(this) /* [VFTABLE-STUB] */;
            this->ShowWindow(0);
          }
        }
        else
        {
          v4 = 0;
          if ( top > 0 )
          {
            do
              (((UIStatic *)this))->UIStatic::RenderTile(v4++, 255) /* [ROWTABLE] */;
            while ( v4 < this[1].m_rect.top );
          }
          (((UIStatic *)this))->UIStatic::RenderTile(this[1].m_rect.top, (__int64)(*(float *)&this[1].m_rect.right / 2.0 * 255.0)) /* [ROWTABLE] */;
        }
      }
    }
  }
}

static void pal3_vtbl_unk_0(UIWnd *)
{
    
}


// 0x00450390
void UIWnd::DelegateRender()
{
  this->UIWnd::Destroy();
}

// 0x00450440
void UIWnd::RenderContent()
{
  unsigned int v2; // [esp+0x4] [ebp-0x5C]

  if ( this->m_bvisible )
  {
    if ( this[1].m_rect.right )
      (((TextureLibDataBase *)&this->m_wndcolor))->TextureLibDataBase::SetLibFolder((char *)&this->m_rect);
    strlen((const char *)&this[1].m_rect.bottom);
    if ( gbColorQuad::ColorQuadFmt )
    {
      BYTE2(v2) = this->m_fontcolor.Color;
      BYTE1(v2) = BYTE1(this->m_fontcolor.Color);
      LOBYTE(v2) = BYTE2(this->m_fontcolor.Color);
    }
    else
    {
      BYTE2(v2) = BYTE2(this->m_fontcolor.Color);
      LOWORD(v2) = this->m_fontcolor.Color;
    }
    HIBYTE(v2) = -1;
    gfxMgr->pFontMgr->pAllFont[1]->curColor.Color = v2;
    crt_sub_00541210();
    (((UITitle_BBTY *)this))->UITitle_BBTY::Render() /* [ROWTABLE] */;
  }
}

// 0x00451730
int UIWnd::_todo_451730()
{
  return this[16].m_rect.left;
}

// 0x004D5950
void UIWnd::BringWindowToTop()
{
  int v0; // ebx
  char *v1; // esi
  int v2; // eax
  char *Buffer; // [esp+0x10] [ebp+0x4]
  const char *v4; // [esp+0x14] [ebp+0x8]

  if ( Buffer != v4 )
    strcpy(Buffer, v4);
  v0 = 0;
  v1 = (char *)Buffer;
  if ( strlen(Buffer) )
  {
    while ( *v1 < 48 || *v1 > 57 )
    {
      ++v1;
      if ( ++v0 >= strlen(Buffer) )
        goto LABEL_7;
    }
    v2 = atoi(v1);
    sprintf(v1, &dir[20], v2 + 1);
  }
  else
  {
LABEL_7:
    strcat(Buffer, (const char *)&pTarget.m_nTargetType + 224);
  }
}

// 0x00525080
int UIWnd::_todo_525080()
{
  return this[77].m_rect.bottom;
}
