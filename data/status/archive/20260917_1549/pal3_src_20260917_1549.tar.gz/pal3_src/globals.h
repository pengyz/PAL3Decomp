#pragma once
// PAL3 global variables with known types
// Auto-generated from pipeline/data/annotations/globals.json

#include <windows.h>
#include "pal3/ida_types.h"
#ifndef _PVFV
typedef void (__cdecl *_PVFV)(void);
#include "Misc/ARC_PlayerAtt.h"
#include "Role/Actor.h"
#include "Misc/Array.h"
#include "Misc/CCBEditor.h"
#include "Effect/CEffMgr.h"
#include "Render/CScreenMode.h"
#include "Misc/CScreenModeNode.h"
#include "GameBase/GRPinput.h"
#include "GameBase/PAL3.h"
#include "Script/PalScript.h"
#include "Script/PalScriptMgr.h"
#include "Misc/PtrArray.h"
#include "Render/RenderTarget2.h"
#include "Render/RenderTarget3.h"
#include "Misc/RoleCameraCtrl.h"
#include "Role/RoleSystem.h"
#include "Misc/SceneMapPlayer.h"
#include "Scene/SceneMgr.h"
#include "Misc/ScriptCounter.h"
#include "Misc/ScriptSystemData.h"
#include "Misc/TextureLibDataBase.h"
#include "UI/UIListBox.h"
#include "Misc/UISceneMap.h"
#include "UI/UISystem.h"
#include "Misc/tag17A7BData.h"
#include "Misc/tag17A8Data.h"
#include "Misc/tagC10Data.h"
#include "Misc/tagCCBStageData.h"
#include "Misc/tagCombatTaskData.h"
#include "Misc/tagEffMgrData.h"
#include "Misc/tagEffSParticleSys.h"
#include "Misc/tagRoleSystemData.h"
#include "Misc/tagStageRoleData.h"

class CCBSystem;
class CameraCtrl;
class ComposeUI;
class PAL_GDB;
class gbActorMgr;
class gbDropGroup;
class gbGfxDriverInfo;
class gbGfxManager;
class gbRenderEffect;
class gbVFileSystem;
class gbVec3D;
class gbVolModNode;
class scAsmDecoder;

#endif

// 2785 typed globals

extern float g_fHeuristicScale[8]; // 0x56a5e0
extern unsigned __int8 g_bActorFlag; // 0x56a634
extern const char ArgList[]; // 0x56a660
extern char *const pszAction; // 0x56a7ac
extern int dword_56A898; // 0x56a898
extern const unsigned int dwVal2; // 0x56ab90
extern void * off_56ABA4; // 0x56aba4
extern int dword_56AEE8; // 0x56aee8
extern int stru_56AF80; // 0x56af80
extern int dword_56B220; // 0x56b220
extern int stru_56B22C; // 0x56b22c
extern void * off_56B24C; // 0x56b24c
extern void * off_56B260; // 0x56b260
extern int dword_56B294; // 0x56b294
extern int dword_56B3C8; // 0x56b3c8
extern void * off_56B43C; // 0x56b43c
extern const LPCSTR nData; // 0x56b460
extern int dword_56B4DC; // 0x56b4dc
extern int dword_56B4F0; // 0x56b4f0
extern void * off_56B504; // 0x56b504
extern void * off_56B518; // 0x56b518
extern void * off_56B52C; // 0x56b52c
extern int dword_56B540; // 0x56b540
extern int dword_56B554; // 0x56b554
extern int dword_56B568; // 0x56b568
extern int dword_56B57C; // 0x56b57c
extern int dword_56B590; // 0x56b590
extern int dword_56B5A4; // 0x56b5a4
extern int dword_56B5B8; // 0x56b5b8
extern int dword_56B608; // 0x56b608
extern void * off_56B674; // 0x56b674
extern int dword_56B6F0; // 0x56b6f0
extern int dword_56B77C; // 0x56b77c
extern void * off_56B794; // 0x56b794
extern int dword_56B884; // 0x56b884
extern void * off_56B898; // 0x56b898
extern void * off_56B97C; // 0x56b97c
extern void * off_56B990; // 0x56b990
extern void * off_56BA08; // 0x56ba08
extern void * off_56BA1C; // 0x56ba1c
extern void * off_56C534; // 0x56c534
extern void * off_56C548; // 0x56c548
extern int g_MonsterEntryTable[]; // 0x56c568
extern void * g_ArcSceneMonsterTable; // 0x56c57c
extern void * off_56D5B0; // 0x56d5b0
extern void * off_56D5D8; // 0x56d5d8
extern int dword_56D5F0; // 0x56d5f0
extern void * g_pfnCallback; // 0x56d604
extern void * off_56E11C; // 0x56e11c
extern void * off_56E130; // 0x56e130
extern int dword_56E148; // 0x56e148
extern void * g_ArcSceneMonsterTable2; // 0x56e15c
extern void * off_56F018; // 0x56f018
extern int g_ComposeUIChildIDs[]; // 0x56f02c
extern void * off_56F1A4; // 0x56f1a4
extern void * off_56F1B8; // 0x56f1b8
extern void * off_56F1CC; // 0x56f1cc
extern void * off_56F1E0; // 0x56f1e0
extern void * off_56F1F4; // 0x56f1f4
extern void * off_56F208; // 0x56f208
extern void * off_56F314; // 0x56f314
extern void * off_56F328; // 0x56f328
extern const int nVal5; // 0x56fbec
extern const LPCSTR lpFileName; // 0x56fc8c
extern int g_nStatePanelL[4]; // 0x56fcc8
extern int g_nStatePanelT[4]; // 0x56fcd8
extern const float formal; // 0x56fd04
extern const float fVal; // 0x56fd0c
extern const int bVisible; // 0x56fdac
extern int animId; // 0x56fe20
extern int dword_56FE98; // 0x56fe98
extern int g_nItemTypeBase[4]; // 0x570080
extern int g_nSkillTabIDs[4]; // 0x570090
extern int g_nMagicTabIDs[4]; // 0x5700a0
extern int g_nItemTabIDs[4]; // 0x5700b0
extern int g_nItemIDs_69[5]; // 0x5700c0
extern int g_nSkillItemIDTable[25]; // 0x5700d4
extern int g_nPropIDs_208[5]; // 0x570138
extern int g_nPropIDs_241[11]; // 0x57014c
extern int g_nStatePanelL_dup[4]; // 0x570178
extern int g_nStatePanelT_dup[4]; // 0x570188
extern int g_nSpriteSize_64[5]; // 0x570198
extern int g_nSpriteSize_82[5]; // 0x5701ac
extern int g_nSpriteSize_20[5]; // 0x5701c0
extern int g_nUnkDataTable[30]; // 0x5701d4
extern int g_nUnkTable_24C[7]; // 0x57024c
extern int g_nUnkTable_268[7]; // 0x570268
extern void * off_570298; // 0x570298
extern void * off_570310; // 0x570310
extern int dword_570324; // 0x570324
extern const LPCSTR lpString; // 0x570618
extern void * off_5706AC; // 0x5706ac
extern void * off_5706C0; // 0x5706c0
extern void * off_5706CC; // 0x5706cc
extern void * off_570748; // 0x570748
extern void * off_570754; // 0x570754
extern void * off_5707D0; // 0x5707d0
extern void * off_5707F0; // 0x5707f0
extern void * off_57081C; // 0x57081c
extern void * off_570904; // 0x570904
extern const CHAR SubKey[]; // 0x572b3c
extern const CHAR OutputString[]; // 0x572db0
extern const CHAR ProcName[]; // 0x573268
extern const CHAR ModuleName[]; // 0x573284
extern const WCHAR SrcStr; // 0x573388
extern const CHAR LibFileName[]; // 0x5737d4
extern int dword_573800; // 0x573800
extern int dword_573810; // 0x573810
extern const IID riidltf; // 0x573860
extern int dword_573A5C; // 0x573a5c
extern int dword_573C64; // 0x573c64
extern char ValueName_0[256]; // 0x575098
extern _PVFV First; // 0x5809ec
extern _PVFV Last; // 0x580a00
extern char Format[256]; // 0x580a88
extern char msg[]; // 0x580afc
extern char file[]; // 0x580b1c
extern char aSS[]; // 0x580b54
extern const char * off_580CFC; // 0x580cfc
extern char Mode[3]; // 0x580d00
extern int g_nPAL3_5833B8; // 0x5833b8
extern unsigned int g_dwGameFlags; // 0x5833bc
extern unsigned __int8 g_bFullScreen; // 0x5833c0
extern unsigned __int8 g_bGameFlag2; // 0x5833c2
extern int g_nKeyMap1; // 0x5833c4
extern int g_nKeyMap2; // 0x5833c8
extern int g_nKeyMap3; // 0x5833cc
extern char g_szGamePath[256]; // 0x5833d0
extern char aCouldNotAlloca_0[]; // 0x58378c
extern char aCouldNotAlloca[]; // 0x5837b4
extern char aGameCreateOk[]; // 0x5837e4
extern char aSBulidSS[]; // 0x5837f8
extern char a163941[]; // 0x583814
extern char path[256]; // 0x583820
extern char a03d[]; // 0x583948
extern char aWindowCreateFa[]; // 0x583950
extern CHAR aRate[]; // 0x583968
extern CHAR aDepthbits[]; // 0x583970
extern CHAR aColorbits[]; // 0x58397c
extern CHAR aHeight[]; // 0x583988
extern CHAR aDisplay[]; // 0x583990
extern CHAR section[]; // 0x583998
extern char filename[]; // 0x5839a0
extern char aRegisterclassF[]; // 0x5839ac
extern CHAR WindowName[]; // 0x5839c4
extern CHAR aScursor[]; // 0x5839d8
extern CHAR aMotionblur[]; // 0x5839e0
extern CHAR aSync[]; // 0x5839ec
extern CHAR aXmusic[]; // 0x5839f4
extern CHAR aXsnd[]; // 0x5839fc
extern CHAR aSoftcursor[]; // 0x583a04
extern CHAR CmdLine[]; // 0x583a10
extern CHAR aMisc[]; // 0x583a14
extern char byte_583A1C[3]; // 0x583a1c
extern char aS[]; // 0x583a20
extern CHAR aSoftwareSoftst[]; // 0x583a28
extern CHAR aSGameA[]; // 0x583a48
extern CHAR aWriteRegError[]; // 0x583a54
extern CHAR szCaption[]; // 0x583a64
extern char aExceptionInitC[]; // 0x583a78
extern char dir[256]; // 0x583a9c
extern int g_nPtrArray_586154; // 0x586154
extern int g_nFrameRate; // 0x586158
extern int g_nUpdateInterval; // 0x58615c
extern char aUiFlexNote_0[]; // 0x586160
extern char g_pszDefaultScene[4]; // 0x586180
extern char g_pszScene1[4]; // 0x586184
extern char g_pszScene2[4]; // 0x586188
extern char g_pfnUpdateFuncs[4][5]; // 0x58618c
extern char g_szFormat105[]; // 0x586190
extern int dword_586194; // 0x586194
extern int dword_586198; // 0x586198
extern int dword_58619C; // 0x58619c
extern char aGetmoney[]; // 0x5861a8
extern char aLossmoney[]; // 0x5861b4
extern char name[]; // 0x5861c0
extern char byte_5861F8[3]; // 0x5861f8
extern char aYlfSS[]; // 0x586218
extern tagCCBStageData g_CCBStageData; // 0x5888a8
extern char aHold[]; // 0x588994
extern char aOver[]; // 0x5889bc
extern char pszMsgName[]; // 0x5889c4
extern char aOutdist[]; // 0x5889cc
extern char aRoleSSTga[]; // 0x5889d4
extern char aS4[]; // 0x5889e4
extern char aGetitem[]; // 0x5889ec
extern char aGetexp[]; // 0x5889fc
extern char aS3[]; // 0x588a04
extern char aWeaponSSSTga[]; // 0x588a14
extern char aWeaponSSPol[]; // 0x588a28
extern int g_nCameraUpdateCount; // 0x58b230
extern int g_nRoleSystem_58B234; // 0x58b234
extern float g_fCameraDefaultDist; // 0x58b238
extern char aSndWe022CWav[]; // 0x58b23c
extern char aSndWe021CWav[]; // 0x58b24c
extern tagRoleSystemData g_RoleSystemData; // 0x58b260
extern int dword_58B440; // 0x58b440
extern int off_58B444; // 0x58b444
extern char g_LanguageCode[3]; // 0x58b448
extern char aRole[]; // 0x58b44c
extern char aDatascriptScen_0[]; // 0x58b454
extern char nIndex[]; // 0x58b770
extern char aN05[]; // 0x58b77c
extern char aQ02[4]; // 0x58b780
extern char a1n07a[]; // 0x58b784
extern char aM26[]; // 0x58b78c
extern char aSSLgt[]; // 0x58b790
extern char aSSCvd[]; // 0x58b7a8
extern char aSSPol_0[]; // 0x58b7b4
extern char aS1SPol[]; // 0x58b7c0
extern char aSSNav[]; // 0x58b7cc
extern char aXmouse[]; // 0x58b7d8
extern char aSScn[]; // 0x58b7e4
extern float g_fEffectTimer; // 0x58de64
extern char aM02[4]; // 0x58de68
extern char aSSce[]; // 0x58de6c
extern char aQ08p[]; // 0x58de74
extern char aQ08f[]; // 0x58de7c
extern char pszBuf[]; // 0x58de84
extern char aM25[]; // 0x58de88
extern char aM20_0[]; // 0x58de8c
extern char aM19_0[]; // 0x58de90
extern char a4_0[3]; // 0x590538
extern char aObjectS[]; // 0x59053c
extern char aItemSSPol_0[]; // 0x590548
extern char aSS_1[]; // 0x590560
extern char aSndSWav[]; // 0x590568
extern char aLessweight[]; // 0x590574
extern char aM09[]; // 0x59058c
extern char aNothing[]; // 0x590590
extern char aAddluck[]; // 0x590598
extern char aAddspeed[]; // 0x5905a0
extern int a368; // 0x5905ac
extern char aNotmoney[]; // 0x5905b0
extern char aThrow0[]; // 0x5905c4
extern char aThrow100[]; // 0x5905cc
extern char aThrow10[]; // 0x5905d8
extern char aThrow1[]; // 0x5905e0
extern char aChestNotopen[]; // 0x5905e8
extern char aChestFailed[]; // 0x5905f8
extern char aObjectWz20DCvd[]; // 0x590608
extern char aPol[]; // 0x59061c
extern char aCvd[]; // 0x590624
extern char aM22[]; // 0x59062c
extern CHAR a3[]; // 0x590630
extern char aM15[]; // 0x590634
extern CHAR a2[]; // 0x590638
extern char aG01Cvd[]; // 0x59063c
extern char a3_0[]; // 0x590644
extern char aM22_0[]; // 0x590650
extern char pszName2[]; // 0x590654
extern LPCSTR lpDefault; // 0x592d80
extern char aPal3lang[]; // 0x592d84
extern char aBegin[]; // 0x592d9c
extern char byte_592DA4[3]; // 0x592da4
extern char aBigmapScriptLo[]; // 0x592da8
extern char aUiBigmapBigmap[]; // 0x592dc4
extern char aSystemScriptLo[]; // 0x592ddc
extern char aInitSce[]; // 0x592df8
extern char aScriptSysInitF[]; // 0x592e04
extern char aDProjectPal3Sc[]; // 0x592e1c
extern char pszFileName[]; // 0x592e44
extern char aSS_5[]; // 0x592e50
extern const char * off_592E58; // 0x592e58
extern int dword_592E5C; // 0x592e5c
extern char aChangqing[]; // 0x592e60
extern char aZixuan[]; // 0x592e6c
extern char aLongkui[]; // 0x592e74
extern char aXuejian[]; // 0x592e7c
extern char aJingtian[]; // 0x592e84
extern char aPal3op[]; // 0x5955dc
extern char a13i2[]; // 0x595960
extern char a14i1[]; // 0x5959d8
extern char a15b1[]; // 0x595a50
extern char a15c1[]; // 0x595a8c
extern char a15h1[]; // 0x595b04
extern char aRemoveteam[]; // 0x5961e0
extern char aAddteam[]; // 0x5961ec
extern char aLoseitem[]; // 0x5961f4
extern char a106[]; // 0x596200
extern char aAddskill[]; // 0x596204
extern char aM08[]; // 0x596210
extern char aD1[]; // 0x596214
extern char aC1[]; // 0x596218
extern char aB1[]; // 0x59621c
extern char aA1[]; // 0x596220
extern char aD_5[]; // 0x596224
extern char aC_0[]; // 0x596228
extern char aB[]; // 0x59622c
extern char aA[]; // 0x596230
extern char aCaptionSTga[]; // 0x596234
extern char aMovieSBik[]; // 0x596244
extern CHAR aEnd[]; // 0x596254
extern CHAR aMovieB[]; // 0x59625c
extern CHAR szSubKey[]; // 0x596264
extern CHAR szValueName[]; // 0x596284
extern CHAR pTemplate[]; // 0x59628c
extern char pszName[]; // 0x5962a0
extern char byte_596420[3]; // 0x596420
extern char byte_596424[3]; // 0x596424
extern char aSDTga[]; // 0x5965a4
extern char aS_2[3]; // 0x5967b0
extern void * pData; // 0x59693c
extern char aDProjectPal3Ui[]; // 0x5971b8
extern int off_5974E0; // 0x5974e0
extern CHAR String2[]; // 0x597864
extern int aQ07; // 0x598c14
extern int off_599594; // 0x599594
extern const char * off_59959C; // 0x59959c
extern const char * off_5995A0; // 0x5995a0
extern const char * off_5995A4; // 0x5995a4
extern const char * off_5995A8; // 0x5995a8
extern const char * g_szDataPath; // 0x5995ac
extern char aDatascriptScen[]; // 0x59b08c
extern char aSSS_0[]; // 0x59b2e8
extern const char * g_pCScreenMode; // 0x59b5e8
extern LPCSTR off_59BA88; // 0x59ba88
extern LPCSTR off_59BA8C; // 0x59ba8c
extern LPCSTR off_59BA90; // 0x59ba90
extern int off_59BA94; // 0x59ba94
extern CHAR aMId[]; // 0x59ba98
extern char aGStory[]; // 0x59dae4
extern char aNSDS_0[]; // 0x59daec
extern char aSec1[]; // 0x59db00
extern void * off_59DC84; // 0x59dc84
extern int off_59DC90; // 0x59dc90
extern LPCSTR off_59DD08; // 0x59dd08
extern LPCSTR off_59DD0C; // 0x59dd0c
extern LPCSTR off_59DD10; // 0x59dd10
extern LPCSTR off_59DD14; // 0x59dd14
extern int off_59DD18; // 0x59dd18
extern int off_59DD60; // 0x59dd60
extern int off_59DD70; // 0x59dd70
extern int off_59DD80; // 0x59dd80
extern int off_59DDA0; // 0x59dda0
extern int off_59DDA8; // 0x59dda8
extern int off_59DDB4; // 0x59ddb4
extern int off_59DDB8; // 0x59ddb8
extern int off_59DDBC; // 0x59ddbc
extern int off_59DDC0; // 0x59ddc0
extern int off_59DDC4; // 0x59ddc4
extern int off_59DDC8; // 0x59ddc8
extern LPCSTR off_59DDCC; // 0x59ddcc
extern LPCSTR off_59DDD0; // 0x59ddd0
extern LPCSTR off_59DDD4; // 0x59ddd4
extern LPCSTR off_59DDDC; // 0x59dddc
extern char a13i2_0[]; // 0x5a06b0
extern char a14i1_0[]; // 0x5a0728
extern char a15b1_0[]; // 0x5a07a0
extern char a15c1_0[]; // 0x5a07dc
extern char a15h1_0[]; // 0x5a0854
extern unsigned __int8 g_bSceneLoaded; // 0x5a0998
extern float g_fDefaultFOV; // 0x5a099c
extern CHAR aSGameC[]; // 0x5a0d68
extern CHAR aSGameB[]; // 0x5a0d74
extern char aUiEmoteEm02dTg[]; // 0x5a0f80
extern int g_nMiniGameParam; // 0x5a3748
extern char aUiDlgSelbkTga[]; // 0x5a374c
extern char aUiDlgHeadbkTga[]; // 0x5a3760
extern char tex[256]; // 0x5a3774
extern CHAR aUiGameoverDiTg[]; // 0x5a5e20
extern LPCSTR off_5A6234; // 0x5a6234
extern LPCSTR off_5A6238; // 0x5a6238
extern LPCSTR off_5A623C; // 0x5a623c
extern LPCSTR off_5A6244; // 0x5a6244
extern CHAR aUiSceneTimepTg[]; // 0x5a6648
extern CHAR aUiSceneTimebkT[]; // 0x5a665c
extern CHAR aUiSceneTimeclo[]; // 0x5a6670
extern char aUiFlexDlg[]; // 0x5a6698
extern char aSeldlg[]; // 0x5a68b8
extern int off_5A6A3C; // 0x5a6a3c
extern CHAR aUiSceneFaceHpT[]; // 0x5a8f98
extern CHAR aUiSceneFaceMpT[]; // 0x5a8fb0
extern CHAR aUiSceneFaceBkT[]; // 0x5a8fc8
extern char aUiSceneFaceFac[]; // 0x5a8fe0
extern CHAR aUiSceneMapComp[]; // 0x5ab890
extern CHAR aUiSceneMapBase[]; // 0x5ab8ac
extern char aUiFlexMap[]; // 0x5ab8c4
extern char aP[]; // 0x5aba60
extern int off_5ABBE0; // 0x5abbe0
extern LPCSTR off_5AC080; // 0x5ac080
extern int off_5AC084; // 0x5ac084
extern int off_5AC088; // 0x5ac088
extern LPCSTR off_5AC094; // 0x5ac094
extern LPCSTR off_5AC09C; // 0x5ac09c
extern int off_5AC0A0; // 0x5ac0a0
extern LPCSTR off_5AC0A4; // 0x5ac0a4
extern LPCSTR off_5AC0A8; // 0x5ac0a8
extern LPCSTR off_5AC0AC; // 0x5ac0ac
extern int off_5AC180; // 0x5ac180
extern unsigned __int8 g_bAudioEnabled; // 0x5ae1e4
extern char aSNSNS[]; // 0x5ae1e8
extern char aSNSNSNS[]; // 0x5ae1f4
extern void * off_5AE380; // 0x5ae380
extern int off_5AE388; // 0x5ae388
extern void * off_5AE38C; // 0x5ae38c
extern void * off_5AE3A8; // 0x5ae3a8
extern void * off_5AE3C4; // 0x5ae3c4
extern LPCSTR off_5B087C; // 0x5b087c
extern void * off_5B0950; // 0x005B0950
extern unsigned __int8 g_bEffectEnabled; // 0x5b0958
extern CHAR aUiGamemainuiSy_3[]; // 0x5b0a88
extern CHAR aUiGamemainuiSy_0[]; // 0x5b0b08
extern CHAR aUiGamemainuiSy[]; // 0x5b0b2c
extern char aUiGamemainuiSy_5[]; // 0x5b0b4c
extern CHAR aUiGamemainuiSy_16[]; // 0x5b0b88
extern char aNS_3[]; // 0x5b0ba4
extern char aNS_0[]; // 0x5b0bac
extern char aSavePal304dJpg[]; // 0x5b0bb8
extern char aSS_4[]; // 0x5b0bcc
extern char aSD[]; // 0x5b0bd4
extern char aS02d02d02d[]; // 0x5b0bdc
extern CHAR aSoftwareSoftst_0[]; // 0x5b0c04
extern CHAR aSeek[]; // 0x5b0c20
extern int off_5B0DA4; // 0x5b0da4
extern LPCSTR off_5B0E28; // 0x5b0e28
extern const char * off_5B0E2C; // 0x5b0e2c
extern char a13i2_1[]; // 0x5b1280
extern char a14i1_1[]; // 0x5b12f8
extern char a15b1_1[]; // 0x5b1370
extern char a15c1_1[]; // 0x5b13ac
extern char a15h1_1[]; // 0x5b1424
extern int off_5B1604; // 0x5b1604
extern int byte_5B1A26; // 0x5b1a26
extern char aMovieSBik_0[]; // 0x5b1a28
extern CHAR aSt_0[]; // 0x5b1a50
extern CHAR aAcptquantum[]; // 0x5b1ce4
extern CHAR aItemId[]; // 0x5b1e6c
extern int asc_5B1E74; // 0x5b1e74
extern char aS10[]; // 0x5b1e78
extern char aSD_4[]; // 0x5b1e84
extern char aSD_3[]; // 0x5b1e90
extern char aSD_2[]; // 0x5b1e98
extern char aSD_1[]; // 0x5b1ea0
extern char aSD_0[]; // 0x5b1ea8
extern char aS_1[]; // 0x5b1eb4
extern char aSS_8[]; // 0x5b1eb8
extern int off_5B203C; // 0x5b203c
extern const char * g_pCScreenMode_5B46B4; // 0x5b46b4
extern void * off_5B46C0; // 0x005B46C0
extern int off_5B46C4; // 0x5b46c4
extern char aItemSSPol[]; // 0x5b7458
extern char aNone[]; // 0x5b7468
extern char aNum1[]; // 0x5b7474
extern char aPrice[]; // 0x5b747c
extern char aName[]; // 0x5b7484
extern char aSSS[]; // 0x5b748c
extern char aNS_4[]; // 0x5b74a8
extern int asc_5B74B4; // 0x5b74b4
extern char aSD_10[]; // 0x5b74bc
extern char aItemSSTga[]; // 0x5b74c4
extern int off_5B7650; // 0x5b7650
extern void * off_5B765C; // 0x005B765C
extern int off_5B7660; // 0x5b7660
extern int off_5B9DE4; // 0x5b9de4
extern void * off_5B9DF0; // 0x005B9DF0
extern void * off_5B9DF4; // 0x5b9df4
extern int off_5BC4A4; // 0x5bc4a4
extern void * g_pCombatUIData; // 0x5bc4a8
extern char aSSSS[]; // 0x5bc4ac
extern char aCombatDataCoul[]; // 0x5bc6e0
extern char aDProjectPal3Fi[]; // 0x5bc6fc
extern const char * off_5BC90C; // 0x5bc90c
extern int off_5BC914; // 0x5bc914
extern const char * g_pCScreenMode_5BC918; // 0x5bc918
extern int off_5BC940; // 0x5bc940
extern char aSmelt[]; // 0x5bee2c
extern char aBone[]; // 0x5bee34
extern char szFilename[260]; // 0x5bee3c
extern int off_5BF000; // 0x5bf000
extern char aSubgameHocksho_1[]; // 0x5c3cf0
extern char aUiFlexNote[]; // 0x5c3d18
extern char aNS_5[]; // 0x5c3d28
extern int off_5C3EAC; // 0x5c3eac
extern int off_5C3ED4; // 0x5c3ed4
extern char aUiGamemainuiJu[]; // 0x5c5414
extern char aUiGamemainuiJu_23[]; // 0x5c5514
extern char aUiGamemainuiJu_22[]; // 0x5c5614
extern char aUiGamemainuiJu_9[]; // 0x5c59d4
extern char aUiGamemainuiJu_4[]; // 0x5c5a78
extern char aUiGamemainuiJu_3[]; // 0x5c5a98
extern char aUiGamemainuiJu_1[]; // 0x5c5adc
extern char a02d02d02d[]; // 0x5c5b20
extern CHAR aUiGamemainuiJu_21[]; // 0x5c5b40
extern CHAR aUiGamemainuiJu_20[]; // 0x5c5b68
extern CHAR aUiGamemainuiJu_19[]; // 0x5c5b94
extern CHAR aUiGamemainuiJu_18[]; // 0x5c5bbc
extern CHAR aUiGamemainuiJu_17[]; // 0x5c5be8
extern CHAR aUiGamemainuiJu_16[]; // 0x5c5c10
extern CHAR aUiGamemainuiJu_15[]; // 0x5c5c3c
extern CHAR aUiGamemainuiJu_14[]; // 0x5c5c64
extern CHAR aUiGamemainuiJu_13[]; // 0x5c5c90
extern CHAR aUiGamemainuiJu_12[]; // 0x5c5cb8
extern CHAR aUiGamemainuiJu_11[]; // 0x5c5ce4
extern CHAR aUiGamemainuiJu_10[]; // 0x5c5d08
extern char aD_4[]; // 0x5c5d30
extern char aSD_8[]; // 0x5c5d38
extern int off_5C5EBC; // 0x5c5ebc
extern void * off_5C5EC4; // 0x005C5EC4
extern int off_5C5EC8; // 0x5c5ec8
extern void * fVal2; // 0x5c5ef8
extern LPCSTR off_5C641C; // 0x5c641c
extern LPCSTR off_5C6420; // 0x5c6420
extern char aUiGamemainuiLi_2[]; // 0x5c749c
extern char aUiGamemainuiLi_1[]; // 0x5c74c0
extern CHAR aUiGamemainuiLi_4[]; // 0x5c74dc
extern CHAR aUiGamemainuiLi_3[]; // 0x5c7500
extern char aNS_6[]; // 0x5c7524
extern int off_5C775C; // 0x5c775c
extern int off_5C7760; // 0x5c7760
extern void * off_5C7764; // 0x5c7764
extern const char * g_pCScreenMode_5C7768; // 0x5c7768
extern int off_5C7770; // 0x5c7770
extern int off_5C7774; // 0x5c7774
extern int off_5C778C; // 0x5c778c
extern char aDD[]; // 0x5c9114
extern char aNS[]; // 0x5c911c
extern char aSSSN[]; // 0x5c912c
extern char aNNSSSDSN[]; // 0x5c913c
extern char aD_0[]; // 0x5c9154
extern char aNNNS[]; // 0x5c9170
extern char aSDN[]; // 0x5c9184
extern int asc_5C9190; // 0x5c9190
extern char aPercent[]; // 0x5c9198
extern char aCom3[]; // 0x5c91a0
extern char aCom2[]; // 0x5c91a8
extern char aCom1[]; // 0x5c91b0
extern char aUsetimes[]; // 0x5c91b8
extern char aLv[]; // 0x5c91c4
extern int off_5C91C8; // 0x5c91c8
extern char aNSNS[]; // 0x5c91cc
extern char aNS_2[]; // 0x5c91dc
extern int off_5C936C; // 0x5c936c
extern void * off_5C9370; // 0x5c9370
extern void * off_5C9378; // 0x005C9378
extern char aD_3[]; // 0x5cac04
extern char aD_2[]; // 0x5cac10
extern char aD_1[]; // 0x5cac20
extern char aSS_6[]; // 0x5cac2c
extern int off_5CADC4; // 0x5cadc4
extern int off_5CADC8; // 0x5cadc8
extern int off_5CADD0; // 0x5cadd0
extern char aNSS[]; // 0x5cc3bc
extern char aNSSSNNS[]; // 0x5cc3c8
extern char aSS_7[]; // 0x5cc3e0
extern int off_5CC578; // 0x5cc578
extern int off_5CC7AC; // 0x5cc7ac
extern unsigned __int8 g_bDebugMode; // 0x5cefa8
extern unsigned __int8 g_bRoleSystem_5CEFA9; // 0x5cefa9
extern char aSNS_0[]; // 0x5cf03c
extern char aSND[]; // 0x5cf048
extern char aSDSDSDSD[]; // 0x5cf054
extern const char * g_pCScreenMode_5CF1E8; // 0x5cf1e8
extern int off_5CF1EC; // 0x5cf1ec
extern int off_5CF1F0; // 0x5cf1f0
extern const char * g_pCScreenMode_5CF1F4; // 0x5cf1f4
extern int off_5CF220; // 0x5cf220
extern int g_nFiveNimbusCount; // 0x5d0750
extern char aGu[]; // 0x5d0ee8
extern char aSSSS_0[]; // 0x5d0eec
extern char aNNS[]; // 0x5d0f08
extern char aNSNS_0[]; // 0x5d0f18
extern char aSS_3[]; // 0x5d0f28
extern char aSD_5[]; // 0x5d0f34
extern CHAR aN[]; // 0x5d0f44
extern char aSS_2[]; // 0x5d0f48
extern char pszPath[]; // 0x5d0f58
extern char aUiGamemainuiSw[]; // 0x5d0f80
extern CHAR aUiGamemainuiPa_0[]; // 0x5d0fa8
extern CHAR aUiGamemainuiPa_1[]; // 0x5d0fcc
extern char aNNSDNSS[]; // 0x5d0ff0
extern char aQ14[]; // 0x5d1008
extern char aNNS_1[]; // 0x5d100c
extern char aNNS_0[]; // 0x5d1018
extern char aNSNS_1[]; // 0x5d1028
extern int off_5D11B8; // 0x5d11b8
extern int off_5D11C0; // 0x5d11c0
extern void * off_5D11C4; // 0x5d11c4
extern int off_5D11E0; // 0x5d11e0
extern int off_5D11F8; // 0x5d11f8
extern int off_5D11FC; // 0x5d11fc
extern CHAR aUiGamemainuiSy_14[]; // 0x5d3700
extern CHAR aUiGamemainuiSy_13[]; // 0x5d3728
extern CHAR aUiGamemainuiSy_12[]; // 0x5d374c
extern CHAR aUiGamemainuiSy_11[]; // 0x5d3778
extern CHAR aUiGamemainuiSy_9[]; // 0x5d37bc
extern CHAR aUiGamemainuiSy_7[]; // 0x5d37f8
extern CHAR aUiGamemainuiSy_19[]; // 0x5d3834
extern CHAR aM05[4]; // 0x5d3850
extern CHAR aM04[4]; // 0x5d3854
extern char aDS_1[]; // 0x5d3858
extern int unk_5D3C68; // 0x5d3c68
extern int unk_5D3C6C; // 0x5d3c6c
extern int dword_5D41AC; // 0x5d41ac
extern int g_nTextureDefault; // 0x5d41b0
extern float g_fConst400; // 0x5d41b4
extern float g_fRenderHeight; // 0x5d41b8
extern float g_fRenderWidth; // 0x5d41bc
extern int asc_5D41EC; // 0x5d41ec
extern CHAR aNotSupportedFi[]; // 0x5d4214
extern CHAR aInfo[]; // 0x5d4230
extern CHAR Text[]; // 0x5d4238
extern CHAR Caption[]; // 0x5d4254
extern char aLockBackBuffer[]; // 0x5d4530
extern char aDProjectPal3Ef[]; // 0x5d454c
extern char g_EffCylinderEditorData[4]; // 0x5d4d3c
extern const char * g_pszEditorDesc; // 0x5d4d7c
extern tagEffMgrData g_EffMgrData; // 0x5d4dac
extern char aCouldNotMalloc_1[]; // 0x5d5394
extern char aCouldNotMalloc_0[]; // 0x5d53c0
extern char aCouldNotMalloc[]; // 0x5d53e8
extern char aFewOfNodeInMet[]; // 0x5d5410
extern int g_TargetData; // 0x5d542c
extern CEffMgr g_EffMgr; // 0x5d5484
extern RenderTarget2 pTarget; // 0x5d548c
extern int unk_5D87F0; // 0x005D87F0
extern unsigned int roleIdx; // 0x5d87f4
extern int unk_5D87F8; // 0x5d87f8
extern int unk_5D87FC; // 0x5d87fc
extern int unk_5D8800; // 0x005D8800
extern int index; // 0x5d8804
extern int unk_5D8808; // 0x005D8808
extern int unk_5D8848; // 0x5d8848
extern int ppUI; // 0x5d8864
extern int unk_5D8884; // 0x005D8884
extern const char a164229[]; // 0x5d88bc
extern int unk_5D88EC; // 0x005D88EC
extern int unk_5D88F4; // 0x005D88F4
extern int unk_5D88FC; // 0x5d88fc
extern int unk_5D8938; // 0x005D8938
extern int unk_5D893C; // 0x005D893C
extern int unk_5D8940; // 0x005D8940
extern int unk_5D8944; // 0x005D8944
extern int unk_5D8948; // 0x005D8948
extern int unk_5D8950; // 0x005D8950
extern int unk_5D8954; // 0x005D8954
extern int unk_5D8958; // 0x005D8958
extern int unk_5D895C; // 0x005D895C
extern int unk_5D8960; // 0x005D8960
extern int unk_5D8964; // 0x005D8964
extern const char a03dS[]; // 0x5d8968
extern const char aY[]; // 0x5d8970
extern int unk_5D8974; // 0x5d8974
extern char byte_5D897C[8]; // 0x5d897c
extern char byte_5D8984[8]; // 0x5d8984
extern char byte_5D898C[8]; // 0x5d898c
extern char byte_5D8994[8]; // 0x5d8994
extern char byte_5D899C[8]; // 0x5d899c
extern int unk_5D89A4; // 0x5d89a4
extern int unk_5D89B0; // 0x5d89b0
extern const char a15f[]; // 0x5d89b4
extern const char off_5D89BC[]; // 0x5d89bc
extern const CHAR AppName[]; // 0x5d89e0
extern const CHAR KeyName[]; // 0x5d89e8
extern int unk_5D89F0; // 0x005D89F0
extern int unk_5D89F8; // 0x005D89F8
extern int unk_5D8A00; // 0x5d8a00
extern char byte_5D8A18[4]; // 0x5d8a18
extern char byte_5D8A1C[4]; // 0x5d8a1c
extern char byte_5D8A20[4]; // 0x5d8a20
extern char byte_5D8A24[4]; // 0x5d8a24
extern char byte_5D8A28[4]; // 0x5d8a28
extern char byte_5D8A2C[4]; // 0x5d8a2c
extern char byte_5D8A30[8]; // 0x5d8a30
extern char g_szCCBStageCamName[]; // 0x5d8a38
extern int unk_5D8A3C; // 0x005D8A3C
extern int unk_5D8A40; // 0x005D8A40
extern int unk_5D8A48; // 0x005D8A48
extern int unk_5D8A50; // 0x005D8A50
extern int unk_5D8A58; // 0x005D8A58
extern int unk_5D8A5C; // 0x005D8A5C
extern int unk_5D8A64; // 0x005D8A64
extern int unk_5D8A6C; // 0x5d8a6c
extern int unk_5D8A90; // 0x5d8a90
extern int unk_5D8AB4; // 0x5d8ab4
extern int unk_5D8ABC; // 0x5d8abc
extern int unk_5D8AC4; // 0x5d8ac4
extern const char a12f[]; // 0x5d8acc
extern int unk_5D8AD4; // 0x5d8ad4
extern int unk_5D8AF4; // 0x5d8af4
extern int unk_5D8B00; // 0x005D8B00
extern int unk_5D8B04; // 0x005D8B04
extern int unk_5D8B0C; // 0x005D8B0C
extern int unk_5D8B14; // 0x5d8b14
extern int unk_5D8B3C; // 0x5d8b3c
extern int unk_5D8B44; // 0x5d8b44
extern int unk_5D8B6C; // 0x5d8b6c
extern const char a02f[]; // 0x5d8b78
extern const char aO[]; // 0x5d8b84
extern int unk_5D8B88; // 0x5d8b88
extern int unk_5D8BE4; // 0x5d8be4
extern int unk_5D8C20; // 0x5d8c20
extern int asc_5D8C3C; // 0x5d8c3c
extern _DWORD dword_5D8DB8[1]; // 0x5d8db8
extern _DWORD dword_5D8DBC[1]; // 0x5d8dbc
extern int unk_5D8DC0; // 0x005D8DC0
extern _DWORD dword_5D8DC4[15]; // 0x5d8dc4
extern char aLevel[]; // 0x5d8e18
extern int unk_5D8E20; // 0x005D8E20
extern int unk_5D8E30; // 0x005D8E30
extern int unk_5D8E3C; // 0x005D8E3C
extern int unk_5D8E48; // 0x005D8E48
extern char aFailToCreateWe[]; // 0x5d8e50
extern char aDProjectPal3Co[]; // 0x5d8e70
extern int dword_5D8E98; // 0x5d8e98
extern int unk_5D8EB0; // 0x005D8EB0
extern int unk_5D8EB8; // 0x005D8EB8
extern int unk_5D8EC0; // 0x005D8EC0
extern int dword_5D8EC8; // 0x5d8ec8
extern int dword_5D8EE0; // 0x5d8ee0
extern int dword_5D8EF8; // 0x5d8ef8
extern int dword_5D8F0C; // 0x5d8f0c
extern int unk_5D8F28; // 0x005D8F28
extern int unk_5D8F30; // 0x005D8F30
extern int unk_5D8F38; // 0x005D8F38
extern int unk_5D8F40; // 0x005D8F40
extern int unk_5D8F48; // 0x005D8F48
extern int unk_5D8F50; // 0x005D8F50
extern int unk_5D8F58; // 0x005D8F58
extern int unk_5D8F60; // 0x005D8F60
extern int unk_5D8F68; // 0x005D8F68
extern int unk_5D8F70; // 0x005D8F70
extern int unk_5D8F78; // 0x005D8F78
extern int unk_5D8F80; // 0x005D8F80
extern int unk_5D8F88; // 0x005D8F88
extern int unk_5D8F90; // 0x005D8F90
extern int unk_5D8F98; // 0x005D8F98
extern const char aGpfullD[]; // 0x5d8fa0
extern const char aSsleepD[]; // 0x5d8fac
extern const char aPoisonD[]; // 0x5d8fb8
extern const char aShplowD[]; // 0x5d8fc4
extern const char aDyingD[]; // 0x5d8fd0
extern const char aSCombatdialog[]; // 0x5d8fd8
extern char aZ39[4]; // 0x5d8fe8
extern const char off_5D8FEC[]; // 0x5d8fec
extern const char aD02d[]; // 0x5d8ff0
extern char aNewFailedAtCre[]; // 0x5db678
extern char aDProjectPal3Co_0[]; // 0x5db6a0
extern int dword_5DB6C4; // 0x5db6c4
extern char aEnemysneakatta[]; // 0x5db708
extern char aWesneakattacke[]; // 0x5db71c
extern char aWitch[]; // 0x5db738
extern char aMoney[]; // 0x5db740
extern char aFleefail[9]; // 0x5db758
extern const char aSSDS[]; // 0x5db778
extern char aLevelup[8]; // 0x5db784
extern const char aSSD[]; // 0x5db78c
extern const char aSDS_0[]; // 0x5db798
extern char aGetitem_0[8]; // 0x5db7a4
extern const char aSSS_1[]; // 0x5db7b4
extern char aMastered[9]; // 0x5db7bc
extern const char aSSSDS[]; // 0x5db7c8
extern const char aUiCombatPointe[]; // 0x5db7d8
extern const char aCbdataFlexcamD[]; // 0x5db7f8
extern const char aDatascriptCbca[]; // 0x5db80c
extern const char aRoll[]; // 0x5db9a0
extern const char aPitch[]; // 0x5db9a8
extern const char off_5DB9B0[]; // 0x5db9b0
extern const char aZ[]; // 0x5db9b4
extern const char aY_0[]; // 0x5db9b8
extern const char aEditorcamD[]; // 0x5db9bc
extern char aCamFovF[]; // 0x5db9c8
extern char aCamYawFPitchFR[]; // 0x5db9d4
extern char aCamXFYFZF[]; // 0x5db9f4
extern char aCouldnTOpenCbC[35]; // 0x5dba0c
extern char aDProjectPal3Co_1[38]; // 0x5dba30
extern const char aBasedataCbdata[]; // 0x5dba58
extern const char aGfxscriptGeomD_0[]; // 0x5dbbf0
extern const char aGfxscriptGeomD[]; // 0x5dbc10
extern char aCouldnTOpenEff[38]; // 0x5dbc2c
extern char aDProjectPal3Co_2[41]; // 0x5dbc54
extern const char aCbdataEfflinke[]; // 0x5dbc80
extern char aCouldnTOpenCbE[33]; // 0x5dbc98
extern const char asc_5DBE44[]; // 0x5dbe44
extern const char aFlydown[]; // 0x5dbe48
extern const char aFlyup[]; // 0x5dbe50
extern const char aStore[]; // 0x5dbe58
extern const char aPause[]; // 0x5dbe60
extern const char aWork1[]; // 0x5dbe68
extern const char aWork[]; // 0x5dbe70
extern char aDProjectPal3Co_3[39]; // 0x5dbe78
extern const char a203[]; // 0x5dbea0
extern const char aRoleSSIni[]; // 0x5dbea4
extern char aWe011b[7]; // 0x5dbeb4
extern char aWe011[6]; // 0x5dbebc
extern const char aZ02d[]; // 0x5dbec4
extern char aWe014[6]; // 0x5dbecc
extern char aWe013[6]; // 0x5dbed4
extern char aWe012[6]; // 0x5dbedc
extern char aCouldnTCreateT[52]; // 0x5dbf54
extern char aDProjectPal3Co_4[40]; // 0x5dbf88
extern int unk_5DBFB0; // 0x005DBFB0
extern int unk_5DBFD0; // 0x005DBFD0
extern const char aGfxscriptAddit_1[]; // 0x5dbfe8
extern const char aItemSSSTga[]; // 0x5dc004
extern const char aDS_0[]; // 0x5dc018
extern const char aCbsceneSSLgt[]; // 0x5dc020
extern const char aCbsceneSSCvd[]; // 0x5dc034
extern const char aCbsceneSSPol[]; // 0x5dc048
extern const char aCbscene[]; // 0x5dc05c
extern const char aRoleDZ[]; // 0x5dc068
extern const char aRoleDX[]; // 0x5dc074
extern const char aRolepos[]; // 0x5dc080
extern const char aRadius[]; // 0x5dc0a4
extern char aDProjectPal3Co_5[41]; // 0x5dc228
extern int unk_5DC254; // 0x005DC254
extern int nVal3; // 0x5dc3dc
extern char aDProjectPal3Co_6[]; // 0x5de8fc
extern const char aS_2_0[]; // 0x5de9a8
extern char aTooManyCharact[]; // 0x5de9bc
extern int unk_5DE9E4; // 0x5de9e4
extern int unk_5DF59C; // 0x005DF59C
extern int unk_5DF6AC; // 0x005DF6AC
extern int unk_5DF6D0; // 0x005DF6D0
extern int unk_5DF6F4; // 0x005DF6F4
extern char aDProjectPal3Co_7[]; // 0x5dfd6c
extern int unk_5DFDB4; // 0x5dfdb4
extern int unk_5DFDC0; // 0x5dfdc0
extern int unk_5DFDCC; // 0x5dfdcc
extern int unk_5DFDEB; // 0x5dfdeb
extern unsigned int g_nCombatRandSeed; // 0x5dfdec
extern const char aRb[]; // 0x5dfe08
extern const char * off_5DFF88; // 0x5dff88
extern const char * off_5DFF90; // 0x5dff90
extern const char * off_5DFF94; // 0x5dff94
extern int asc_5E2540; // 0x5e2540
extern int asc_5E25F4; // 0x5e25f4
extern int asc_5E286C; // 0x5e286c
extern int asc_5E28E4; // 0x5e28e4
extern int asc_5E2A38; // 0x5e2a38
extern int asc_5E2A3C; // 0x5e2a3c
extern void * off_5E2BC4; // 0x5e2bc4
extern char aSD_11[]; // 0x5e50b8
extern char aHockshopGut[]; // 0x5e50c0
extern const char * off_5E524C; // 0x5e524c
extern int off_5E525C; // 0x5e525c
extern char aSubgameHocksho[]; // 0x5e6d84
extern void * off_5E7ECC; // 0x5e7ecc
extern void * off_5E7ED8; // 0x005E7ED8
extern void * off_5E7F20; // 0x5e7f20
extern void * off_5E7F24; // 0x5e7f24
extern char aSubgameApprais_17[]; // 0x5e9018
extern CHAR aUiGamemainuiPa_2[]; // 0x5e9040
extern char pszTexBase[]; // 0x5e9068
extern char aSSPol[]; // 0x5e9084
extern int asc_5E9090; // 0x5e9090
extern char aNNSNN[]; // 0x5e909c
extern char aNNSS[]; // 0x5e90b4
extern char aNNSDNSDNSDN[]; // 0x5e90cc
extern int off_5E92A0; // 0x5e92a0
extern char aNS_7[]; // 0x5eb794
extern int off_5EB920; // 0x5eb920
extern char aSubgameApprais[]; // 0x5ecf20
extern char aSNSN[]; // 0x5ecf48
extern int off_5ED1D0; // 0x5ed1d0
extern int off_5ED1D4; // 0x5ed1d4
extern char aSD_7[]; // 0x5ef66c
extern char aNNSDSNSD[]; // 0x5ef674
extern char aDProjectPal3Su[]; // 0x5ef88c
extern char aSubgameEncampm[]; // 0x5ef8c4
extern void * off_5EFAB4; // 0x5efab4
extern char aSubgameEncampm_3[]; // 0x5efb20
extern char pszModelName[]; // 0x5efbd0
extern int off_5EFF48; // 0x5eff48
extern int off_5EFF78; // 0x5eff78
extern int off_5EFF90; // 0x5eff90
extern int off_5EFF98; // 0x5eff98
extern char aSubgameEncampm_5[]; // 0x5f2424
extern char aSSSD[]; // 0x5f2444
extern char aNSS10[]; // 0x5f245c
extern char aNSS_2[]; // 0x5f2474
extern const char * off_5F2488; // 0x5f2488
extern char aFFF[]; // 0x5f248c
extern char aSUd[]; // 0x5f24b8
extern char aR[]; // 0x5f24cc
extern float flt_5F4B9C; // 0x5f4b9c
extern const char * off_5F4D20; // 0x5f4d20
extern char aSSDPol[]; // 0x5f4d28
extern char aBasedataSkeePa[]; // 0x5f4d34
extern char aObstruct[]; // 0x5f4d80
extern char pszFilename[]; // 0x5f4f08
extern const char * off_5F50B4; // 0x5f50b4
extern LPCSTR lpString2; // 0x5f50b8
extern const char * off_5F50BC; // 0x5f50bc
extern const char * off_5F50C0; // 0x5f50c0
extern const char * off_5F50C4; // 0x5f50c4
extern const char * off_5F50C8; // 0x5f50c8
extern void * off_5F7790; // 0x5f7790
extern LPCSTR off_5F7820; // 0x5f7820
extern LPCSTR off_5F7824; // 0x5f7824
extern LPCSTR off_5F7828; // 0x5f7828
extern char aSubgameApprais_0[]; // 0x5f9cb4
extern CHAR aN_0[]; // 0x5f9cd4
extern char aNSSNNS[]; // 0x5f9ce0
extern char aNSD[]; // 0x5f9cf8
extern int asc_5F9D04; // 0x5f9d04
extern char aNSSNNSN[]; // 0x5f9d0c
extern float flt_5FC3A8; // 0x5fc3a8
extern char pszModel1[]; // 0x5feab4
extern CHAR a1[2]; // 0x601138
extern const char * off_60113C; // 0x60113c
extern char PathName_0[256]; // 0x601528
extern char aSNS[]; // 0x6039cc
extern char aRoleS02dIni[]; // 0x6039fc
extern char aSavePal02dArc[]; // 0x606088
extern CHAR PathName[]; // 0x60609c
extern char off_6088D8[]; // 0x6088d8
extern char aConsoleErrorCo[]; // 0x6088dc
extern char aBadCommandOrFi[]; // 0x608900
extern char aSD_9[]; // 0x60891c
extern char aFv[]; // 0x60892c
extern char byte_608930[4]; // 0x608930
extern int dword_608940; // 0x608940
extern char desc[]; // 0x608944
extern char aExceptionS[]; // 0x60895c
extern char aSDS[]; // 0x608970
extern char aSDSS[]; // 0x60897c
extern char aLogAtS[]; // 0x60898c
extern char aS_0[]; // 0x608998
extern char aSLogAt[]; // 0x6089a4
extern char aEnginelogTxt[]; // 0x6089b0
extern char aAt[]; // 0x6089c0
extern char aDatascriptMusi[]; // 0x608af4
extern char aMusicSMp3[]; // 0x608b0c
extern char aScene[]; // 0x608b1c
extern char aCombat[]; // 0x608b24
extern char aLuLuMp3[]; // 0x608b2c
extern LPCSTR lpString1; // 0x608b3c
extern CHAR aTName[]; // 0x608b40
extern CHAR aEndKey[]; // 0x608ca0
extern CHAR aEndfile[]; // 0x608ca8
extern char Delimiter[256]; // 0x608cb4
extern char aC[]; // 0x608fc0
extern CHAR aPal3Exception[]; // 0x608fc8
extern CHAR aPal3[]; // 0x608fdc
extern char aPleaseInsertDi[]; // 0x608fe4
extern char aSmovie[]; // 0x609008
extern CHAR aSoftwareSoftst_1[]; // 0x609010
extern CHAR ValueName[]; // 0x609028
extern char * off_60ACD0; // 0x60acd0
extern int g_TileData[]; // 0x60ad00
extern unsigned __int16 __ctype[]; // 0x60ad08
extern size_t cbMultiByte; // 0x60af0c
extern void * jpt_55C6DD; // 0x60b76e
extern int dword_60BDC8; // 0x60bdc8
extern gbVFileSystem * g_VFileSystem; // 0x6ebfa0
extern gbVFileSystem * g_BaseVFileSystem; // 0x7cc178
extern int dword_800000; // 0x800000
extern int byte_80AB19; // 0x80ab19
extern int byte_80AB20; // 0x80ab20
extern int byte_80AB21; // 0x80ab21
extern int byte_80AC01; // 0x80ac01
extern int byte_80AC02; // 0x80ac02
extern int byte_80AC03; // 0x80ac03
extern int byte_80AC04; // 0x80ac04
extern int byte_80AC05; // 0x80ac05
extern int byte_80AC06; // 0x80ac06
extern int byte_80AC07; // 0x80ac07
extern int g_nSaveDataSize; // 0x8834c0
extern char byte_8AC5D8[1556]; // 0x8ac5d8
extern float g_fPAL3Timer; // 0x8acbec
extern PAL3 g_PAL3_Instance; // 0x8acbf0
extern int g_nLoadBufferSize; // 0x8ddce0
extern _WORD p_WORD; // 0x971a74
extern PAL_GDB * g_pGDB; // 0x975ed8
extern unsigned __int8 g_UITemplateData[]; // 0xa00000
extern int byte_A00001; // 0xa00001
extern int byte_A00102; // 0xa00102
extern int byte_A00103; // 0xa00103
extern int byte_A00104; // 0xa00104
extern int byte_A00105; // 0xa00105
extern int byte_A00106; // 0xa00106
extern int byte_A00107; // 0xa00107
extern int byte_A00108; // 0xa00108
extern int byte_A00109; // 0xa00109
extern int byte_A00110; // 0xa00110
extern int byte_A00215; // 0xa00215
extern int byte_A00217; // 0xa00217
extern int byte_A00218; // 0xa00218
extern int byte_A00219; // 0xa00219
extern int byte_A00220; // 0xa00220
extern int byte_A00221; // 0xa00221
extern int byte_A00222; // 0xa00222
extern int byte_A00223; // 0xa00223
extern int byte_A00224; // 0xa00224
extern int byte_A00225; // 0xa00225
extern int byte_A00226; // 0xa00226
extern int byte_A00227; // 0xa00227
extern int byte_A00228; // 0xa00228
extern int byte_A00229; // 0xa00229
extern int byte_A00230; // 0xa00230
extern int byte_A00231; // 0xa00231
extern unsigned short word_A00232; // 0x00A00232
extern int dword_A00234; // 0xa00234
extern int byte_A00323; // 0xa00323
extern int byte_A00324; // 0xa00324
extern int byte_A00400; // 0xa00400
extern int byte_A00401; // 0xa00401
extern int byte_A00403; // 0xa00403
extern int byte_A00404; // 0xa00404
extern int byte_A00405; // 0xa00405
extern int byte_A00406; // 0xa00406
extern int byte_A00407; // 0xa00407
extern int dword_A00408; // 0xa00408
extern int byte_A00416; // 0xa00416
extern int byte_A00417; // 0xa00417
extern int byte_A00418; // 0xa00418
extern int byte_A00419; // 0xa00419
extern int byte_A00420; // 0xa00420
extern int byte_A00421; // 0xa00421
extern int byte_A00427; // 0xa00427
extern int byte_A00428; // 0xa00428
extern int byte_A00429; // 0xa00429
extern int dword_A00430; // 0xa00430
extern int dword_A00500; // 0xa00500
extern int dword_A00510; // 0xa00510
extern int byte_A00517; // 0xa00517
extern int byte_A00518; // 0xa00518
extern int byte_A00519; // 0xa00519
extern int byte_A00520; // 0xa00520
extern int byte_A00521; // 0xa00521
extern int byte_A00522; // 0xa00522
extern int byte_A00523; // 0xa00523
extern int byte_A00524; // 0xa00524
extern int byte_A00525; // 0xa00525
extern int byte_A00526; // 0xa00526
extern int byte_A00527; // 0xa00527
extern int byte_A00529; // 0xa00529
extern int byte_A00530; // 0xa00530
extern int byte_A00531; // 0xa00531
extern int byte_A00532; // 0xa00532
extern int byte_A00533; // 0xa00533
extern int byte_A00534; // 0xa00534
extern int byte_A00536; // 0xa00536
extern int byte_A00537; // 0xa00537
extern int byte_A00539; // 0xa00539
extern int byte_A00540; // 0xa00540
extern int byte_A00541; // 0xa00541
extern int byte_A00542; // 0xa00542
extern int byte_A00543; // 0xa00543
extern int byte_A00544; // 0xa00544
extern int byte_A00545; // 0xa00545
extern int byte_A00546; // 0xa00546
extern int byte_A00547; // 0xa00547
extern int byte_A00548; // 0xa00548
extern int byte_A00549; // 0xa00549
extern int byte_A00550; // 0xa00550
extern int byte_A00551; // 0xa00551
extern unsigned short word_A00552; // 0x00A00552
extern int byte_A00555; // 0xa00555
extern int byte_A00556; // 0xa00556
extern int byte_A00557; // 0xa00557
extern int byte_A00558; // 0xa00558
extern int byte_A00559; // 0xa00559
extern int byte_A00560; // 0xa00560
extern int byte_A00561; // 0xa00561
extern int byte_A00562; // 0xa00562
extern int byte_A00563; // 0xa00563
extern int byte_A00564; // 0xa00564
extern int byte_A00565; // 0xa00565
extern int byte_A00566; // 0xa00566
extern int byte_A00567; // 0xa00567
extern int byte_A00568; // 0xa00568
extern int byte_A00569; // 0xa00569
extern int byte_A00570; // 0xa00570
extern int byte_A00571; // 0xa00571
extern unsigned short word_A00572; // 0x00A00572
extern int byte_A00602; // 0xa00602
extern int byte_A00604; // 0xa00604
extern int byte_A00605; // 0xa00605
extern int byte_A00606; // 0xa00606
extern int byte_A00607; // 0xa00607
extern int byte_A00608; // 0xa00608
extern int byte_A00609; // 0xa00609
extern int byte_A00610; // 0xa00610
extern int byte_A00611; // 0xa00611
extern int byte_A00630; // 0xa00630
extern int byte_A00700; // 0xa00700
extern int byte_A00701; // 0xa00701
extern int byte_A00702; // 0xa00702
extern int byte_A00703; // 0xa00703
extern int byte_A00704; // 0xa00704
extern int byte_A00705; // 0xa00705
extern int byte_A00708; // 0xa00708
extern int byte_A00709; // 0xa00709
extern int dword_A00710; // 0xa00710
extern int byte_A00B00; // 0xa00b00
extern int byte_A00B01; // 0xa00b01
extern int byte_A00B02; // 0xa00b02
extern int byte_A00B03; // 0xa00b03
extern int byte_A00B04; // 0xa00b04
extern int byte_A00B05; // 0xa00b05
extern int byte_A00B06; // 0xa00b06
extern int byte_A00B07; // 0xa00b07
extern int dword_A00B08; // 0xa00b08
extern int g_nRenderFlags; // 0xa3a6ec
extern int g_nRenderMode; // 0xa3a6f0
extern gbVolModNode * g_pVolModNode; // 0xa3a6f8
extern int dword_A3A750; // 0xa3a750
extern CScreenMode g_ScreenMode; // 0xa3a7d8
extern ARC_PlayerAtt g_PlayerAttBuffer; // 0xaa0b00
extern int byte_AABC03; // 0xaabc03
extern int dword_AABC04; // 0xaabc04
extern unsigned __int8 g_PalScriptTemplate[]; // 0xaabef6
extern int byte_AABEF7; // 0xaabef7
extern int byte_AABEF8; // 0xaabef8
extern int byte_AABEF9; // 0xaabef9
extern int byte_ABAB09; // 0xabab09
extern int byte_ABC000; // 0xabc000
extern int byte_ABC001; // 0xabc001
extern int word_ABC002; // 0xabc002
extern int byte_ABC00B; // 0xabc00b
extern int byte_ABC00C; // 0xabc00c
extern int byte_ABC00D; // 0xabc00d
extern int word_ABC00E; // 0xabc00e
extern ARC_PlayerAtt g_PlayerAttBuffer2; // 0xabcd00
extern int byte_ABE000; // 0xabe000
extern int byte_ABE00B; // 0xabe00b
extern int g_ScriptSlots[132]; // 0xbfab60
extern GRPinput g_Input; // 0xbfad70
extern gbGfxDriverInfo g_DrvInfo; // 0xbfd6c8
extern int g_nGameTime; // 0xbfda04
extern int g_nTickCount; // 0xbfda2c
extern float g_fDeltaTime; // 0xbfda30
extern float g_fGameSpeed; // 0xbfda34
extern gbDropGroup * g_pDropGroup; // 0xbfda38
extern int g_nPAL3_BFDA3C; // 0xbfda3c
extern int byte_BFDA40; // 0xbfda40
extern int byte_BFDA41; // 0xbfda41
extern int g_nWolfIndex; // 0xbfda44
extern HINSTANCE hInstance; // 0xbfda48
extern int b; // 0xbfda4c
extern HWND hDlg; // 0xbfda50
extern HWND g_hMainWnd; // 0xbfda54
extern float g_fFadeAngle; // 0xbfda58
extern float g_fTimeScale; // 0xbfda5c
extern gbGfxManager * gfxMgr; // 0xbfda60
extern gbActorMgr * g_pActorMgr; // 0xbfda64
extern CameraCtrl * g_pCameraCtrl; // 0xbfda68
extern int g_nSceneState; // 0xbfda6c
extern void * g_pEffectSystem; // 0xbfda70
extern CCBSystem * g_pCBSystem; // 0xbfda74
extern void * g_pSceneManager; // 0xbfda78
extern void * g_pMiniGame2; // 0xbfda7c
extern void * g_pMiniGame1; // 0xbfda80
extern void * g_pMiniGame3; // 0xbfda84
extern unsigned __int8 g_bSceneLoaded_0; // 0xbfda88
extern int g_nCombatMode; // 0xbfda8c
extern unsigned __int8 g_bTestCombat; // 0xbfda90
extern unsigned __int8 g_bPAL3_BFDA91; // 0xbfda91
extern HCURSOR g_hCursor; // 0xbfda94
extern int g_bEditorMode; // 0xbfda98
extern float g_fGameTimer; // 0xbfdaa0
extern CHAR Default[8]; // 0xbfdaa4
extern float flt_BFDAAC; // 0xbfdaac
extern int dword_BFDAB0; // 0xbfdab0
extern int g_nMagicSlotCountA; // 0xbfdb70
extern int g_nMagicSlotCountB; // 0xbfdb74
extern int byte_BFDB78; // 0xbfdb78
extern void ** g_pScriptObjArray; // 0xbfdb80
extern void * g_pScriptEventObj; // 0xbfdb84
extern int g_nScriptEventParam; // 0xbfdb90
extern float g_fScriptEventParam2; // 0xbfdb94
extern int g_nScriptRolePosX; // 0xbfdb98
extern int g_nScriptRolePosY; // 0xbfdb9c
extern int g_nScriptRolePosZ; // 0xbfdba0
extern unsigned int g_nCurrentEventId; // 0xbfdba4
extern int g_nActor_BFDBA8; // 0xbfdba8
extern int g_nActor_BFDBAC; // 0xbfdbac
extern RoleSystem g_RoleSystemExtra0; // 0xbfdbb0
extern RoleSystem g_RoleSystemExtra1; // 0xbffdb0
extern float g_fCamRoleParams[40]; // 0xc01fb0
extern ScriptCounter g_ScriptCounters[10]; // 0xc02050
extern int KEEP_dword_0205C; // 0xc0205c
extern unsigned __int8 g_ScriptCountersEnd; // 0xc020f0
extern int dword_C020F4; // 0xc020f4
extern RoleSystem g_RoleSystemMain; // 0xc020f8
extern float g_fScriptTimeAccum; // 0xc042e8
extern tagC10Data g_C10Data; // 0xc042f8
extern int g_nRoleInitLevel[6]; // 0xc04334
extern Array g_SceneMgrPrefix; // 0xc04350
extern Array g_RoleTeamArray; // 0xc04360
extern Array g_nSceneFlags; // 0xc04370
extern Array g_SceneArray; // 0xc04380
extern SceneMgr g_SceneMgr; // 0xc04390
extern int pElem; // 0xc04394
extern int pEnd; // 0xc04398
extern int * g_pSceneArrayEnd2; // 0xc0439c
extern RoleSystem g_RoleSlotBuf; // 0xc043a0
extern int dword_C057EC[5]; // 0xc057ec
extern RoleSystem stru_C059A0; // 0xc059a0
extern int dword_C08150; // 0xc08150
extern int dword_C08154; // 0xc08154
extern int dword_C08158; // 0xc08158
extern int dword_C0815C; // 0xc0815c
extern RoleSystem unk_C08160; // 0xc08160
extern int g_nScriptObjectCount; // 0xc08664
extern float fDeltaTime; // 0xc0a350
extern RoleSystem stru_C0A360; // 0xc0a360
extern int unk_C0E760; // 0xc0e760
extern int unk_C0EC50; // 0xc0ec50
extern PalScript g_palScript; // 0xc10968
extern PalScript * g_pScriptArrayEnd2; // 0xc1096c
extern int dword_C109F0; // 0xc109f0
extern int unk_C10A0E; // 0xc10a0e
extern _DWORD dword_C10A10[2]; // 0xc10a10
extern int dword_C10BA0[]; // 0xc10ba0
extern _DWORD * dword_C10CBC; // 0xc10cbc
extern int dword_C10CC4; // 0xc10cc4
extern scAsmDecoder * dword_C10CC8; // 0xc10cc8
extern int nVal; // 0xc10ccc
extern CHAR unk_C10D38[8]; // 0xc10d38
extern float pfVal; // 0xc10d50
extern float byte_C10D80[2]; // 0xc10d80
extern RoleSystem stru_C10DF0; // 0xc10df0
extern float g_fTileScale; // 0xc12b14
extern int g_nLastUpdateTime; // 0xc12b1c
extern unsigned int g_lastupdateloading; // 0xc12b20
extern float g_fPalScript_C12B28; // 0xc12b28
extern float g_fPalScript_C12B2C; // 0xc12b2c
extern float g_fPalScript_C12B30; // 0xc12b30
extern int g_nunknown_libname_331_C12B38; // 0xc12b38
extern int g_nunknown_libname_331_C12B3C; // 0xc12b3c
extern int g_nunknown_libname_331_C12B40; // 0xc12b40
extern RoleSystem g_RoleSystemInstance; // 0xc12b48
extern int dword_C12BA8; // 0xc12ba8
extern PalScriptMgr pOut; // 0xc21fe8
extern int dword_C300C8; // 0xc300c8
extern int dword_C9A63C; // 0xc9a63c
extern int byte_D8B314; // 0xd8b314
extern ScriptSystemData g_ScriptSystemData; // 0xd8b318
extern SceneMapPlayer stru_D8B4A0; // 0xd8b4a0
extern SceneMapPlayer stru_D8B628; // 0xd8b628
extern SceneMapPlayer stru_D8B7B0; // 0xd8b7b0
extern UISystem stru_D8B938; // 0xd8b938
extern float flt_D8BBC0; // 0x00D8BBC0
extern int dword_D8BBEC; // 0xd8bbec
extern gbVec3D g_vRotateAxis; // 0xd8bc20
extern unsigned __int8 g_bMapRenderFlags; // 0xd8bc2c
extern int dword_D8BC30; // 0xd8bc30
extern int dword_D8BC34; // 0xd8bc34
extern int dword_D8BC38; // 0xd8bc38
extern float g_fScriptTileSize; // 0xd8bec4
extern RoleSystem * dword_D8BEEC; // 0xd8beec
extern float flt_D8BEF0; // 0x00D8BEF0
extern float g_fScriptTileSize2; // 0xd8c17c
extern CHAR String[260]; // 0xd8c1ac
extern PalScript * dword_D8C2B0; // 0xd8c2b0
extern GRPinput stru_D8C2B8; // 0xd8c2b8
extern float g_fDonateValue; // 0xd8f624
extern float flt_D90060; // 0xd90060
extern int dword_D90064; // 0xd90064
extern float g_fSubItemOffset; // 0xd902f0
extern float g_fDefaultColumnWidth; // 0xd902f4
extern int g_pbkLastCreated; // 0xd90d3c
extern int g_fUIColorParam; // 0xd91780
extern char g_DefaultColorR; // 0xd91781
extern char g_DefaultColorG; // 0xd91782
extern char g_DefaultColorB; // 0xd91783
extern int g_bRoleLoadFlags; // 0xd924b4
extern int g_bGameUpdating; // 0xd924e8
extern _BYTE p_BYTE; // 0xd92784
extern int byte_D92785; // 0xd92785
extern int g_SceneTransitionBuffer; // 0xd92788
extern CHAR byte_D92894[765]; // 0xd92894
extern int g_gamefrm; // 0xdb9fd0
extern unsigned __int8 * g_pSceneTransitionBegin; // 0xdba014
extern unsigned __int8 * g_pSceneTransitionEnd; // 0xdba0ac
extern int dword_DBA118; // 0xdba118
extern RoleCameraCtrl stru_DBA134; // 0xdba134
extern int dword_DBA240; // 0xdba240
extern int dword_DBA244; // 0xdba244
extern int dword_DBA248; // 0xdba248
extern PalScriptMgr * dword_DBA24C; // 0xdba24c
extern unsigned int g_dwUISettings; // 0xdba250
extern PalScriptMgr * dword_DBA254; // 0xdba254
extern int byte_DBA25C; // 0xdba25c
extern UIListBox g_UIListBoxDlg; // 0xdba260
extern int dword_DBA830; // 0xdba830
extern UISceneMap g_UISceneMapDlg; // 0xdbaf10
extern CCBEditor g_CCBEditorInst; // 0xdbb364
extern ComposeUI * g_pComposeUI; // 0xdc0de8
extern int g_nsub_41FA90_DC10FC; // 0xdc10fc
extern int g_nMiniGameState; // 0xdc1100
extern int dword_DC25E8; // 0xdc25e8
extern int dword_DC25EC; // 0xdc25ec
extern int dword_DC25F0; // 0xdc25f0
extern int byte_DC25F4; // 0xdc25f4
extern unsigned __int8 g_bStateFlags[]; // 0xdc3304
extern unsigned __int8 g_bListNeedsRefresh; // 0xdc3338
extern char Destination[256]; // 0xdc333c
extern CHAR byte_DC343C[256]; // 0xdc343c
extern int dword_DC353C; // 0xdc353c
extern int dword_DC363C; // 0xdc363c
extern int dword_DC373C; // 0xdc373c
extern int dword_DC383C; // 0xdc383c
extern int dword_DC393C; // 0xdc393c
extern int dword_DC3A3C; // 0xdc3a3c
extern int dword_DC3B3C; // 0xdc3b3c
extern unsigned __int8 g_bSlotFlag[768]; // 0xdc3c3c
extern CHAR byte_DC3F3C[256]; // 0xdc3f3c
extern CHAR byte_DC403C[256]; // 0xdc403c
extern int dword_DC413C; // 0xdc413c
extern int dword_DC423C; // 0xdc423c
extern int dword_DC433C; // 0xdc433c
extern const char * g_szRoleName0; // 0xdc443c
extern const char * g_szRoleName1; // 0xdc453c
extern const char * g_szRoleName2; // 0xdc463c
extern const char * g_szRoleName3; // 0xdc473c
extern int dword_DC483C; // 0xdc483c
extern int dword_DC493C; // 0xdc493c
extern int dword_DC4A3C; // 0xdc4a3c
extern int dword_DC4B3C; // 0xdc4b3c
extern CHAR byte_DC4C3C[256]; // 0xdc4c3c
extern CHAR byte_DC4D3C[256]; // 0xdc4d3c
extern CHAR byte_DC4E3C[256]; // 0xdc4e3c
extern CHAR byte_DC4F3C[256]; // 0xdc4f3c
extern CHAR byte_DC503C[256]; // 0xdc503c
extern CHAR byte_DC513C[256]; // 0xdc513c
extern CHAR byte_DC523C[256]; // 0xdc523c
extern CHAR byte_DC533C[256]; // 0xdc533c
extern CHAR byte_DC543C[256]; // 0xdc543c
extern CHAR byte_DC553C[256]; // 0xdc553c
extern CHAR byte_DC563C[256]; // 0xdc563c
extern int dword_DC573C; // 0xdc573c
extern CHAR byte_DC583C[256]; // 0xdc583c
extern CHAR byte_DC593C[256]; // 0xdc593c
extern CHAR byte_DC5A3C[256]; // 0xdc5a3c
extern CHAR byte_DC5B3C[256]; // 0xdc5b3c
extern CHAR byte_DC5C3C[768]; // 0xdc5c3c
extern unsigned __int8 g_bSaveFlag; // 0xdc5f3c
extern int dword_DC633C; // 0xdc633c
extern int dword_DC643C; // 0xdc643c
extern int dword_DC673C; // 0xdc673c
extern int dword_DC683C; // 0xdc683c
extern CHAR byte_DC6A3C[256]; // 0xdc6a3c
extern int dword_DC6B3C; // 0xdc6b3c
extern const char * g_szSceneName; // 0xdc6c3c
extern char g_szRoleNameTable[256]; // 0xdc733c
extern int dword_DC743C; // 0xdc743c
extern int dword_DC753C; // 0xdc753c
extern int dword_DC763C; // 0xdc763c
extern CHAR byte_DC773C[256]; // 0xdc773c
extern int dword_DC783C; // 0xdc783c
extern CHAR byte_DC7D3C[512]; // 0xdc7d3c
extern int dword_DC7F3C; // 0xdc7f3c
extern int dword_DC803C; // 0xdc803c
extern int dword_DC813C; // 0xdc813c
extern int dword_DC823C; // 0xdc823c
extern int dword_DC833C; // 0xdc833c
extern int dword_DC843C; // 0xdc843c
extern int dword_DC853C; // 0xdc853c
extern int dword_DC863C; // 0xdc863c
extern int dword_DC873C; // 0xdc873c
extern int dword_DC883C; // 0xdc883c
extern int dword_DC893C; // 0xdc893c
extern int dword_DC8A3C; // 0xdc8a3c
extern int dword_DC8B3C; // 0xdc8b3c
extern int dword_DC8C3C; // 0xdc8c3c
extern int dword_DC8D3C; // 0xdc8d3c
extern int dword_DC913C; // 0xdc913c
extern int dword_DC923C; // 0xdc923c
extern int dword_DC933C; // 0xdc933c
extern int dword_DC943C; // 0xdc943c
extern int dword_DC9F3C; // 0xdc9f3c
extern int dword_DCA03C; // 0xdca03c
extern int dword_DCA33C; // 0xdca33c
extern CHAR byte_DCAD3C[256]; // 0xdcad3c
extern char g_szCombatFieldName[]; // 0xdcae3c
extern int dword_DCAF3C; // 0xdcaf3c
extern int dword_DCB03C; // 0xdcb03c
extern int dword_DCB13C; // 0xdcb13c
extern int dword_DCB23C; // 0xdcb23c
extern int dword_DCB33C; // 0xdcb33c
extern int dword_DCB43C; // 0xdcb43c
extern int dword_DCB53C; // 0xdcb53c
extern int dword_DCB63C; // 0xdcb63c
extern int dword_DCB73C; // 0xdcb73c
extern int dword_DCB83C; // 0xdcb83c
extern int dword_DCB93C; // 0xdcb93c
extern int dword_DCBA3C; // 0xdcba3c
extern int dword_DCBB3C; // 0xdcbb3c
extern CHAR byte_DCBC3C[256]; // 0xdcbc3c
extern int dword_DCBD3C; // 0xdcbd3c
extern int dword_DCBE3C; // 0xdcbe3c
extern int dword_DCBF3C; // 0xdcbf3c
extern int dword_DCC13C; // 0xdcc13c
extern int dword_DCC23C; // 0xdcc23c
extern int dword_DCC33C; // 0xdcc33c
extern int dword_DCC43C; // 0xdcc43c
extern int dword_DCC53C; // 0xdcc53c
extern int dword_DCC63C; // 0xdcc63c
extern int dword_DCC73C; // 0xdcc73c
extern int dword_DCC83C; // 0xdcc83c
extern CHAR byte_DCC93C[256]; // 0xdcc93c
extern int dword_DCCA3C; // 0xdcca3c
extern int dword_DCCC3C; // 0xdccc3c
extern int dword_DCCD3C; // 0xdccd3c
extern int dword_DCCE3C; // 0xdcce3c
extern int dword_DCCF3C; // 0xdccf3c
extern CHAR byte_DCD03C[256]; // 0xdcd03c
extern CHAR byte_DCD13C[256]; // 0xdcd13c
extern char dword_DCD23C[]; // 0xdcd23c
extern char dword_DCD33C[]; // 0xdcd33c
extern char szText[]; // 0xdcd43c
extern char dword_DCD53C[]; // 0xdcd53c
extern char dword_DCD63C[]; // 0xdcd63c
extern char dword_DCD93C[]; // 0xdcd93c
extern int dword_DCDA3C; // 0xdcda3c
extern int dword_DCDB3C; // 0xdcdb3c
extern int dword_DCDC3C; // 0xdcdc3c
extern int dword_DCDD3C; // 0xdcdd3c
extern int dword_DCDE3C; // 0xdcde3c
extern int dword_DCDF3C; // 0xdcdf3c
extern int dword_DCE03C; // 0xdce03c
extern int dword_DCE13C; // 0xdce13c
extern int dword_DCE23C; // 0xdce23c
extern int dword_DCE33C; // 0xdce33c
extern int dword_DCE43C; // 0xdce43c
extern int dword_DCE53C; // 0xdce53c
extern int dword_DCE63C; // 0xdce63c
extern int dword_DCE73C; // 0xdce73c
extern char dword_DCE83C[]; // 0xdce83c
extern int dword_DCE93C; // 0xdce93c
extern int dword_DCEA3C; // 0xdcea3c
extern CHAR byte_DCEB3C[256]; // 0xdceb3c
extern int dword_DCEC3C; // 0xdcec3c
extern int dword_DCEF3C; // 0xdcef3c
extern int dword_DCF03C; // 0xdcf03c
extern int dword_DCF13C; // 0xdcf13c
extern int dword_DCF33C; // 0xdcf33c
extern CHAR byte_DCF43C[256]; // 0xdcf43c
extern int dword_DCF53C; // 0xdcf53c
extern int dword_DCF63C; // 0xdcf63c
extern int dword_DCF73C; // 0xdcf73c
extern int dword_DCF83C; // 0xdcf83c
extern int dword_DCF93C; // 0xdcf93c
extern int dword_DCFA3C; // 0xdcfa3c
extern int dword_DCFB3C; // 0xdcfb3c
extern CHAR byte_DCFC3C[512]; // 0xdcfc3c
extern int dword_DCFE3C; // 0xdcfe3c
extern int dword_DCFF3C; // 0xdcff3c
extern unsigned __int8 g_ComposeRecipeTable[]; // 0xdd003c
extern int dword_DD203C; // 0xdd203c
extern int dword_DD213C; // 0xdd213c
extern int dword_DD253C; // 0xdd253c
extern int dword_DD263C; // 0xdd263c
extern int dword_DD273C; // 0xdd273c
extern int dword_DD293C; // 0xdd293c
extern int dword_DD2A3C; // 0xdd2a3c
extern int dword_DD2B3C; // 0xdd2b3c
extern int dword_DD2C3C; // 0xdd2c3c
extern int dword_DD2D3C; // 0xdd2d3c
extern int dword_DD2E3C; // 0xdd2e3c
extern int dword_DD2F3C; // 0xdd2f3c
extern int dword_DD303C; // 0xdd303c
extern int dword_DD313C; // 0xdd313c
extern int dword_DD323C; // 0xdd323c
extern int dword_DD333C; // 0xdd333c
extern int dword_DD343C; // 0xdd343c
extern int dword_DD353C; // 0xdd353c
extern int dword_DD363C; // 0xdd363c
extern int dword_DD373C; // 0xdd373c
extern int dword_DD383C; // 0xdd383c
extern char dword_DD393C[]; // 0xdd393c
extern char dword_DD3A3C[]; // 0xdd3a3c
extern char dword_DD3B3C[]; // 0xdd3b3c
extern int dword_DD3D3C; // 0xdd3d3c
extern char dword_DD3F3C[]; // 0xdd3f3c
extern char dword_DD413C[]; // 0xdd413c
extern int dword_DD423C; // 0xdd423c
extern int dword_DD433C; // 0xdd433c
extern int dword_DD443C; // 0xdd443c
extern int dword_DD453C; // 0xdd453c
extern int dword_DD463C; // 0xdd463c
extern int dword_DD473C; // 0xdd473c
extern int dword_DD483C; // 0xdd483c
extern int dword_DD493C; // 0xdd493c
extern int dword_DD4A3C; // 0xdd4a3c
extern int dword_DD4B3C; // 0xdd4b3c
extern int dword_DD4E3C; // 0xdd4e3c
extern int dword_DD4F3C; // 0xdd4f3c
extern int dword_DD513C; // 0xdd513c
extern int dword_DD523C; // 0xdd523c
extern int dword_DD533C; // 0xdd533c
extern int dword_DD543C; // 0xdd543c
extern int dword_DD553C; // 0xdd553c
extern int dword_DD893C; // 0xdd893c
extern int dword_DD8A3C; // 0xdd8a3c
extern int dword_DD8B3C; // 0xdd8b3c
extern int dword_DD8D3C; // 0xdd8d3c
extern int dword_DD8E3C; // 0xdd8e3c
extern char dword_DD8F3C[]; // 0xdd8f3c
extern char dword_DD903C[]; // 0xdd903c
extern char dword_DD913C[]; // 0xdd913c
extern int dword_DD923C; // 0xdd923c
extern int dword_DD933C; // 0xdd933c
extern int dword_DD943C; // 0xdd943c
extern int dword_DD953C; // 0xdd953c
extern int dword_DD963C; // 0xdd963c
extern int dword_DD973C; // 0xdd973c
extern int dword_DD983C; // 0xdd983c
extern int dword_DD993C; // 0xdd993c
extern int dword_DD9A3C; // 0xdd9a3c
extern int dword_DD9C3C; // 0xdd9c3c
extern int dword_DD9D3C; // 0xdd9d3c
extern CHAR byte_DD9E3C[256]; // 0xdd9e3c
extern CHAR byte_DD9F3C[256]; // 0xdd9f3c
extern CHAR byte_DDA03C[256]; // 0xdda03c
extern CHAR byte_DDA13C[256]; // 0xdda13c
extern CHAR byte_DDA23C[256]; // 0xdda23c
extern CHAR byte_DDA33C[256]; // 0xdda33c
extern CHAR byte_DDA43C[256]; // 0xdda43c
extern CHAR byte_DDA53C[256]; // 0xdda53c
extern CHAR byte_DDA63C[256]; // 0xdda63c
extern CHAR byte_DDA73C[512]; // 0xdda73c
extern int dword_DDA93C; // 0xdda93c
extern int dword_DDAA3C; // 0xddaa3c
extern int dword_DDAB3C; // 0xddab3c
extern int dword_DDAC3C; // 0xddac3c
extern int dword_DDAD3C; // 0xddad3c
extern int dword_DDAE3C; // 0xddae3c
extern int dword_DDAF3C; // 0xddaf3c
extern int dword_DDB03C; // 0xddb03c
extern int dword_DDB13C; // 0xddb13c
extern int dword_DDB23C; // 0xddb23c
extern int dword_DDB33C; // 0xddb33c
extern int dword_DDB43C; // 0xddb43c
extern int dword_DDB53C; // 0xddb53c
extern int dword_DDB63C; // 0xddb63c
extern int dword_DDB73C; // 0xddb73c
extern int dword_DDB83C; // 0xddb83c
extern int dword_DDBA3C; // 0xddba3c
extern int dword_DDBB3C; // 0xddbb3c
extern int dword_DDBC3C; // 0xddbc3c
extern int dword_DDBD3C; // 0xddbd3c
extern int dword_DDBE3C; // 0xddbe3c
extern int dword_DDBF3C; // 0xddbf3c
extern int dword_DDC03C; // 0xddc03c
extern int dword_DDC13C; // 0xddc13c
extern int dword_DDC23C; // 0xddc23c
extern CHAR String1; // 0xde333c
extern float flt_DE4A00; // 0xde4a00
extern int dword_DE4C94; // 0xde4c94
extern unsigned __int8 g_SaveSlotFlags[40]; // 0xde5220
extern CHAR byte_DE54D4[3]; // 0xde54d4
extern CHAR byte_DE54D7[3]; // 0xde54d7
extern CHAR byte_DE54DA[3]; // 0xde54da
extern CHAR byte_DE54DD[3]; // 0xde54dd
extern CHAR byte_DE54E0[3]; // 0xde54e0
extern CHAR byte_DE54E3[3]; // 0xde54e3
extern CHAR byte_DE54E6[3]; // 0xde54e6
extern CHAR byte_DE54E9[3]; // 0xde54e9
extern CHAR byte_DE54EC[3]; // 0xde54ec
extern unsigned __int8 g_ArcSceneObjBuffer; // 0xde54ef
extern int g_nUILayoutFlags; // 0xde5ce4
extern CHAR byte_DE5F74[3]; // 0xde5f74
extern CHAR byte_DE5F77[3]; // 0xde5f77
extern CHAR byte_DE5F7A[3]; // 0xde5f7a
extern CHAR byte_DE5F7D[3]; // 0xde5f7d
extern CHAR byte_DE5F80[3]; // 0xde5f80
extern CHAR byte_DE5F83[3]; // 0xde5f83
extern CHAR byte_DE5F86[3]; // 0xde5f86
extern CHAR byte_DE5F89[3]; // 0xde5f89
extern CHAR byte_DE5F8C[3]; // 0xde5f8c
extern CHAR byte_DE5F8F[3]; // 0xde5f8f
extern unsigned __int8 g_bRoleFlag1; // 0xde5f92
extern unsigned __int8 g_bRoleFlag2; // 0xde5f93
extern int g_nActorState; // 0xde5f98
extern int g_nActor_DE5F9C; // 0xde5f9c
extern int g_nRoleParam; // 0xde5fa0
extern int g_nRoleState; // 0xde5fa4
extern int g_nActor_DE5FA8; // 0xde5fa8
extern unsigned __int8 g_bUIWnd_DE625A; // 0xde625a
extern int dword_DE6A30; // 0xde6a30
extern int byte_DE6A4C; // 0xde6a4c
extern RenderTarget3 g_RenderTarget3; // 0xde6cd8
extern unsigned int g_nFileVersion; // 0xde7710
extern char g_szParticleTexName[256]; // 0xde7714
extern PAL3 g_PAL3; // 0xde7aa0
extern int g_nSaveSlot0; // 0xec9e70
extern int g_nSaveSlot1; // 0xec9e74
extern int g_nSaveSlotBase[]; // 0xec9eb4
extern int dword_EC9F00; // 0xec9f00
extern char byte_EC9F0C[]; // 0xec9f0c
extern int byte_FFFFFF; // 0xffffff
extern int dword_1000000; // 0x1000000
extern int byte_1010101; // 0x1010101
extern int byte_1234567; // 0x1234567
extern char g_EffTable[370720]; // 0x174d330
extern int g_nCEffMgr_17A7B50; // 0x17a7b50
extern tag17A7BData g_17A7BData; // 0x17a7b54
extern unsigned __int8 g_bgbMatrixStackFlag_17A7B84; // 0x17a7b84
extern int g_nEffectUID; // 0x17a7b88
extern int g_nSceneObjCount; // 0x17a7bc0
extern int g_EffTaskEnd; // 0x17a7c24
extern int dword_17A7E50; // 0x17a7e50
extern int g_nEffShockCount; // 0x17a7e88
extern tagEffSParticleSys g_SParticleSys; // 0x17a8118
extern tag17A8Data g_17A8Data; // 0x17a8440
extern int dword_17A89C8; // 0x17a89c8
extern int dword_17A89CC; // 0x17a89cc
extern int dword_17A89D0; // 0x17a89d0
extern int dword_17A89D4; // 0x17a89d4
extern int dword_17A89D8; // 0x17a89d8
extern int dword_17A89DC; // 0x17a89dc
extern int dword_17A89E0; // 0x17a89e0
extern int dword_17A89E4; // 0x17a89e4
extern char byte_17A89E8[256]; // 0x17a89e8
extern RoleSystem g_RoleSystemCombat; // 0x17a8ae8
extern int dword_17A9E50; // 0x17a9e50
extern int dword_17A9F50; // 0x17a9f50
extern int dword_17AA050; // 0x17aa050
extern int dword_17AA150; // 0x17aa150
extern int dword_17AA250; // 0x17aa250
extern int dword_17AA350; // 0x17aa350
extern int dword_17AA450; // 0x17aa450
extern float flt_17AA550; // 0x17aa550
extern float flt_17AA800; // 0x017AA800
extern int dword_17AA808; // 0x17aa808
extern int dword_17AA818; // 0x17aa818
extern int dword_17AA828; // 0x17aa828
extern int dword_17AA838; // 0x17aa838
extern int dword_17AA848; // 0x17aa848
extern int dword_17AA858; // 0x17aa858
extern unsigned __int8 g_CCBStageState; // 0x17aa870
extern int g_nCBStageFlags[8]; // 0x17aa880
extern int g_nCBRoleAnimData[24]; // 0x17aa8a0
extern int pnVal; // 0x17aa910
extern int dword_17AA914; // 0x17aa914
extern int dword_17AA918; // 0x17aa918
extern int byte_17AA91C; // 0x17aa91c
extern char byte_17AA920[256]; // 0x17aa920
extern int dword_17AAA20; // 0x17aaa20
extern int dword_17AAA24; // 0x17aaa24
extern int dword_17AAA28; // 0x17aaa28
extern int byte_17AAA2C; // 0x17aaa2c
extern int fBladeTime; // 0x17aad3c
extern float g_fCBAnimTime; // 0x17aad48
extern tagCombatTaskData g_CombatTaskData; // 0x17aad4c
extern int byte_17AAEE0; // 0x17aaee0
extern char byte_17AAEE4[61]; // 0x17aaee4
extern int byte_17AAF21; // 0x17aaf21
extern unsigned __int8 g_CCBCamControlData; // 0x17aaf64
extern int dword_17AB584; // 0x17ab584
extern int g_nCBFormation1[12]; // 0x17ab588
extern int g_nCBFormation2[16]; // 0x17ab5e8
extern int g_nCBFormation3[12]; // 0x17ab658
extern int g_nCBFormation4[12]; // 0x17ab6b8
extern int g_nCBRoleAttackTable[44]; // 0x17ab6e8
extern int g_nCBRoleMoveTable[24]; // 0x17ab7a8
extern char byte_17AB808[16]; // 0x17ab808
extern char byte_17AB818[16]; // 0x17ab818
extern int g_nCBRoleHitTable[18]; // 0x17ab874
extern int dword_17AB9B8; // 0x17ab9b8
extern int dword_17AB9BC; // 0x17ab9bc
extern int dword_17AB9C0; // 0x17ab9c0
extern int byte_17AB9C4; // 0x17ab9c4
extern int dword_17AB9C8; // 0x17ab9c8
extern int dword_17AB9CC; // 0x17ab9cc
extern int dword_17AB9D8; // 0x17ab9d8
extern int dword_17AB9DC; // 0x17ab9dc
extern tagStageRoleData g_StageRoleData; // 0x17abc60
extern char byte_17ABD00[256]; // 0x17abd00
extern char byte_17ABE00[256]; // 0x17abe00
extern unsigned __int8 g_CCBStageSceneData; // 0x17abf00
extern UINT uType; // 0x17ac5d8
extern unsigned __int8 g_bCBFlag; // 0x17ac5dc
extern CHAR byte_17AC6DC[256]; // 0x17ac6dc
extern float g_fCBDeltaTime; // 0x17ac7dc
extern int g_nCBRoundCount[3]; // 0x17ac7e0
extern float g_fCBSpeed; // 0x17ac7ec
extern unsigned __int8 g_bCBActive; // 0x17ac7f0
extern float g_fCBTimeScale; // 0x17aca78
extern int dword_17ACA7C; // 0x17aca7c
extern int g_nCBRolePos[32]; // 0x17aca80
extern char byte_17ACB08[128]; // 0x17acb08
extern int g_nAIWindowBase; // 0x17acb88
extern int g_nCCBAIWindow_17ACB8C; // 0x17acb8c
extern float g_fCBCamParam; // 0x17ace10
extern int g_nCBCamState[24]; // 0x17ace14
extern unsigned __int8 g_TempBuffer1024[1024]; // 0x17acf80
extern float flt_17AD598; // 0x17ad598
extern int dword_17AD59C; // 0x17ad59c
extern unsigned __int8 g_CCBProtectData[]; // 0x17ad5c4
extern int dword_17AD5C8; // 0x17ad5c8
extern int dword_17AD5CC; // 0x17ad5cc
extern float flt_17ADB00; // 0x17adb00
extern int dword_17ADB04; // 0x17adb04
extern int dword_17AF5A8; // 0x17af5a8
extern int dword_17AF5AC; // 0x17af5ac
extern int dword_17AF5B0; // 0x17af5b0
extern int dword_17AF5B8; // 0x17af5b8
extern int dword_17AF5BC; // 0x17af5bc
extern int dword_17AF5C0; // 0x17af5c0
extern unsigned __int8 g_bgbGeomNodeFlag_17AF5C4; // 0x17af5c4
extern int dword_17AFAE8; // 0x17afae8
extern int dword_17AFAEC; // 0x17afaec
extern int dword_17AFAF0; // 0x17afaf0
extern int dword_17AFAF8; // 0x17afaf8
extern int dword_17AFAFC; // 0x17afafc
extern int dword_17AFB00; // 0x17afb00
extern int byte_17AFB04; // 0x17afb04
extern float g_fSceneScale; // 0x17b02ec
extern float flt_17B1298; // 0x17b1298
extern int dword_17B129C; // 0x17b129c
extern float flt_17B1548; // 0x17b1548
extern int dword_17B154C; // 0x17b154c
extern Actor g_ActorSaveData; // 0x17b1550
extern char Source[99]; // 0x17b1cc0
extern char byte_17B1D23[413]; // 0x17b1d23
extern int g_InputState; // 0x17b1ec0
extern int g_nCBResultState; // 0x17b30e4
extern char byte_17B3AAC[1028]; // 0x17b3aac
extern PtrArray stru_17B3EB0; // 0x17b3eb0
extern int byte_17B3ED0; // 0x17b3ed0
extern CScreenModeNode stru_17B3ED8; // 0x17b3ed8
extern CScreenMode g_CScreenMode; // 0x17b41e8
extern BYTE Data; // 0x1894970
extern CHAR Filename[260]; // 0x1894a74
extern TextureLibDataBase stru_1894B78; // 0x1894b78
extern float flt_1895038; // 0x1895038
extern int dword_189503C; // 0x189503c
extern int dword_1895040; // 0x1895040
extern int dword_1895044; // 0x1895044
extern gbRenderEffect * g_pRenderEffect_1895048; // 0x1895048
extern gbRenderEffect * g_pRenderEffect_189504C; // 0x189504c
extern gbRenderEffect * g_pRenderEffect_1895050; // 0x1895050
extern gbRenderEffect * g_pRenderEffect_1895054; // 0x1895054
extern int g_pTexColorEffect; // 0x1895058
extern gbRenderEffect * g_pRenderEffect_189505C; // 0x189505c
extern gbRenderEffect * g_pRenderEffect_1895060; // 0x1895060
extern gbRenderEffect * g_pRenderEffect_1895064; // 0x1895064
extern gbRenderEffect * g_pRenderEffect_1895068; // 0x1895068
extern int g_nParent_Data_189506C; // 0x189506c
extern double dbl_1895070; // 0x1895070
extern char * Str; // 0x1895318
extern int dword_1895328; // 0x1895328
extern int g_nScriptState; // 0x189533c
extern void * lp; // 0x1895388
extern LPTOP_LEVEL_EXCEPTION_FILTER lpTopLevelExceptionFilter; // 0x1895398
extern LCID dword_18953A8; // 0x18953a8
extern UINT dword_18953B8; // 0x18953b8
extern CHAR byte_18953F0[260]; // 0x18953f0
extern int byte_1895558; // 0x1895558
extern int byte_1895559; // 0x1895559
extern int dword_189555C; // 0x189555c
extern unsigned __int8 g_bEffSystemFlags; // 0x1895560
extern unsigned __int8 g_bScriptFlag; // 0x1895561
extern int g_pCEffMgrBackup; // 0x1895580
extern int g_nCEffect_1895980; // 0x1895980
extern unsigned int g_nRandSeed; // 0x1895984
extern int g_nRandCount; // 0x1895988
extern int byte_189598C; // 0x189598c
extern unsigned __int8 g_bSceneChangeFlags; // 0x189598d
extern unsigned __int8 g_bStaticInitFlags; // 0x189598e
extern size_t Count; // 0x18969a0
extern UINT CodePage; // 0x18969a4
extern LCID Locale; // 0x1896bc4
extern int g_nUIState; // 0x1896be0
extern UINT uNumber; // 0x1896ce0
extern void * g_Block_1896CF0; // 0x1896cf0
extern int g_nScriptCounter; // 0x1896d00
extern LPVOID lpMem; // 0x1896d08
extern HANDLE hHeap; // 0x1896d0c
extern int dword_C10C1C; // 0x00C10C1C
extern int dword_C05804; // 0x00C05804
extern float flt_C0817C; // 0x00C0817C
extern int dword_C10C44; // 0x00C10C44
extern int dword_C10A78; // 0x00C10A78
extern int dword_C10A70; // 0x00C10A70
extern int dword_5D4D70; // 0x005D4D70
extern void * off_570440; // 0x00570440
extern void * off_5AC098; // 0x005AC098
extern int dword_D8BC18; // 0x00D8BC18
extern int dword_5D4DA0; // 0x005D4DA0
extern float flt_C08180; // 0x00C08180
extern int dword_C10A98; // 0x00C10A98
extern int dword_C020AC; // 0x00C020AC
extern float flt_56AB44; // 0x0056AB44
extern int dword_C057B8; // 0x00C057B8
extern int unk_5DEB90; // 0x005DEB90
extern int unk_5DEF18; // 0x005DEF18
extern int dword_C057A4; // 0x00C057A4
extern int dword_C10B08; // 0x00C10B08
extern void * off_570284; // 0x00570284
extern int dword_C10BF4; // 0x00C10BF4
extern int dword_C10C24; // 0x00C10C24
extern unsigned char byte_C10CC0; // 0x00C10CC0
extern int dword_C10BB8; // 0x00C10BB8
extern float flt_56A9D4; // 0x0056A9D4
extern int dword_C10AA8; // 0x00C10AA8
extern int dword_C10B5C; // 0x00C10B5C
extern int dword_C10AB8; // 0x00C10AB8
extern int dword_5D4D94; // 0x005D4D94
extern int unk_5DEAFC; // 0x005DEAFC
extern int dword_C10AA0; // 0x00C10AA0
extern int unk_5DBF30; // 0x005DBF30
extern int dword_C10BC4; // 0x00C10BC4
extern float flt_C0816C; // 0x00C0816C
extern float flt_C10D48; // 0x00C10D48
extern int dword_C020EC; // 0x00C020EC
extern int unk_5D88D4; // 0x005D88D4
extern int unk_5DEF9C; // 0x005DEF9C
extern int unk_5DBEF8; // 0x005DBEF8
extern int unk_5DEF70; // 0x005DEF70
extern int dword_C10D58; // 0x00C10D58
extern int dword_DCA13C; // 0x00DCA13C
extern int dword_C10BD0; // 0x00C10BD0
extern int dword_C10C40; // 0x00C10C40
extern int dword_C10A30; // 0x00C10A30
extern int dword_C10B9C; // 0x00C10B9C
extern int dword_C10B78; // 0x00C10B78
extern int unk_5DBF18; // 0x005DBF18
extern int dword_DDB93C; // 0x00DDB93C
extern float flt_56AB40; // 0x0056AB40
extern float flt_C08204; // 0x00C08204
extern float flt_56A768; // 0x0056A768
extern int dword_C10AC8; // 0x00C10AC8
extern int unk_5DEFB4; // 0x005DEFB4
extern int dword_C10B10; // 0x00C10B10
extern int unk_5DF3E4; // 0x005DF3E4
extern int dword_C10B68; // 0x00C10B68
extern int dword_C10A38; // 0x00C10A38
extern int dword_C10A7C; // 0x00C10A7C
extern int dword_C10C6C; // 0x00C10C6C
extern int dword_D92780; // 0x00D92780
extern int dword_C057AC; // 0x00C057AC
extern int dword_C056AC; // 0x00C056AC
extern float flt_56A9F0; // 0x0056A9F0
extern int unk_5DF370; // 0x005DF370
extern int dword_C10C58; // 0x00C10C58
extern int dword_C10B0C; // 0x00C10B0C
extern unsigned char byte_C10DA4; // 0x00C10DA4
extern float flt_56A9F4; // 0x0056A9F4
extern int unk_C10A08; // 0x00C10A08
extern int dword_C10B1C; // 0x00C10B1C
extern int dword_C10BF8; // 0x00C10BF8
extern int dword_C10B6C; // 0x00C10B6C
extern int unk_5DF42C; // 0x005DF42C
extern unsigned char byte_C10CC1; // 0x00C10CC1
extern int dword_D8BC04; // 0x00D8BC04
extern int unk_5DF2E0; // 0x005DF2E0
extern int unk_5DB7AC; // 0x005DB7AC
extern int dword_C10D9C; // 0x00C10D9C
extern int dword_C0579C; // 0x00C0579C
extern int dword_C057B0; // 0x00C057B0
extern int dword_C10C00; // 0x00C10C00
extern int dword_C05780; // 0x00C05780
extern int dword_C10BFC; // 0x00C10BFC
extern int dword_C10AFC; // 0x00C10AFC
extern int dword_C10C08; // 0x00C10C08
extern int dword_C05784; // 0x00C05784
extern int dword_C10C34; // 0x00C10C34
extern int unk_5DF320; // 0x005DF320
extern int unk_5DEBDC; // 0x005DEBDC
extern int dword_C10BC8; // 0x00C10BC8
extern int dword_C10AB0; // 0x00C10AB0
extern int dword_C0578C; // 0x00C0578C
extern int unk_C08650; // 0x00C08650
extern int dword_C10A90; // 0x00C10A90
extern unsigned char byte_A00603; // 0x00A00603
extern int unk_5DEAD4; // 0x005DEAD4
extern int unk_5DEA3C; // 0x005DEA3C
extern int dword_C10B60; // 0x00C10B60
extern int dword_C10C8C; // 0x00C10C8C
extern int dword_C10C30; // 0x00C10C30
extern int dword_D8BBF8; // 0x00D8BBF8
extern int unk_5DF2C0; // 0x005DF2C0
extern int dword_C10D90; // 0x00C10D90
extern float flt_56A9F8; // 0x0056A9F8
extern int dword_C10BB4; // 0x00C10BB4
extern int unk_5DF718; // 0x005DF718
extern unsigned char byte_C10D94; // 0x00C10D94
extern unsigned char byte_C0599E; // 0x00C0599E
extern int dword_C10C10; // 0x00C10C10
extern int dword_C10A20; // 0x00C10A20
extern int dword_C057A8; // 0x00C057A8
extern float flt_C08184; // 0x00C08184
extern int unk_5DF348; // 0x005DF348
extern int dword_C10B58; // 0x00C10B58
extern float flt_56AB4C; // 0x0056AB4C
extern float flt_56B5E8; // 0x0056B5E8
extern int dword_C10D68; // 0x00C10D68
extern int unk_5DBF20; // 0x005DBF20
extern float flt_56A9D0; // 0x0056A9D0
extern int dword_C10C4C; // 0x00C10C4C
extern float flt_56A9FC; // 0x0056A9FC
extern int dword_C056A8; // 0x00C056A8
extern int dword_C05794; // 0x00C05794
extern int dword_C10A4C; // 0x00C10A4C
extern int unk_5DB750; // 0x005DB750
extern int dword_C10A2C; // 0x00C10A2C
extern int unk_5D8C14; // 0x005D8C14
extern float flt_56AA54; // 0x0056AA54
extern int dword_C10A68; // 0x00C10A68
extern int unk_5D88E0; // 0x005D88E0
extern int dword_DE3490; // 0x00DE3490
extern int unk_5DEC04; // 0x005DEC04
extern int dword_C10BCC; // 0x00C10BCC
extern float flt_C10D44; // 0x00C10D44
extern int unk_5DBEE8; // 0x005DBEE8
extern int dword_C10D40; // 0x00C10D40
extern float flt_C08178; // 0x00C08178
extern int dword_C10AEC; // 0x00C10AEC
extern int dword_C10B28; // 0x00C10B28
extern int unk_5DEA8C; // 0x005DEA8C
extern int dword_C10B40; // 0x00C10B40
extern int dword_C10C54; // 0x00C10C54
extern int dword_C10C28; // 0x00C10C28
extern int dword_C10A80; // 0x00C10A80
extern int unk_5DE8DC; // 0x005DE8DC
extern int unk_5DEFD4; // 0x005DEFD4
extern int dword_C02080; // 0x00C02080
extern float flt_56A99C; // 0x0056A99C
extern int unk_5DEF44; // 0x005DEF44
extern int dword_C10A28; // 0x00C10A28
extern int unk_5DF3BC; // 0x005DF3BC
extern int dword_C10C68; // 0x00C10C68
extern int unk_5DFD8C; // 0x005DFD8C
extern int dword_C10D88; // 0x00C10D88
extern int dword_C10B88; // 0x00C10B88
extern int dword_C10BD8; // 0x00C10BD8
extern int unk_5DF73C; // 0x005DF73C
extern int dword_D8BBF0; // 0x00D8BBF0
extern int dword_C10BA4; // 0x00C10BA4
extern int dword_C10B3C; // 0x00C10B3C
extern int dword_D8BC14; // 0x00D8BC14
extern int dword_C05818; // 0x00C05818
extern int dword_C10D54; // 0x00C10D54
extern int dword_C10C70; // 0x00C10C70
extern int dword_C05798; // 0x00C05798
extern int unk_5DBEE4; // 0x005DBEE4
extern int dword_C056C0; // 0x00C056C0
extern int unk_5DF300; // 0x005DF300
extern float flt_C08164; // 0x00C08164
extern int dword_C10AE8; // 0x00C10AE8
extern int dword_C10BA8; // 0x00C10BA8
extern int unk_5DEA20; // 0x005DEA20
extern int dword_C10ACC; // 0x00C10ACC
extern int dword_C10D70; // 0x00C10D70
extern int dword_C10BDC; // 0x00C10BDC
extern int dword_C10A50; // 0x00C10A50
extern int unk_5DECD4; // 0x005DECD4
extern int unk_5DB770; // 0x005DB770
extern float flt_56AA24; // 0x0056AA24
extern int dword_C10C50; // 0x00C10C50
extern float flt_56A65C; // 0x0056A65C
extern int dword_C10BB0; // 0x00C10BB0
extern int dword_C10A1C; // 0x00C10A1C
extern int dword_C10C5C; // 0x00C10C5C
extern int unk_5DBF10; // 0x005DBF10
extern float flt_56A610; // 0x0056A610
extern int dword_C10C80; // 0x00C10C80
extern int dword_C10AD0; // 0x00C10AD0
extern int dword_C056C8; // 0x00C056C8
extern void * off_56B364; // 0x0056B364
extern float flt_56AA5C; // 0x0056AA5C
extern int dword_C10A9C; // 0x00C10A9C
extern float flt_56A668; // 0x0056A668
extern float flt_56AA08; // 0x0056AA08
extern int dword_5D4D88; // 0x005D4D88
extern int dword_D8BC08; // 0x00D8BC08
extern int unk_5DBF08; // 0x005DBF08
extern int dword_C10A8C; // 0x00C10A8C
extern int unk_5DF204; // 0x005DF204
extern int dword_C05800; // 0x00C05800
extern int dword_C056BC; // 0x00C056BC
extern int dword_DE3448; // 0x00DE3448
extern int dword_C056B8; // 0x00C056B8
extern int dword_C083D4; // 0x00C083D4
extern int unk_5DBEF0; // 0x005DBEF0
extern int dword_C10B80; // 0x00C10B80
extern int dword_C10C7C; // 0x00C10C7C
extern float flt_56A648; // 0x0056A648
extern int unk_5DEBB4; // 0x005DEBB4
extern int dword_C0577C; // 0x00C0577C
extern int dword_C10A58; // 0x00C10A58
extern float flt_56A63C; // 0x0056A63C
extern int dword_C10AC0; // 0x00C10AC0
extern int dword_C10BE4; // 0x00C10BE4
extern int dword_C10B50; // 0x00C10B50
extern int dword_C10D8C; // 0x00C10D8C
extern int dword_C10C74; // 0x00C10C74
extern int unk_5DF450; // 0x005DF450
extern int dword_C10A48; // 0x00C10A48
extern int dword_C05790; // 0x00C05790
extern int dword_C057B4; // 0x00C057B4
extern int dword_C056C4; // 0x00C056C4
extern int unk_5DECA8; // 0x005DECA8
extern int dword_C10C88; // 0x00C10C88
extern void * off_57042C; // 0x0057042C
extern int unk_C083B8; // 0x00C083B8
extern float flt_56A644; // 0x0056A644
extern int dword_C10B4C; // 0x00C10B4C
extern float flt_C08174; // 0x00C08174
extern int dword_C10BD4; // 0x00C10BD4
extern int dword_C10CD0; // 0x00C10CD0
extern float flt_56A774; // 0x0056A774
extern int unk_5DBF34; // 0x005DBF34
extern void * off_56B754; // 0x0056B754
extern int dword_C10D98; // 0x00C10D98
extern int unk_5DF394; // 0x005DF394
extern int dword_C10D6C; // 0x00C10D6C
extern float flt_C08188; // 0x00C08188
extern int dword_C057A0; // 0x00C057A0
extern int unk_5DF2A0; // 0x005DF2A0
extern int dword_C05788; // 0x00C05788
extern int unk_5DEA00; // 0x005DEA00
extern float flt_56A6C8; // 0x0056A6C8
extern int dword_C10D64; // 0x00C10D64
extern int dword_C10A6C; // 0x00C10A6C
extern int dword_C10A3C; // 0x00C10A3C
extern int dword_C10A40; // 0x00C10A40
extern int unk_5DF408; // 0x005DF408
extern int dword_C10ADC; // 0x00C10ADC
extern int dword_C10B7C; // 0x00C10B7C
extern int unk_5DB748; // 0x005DB748
extern int unk_5DEC7C; // 0x005DEC7C
extern int dword_C10C78; // 0x00C10C78
extern int unk_5DEC2C; // 0x005DEC2C
extern float flt_56A744; // 0x0056A744
extern int dword_C10C3C; // 0x00C10C3C
extern int dword_C10A18; // 0x00C10A18
extern int unk_5D8C08; // 0x005D8C08
extern int dword_C05808; // 0x00C05808
extern float flt_56AB20; // 0x0056AB20
extern int dword_C10B2C; // 0x00C10B2C
extern int unk_5DEB68; // 0x005DEB68
extern int dword_C05814; // 0x00C05814
extern int dword_D8BBF4; // 0x00D8BBF4
extern int dword_C0209C; // 0x00C0209C
extern int dword_C0580C; // 0x00C0580C
extern int unk_5DECFC; // 0x005DECFC
extern int dword_C10D74; // 0x00C10D74
extern int dword_C10BAC; // 0x00C10BAC
extern int dword_C10B18; // 0x00C10B18
extern int dword_C056B4; // 0x00C056B4
extern int unk_5DBF00; // 0x005DBF00
extern int unk_5DEB44; // 0x005DEB44
extern int dword_C10C18; // 0x00C10C18
extern int dword_C10B30; // 0x00C10B30
extern int unk_5DEA64; // 0x005DEA64
extern int dword_C10BE8; // 0x00C10BE8
extern int dword_C10C20; // 0x00C10C20
extern int dword_5D4D58; // 0x005D4D58
extern int dword_C10C2C; // 0x00C10C2C
extern int dword_C10B48; // 0x00C10B48
extern int dword_C10BE0; // 0x00C10BE0
extern float flt_56A64C; // 0x0056A64C
extern int dword_C020DC; // 0x00C020DC
extern int dword_C10C64; // 0x00C10C64
extern int dword_D8BC00; // 0x00D8BC00
extern float flt_56AA04; // 0x0056AA04
extern float flt_56A658; // 0x0056A658
extern int dword_C10A60; // 0x00C10A60
extern int dword_C10BC0; // 0x00C10BC0
extern int dword_C10C60; // 0x00C10C60
extern int unk_5DEC54; // 0x005DEC54
extern int dword_C10C0C; // 0x00C10C0C
extern float flt_56AB48; // 0x0056AB48
extern int dword_C020CC; // 0x00C020CC
extern int dword_C05778; // 0x00C05778
extern int dword_C056A4; // 0x00C056A4
extern int dword_C10D5C; // 0x00C10D5C
extern int dword_C10C04; // 0x00C10C04
extern int dword_C020BC; // 0x00C020BC
extern int dword_C10B38; // 0x00C10B38
extern int dword_C056B0; // 0x00C056B0
extern int unk_5DEB20; // 0x005DEB20
extern int dword_C10AAC; // 0x00C10AAC
extern int dword_C10D7C; // 0x00C10D7C
extern int dword_C10AD8; // 0x00C10AD8
extern int unk_5D8C04; // 0x005D8C04
extern int dword_C10B90; // 0x00C10B90
extern int dword_C10B20; // 0x00C10B20
extern int dword_C10AE0; // 0x00C10AE0
extern int dword_C10BEC; // 0x00C10BEC
extern int unk_5D8C0C; // 0x005D8C0C
extern float flt_56AB10; // 0x0056AB10
extern int dword_C10ABC; // 0x00C10ABC
extern int dword_C02060; // 0x00C02060
extern int dword_C10C48; // 0x00C10C48
extern int dword_5D4D44; // 0x005D4D44
extern float flt_56A984; // 0x0056A984
extern float flt_56AA3C; // 0x0056AA3C
extern int dword_C057BC; // 0x00C057BC
extern int dword_C10B8C; // 0x00C10B8C
extern int dword_C10B70; // 0x00C10B70
extern int dword_C10DA0; // 0x00C10DA0
extern float flt_56AA00; // 0x0056AA00
extern int dword_C10C38; // 0x00C10C38
extern unsigned char byte_A00601; // 0x00A00601
extern float flt_56AB24; // 0x0056AB24
extern int dword_C10C14; // 0x00C10C14
extern int unk_5DEAB0; // 0x005DEAB0
extern int dword_C10BF0; // 0x00C10BF0
extern int unk_5DBF28; // 0x005DBF28
extern int dword_C05704; // 0x00C05704
extern int dword_C10D78; // 0x00C10D78
extern int dword_C10D60; // 0x00C10D60
extern float flt_56A77C; // 0x0056A77C
extern int dword_C10A88; // 0x00C10A88
extern int dword_C10B98; // 0x00C10B98
extern int dword_C05810; // 0x00C05810
extern float flt_56A6C0; // 0x0056A6C0
extern int dword_C10BBC; // 0x00C10BBC
extern int dword_C02070; // 0x00C02070
extern int dword_D8BC10; // 0x00D8BC10
extern int unk_5DF580; // 0x005DF580
extern int dword_DCA23C; // 0x00DCA23C
extern int dword_C083D8; // 0x00C083D8
extern int unk_5D88C8; // 0x005D88C8
extern int dword_C10A5C; // 0x00C10A5C
extern int dword_C10CD4; // 0x00C10CD4
extern float flt_C08168; // 0x00C08168
extern int dword_C10B00; // 0x00C10B00
extern int dword_C10AF8; // 0x00C10AF8
extern int dword_C10C84; // 0x00C10C84
extern int dword_C05774; // 0x00C05774
extern int dword_C10AF0; // 0x00C10AF0
