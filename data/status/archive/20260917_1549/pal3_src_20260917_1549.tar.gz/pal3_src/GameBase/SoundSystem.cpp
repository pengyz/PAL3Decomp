#include "pal3/ida_defs.h"
#include "globals.h"
#include "pal3/pal3_constants.h"
#include "GameBase/SoundSystem.h"
#include "Role/RoleSystem.h"

// 0x0041ED00
int SoundSystem::Init()
{
  int v1; // edi
  int v2; // esi
  gbSound2DNode *v3; // eax
  gbSound2DNode *v4; // eax
  gbSound2DNode *v5; // eax
  gbSound2DNode *v6; // eax
  int result; // eax
  int v8; // ecx
  char Buffer[256]; // [esp+0x14] [ebp-0x10C] BYREF
  int v10; // [esp+0x11C] [ebp-0x4]

  memset(&((RoleSystem *)&stru_C10DF0)->m_fMoveTargetZ, 0, 0x60u);
  memset(&((RoleSystem *)&stru_C10DF0)->m_nRoleCount, 0, 0x60u);
  v1 = 97;
  ((RoleSystem *)&stru_C10DF0)->m_teamSlotOverlay.m_teamSlots[156] = 0;
  v2 = 0;
  do
  {
    sprintf(Buffer, "snd\\we021%c.wav", v1);
    v3 = (gbSound2DNode *)operator new(0x10u);
    v10 = 0;
    if ( v3 )
      v4 = ((gbSound2DNode *)v3);
    else
      v4 = 0;
    v10 = -1;
    *(_DWORD *)((char *)&((RoleSystem *)&stru_C10DF0)->m_fMoveTargetZ + v2) = (_DWORD)v4;
    (((gbSound2DNode *)v4))->gbSound2DNode::LoadFromFile(Buffer);
    *(_DWORD *)(*(_DWORD *)((char *)&((RoleSystem *)&stru_C10DF0)->m_fMoveTargetZ + v2) + 8) = 0;
    v5 = (gbSound2DNode *)operator new(0x10u);
    v10 = 1;
    if ( v5 )
      v6 = ((gbSound2DNode *)v5);
    else
      v6 = 0;
    v10 = -1;
    *(int *)((char *)&((RoleSystem *)&stru_C10DF0)->m_nRoleCount + v2) = (int)v6;
    sprintf(Buffer, "snd\\we022%c.wav", v1);
    result = gbSound2DNode::LoadFromFile(*(gbSound2DNode **)((char *)&((RoleSystem *)&stru_C10DF0)->m_nRoleCount + v2), Buffer);
    v8 = *(int *)((char *)&((RoleSystem *)&stru_C10DF0)->m_nRoleCount + v2);
    ++v1;
    v2 += 4;
    *(_DWORD *)(v8 + 8) = 0;
  }
  while ( v1 - 97 < 4 );
  return result;
}
