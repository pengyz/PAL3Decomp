#pragma once
// Auto-generated: SoundSystem
#include "pal3/ida_types.h"

class SoundSystem {
public:
    _BYTE _tail_000[4]; // +0x0
    // total size: 0x4 (4)

    int Init(); // 0x0041ED00
    // Scalar-wrapper: ctors for IDA (Cls)int casts (no init code)
    SoundSystem() {}
    SoundSystem(int v) { *(int*)this = v; }

};
