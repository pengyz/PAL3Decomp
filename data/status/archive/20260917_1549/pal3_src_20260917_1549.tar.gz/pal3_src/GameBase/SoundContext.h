#pragma once
// Auto-generated: SoundContext
#include "pal3/ida_types.h"

class SoundContext {
public:
    _BYTE _tail_000[4]; // +0x0
    // total size: 0x4 (4)

    void CreateSubPanels(int nMode); // 0x00527A80
    // Scalar-wrapper: ctors for IDA (Cls)int casts (no init code)
    SoundContext() {}
    SoundContext(int v) { *(int*)this = v; }

};
