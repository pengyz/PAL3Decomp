# pal3-gates

PAL3 反编译管线门禁 plugin — 为 Claude Code / aide 提供 harness 级硬约束。

## 功能

| Hook | 触发条件 | 行为 |
|------|---------|------|
| **PreToolUse** | Write/Edit `annotations/*` | 运行 `check_annotations.py`，失败阻止写入 |
| **PreToolUse** | `Bash(git commit*)` | 检查暂存区 annotations 验证 |
| **PreToolUse** | Write/Edit `pipeline/*.py` | 阻止修改管线脚本（只读保护） |
| **PostToolUse** | 所有工具调用 | 追加审计日志到 `.project/audit.log` |
| **Stop** | LLM 想停止时 | 除致命错误/用户指令外，强制继续工作 |

**Skill：** `annotation-guide` — PAL3 annotations 标注规范与验证流程。

## 目录结构

```
pal3-gates/
├── .claude-plugin/
│   └── plugin.json        # 清单
├── hooks/
│   └── hooks.json         # 事件订阅
├── scripts/
│   ├── gate_annotations.sh
│   ├── gate_commit.sh
│   ├── gate_readonly.sh
│   ├── check_stop.sh
│   ├── audit_log.sh
│   ├── post_annotation_check.sh
│   ├── collect_metrics.py
│   ├── pipeline_checkpoint.sh
│   └── remind_quality.sh
├── skills/
│   └── annotation-guide/
│       └── SKILL.md
└── README.md
```

## 手动安装（Claude Code）

### 1. 复制 plugin 到 cache 目录

```bash
PLUGIN_SRC="path/to/pal3-gates"  # 本 plugin 目录
CACHE_DIR="$HOME/.claude/plugins/cache/local/pal3-gates/1.0.0"

mkdir -p "$CACHE_DIR"
cp -r "$PLUGIN_SRC"/* "$PLUGIN_SRC"/.claude-plugin "$CACHE_DIR/"
chmod +x "$CACHE_DIR/scripts/"*.sh "$CACHE_DIR/scripts/"*.py
```

### 2. 创建 local marketplace

```bash
MKT_DIR="$HOME/.claude/plugins/marketplaces/local"
mkdir -p "$MKT_DIR/.claude-plugin" "$MKT_DIR/plugins"

# 复制 plugin 到 marketplace
cp -r "$CACHE_DIR" "$MKT_DIR/plugins/pal3-gates"

# 创建 marketplace.json
cat > "$MKT_DIR/.claude-plugin/marketplace.json" << 'EOF'
{
  "name": "local",
  "owner": { "name": "local" },
  "plugins": [
    {
      "name": "pal3-gates",
      "description": "PAL3 反编译管线门禁",
      "version": "1.0.0",
      "source": "./plugins/pal3-gates",
      "strict": true
    }
  ]
}
EOF
```

### 3. 注册 marketplace

编辑 `~/.claude/plugins/known_marketplaces.json`，添加：

```json
{
  "local": {
    "source": {
      "source": "directory",
      "path": "/home/YOUR_USER/.claude/plugins/marketplaces/local"
    },
    "installLocation": "/home/YOUR_USER/.claude/plugins/marketplaces/local",
    "lastUpdated": "2026-01-01T00:00:00.000Z"
  }
}
```

### 4. 注册 plugin

编辑 `~/.claude/plugins/installed_plugins.json`，在 `plugins` 对象中添加：

```json
{
  "pal3-gates@local": [{
    "scope": "user",
    "installPath": "/home/YOUR_USER/.claude/plugins/cache/local/pal3-gates/1.0.0",
    "version": "1.0.0",
    "installedAt": "2026-01-01T00:00:00.000Z"
  }]
}
```

### 5. 启用 plugin

编辑 `~/.claude/settings.json`，在 `enabledPlugins` 中添加：

```json
{
  "enabledPlugins": {
    "pal3-gates@local": true
  }
}
```

### 6. 验证

重启 Claude Code，运行 `/plugin`，应看到 `pal3-gates` 已加载。

## 手动安装（aide）

将 plugin 目录复制到项目的 `.project/plugins/` 下：

```bash
cp -r path/to/pal3-gates YOUR_PROJECT/.project/plugins/pal3-gates
```

重新打开项目即自动加载。aide 额外支持 `Notification` interval 周期提醒和 `required_tools` 强制工具检查。

## 适配说明

| 特性 | Claude Code | aide |
|------|------------|------|
| PreToolUse / PostToolUse / Stop | 原生支持 | 原生支持 |
| Notification interval | 不支持 | 支持 |
| required_tools | 不支持 | 支持 |
| data_write 面板 | 无面板 | 支持 |
| ${CLAUDE_PLUGIN_ROOT} | 原生 | 用 ${AIDE_PLUGIN_ROOT} |
