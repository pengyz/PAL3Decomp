#!/bin/bash
# Stop hook: 阻止 LLM 过早停止，强制持续工作
#
# 策略：LLM 想停下时，检查是否有充分理由。
# 只有以下情况允许停止：
#   1. 明确遇到不可恢复的错误（IDA 崩溃、编译环境损坏等）
#   2. 用户明确要求停止
#   3. 已完成明确的用户指定任务（非自主决定"够了"）
#
# 其他情况一律强制继续 — 反编译是长程任务，LLM 不应自行决定何时收工。

input=$(cat)
turn=$(echo "$input" | python3 -c "import sys,json; print(json.load(sys.stdin).get('turn',0))" 2>/dev/null || echo 0)
last_msg=$(echo "$input" | python3 -c "import sys,json; print(json.load(sys.stdin).get('last_assistant_message','')[:500])" 2>/dev/null || echo "")

# 检查是否有明确的终止信号
has_fatal_error=false
case "$last_msg" in
    *"IDA 崩溃"*|*"无法启动"*|*"编译环境"*|*"permission denied"*|*"disk full"*)
        has_fatal_error=true
        ;;
esac

# 检查是否是用户主动要求停止的回应
case "$last_msg" in
    *"根据你的要求"*|*"按照你的指示停止"*|*"用户要求停止"*)
        exit 0
        ;;
esac

# 致命错误允许停止
if [ "$has_fatal_error" = true ]; then
    exit 0
fi

# 其他情况：强制继续
# 根据轮次给出不同的引导
if [ "$turn" -le 3 ]; then
    reason="你刚开始工作（第 ${turn} 轮），还有大量函数等待标注。请继续：\n1. 检查 annotations 当前状态\n2. 从 decomp 数据中选择下一个目标函数\n3. 分析并更新 annotations"
elif [ "$turn" -le 10 ]; then
    reason="你已经工作了 ${turn} 轮，但反编译是长程任务，不应自行决定停止。请继续：\n1. 运行 check_annotations.py 确认当前状态\n2. 选择下一个目标函数继续标注\n3. 如果当前类的函数已处理完，切换到下一个类"
else
    reason="你已经工作了 ${turn} 轮。如果遇到困难，请明确说明问题而不是停止。继续选择下一个目标函数进行标注。使用 data_write 更新迭代日志记录进展。"
fi

cat <<EOF
{"reason": "${reason}"}
EOF
exit 2
