#!/bin/bash
# PreToolUse gate: 写入 annotations 前必须通过验证
# exit 0 = 允许, exit 2 = 阻止

cd "${CLAUDE_PROJECT_ROOT:-/home/peng/workspace/PAL3Decomp}" || exit 2

# 运行验证脚本
output=$(python3 pipeline/check_annotations.py 2>&1)
code=$?

if [ $code -ne 0 ]; then
    # 验证失败 → 阻止写入
    cat <<EOF
{"reason": "Annotations 验证失败，禁止写入。请先修复以下问题：\n\n${output}\n\n运行 \`cd ${CLAUDE_PROJECT_ROOT} && python3 pipeline/check_annotations.py\` 查看详情。"}
EOF
    exit 2
fi

# 验证通过 → 允许
exit 0
