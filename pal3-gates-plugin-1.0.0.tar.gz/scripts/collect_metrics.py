#!/usr/bin/env python3
"""PAL3Decomp 进度面板 — 标注进度、编译进度、binary match 进度。"""
import json
import os
import subprocess
import sys

PROJECT = os.environ.get("CLAUDE_PROJECT_ROOT", "/home/peng/workspace/PAL3Decomp")
ANN_DIR = os.path.join(PROJECT, "pipeline/data/annotations")


def bar(current, total, width=20):
    if total <= 0:
        return "`[" + "." * width + "]`"
    filled = min(int(current / total * width), width)
    return "`[" + "#" * filled + "." * (width - filled) + "]`"


# ── 标注进度 ──

def collect_annotation():
    m = {}
    try:
        funcs = json.load(open(os.path.join(ANN_DIR, "functions.json")))
        named = sum(1 for f in funcs.values()
                    if f.get("name", "").strip()
                    and not f["name"].startswith("sub_")
                    and not f["name"].startswith("nullsub_"))
        m["func_total"] = len(funcs)
        m["func_named"] = named
    except Exception:
        m["func_total"] = m["func_named"] = 0

    struct_dir = os.path.join(ANN_DIR, "structs")
    total_members = verified = struct_count = 0
    try:
        for f in os.listdir(struct_dir):
            if not f.endswith(".json"):
                continue
            struct_count += 1
            s = json.load(open(os.path.join(struct_dir, f)))
            for mb in s.get("known_members", {}).values():
                total_members += 1
                src = mb.get("source", "")
                if "pdb" in src or "binary" in src:
                    verified += 1
    except Exception:
        pass
    m["struct_count"] = struct_count
    m["member_total"] = total_members
    m["member_verified"] = verified

    try:
        manifest = json.load(open(os.path.join(ANN_DIR, "manifest.json")))
        m["skip"] = manifest.get("stats", {}).get("skip_functions", 0)
    except Exception:
        m["skip"] = 0

    return m


# ── 编译进度 ──

def collect_compile():
    """用 cmake --build 编译，统计错误数。"""
    m = {"total_files": 0, "errors": 0, "error_files": []}
    build_dir = os.path.join(PROJECT, "build/pal3")
    if not os.path.isdir(build_dir):
        return m

    try:
        result = subprocess.run(
            ["cmake", "--build", build_dir],
            capture_output=True, text=True, timeout=180, cwd=PROJECT,
        )
        output = result.stdout + result.stderr
        # 统计 error C 开头的行
        error_lines = [l.strip() for l in output.split("\n") if ": error C" in l]
        m["errors"] = len(error_lines)
        # 提取失败文件名
        seen = set()
        for line in error_lines:
            # 格式: Z:\path\file.cpp(123) : error C...
            if "(" in line:
                fname = line.split("(")[0].split("\\")[-1]
                if fname not in seen:
                    seen.add(fname)
                    m["error_files"].append(fname)

        # 统计总 cpp 文件数
        src_dir = os.path.join(PROJECT, "src/pal3")
        if os.path.isdir(src_dir):
            m["total_files"] = sum(1 for r, _, fs in os.walk(src_dir)
                                   for f in fs if f.endswith(".cpp"))
        m["passed"] = m["total_files"] - len(m["error_files"])
    except Exception as e:
        m["compile_err"] = str(e)

    return m


# ── Binary Match 进度 ──

def collect_match():
    """从 gbengine_progress.json 读取（如有）+ 扫描 build/*.obj 对比。"""
    m = {"done": 0, "target": 0, "done_bytes": 0, "target_bytes": 0, "todo": 0, "unknown": 0}

    # 优先读已有进度文件
    progress_file = os.path.join(PROJECT, "build/gbengine_progress.json")
    if os.path.exists(progress_file):
        try:
            p = json.load(open(progress_file))
            m["done"] = p.get("done", 0)
            m["target"] = p.get("target_functions", 0)
            m["done_bytes"] = p.get("done_bytes", 0)
            m["target_bytes"] = p.get("target_bytes", 0)
            m["todo"] = p.get("todo", 0)
            m["unknown"] = p.get("unknown", 0)
        except Exception:
            pass

    return m


# ── 面板格式化 ──

def format_dashboard(ann, comp, match):
    func_pct = round(ann["func_named"] / max(ann["func_total"], 1) * 100, 1)
    member_pct = round(ann["member_verified"] / max(ann["member_total"], 1) * 100, 1)

    compile_section = ""
    if comp["total_files"] > 0:
        cpassed = comp.get("passed", 0)
        compile_section = f"""{bar(cpassed, comp['total_files'])} **{cpassed}/{comp['total_files']}** 通过 | **{comp['errors']} errors**"""
        if comp["error_files"]:
            compile_section += "\n" + "\n".join(f"  - {f}" for f in comp["error_files"][:8])
    else:
        compile_section = "未执行编译"

    match_section = ""
    if match["target"] > 0:
        done_pct = round(match["done"] / max(match["target"], 1) * 100, 1)
        byte_pct = round(match["done_bytes"] / max(match["target_bytes"], 1) * 100, 1)
        match_section = f"""{bar(match['done'], match['target'])} **{done_pct}%** 函数完成 ({match['done']}/{match['target']})
字节匹配: {bar(match['done_bytes'], match['target_bytes'])} **{byte_pct}%** ({match['done_bytes']}/{match['target_bytes']} bytes)
待处理: {match['todo']} todo | {match['unknown']} unknown"""
    else:
        match_section = "无 match 数据"

    return f"""## 标注进度

### 函数命名
{bar(ann['func_named'], ann['func_total'])} **{func_pct}%** ({ann['func_named']}/{ann['func_total']})
跳过: {ann['skip']} | 未命名: {ann['func_total'] - ann['func_named']}

### 结构体成员验证
{bar(ann['member_verified'], ann['member_total'])} **{member_pct}%** ({ann['member_verified']}/{ann['member_total']})
结构体数: {ann['struct_count']}

---

## 编译进度

{compile_section}

---

## Binary Match 进度

{match_section}"""


if __name__ == "__main__":
    ann = collect_annotation()

    if "--fast" in sys.argv:
        comp = {"total_files": 0, "errors": 0, "error_files": [], "passed": 0}
        match = {"done": 0, "target": 0, "done_bytes": 0, "target_bytes": 0, "todo": 0, "unknown": 0}
    else:
        comp = collect_compile()
        match = collect_match()

    if "--dashboard" in sys.argv or "--fast" in sys.argv:
        print(format_dashboard(ann, comp, match))
    else:
        json.dump({"annotation": ann, "compile": comp, "match": match}, sys.stdout, indent=2)
