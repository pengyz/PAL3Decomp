#!/bin/bash
# PostToolUse: annotations 写入后立即检查质量
# 不阻止（已经写了），但注入警告让 LLM 立即修复
#
# 检查项：
# 1. JSON 语法是否有效
# 2. 新增成员是否有 source 字段
# 3. 是否存在类型降级（void*, int 替换具体类型）

input=$(cat)
file_path=$(echo "$input" | python3 -c "
import sys, json
d = json.load(sys.stdin)
print(d.get('tool_input', {}).get('file_path', d.get('tool_input', {}).get('path', '')))
" 2>/dev/null)

[ -z "$file_path" ] && exit 0

cd "${CLAUDE_PROJECT_ROOT:-/home/peng/workspace/PAL3Decomp}" || exit 0

# 运行验证
output=$(python3 pipeline/check_annotations.py 2>&1)
code=$?

if [ $code -ne 0 ]; then
    # 写入后验证失败 — 注入附加上下文要求立即修复
    cat <<EOF
{"additional_context": "\n\n⚠️ [pal3-gates] annotations 验证失败！你刚写入的内容有错误，必须立即修复：\n${output}\n\n请立即修正上述问题。"}
EOF
fi

# 标记 dirty（写一个临时文件，Stop hook 检查用）
touch /tmp/pal3_annotations_dirty_$$

exit 0
