#!/bin/bash
# Notification hook (interval=10): 每 10 轮执行完整管线验证 + 进度收集
#
# 流程：
# 1. 收集全维度进度指标
# 2. check_annotations.py 验证
# 3. IDA apply + export (if available)
# 4. gen_cpp 生成代码
# 5. 编译验证
# 6. 写入里程碑日志
# 7. 输出 system-reminder 含进度面板 + 管线状态 + 操作记录

input=$(cat)
turn=$(echo "$input" | python3 -c "import sys,json; print(json.load(sys.stdin).get('turn',0))" 2>/dev/null || echo 0)

PROJECT="${CLAUDE_PROJECT_ROOT:-/home/peng/workspace/PAL3Decomp}"
PLUGIN="${CLAUDE_PLUGIN_ROOT:-$(dirname "$0")/..}"
LOG="$PROJECT/.project/pipeline_milestones.log"
TS=$(date '+%Y-%m-%d %H:%M:%S')

report=""
has_error=false

# ── 1. 收集进度指标 ──
dashboard=$(cd "$PROJECT" && python3 "$PLUGIN/scripts/collect_metrics.py" --dashboard 2>/dev/null || echo "指标收集失败")
metrics_json=$(cd "$PROJECT" && python3 "$PLUGIN/scripts/collect_metrics.py" 2>/dev/null || echo "{}")

# ── 2. Annotations 验证 ──
ann_output=$(cd "$PROJECT" && python3 pipeline/check_annotations.py 2>&1)
ann_code=$?
if [ $ann_code -eq 0 ]; then
    report="${report}Annotations 验证通过\n"
else
    report="${report}Annotations 验证失败:\n${ann_output}\n"
    has_error=true
fi

# ── 3. IDA apply + export ──
IDA="${IDA_PATH:-/opt/ida/idat64}"
if [ -x "$IDA" ] && [ -f "$PROJECT/original/PAL3.exe.i64" ]; then
    ida_out=$(cd "$PROJECT" && "$IDA" -A -S"pipeline/ida/apply_annotations.py" "original/PAL3.exe.i64" 2>&1)
    if [ $? -eq 0 ]; then
        report="${report}IDA apply_annotations 完成\n"
        export_out=$(cd "$PROJECT" && "$IDA" -A -S"pipeline/ida/export_full.py" "original/PAL3.exe.i64" 2>&1)
        [ $? -eq 0 ] && report="${report}IDA export 完成\n" || report="${report}IDA export 失败（非致命）\n"
    else
        report="${report}IDA apply 失败（非致命）\n"
    fi
else
    report="${report}IDA 不可用，跳过\n"
fi

# ── 4. gen_cpp ──
gen_out=$(cd "$PROJECT" && python3 pipeline/gen/gen_headers.py 2>&1 && python3 pipeline/gen/gen_cpp.py 2>&1)
if [ $? -eq 0 ]; then
    report="${report}gen_cpp 完成\n"
else
    report="${report}gen_cpp 失败:\n$(echo "$gen_out" | tail -3)\n"
    has_error=true
fi

# ── 5. 编译 ──
if [ -f "$PROJECT/Makefile" ] || [ -f "$PROJECT/build.sh" ]; then
    build_out=$(cd "$PROJECT" && make 2>&1 || bash build.sh 2>&1)
    if [ $? -eq 0 ]; then
        report="${report}编译通过\n"
    else
        error_count=$(echo "$build_out" | grep -c "error")
        report="${report}编译失败 (${error_count} errors)\n"
        has_error=true
    fi
else
    report="${report}无 build 脚本，跳过编译\n"
fi

# ── 6. 里程碑日志 ──
status="PASS"
[ "$has_error" = true ] && status="FAIL"
func_named=$(echo "$metrics_json" | python3 -c "import sys,json; print(json.load(sys.stdin).get('functions_named','?'))" 2>/dev/null || echo "?")
func_total=$(echo "$metrics_json" | python3 -c "import sys,json; print(json.load(sys.stdin).get('functions_total','?'))" 2>/dev/null || echo "?")
struct_verified=$(echo "$metrics_json" | python3 -c "import sys,json; print(json.load(sys.stdin).get('struct_members_verified','?'))" 2>/dev/null || echo "?")
echo "[$TS] Turn ${turn} | ${status} | funcs=${func_named}/${func_total} struct_members_verified=${struct_verified}" >> "$LOG"

# ── 7. 审计日志摘要（最近 20 条）──
audit_tail=""
if [ -f "$PROJECT/.project/audit.log" ]; then
    audit_tail=$(tail -20 "$PROJECT/.project/audit.log" | sed 's/$/\\n/g' | tr -d '\n')
fi

# ── 8. 输出 ──
# 用 Python 生成合法 JSON（避免 shell 转义问题）
python3 -c "
import json, sys

dashboard = '''$dashboard'''
report = '''$report'''
audit = '''$audit_tail'''
turn = $turn
has_error = $( [ \"$has_error\" = true ] && echo True || echo False )

status_icon = 'FAIL' if has_error else 'PASS'

content = f'''## 管线检查点（第 {turn} 轮）— {status_icon}

### 管线验证
{report}
### 指令

你必须立即执行以下 data_write 操作：

1. \`data_write(slot=\"progress_dashboard\", value=\"...\")\` — 写入下方进度数据
2. \`data_write(slot=\"pipeline_status\", value=\"...\")\` — 写入管线验证结果
3. \`data_write(slot=\"iteration_log\", value=\"...\")\` — 追加本轮摘要
4. \`data_write(slot=\"audit_trail\", value=\"...\")\` — 写入最近操作记录

### 进度数据（写入 progress_dashboard）
{dashboard}

### 最近操作记录（写入 audit_trail）
\`\`\`
{audit}
\`\`\`
'''

print(json.dumps({'content': content}))
" 2>/dev/null || cat <<EOF
{"content": "管线检查点（第 ${turn} 轮）执行完毕。请用 data_write 更新所有面板。"}
EOF

exit 0
