#!/bin/bash
# Notification hook: 每 3 轮提醒关键约束 + 面板更新
cat <<'EOF'
{"content": "## 质量门禁提醒\n\n1. **结构体偏移必须有二进制证据** — 禁止从 Hex-Rays 反编译文本推断偏移\n2. **修改 annotations 前必须运行** `python3 pipeline/check_annotations.py`\n3. **不降级已有信息** — 不把已知类型改为 void*/int\n4. **commit 前再次验证** annotations 一致性\n\n**面板更新**：用 `data_write` 将当前工作进展写入 `iteration_log`（函数名、修改内容、验证结果）。用 `data_write` 将管线当前状态写入 `pipeline_status`。"}
EOF
exit 0
