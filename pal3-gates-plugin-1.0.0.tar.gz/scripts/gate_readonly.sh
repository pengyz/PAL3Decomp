#!/bin/bash
# PreToolUse gate: 保护管线脚本不被 LLM 修改
# 只允许修改 annotations 和 docs，其余 pipeline/ 下文件只读

input=$(cat)
file_path=$(echo "$input" | python3 -c "
import sys, json
d = json.load(sys.stdin)
ti = d.get('tool_input', {})
print(ti.get('file_path', ti.get('path', '')))
" 2>/dev/null)

# 如果不是文件操作，放行
[ -z "$file_path" ] && exit 0

# 允许写入的路径白名单
case "$file_path" in
    */pipeline/data/annotations/*) exit 0 ;;
    */docs/*) exit 0 ;;
    */.project/*) exit 0 ;;
esac

# 阻止写入管线脚本
case "$file_path" in
    */pipeline/*.py|*/pipeline/ida/*.py|*/pipeline/gen/*.py|*/pipeline/hooks/*)
        cat <<EOF
{"reason": "禁止修改管线脚本 ${file_path}。反编译迭代中只允许修改 annotations 数据，不允许修改 pipeline 代码。如果确实需要修改脚本，请先告知用户获得确认。"}
EOF
        exit 2
        ;;
esac

exit 0
