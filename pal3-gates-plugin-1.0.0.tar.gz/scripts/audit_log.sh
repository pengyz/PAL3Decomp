#!/bin/bash
# PostToolUse: 每次工具调用后记录审计日志
# 追加到 .project/audit.log，格式：时间 | 轮次 | 工具 | 成功/失败 | 摘要

input=$(cat)
eval "$(echo "$input" | python3 -c "
import sys, json
d = json.load(sys.stdin)
print(f'TOOL={json.dumps(d.get(\"tool_name\",\"\"))}')
print(f'SUCCESS={json.dumps(d.get(\"tool_success\",True))}')
ti = d.get('tool_input', {})
# 摘要：文件路径或命令前80字符
path = ti.get('file_path', ti.get('path', ''))
cmd = ti.get('command', ti.get('cmd', ''))
summary = path or cmd[:80] or json.dumps(ti)[:80]
print(f'SUMMARY={json.dumps(summary)}')
" 2>/dev/null)"

PROJECT="${CLAUDE_PROJECT_ROOT:-/home/peng/workspace/PAL3Decomp}"
LOG="$PROJECT/.project/audit.log"
TS=$(date '+%Y-%m-%d %H:%M:%S')
STATUS="OK"
[ "$SUCCESS" = '"false"' ] && STATUS="FAIL"

# 去掉 JSON 引号
TOOL=$(echo "$TOOL" | tr -d '"')
SUMMARY=$(echo "$SUMMARY" | tr -d '"')

echo "${TS} | ${TOOL} | ${STATUS} | ${SUMMARY}" >> "$LOG"
exit 0
