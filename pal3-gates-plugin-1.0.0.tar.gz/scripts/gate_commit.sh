#!/bin/bash
# PreToolUse gate: git commit 前验证 annotations + 检查 commit message 格式
# exit 0 = 允许, exit 2 = 阻止

cd "${CLAUDE_PROJECT_ROOT:-/home/peng/workspace/PAL3Decomp}" || exit 2

# 检查是否有 annotations 文件在暂存区
staged_annotations=$(git diff --cached --name-only -- pipeline/data/annotations/ 2>/dev/null)

if [ -n "$staged_annotations" ]; then
    # 有 annotations 修改 → 运行验证
    output=$(python3 pipeline/check_annotations.py 2>&1)
    code=$?
    if [ $code -ne 0 ]; then
        cat <<EOF
{"reason": "Git commit 被阻止：annotations 验证失败。\n\n${output}\n\n请先修复 annotations 错误再提交。"}
EOF
        exit 2
    fi
fi

# 允许提交
exit 0
